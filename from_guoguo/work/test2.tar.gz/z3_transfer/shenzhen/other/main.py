# coding:utf-8
# Created by qinlin.liu at 2017/3/14
import pymongo
import datetime
import copy
from utils.mysqlutil import Mysql
from utils import tools
from config import config
from convert_config import config as table_prkey_config
from common import  pre_date, get_mysql
from data_source_copy import DataSourceCopy
import time
import threadpool


def factor_onecode(c, database, table_name, args, curr_time, update_type):
    print c
    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    m = "make_%s_data" % table_name
    method = getattr(ds, m)
    if update_type == 'timing':
        data = method(c, True)
    else:
        data = method(c)
    # 格式化mysql数据

    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, data, table_info)
    mysql.close()

def main_other_news(args):
    pass

def main_factor(args):
    """
    复权因子表处理
    :param args:
    :return:
    """
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    update_type = args[2] if len(args) > 2 else ''

    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    innercode_list = ds.get_INNER_CODE_list()
    print len(innercode_list)
    mysql.close()
    # innercode_list = [
    # {"INNER_CODE": 101000001},
    # {"INNER_CODE": 101000005}, {"INNER_CODE": 101002348}]
    #innercode_list = [{'INNER_CODE': 101000003}, {'INNER_CODE': 101000005}, {'INNER_CODE': 101000015},
    #                  {'INNER_CODE': 101000443}, {'INNER_CODE': 101001725}, {'INNER_CODE': 101000001},
    #                  {'INNER_CODE': 101002348}, {'INNER_CODE': 101000592}, {'INNER_CODE': 101000600},
    #                  {'INNER_CODE': 101000602}]

    args_list = []
    for c in innercode_list:
        # for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time,
            'update_type': update_type
        }))
    pool = threadpool.ThreadPool(25)
    requests = threadpool.makeRequests(factor_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()

    # return

    # update_task(ds, curr_time, database, table_name)


def equity_onecode(c, database, table_name, args, curr_time):
    print c
    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    m = "make_%s_data" % table_name
    method = getattr(ds, m)
    data = method([c, ])
    # 格式化mysql数据

    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, 'Z3_EQUITY', data, table_info)


def main_equity(args):
    """
    日级信号指标处理
    :param args:
    :return:
    """
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    if args[2]:
        curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    stock_list = ds.get_STOCKINFO_list_on()

    # print stock_list\
    # start = int(args[1])
    # end = start + 100
    args_list = []
    for c in stock_list:
        # for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time
        }))
    pool = threadpool.ThreadPool(20)
    requests = threadpool.makeRequests(equity_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()


# update_task(ds, curr_time, database, table_name)


def equity_history_onecode(c, database, table_name, args, curr_time, m):
    print c

    print "start:{},time:{}!".format(c["symbol"],datetime.datetime.now())

    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    method = getattr(ds, m)

    tradedate_list = ds.get_TRADEDATE_list(c)
    print len(tradedate_list)
    for d in tradedate_list:
        print d

        #d = {"TRADEDATE": d["trade_date"]}

        # print ddo_method2(method, i, d, args, database)
        do_method2(method, c, d, args, database)

    print "finish:{},time:{}!".format(c["symbol"],datetime.datetime.now())


def equity_history_onecode_bak(c, database, table_name, args, curr_time, m):
    print c
    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    method = getattr(ds, m)
    # tradedate_list = ds.get_TRADEDATE_list(c["INNER_CODE"])
    tradedate_list = ds.get_history_day_no_equity(c)
    print len(tradedate_list)
    for d in tradedate_list:
        # print d

        d = {"TRADEDATE": d["trade_date"]}
        # print ddo_method2(method, i, d, args, database)
        do_method2(method, c, d, args, database)


def main_equity_history_bak(args, m):
    """
    日级信号指标处理
    :param args:
    :return:
    """
    mysql = get_mysql()
    database, table_name = args[0].split(".")
    # m = "make_Z3_EQUITY2_data"

    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    if args[2]:
        curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    stock_list = ds.get_STOCKINFO_list_all()

    print len(stock_list)
    start = int(args[1])
    end = start + 100
    # print start,end
    args_list = []
    for c in stock_list[start:end]:
        # for c in innercode_list:
        args_dict = {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time,
            'm': m
        }
        equity_history_onecode(**args_dict)


        # update_task(ds, curr_time, database, table_name)


def main_equity_history(args, m):
    """
    日级信号指标处理
    :param args:
    :return:
    """
    mysql = get_mysql()
    database, table_name = args[0].split(".")
    # m = "make_Z3_EQUITY2_data"

    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    if args[2]:
        curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    stock_list = ds.get_STOCKINFO_list()

    # print stock_list\
    start = int(args[1])
    end = start + 100
    # print start,end
    args_list = []
    for c in stock_list:
        # for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time,
            'm': m
        }))
    pool = threadpool.ThreadPool(20)
    requests = threadpool.makeRequests(equity_history_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()


    # update_task(ds, curr_time, database, table_name)


def do_method2(method, i, d, args, database):
    data = method([i, ], d["TRADEDATE"])
    # 格式化mysql数据

    # 添加，更新，删除数据到mongo
    # print table_prkey_config.keys()
    table_info = table_prkey_config['Z3_EQUITY_HISTORY']

    upsert_mongo_data(args, database, 'Z3_EQUITY_HISTORY', data, table_info)
    try:
        data = method([i, ], d["TRADEDATE"])
        # 格式化mysql数据

        # 添加，更新，删除数据到mongo
        # print table_prkey_config.keys()
        table_info = table_prkey_config['Z3_EQUITY_HISTORY']

        upsert_mongo_data(args, database, 'Z3_EQUITY_HISTORY', data, table_info)
    except Exception, e:
        do_method2(method, i, d, args, database)

def xref_news_onecode(c, database, table_name, args, curr_time):
    m = "make_%s_data2" % table_name
    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    method = getattr(ds, m)

    data = method(c)

    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, data, table_info)


def main_xref_news(args):
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m_ids = "make_%s_ids" % table_name
    m = "make_%s_data" % table_name
    m2 = "make_%s_data2" % table_name

    #m = "make_Z3_STK_MKT_DAY_INTER_data_pre_factor"
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    n1 = datetime.datetime.now()

    # 删除无效数据
    ds.delete_Z3_EQUITY_XREF_NEWS_data()

    print "delete done"

    comcode_list = ds.get_STK_CODE_comcodes()  # 可以考虑函数缓存

    print "comcode_list", len(comcode_list)

    args_list = []
    # 新闻关系
    method_ids = getattr(ds, m_ids)
    method = getattr(ds, m)
    offset = 0
    result_size, maxsize = 100, 100
    while result_size == 100:
        data = method_ids(offset, maxsize)
        print "%s--%s" % (offset, maxsize)
        result_size = len(data)
        print "get ids ", result_size
        #if not result_size:break
        data = method(data)
        print "get data ", len(data)
        offset += maxsize
        # 格式化mysql数据
        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)

    # 公告关系
    for c in comcode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time
        }))

    pool = threadpool.ThreadPool(10)
    requests = threadpool.makeRequests(xref_news_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()
    update_task(ds, curr_time, database, table_name)

def main_xref_news_bak(args):
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m_ids = "make_%s_ids" % table_name
    m = "make_%s_data" % table_name
    m2 = "make_%s_data2" % table_name

    #m = "make_Z3_STK_MKT_DAY_INTER_data_pre_factor"
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    n1 = datetime.datetime.now()
    comcode_list = ds.get_STK_CODE_comcodes()  # 可以考虑函数缓存

    args_list = []
    # 新闻关系
    method_ids = getattr(ds, m_ids)
    method = getattr(ds, m)
    offset = 0
    result_size, maxsize = 100, 100
    while True:
        data = method_ids(offset, maxsize)
        print "%s--%s" % (offset, maxsize)
        result_size = len(data)
        if not result_size:break
        data = method(data)
        print result_size
        print len(data)
        offset += maxsize
        # 格式化mysql数据
        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)

    # 公告关系
    for c in comcode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time
        }))

    pool = threadpool.ThreadPool(10)
    requests = threadpool.makeRequests(xref_news_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()
    update_task(ds, curr_time, database, table_name)





def holder_onecode(c, database, table_name, args, curr_time):
    print c
    m = "make_%s_data" % table_name
    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    method = getattr(ds, m)

    data = method(c)

    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, data, table_info)


def main_holder(args):
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    # m = "make_Z3_STK_MKT_DAY_INTER_data_pre_factor"
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    n1 = datetime.datetime.now()
    comcode_list = ds.get_Z3_MNG_HOLD_STK_INFO_comcodes()  # 可以考虑函数缓存
    mysql.close()
    args_list = []
    for c in comcode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time
        }))

    pool = threadpool.ThreadPool(10)
    requests = threadpool.makeRequests(holder_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()

def update_task(ds, curr_time, database, table_name):
    # 更新任务信息
    # return
    update_dict = {

        "LASTRUNTIME": curr_time,
        "NEXTRUNTIME": get_last_update_time(curr_time, ds.task_info),
        "UPDATETIME": getnow().strftime("%Y-%m-%d %H:%M:%S"),
        "SDATABASE": ds.task_info.get("SDATABASE", ""),
        "STABLE": ds.task_info.get("STABLE", ""),
        "TDATABASE": ds.task_info.get("TDATABASE", database),
        "TTABLE": ds.task_info.get("TTABLE", table_name),
        "FREQUENCY": ds.task_info.get("FREQUENCY", "D"),
        "SPACE": ds.task_info.get("SPACE", 1),
    }
    print update_dict.values()
    sql = """
        INSERT INTO pgznty.z3_update_task(%(keys)s) VALUES (%(values)s)
        ON DUPLICATE KEY UPDATE %(kwargs)s;
    """ % ({
        "keys": ",".join(update_dict.keys()),
        "values": ",".join([("'%s'" % v) if k != "NEXTRUNTIME" else ("%s" % v) for k, v in update_dict.items()]),
        "kwargs": " , ".join(
            [("%s='%s'" % (k, v)) if k != "NEXTRUNTIME" else("%s=%s" % (k, v)) for k, v in update_dict.items()])
    })
    print sql
    ds.update_taks(sql)

def day_inter_onecode_new(c, database, table_name, args, curr_time):
    print c
    print "start:{},time:{}!".format(c["symbol"],datetime.datetime.now())

    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    m = "make_%s_data" % table_name
    method = getattr(ds, m)
    tradedate_list = ds.get_TRADEDATE_list(c, 279)
    for d in tradedate_list:
        print d
        do_method_old(method, d, c, table_name, args, database, '')

    mysql.close()
    print "finish:{},time:{}!".format(c["symbol"],datetime.datetime.now())

def day_inter_onecode(c, database, table_name, args, curr_time):
    print c
    print "start:{},time:{}!".format(c["symbol"],datetime.datetime.now())

    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    #m = "make_%s_data" % table_name
    m = "make_Z3_STK_MKT_DAY_INTER_data_pre_factor"
    method = getattr(ds, m)
    tradedate_list = ds.get_TRADEDATE_listp(c, 0)
    for d in tradedate_list:
        print d
        n3 = datetime.datetime.now()

        c_info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
        #print "do_method_odl"
        #do_method_old(method, d, c, table_name, args, database, '')
        do_methodm(method, d, c_info, d, c, True, table_name, args, database, '')

    mysql.close()
    print "finish:{},time:{}!".format(c["symbol"],datetime.datetime.now())


def main_day_inter_new(args):
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    n1 = datetime.datetime.now()
    innercode_list = ds.get_STOCKINFO_list()  # 可以考虑函数缓存
    mysql.close()

    args_list = []
    for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time
        }))

    pool = threadpool.ThreadPool(10)
    requests = threadpool.makeRequests(day_inter_onecode_new, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()

def main_day_inter(args):
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    n1 = datetime.datetime.now()
    innercode_list = ds.get_STOCKINFO_list()  # 可以考虑函数缓存
    mysql.close()
    print len(innercode_list)
    start = int(args[1])
    end = start + 100
    print start, end
    print innercode_list[0]
    # method = getattr(ds, m)
    #
    args_list = []
    for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time
        }))
    pool = threadpool.ThreadPool(10)
    requests = threadpool.makeRequests(day_inter_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()


def day_inter_timing_onecode_pre_new(c, database, table_name, todays, args, curr_time):

    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    m = "make_%s_data" % table_name
    no_factor = "make_%s_data_no_factor" % table_name
    pre_factor = "make_%s_data_pre_factor" % table_name

    no_factor = getattr(ds, no_factor)
    pre_factor = getattr(ds, pre_factor)

    print c
    for today in todays:
        print today
        # 判断是否退市
        if ds.is_tradeon(c,today):
            print "退市"
            continue
        # 判断是开盘前还是开盘后
        de = 1 if datetime.datetime.now().hour <15 else 0

        tradedate_list = ds.get_tradedate_day_list(c["INNER_CODE"],today["TRADEDATE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        #DATE_MAX = tradedate_list[0]["TRADEDATE"]
        DATE_MAX = today["TRADEDATE"]
        #判断股票是否停牌，判断今天是否开盘

        factor_tody = ds.get_factor_day(c["symbol"], DATE_MAX)
        # 添加今天不复权的数据
        c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        if not (de and today == pre_date()):
            do_method(no_factor, c_info, today, c, True, table_name, args, database, '')
        if factor_tody != 1:
            print '=================================================='
            print "*****需要重新算复权的股票",c,factor_tody,today
            print "--------------------------------------------------"

            # 如果今天的复权因子变化，更新所有日期的前复权数据2次，
            trades = ds.get_TRADEDATE_listp(c)
            print "@@@@@@@@@@@@@@@@@@%s@@@@@@@@@@@@@@" % len(trades)
            for k,d in enumerate(trades):

                print d
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(pre_factor, today,info, d, c, False, table_name, args, database, '')
        else:
            print "不需要重新算复权的股票",c,factor_tody,today

            # 否则，更新今天的前复权

            #print "iiiiiiiiiiiiiiiiiiiii",c_info
            if c_info:

                do_methodm(pre_factor,today, c_info, today, c, False, table_name, args, database, '')

    print "finish:[{}]--pre".format(c["symbol"])

    mysql.close()

def day_inter_timing_onecode_pre_bak(c, database, table_name, todays, args, curr_time):

    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    # 开盘前,判断上个交易日是不是股票开盘日
    m = "make_%s_data" % table_name
    no_factor = "make_%s_data_no_factor" % table_name
    pre_factor = "make_%s_data_pre_factor" % table_name

    no_factor = getattr(ds, no_factor)
    pre_factor = getattr(ds, pre_factor)

    print c
    for today in todays:
        print today
        # 判断是否退市
        if ds.is_tradeon(c,today):
            print "退市"
            continue
        # 判断是开盘前还是开盘后
        de = 1 if datetime.datetime.now().hour <15 else 0

        tradedate_list = ds.get_tradedate_day_list(c["INNER_CODE"],today["TRADEDATE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        #DATE_MAX = tradedate_list[0]["TRADEDATE"]
        DATE_MAX = today["TRADEDATE"]
        #判断股票是否停牌，判断今天是否开盘

        factor_tody = ds.get_factor_day(c["symbol"], DATE_MAX)
        # 添加今天不复权的数据
        c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        if not (de and today == pre_date()):
            do_method(no_factor, c_info, today, c, True, table_name, args, database, '')
        if factor_tody != 1:
            print "*****需要重新算复权的股票",c,factor_tody,today

            # 如果今天的复权因子变化，更新所有日期的前复权数据2次，
            trades = ds.get_TRADEDATE_listp(c)
            for k,d in enumerate(trades):

                print d
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(pre_factor, today,info, d, c, True, table_name, args, database, '')
        else:
            print "不需要重新算复权的股票",c,factor_tody,today

            # 否则，更新今天的前复权

            if c_info:

                do_methodm(pre_factor,today, c_info, today, c, True, table_name, args, database, '')

    print "finish:[{}]--pre".format(c["symbol"])

    mysql.close()

def day_inter_timing_onecode_after_bak(c, database, table_name, todays, args, curr_time):


    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    m = "make_%s_data" % table_name
    no_factor = "make_%s_data_no_factor" % table_name

    after_60_factor = "make_%s_data_after_60_factor" % table_name
    after_160_factor = "make_%s_data_after_160_factor" % table_name

    no_factor = getattr(ds, no_factor)

    after_60_factor = getattr(ds, after_60_factor)
    after_160_factor = getattr(ds, after_160_factor)
    print c
    for today in todays:
        print today
        # 判断是否退市
        if ds.is_tradeon(c,today):
            print "退市"
            continue


        # 判断是否退市
        #if not ds.is_tradeon(c,today):
        #    print "退市"
        #    continue
        # 判断是开盘前还是开盘后
        de = 1 if datetime.datetime.now().hour <15 else 0

        #c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        #print "iiiiiiiiiiiiiiiiiiiii",c_info
        #if not c_info: continue
        tradedate_list = ds.get_tradedate_day_list(c["INNER_CODE"],today["TRADEDATE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        #DATE_MAX = tradedate_list[0]["TRADEDATE"]

        #判断股票是否停牌，判断今天是否开盘
        DATE_MIN_60 = tradedate_list[:(179-de)][-1]["TRADEDATE"]
        DATE_MIN_160 = tradedate_list[:(279-de)][-1]["TRADEDATE"]


        factor_60 = ds.get_factor_day(c["symbol"], DATE_MIN_60)
        factor_160 = ds.get_factor_day(c["symbol"], DATE_MIN_160)
        # 添加今天不复权的数据

        c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        if not (de and today == pre_date()):
            do_method(no_factor, c_info, today, c, True, table_name, args, database, '')

        if factor_60 != 1:
            print "后后【{}】【{}】".format(c["symbol"],today)
            trades = tradedate_list[:(179 - de)][::-1]
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(after_60_factor,{"TRADEDATE":DATE_MIN_60}, info, d, c, True, table_name, args, database, '')

        else:
            print "不需复权的股票",c,factor_60,today
            # 否则，更新今天的前复权
            if c_info:
                do_methodm(after_60_factor,{"TRADEDATE":DATE_MIN_60},c_info, today, c, True, table_name, args, database, '')
        # 如果60或160的复权因子变化，更新历史前复权数据2次，

        if factor_160 != 1:
            print "后后【{}】【{}】".format(c["symbol"],today)
            trades = tradedate_list[:(279 - de)][::-1]
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(after_160_factor,{"TRADEDATE":DATE_MIN_160}, info, d, c, True, table_name, args, database, '')

        else:
            print "不需复权的股票",c,factor_160,today
            # 否则，更新今天的前复权
            if c_info:
                do_methodm(after_160_factor, {"TRADEDATE":DATE_MIN_160},c_info, today, c, True, table_name, args, database, '')
            # 如果60或160的复权因子变化，更新历史前复权数据2次，

    print "finish:[{}]--after".format(c["symbol"])

    mysql.close()

def day_inter_timing_onecode_after(c, database, table_name, todays, args, curr_time):


    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    m = "make_%s_data" % table_name
    no_factor = "make_%s_data_no_factor" % table_name
    pre_factor = "make_%s_data_pre_factor" % table_name
    after_60_factor = "make_%s_data_after_60_factor" % table_name
    after_160_factor = "make_%s_data_after_160_factor" % table_name

    no_factor = getattr(ds, no_factor)
    pre_factor = getattr(ds, pre_factor)
    after_60_factor = getattr(ds, after_60_factor)
    after_160_factor = getattr(ds, after_160_factor)
    for today in todays:
        # 判断上个交易日是否与上个开盘日一致
        print today
        # 判断是开盘前还是开盘后
        de = 1 if datetime.datetime.now().hour <15 else 0
        if ds.isLTDeqLOD(c,today,table_name) and ds.is_tradeon(c,today):
            print "临时休市，,{},{}".format(c,today)
            de -= 1
        elif ds.isReTrade(c,today):
            # 复盘
            pass
        else:
            continue
        # 判断是否退市
        if ds.is_tradeon(c,today):
            print "退市"
            continue
        # 判断是开盘前还是开盘后

        #c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        #if not c_info: continue
        tradedate_list = ds.get_tradedate_day_list(c["INNER_CODE"],today["TRADEDATE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        #DATE_MAX = tradedate_list[0]["TRADEDATE"]
        DATE_MAX = today["TRADEDATE"]
        #判断股票是否停牌，判断今天是否开盘
        DATE_MIN_60 = tradedate_list[:(179-de)][-1]["TRADEDATE"]
        DATE_MIN_160 = tradedate_list[:(279-de)][-1]["TRADEDATE"]

        factor_tody = ds.get_factor_day(c["symbol"], DATE_MAX)
        factor_60 = ds.get_factor_day(c["symbol"], DATE_MIN_60)
        factor_160 = ds.get_factor_day(c["symbol"], DATE_MIN_160)
        # 添加今天不复权的数据
        print "xxxxxxxxxxxxxxxxxxxxxxxx", factor_tody,factor_60,factor_160
        c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])

        do_method(no_factor, c_info, today, c, True, table_name, args, database, '')

        # 如果今天的复权因子变化，更新所有日期的前复权数据2次，
        trades = ds.get_TRADEDATE_listp(c)
        print "@@@@@@@@@@@@@@@@@@%s@@@@@@@@@@@@@@" % len(trades)
        for k,d in enumerate(trades):

            print d
            info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
            # 不算ma


            do_methodm(pre_factor, today,info, d, c, True, table_name, args, database, '')
            print "后后【{}】【{}】".format(c["symbol"],today)
        trades = tradedate_list[:(179 - de)][::-1]
            #trades = ds.get_TRADEDATE_list(c["INNER_CODE"], 0, DATE_MIN_60)
        for d in trades:
            info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
            # 不算ma
            do_methodm(after_60_factor,{"TRADEDATE":DATE_MIN_60}, info, d, c, True, table_name, args, database, '')

            print "后后【{}】【{}】".format(c["symbol"],today)
        trades = tradedate_list[:(279 - de)][::-1]
        for d in trades:
            info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
            # 不算ma
            do_methodm(after_160_factor,{"TRADEDATE":DATE_MIN_160}, info, d, c, True, table_name, args, database, '')


    print "finish:[{}]".format(c["symbol"])

    mysql.close()

def day_inter_timing_onecode_pre(c, database, table_name, todays, args, curr_time):


    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    m = "make_%s_data" % table_name
    no_factor = "make_%s_data_no_factor" % table_name
    pre_factor = "make_%s_data_pre_factor" % table_name
    after_60_factor = "make_%s_data_after_60_factor" % table_name
    after_160_factor = "make_%s_data_after_160_factor" % table_name

    no_factor = getattr(ds, no_factor)
    pre_factor = getattr(ds, pre_factor)
    after_60_factor = getattr(ds, after_60_factor)
    after_160_factor = getattr(ds, after_160_factor)
    for today in todays:
        # 判断上个交易日是否与上个开盘日一致
        print today
        if not ds.isLTDeqLOD(c,today,table_name):
            print "上一个开盘日未交易,{},{}".format(c,today)
            continue
        # 判断是否退市
        if ds.is_tradeon(c,today):
            print "退市"
            continue
        # 判断是开盘前还是开盘后
        de = 1 if datetime.datetime.now().hour <15 else 0

        #c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        #print "iiiiiiiiiiiiiiiiiiiii",c_info
        #if not c_info: continue
        tradedate_list = ds.get_tradedate_day_list(c["INNER_CODE"],today["TRADEDATE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        #DATE_MAX = tradedate_list[0]["TRADEDATE"]
        DATE_MAX = today["TRADEDATE"]
        #判断股票是否停牌，判断今天是否开盘
        DATE_MIN_60 = tradedate_list[:(179-de)][-1]["TRADEDATE"]
        DATE_MIN_160 = tradedate_list[:(279-de)][-1]["TRADEDATE"]

        factor_tody = ds.get_factor_day(c["symbol"], DATE_MAX)
        factor_60 = ds.get_factor_day(c["symbol"], DATE_MIN_60)
        factor_160 = ds.get_factor_day(c["symbol"], DATE_MIN_160)
        # 添加今天不复权的数据
        print "xxxxxxxxxxxxxxxxxxxxxxxx", factor_tody,factor_60,factor_160
        c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])

        do_method(no_factor, c_info, today, c, True, table_name, args, database, '')
        if factor_tody != 1:
            print '=================================================='
            print "*****需要重新算复权的股票",c,factor_tody,today
            print "--------------------------------------------------"

            # 如果今天的复权因子变化，更新所有日期的前复权数据2次，
            trades = ds.get_TRADEDATE_listp(c)
            print "@@@@@@@@@@@@@@@@@@%s@@@@@@@@@@@@@@" % len(trades)
            for k,d in enumerate(trades):

                print d
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma


                do_methodm(pre_factor, today,info, d, c, True, table_name, args, database, '')
            #for d in trades:
            #    info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
            #    # 不算ma
            #    do_method(no_factor, info, d, c, True, table_name, args, database, '')

        else:
            print "不需要重新算复权的股票",c,factor_tody,today

            # 否则，更新今天的前复权

            #print "iiiiiiiiiiiiiiiiiiiii",c_info
            if c_info:

                do_methodm(pre_factor,today, c_info, today, c, True, table_name, args, database, '')


        if factor_60 != 1:
            print "后后【{}】【{}】".format(c["symbol"],today)
            trades = tradedate_list[:(179 - de)][::-1]
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(after_60_factor,{"TRADEDATE":DATE_MIN_60}, info, d, c, True, table_name, args, database, '')

        else:
            print "不需复权的股票",c,factor_60,today
            # 否则，更新今天的前复权
            if c_info:
                do_methodm(after_60_factor,{"TRADEDATE":DATE_MIN_60},c_info, today, c, True, table_name, args, database, '')
        # 如果60或160的复权因子变化，更新历史前复权数据2次，

        if factor_160 != 1:
            print "后后【{}】【{}】".format(c["symbol"],today)
            trades = tradedate_list[:(279 - de)][::-1]
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(after_160_factor,{"TRADEDATE":DATE_MIN_160}, info, d, c, True, table_name, args, database, '')

        else:
            print "不需复权的股票",c,factor_160,today
            # 否则，更新今天的前复权
            if c_info:
                do_methodm(after_160_factor, {"TRADEDATE":DATE_MIN_160},c_info, today, c, True, table_name, args, database, '')
            # 如果60或160的复权因子变化，更新历史前复权数据2次，

    print "finish:[{}]".format(c["symbol"])

    mysql.close()

def day_inter_timing_onecode(c, database, table_name, todays, args, curr_time):


    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    m = "make_%s_data" % table_name
    no_factor = "make_%s_data_no_factor" % table_name
    pre_factor = "make_%s_data_pre_factor" % table_name
    after_60_factor = "make_%s_data_after_60_factor" % table_name
    after_160_factor = "make_%s_data_after_160_factor" % table_name

    no_factor = getattr(ds, no_factor)
    pre_factor = getattr(ds, pre_factor)
    after_60_factor = getattr(ds, after_60_factor)
    after_160_factor = getattr(ds, after_160_factor)
    print c
    for today in todays:
        print today
        # 判断是否退市
        if ds.is_tradeon(c,today):
            print "退市"
            continue
        # 判断是开盘前还是开盘后
        de = 1 if datetime.datetime.now().hour <15 else 0

        #c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        #print "iiiiiiiiiiiiiiiiiiiii",c_info
        #if not c_info: continue
        tradedate_list = ds.get_tradedate_day_list(c["INNER_CODE"],today["TRADEDATE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        #DATE_MAX = tradedate_list[0]["TRADEDATE"]
        DATE_MAX = today["TRADEDATE"]
        #判断股票是否停牌，判断今天是否开盘
        DATE_MIN_60 = tradedate_list[:(179-de)][-1]["TRADEDATE"]
        DATE_MIN_160 = tradedate_list[:(279-de)][-1]["TRADEDATE"]

        factor_tody = ds.get_factor_day(c["symbol"], DATE_MAX)
        factor_60 = ds.get_factor_day(c["symbol"], DATE_MIN_60)
        factor_160 = ds.get_factor_day(c["symbol"], DATE_MIN_160)
        # 添加今天不复权的数据
        print "xxxxxxxxxxxxxxxxxxxxxxxx", factor_tody,factor_60,factor_160
        c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])

        do_method(no_factor, c_info, today, c, True, table_name, args, database, '')
        if factor_tody != 1:
            print '=================================================='
            print "*****需要重新算复权的股票",c,factor_tody,today
            print "--------------------------------------------------"

            # 如果今天的复权因子变化，更新所有日期的前复权数据2次，
            trades = ds.get_TRADEDATE_listp(c)
            print "@@@@@@@@@@@@@@@@@@%s@@@@@@@@@@@@@@" % len(trades)
            for k,d in enumerate(trades):

                print d
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma


                do_methodm(pre_factor, today,info, d, c, True, table_name, args, database, '')
            #for d in trades:
            #    info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
            #    # 不算ma
            #    do_method(no_factor, info, d, c, True, table_name, args, database, '')

        else:
            print "不需要重新算复权的股票",c,factor_tody,today

            # 否则，更新今天的前复权

            #print "iiiiiiiiiiiiiiiiiiiii",c_info
            if c_info:

                do_methodm(pre_factor,today, c_info, today, c, True, table_name, args, database, '')


        if factor_60 != 1:
            print "后后【{}】【{}】".format(c["symbol"],today)
            trades = tradedate_list[:(179 - de)][::-1]
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(after_60_factor,{"TRADEDATE":DATE_MIN_60}, info, d, c, True, table_name, args, database, '')

        else:
            print "不需复权的股票",c,factor_60,today
            # 否则，更新今天的前复权
            if c_info:
                do_methodm(after_60_factor,{"TRADEDATE":DATE_MIN_60},c_info, today, c, True, table_name, args, database, '')
        # 如果60或160的复权因子变化，更新历史前复权数据2次，

        if factor_160 != 1:
            print "后后【{}】【{}】".format(c["symbol"],today)
            trades = tradedate_list[:(279 - de)][::-1]
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_methodm(after_160_factor,{"TRADEDATE":DATE_MIN_160}, info, d, c, True, table_name, args, database, '')

        else:
            print "不需复权的股票",c,factor_160,today
            # 否则，更新今天的前复权
            if c_info:
                do_methodm(after_160_factor, {"TRADEDATE":DATE_MIN_160},c_info, today, c, True, table_name, args, database, '')
            # 如果60或160的复权因子变化，更新历史前复权数据2次，

    print "finish:[{}]".format(c["symbol"])

    mysql.close()


def do_methodm(method,m, c_info, d, c, get_ma, table_name, args, database, mysql_table):
    c_info = copy.deepcopy(c_info)
    data = method(m["TRADEDATE"],c_info, d["TRADEDATE"], c["INNER_CODE"], get_ma, table_name, mysql_table)
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    result_size = len(data)
    # 格式化mysql数据

    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, data, table_info)
    return


def do_method_old(method, d, c, table_name, args, database, mysql_table):
    data = method(d["TRADEDATE"], c["INNER_CODE"], table_name, mysql_table)
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    result_size = len(data)
    # 格式化mysql数据

    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, data, table_info)
    return
    try:
        #
        data = method(d["TRADEDATE"], c["INNER_CODE"], table_name, mysql_table)
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        result_size = len(data)
        # 格式化mysql数据

        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)
    except Exception, e:



        time.sleep(3)
        do_method_old(method, d, c, table_name, args, database, mysql_table)


def do_method(method, c_info, d, c, get_ma, table_name, args, database, mysql_table):
    c_info = copy.deepcopy(c_info)
    data = method(c_info, d["TRADEDATE"], c["INNER_CODE"], get_ma, table_name, mysql_table)
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    result_size = len(data)
    # 格式化mysql数据

    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, data, table_info)


def main_inter_timing_onecode(c, database, table_name, todays, args, curr_time, mysql_table):
    print "xxx"
    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    m = "make_INTER_data"
    no_factor = "make_INTER_data_no_factor"
    pre_factor = "make_INTER_data_pre_factor"
    after_60_factor = "make_INTER_data_after_60_factor"
    after_160_factor = "make_INTER_data_after_160_factor"

    no_factor = getattr(ds, no_factor)
    pre_factor = getattr(ds, pre_factor)
    after_60_factor = getattr(ds, after_60_factor)
    after_160_factor = getattr(ds, after_160_factor)

    for today in todays:
        print today
        # 判断是否退市
        if ds.is_tradeon(c,today):
            print "退市"
            continue
        # 判断是开盘前还是开盘后
        de = 1 if datetime.datetime.now().hour < 15 else 0

        # c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        # print "iiiiiiiiiiiiiiiiiiiii",c_info
        # if not c_info: continue
        tradedate_list = ds.get_tradedate_list(c["INNER_CODE"], mysql_table, today["TRADEDATE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        # DATE_MAX = tradedate_list[0]["TRADEDATE"]

        DATE_MAX = tradedate_list[0]["LAST_TRADE_DATE"]
        END_DATE = tradedate_list[0]["ENDDATE"]
        DATE_MIN_60 = tradedate_list[:(179 - de)][-1]["FIRST_TRADE_DATE"]
        DATE_MIN_160 = tradedate_list[:(279 - de)][-1]["FIRST_TRADE_DATE"]

        #factor_tody = ds.get_factor_day(c["symbol"], DATE_MAX) # 前复权只判断当前的复权状态
        factor_tody = ds.get_factor_day_between(c["symbol"],pre_date(2,DATE_MAX),DATE_MAX)
        print "bbb"
        #factor_tody = ds.get_factor_day_between(c["symbol"],datetime.datetime.strptime('2017-06-10', '%Y-%m-%d'), DATE_MAX)
        #datetime.datetime.strptime('2014-01-02', '%Y-%m-%d')
        print tradedate_list[0]["FIRST_TRADE_DATE"]
        # 只有当前等于first_trade_date 时，才判断前60的后复权
        factor_60 = ds.get_factor_day_between(c["symbol"], DATE_MIN_60, tradedate_list[:(179 - de)][-1]["LAST_TRADE_DATE"]) if tradedate_list[0]["FIRST_TRADE_DATE"] == today else 1
        #factor_60 = ds.get_factor_day_between(c["symbol"], DATE_MIN_60, tradedate_list[:(179 - de)][-1]["LAST_TRADE_DATE"])
        # 只有当前等于first_trade_date 时，才判断前160的后复权
        #factor_160 = ds.get_factor_day_between(c["symbol"], DATE_MIN_160, tradedate_list[:(279 - de)][-1]["LAST_TRADE_DATE"])
        factor_160 = ds.get_factor_day_between(c["symbol"], DATE_MIN_160, tradedate_list[:(279 - de)][-1]["LAST_TRADE_DATE"]) if tradedate_list[0]["FIRST_TRADE_DATE"] == today  else 1
        # 添加今天不复权的数据
        # print "xxxxxxxxxxxxxxxxxxxxxxxx", factor_tody,factor_60,factor_160
        if not (de and today == pre_date()):
            do_method_old(no_factor, {"TRADEDATE": END_DATE}, c, table_name, args, database, mysql_table)
        if factor_tody != 1:
            print '=================================================='
            print "*****需要重新算复权的股票", c, factor_tody, today
            print "--------------------------------------------------"

            # 如果今天的复权因子变化，更新所有日期的前复权数据2次，
            trades = tradedate_list[::-1]
            print "@@@@@@@@@@@@@@@@@@%s@@@@@@@@@@@@@@" % len(trades)
            for k, d in enumerate(trades):
                print d

                do_method_old(pre_factor, {"TRADEDATE": d["ENDDATE"]}, c, table_name, args, database, mysql_table)


                # for d in trades:
                #    info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                #    # 不算ma
                #    do_method(no_factor, info, d, c, True, table_name, args, database, '')

        elif not (de and today == pre_date()):
            print "不需要重新算复权的股票", c, factor_tody, today
            # 否则，更新今天的前复权
            do_method_old(pre_factor, {"TRADEDATE": END_DATE}, c, table_name, args, database, mysql_table)

        if factor_60 != 1:
            print "后后【{}】【{}】".format(c["symbol"], today)
            # trades = ds.get_TRADEDATE_list(c["INNER_CODE"], 0, DATE_MIN_60)
            trades = tradedate_list[:(179 - de)][::-1]
            for d in trades:
                do_method_old(after_60_factor, {"TRADEDATE": d["ENDDATE"]}, c, table_name, args, database, mysql_table)

        elif not (de and today == pre_date()):
            print "不需要重新算复权的股票", c, factor_tody, today
            # 否则，更新今天的前复权
            do_method_old(after_60_factor, {"TRADEDATE": END_DATE}, c, table_name, args, database, mysql_table)

        # 如果60或160的复权因子变化，更新历史前复权数据2次，

        if factor_160 != 1:
            print "后后【{}】【{}】".format(c["symbol"], today)
            # trades = ds.get_TRADEDATE_list(c["INNER_CODE"], 0, DATE_MIN_160)
            trades = tradedate_list[:(279 - de)][::-1]
            for d in trades:
                do_method_old(after_160_factor, {"TRADEDATE": d["ENDDATE"]}, c, table_name,  args, database, mysql_table)

        elif not (de and today == pre_date()):
            print "不需要重新算复权的股票", c, factor_tody, today
            # 否则，更新今天的前复权

            do_method_old(after_160_factor, {"TRADEDATE": END_DATE}, c, table_name,args, database, mysql_table)

    print "finish:[{}]".format(c["symbol"])

    mysql.close()

def main_inter_timing(args, mysql_table):
    """
    定时执行，
    1.算当天的所有股票，4个复权状态的数据，（不算MA,SUM）
    2.如果当天的复权因子!=1，先重跑历史前复权基础数据，
    3.再重跑所有前复权（MA,SUM）
    4.如果DATE_MIN_60 或 DATE_MIN_160当日复权因子！=1，同上
    5.以上规则太复杂，
    6.所以改成如果某只股票
    6.所以改成如果某只股票
    :param args:
    :return:
    """
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    # 判断今天是否开盘

    n1 = datetime.datetime.now()
    innercode_list = ds.get_STOCKINFO_list()  # 可以考虑函数缓存
    print len(innercode_list)
    start = int(args[1]) if len(args) > 1 else 0
    count_days = []
    for i in range(0, 1):
        d = pre_date(i)
        if ds.is_tradedate(d):
            count_days.append({"TRADEDATE": d})
    today = {"TRADEDATE": pre_date(start)}
    print count_days

    # print today
    args_list = []
    for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'todays': count_days[::-1],
            'args': args,
            'curr_time': curr_time,
            'mysql_table': mysql_table
        }))
    pool = threadpool.ThreadPool(20)
    requests = threadpool.makeRequests(main_inter_timing_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()


def main_day_inter_timing(args):
    """
    定时执行，
    1.算当天的所有股票，4个复权状态的数据，（不算MA,SUM）
    2.如果当天的复权因子!=1，先重跑历史前复权基础数据，
    3.再重跑所有前复权（MA,SUM）
    4.如果DATE_MIN_60 或 DATE_MIN_160当日复权因子！=1，同上
    5.以上规则太复杂，
    6.所以改成如果某只股票
    6.所以改成如果某只股票
    :param args:
    :return:
    """
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    # 判断今天是否开盘

    n1 = datetime.datetime.now()
    innercode_list = ds.get_STOCKINFO_list()  # 可以考虑函数缓存
    print len(innercode_list)
    start = int(args[1]) if len(args) > 1 else 0
    count_days = []
    for i in range(0,1):
        d = pre_date(i)
        if ds.is_tradedate(d):
            count_days.append({"TRADEDATE": d})
    today = {"TRADEDATE": pre_date(start)}
    print count_days

    # print today
    args_list = []
    for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'todays': count_days[::-1],
            'args': args,
            'curr_time': curr_time
        }))
    pool = threadpool.ThreadPool(20)
    # 前复权
    if args[3] == 'pre':
        requests = threadpool.makeRequests(day_inter_timing_onecode_pre, args_list)
    elif args[3] == 'after':
        requests = threadpool.makeRequests(day_inter_timing_onecode_after, args_list)
    else:
        requests = threadpool.makeRequests(day_inter_timing_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()

def main_day_inter_timing_new(args):
    """
    定时执行，
    1.算当天的所有股票，4个复权状态的数据，（不算MA,SUM）
    2.如果当天的复权因子!=1，先重跑历史前复权基础数据，
    3.再重跑所有前复权（MA,SUM）
    4.如果DATE_MIN_60 或 DATE_MIN_160当日复权因子！=1，同上
    5.以上规则太复杂，
    6.所以改成如果某只股票
    6.所以改成如果某只股票
    :param args:
    :return:
    """
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    # 判断今天是否开盘

    n1 = datetime.datetime.now()
    innercode_list = ds.get_STOCKINFO_list()  # 可以考虑函数缓存
    print len(innercode_list)
    start = int(args[1]) if len(args) > 1 else 0
    count_days = []
    for i in range(0,1):
        d = pre_date(i)
        if ds.is_tradedate(d):
            count_days.append({"TRADEDATE": d})
    today = {"TRADEDATE": pre_date(start)}
    print count_days

    # print today
    args_list = []
    for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'todays': count_days[::-1],
            'args': args,
            'curr_time': curr_time
        }))
    pool = threadpool.ThreadPool(10)
    # 前复权
    if args[3] == 'pre':
        requests = threadpool.makeRequests(day_inter_timing_onecode_pre, args_list)
    elif args[3] == 'after':
        requests = threadpool.makeRequests(day_inter_timing_onecode_after, args_list)
    else:
        requests = threadpool.makeRequests(day_inter_timing_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()


def inter_onecode(c, database, table_name, args, curr_time, mysql_table):
    print c["INNER_CODE"]
    mysql = get_mysql()
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    m = "make_INTER_data"
    method = getattr(ds, m)
    tradedate_list = ds.get_enddate_list(mysql_table, c)
    for d in tradedate_list:
        print d
        do_method_old(method, d, c, table_name, args, database, mysql_table)
    mysql.close()


def main_inter(args, mysql_table):
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    # m = "make_%s_data" % table_name

    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    innercode_list = ds.get_INNER_CODE_list()

    # innercode_list = [
    # {"INNER_CODE": 101002348}, {"INNER_CODE": 101000001},
    # {"INNER_CODE": 101000005}]

    #innercode_list = [{'INNER_CODE': 101000003}, {'INNER_CODE': 101000005}, {'INNER_CODE': 101000015},
    #                  {'INNER_CODE': 101000443}, {'INNER_CODE': 101001725}, {'INNER_CODE': 101000001},
    #                  {'INNER_CODE': 101002348}, {'INNER_CODE': 101000592}, {'INNER_CODE': 101000600},
    #                  {'INNER_CODE': 101000602}]
    start = int(args[1])
    end = start + 100
    print start, end
    args_list = []
    for c in innercode_list:
        args_list.append((None, {
            'c': c,
            'database': database,
            'table_name': table_name,
            'args': args,
            'curr_time': curr_time,
            'mysql_table': mysql_table
        }))
    pool = threadpool.ThreadPool(10)
    requests = threadpool.makeRequests(inter_onecode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()

def main2(args):
    """
    通过limit分段获取sql数据
    :param args:
    :return:
    """
    # print args
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    indx_code_list = ds.get_indx_code_list()
    for i in indx_code_list:
        print i
        method = getattr(ds, m)
        data = method(i)
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        # 格式化mysql数据

        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)
    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    update_task(ds, curr_time, database, table_name)

def main(args):
    """
    通过limit分段获取sql数据
    :param args:
    :return:
    """
    # print args
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return

    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    declare_date_list = ds.get_declare_dates()
    for i in declare_date_list:
        method = getattr(ds, m)
        data = method(i)
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        # 格式化mysql数据

        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)
    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    update_task(ds, curr_time, database, table_name)


def main_limit(args):
    """
    通过limit分段获取sql数据
    :param args:
    :return:
    """
    # print args
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return



    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    if hasattr(ds, m):
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 100, 100
        while result_size != 0:
            data = method(offset, maxsize)
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 格式化mysql数据

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)
    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    update_task(ds, curr_time, database, table_name)



def main_news(args):
    """
    新闻公告数据处理
    :param args:
    :return:
    """
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m_ids = "make_%s_ids" % table_name
    m_topic_ids = "make_Z3_TOPIC_NEWS_ids"
    m = "make_%s_data" % table_name
    m2 = "make_%s_data2" % table_name
    curr = getnow()
    curr_time = args[2] if args[2] else curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": args[1], "endtime": args[2]}, curr_time, None)
    print "start_news_task"
    if hasattr(ds, m):

        method_ids = getattr(ds, m_ids)
        method = getattr(ds, m)
        # 执行删除
        print "before delete!!"
        ds.delete_Z3_NEWS_data()
        print "delete done"

        offset = 0
        result_size, maxsize = 500, 500
        while True:
            ids = ds.get_changed_newsid(offset, maxsize)
            data = method_ids(offset, maxsize,ids)
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            if not result_size:break
            data = method(data)
            print result_size
            print "last is",len(data)
            offset += maxsize
            # 格式化mysql数据

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)
            ds.insert_z3_news_info_search(data)


        method_ids = getattr(ds, m_topic_ids)
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 500, 500
        while True:
            data = method_ids(offset, maxsize)
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            if not result_size:break
            data = method(data)
            print result_size
            print len(data)
            offset += maxsize
            # 格式化mysql数据

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)
            ds.insert_z3_news_info_search(data)

        method = getattr(ds, m2)
        offset = 0
        result_size, maxsize = 300, 300

        while result_size == 300:
            data = ds.get_changed_ggid(offset, maxsize)
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            data = method(data)
            print len(data)
            offset += maxsize
            # 格式化mysql数据

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)

    #curr = getnow()
    #curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    update_task(ds, curr_time, database, table_name)

def main_news_bak(args):
    """
    新闻公告数据处理
    :param args:
    :return:
    """
    try:
        mysql = get_mysql()
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m_ids = "make_%s_ids" % table_name
    m_topic_ids = "make_Z3_TOPIC_NEWS_ids"
    m = "make_%s_data" % table_name
    m2 = "make_%s_data2" % table_name
    curr = getnow()
    curr_time = args[2] if args[2] else curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": args[1], "endtime": args[2]}, curr_time, None)
    if hasattr(ds, m):

        method_ids = getattr(ds, m_ids)
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 1000, 1000
        while True:
            data = method_ids(offset, maxsize)
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            if not result_size:break
            data = method(data)
            print result_size
            print len(data)
            offset += maxsize
            # 格式化mysql数据

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)

        method_ids = getattr(ds, m_topic_ids)
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 1000, 1000
        while True:
            data = method_ids(offset, maxsize)
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            if not result_size:break
            data = method(data)
            print result_size
            print len(data)
            offset += maxsize
            # 格式化mysql数据

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)

        method = getattr(ds, m2)
        offset = 0
        result_size, maxsize = 500, 500

        while result_size == 500:
            data = method(offset, maxsize)


            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 格式化mysql数据

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)

    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    update_task(ds, curr_time, database, table_name)


def getnow():
    '''
    获取当前时间
    :return:
    '''
    return datetime.datetime.now()


def get_last_update_time(curr_time, info={}):
    """
    生成 预测任务执行时间
    :param curr_time:   datetimestr 当前时间
    :param info:        dict 定时信息
    :return:
    """
    prequency = info.get("FREQUENCY", "H")
    space = info.get("SPACE", 1)
    if prequency == "H":
        interval_time = "HOUR"
    elif prequency == "D":
        interval_time = "DAY"
    elif prequency == "W":
        interval_time = "WEEK"
    elif prequency == "M":
        interval_time = "MONTH"
    elif prequency == "Q":
        interval_time = "QUARTER"
    elif prequency == "Y":
        interval_time = "YEAR"
    else:
        interval_time = "HOUR"

    # return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return "DATE_ADD('%s', INTERVAL %s %s)" % (curr_time, space, interval_time)


def upsert_mongo_data(args, database, table_name, data, table_info):
    """
    更新数据到mongo
    :param args:        list 来自sys.argv
    :param database:    str 目的表库名
    :param table_name:  str 目的表表名
    :param data:        list 需要更新同步的数据
    :param table_info:  dict 目的表配置信息，来自oonvert_config文件
    :return:
    """

    data = copy.deepcopy(data)
    nor_list = []  # 用于删除，不满足条件的历史纪录
    equity_keys = ["innerCode", "symbol", "name"]

    for key, row in enumerate(data):
        tmp = row
        if table_info.get("equity", False):

            filter = {("equity.%s" % i): row[i] for i in table_info["pri_key"] if i in equity_keys}
            filter.update({i: row[i] for i in table_info["pri_key"] if i not in equity_keys})
            equity = {}
            for i in equity_keys:
                if i in tmp:
                    if args[2] != "insert":
                        tmp["equity.%s" % i] = tmp[i]

                    equity[i] = tmp[i]
                    del tmp[i]

            if args[2] == "insert" and equity:
                tmp["equity"] = equity

        else:
            filter = {i: row[i] for i in table_info["pri_key"]}
        if args[2] != "insert":

            conn = tools.mongo_cursor()
            db = conn[database]
            for i in table_info.get("nesteds", []):
                filtero = copy.deepcopy(filter)
                filtero.update({i: None})
                if db[table_name].find_one(filtero):
                    db[table_name].update(filter, {"$set": {i: {}}}, upsert=True)

            db[table_name].update(filter, {"$set": tmp}, upsert=True, multi=True)
        else:
            data[key] = tmp
    if args[2] == "insert" and data:
        conn = tools.mongo_cursor()
        db = conn[database]
        db[table_name].insert_many(data)

    return
    try:

        data = copy.deepcopy(data)
        nor_list = []  # 用于删除，不满足条件的历史纪录
        equity_keys = ["innerCode", "symbol", "name"]

        for key, row in enumerate(data):
            tmp = row
            if table_info.get("equity", False):

                filter = {("equity.%s" % i): row[i] for i in table_info["pri_key"] if i in equity_keys}
                filter.update({i: row[i] for i in table_info["pri_key"] if i not in equity_keys})
                equity = {}
                for i in equity_keys:
                    if i in tmp:
                        if args[2] != "insert":
                            tmp["equity.%s" % i] = tmp[i]

                        equity[i] = tmp[i]
                        del tmp[i]

                if args[2] == "insert" and equity:
                    tmp["equity"] = equity

            else:
                filter = {i: row[i] for i in table_info["pri_key"]}
                # nor_list.append(filter)
            # print filter,tmp

            # except pymongo.errors.ServerSelectionTimeoutError, e:
            #     print e, '连接失败！'
            #     return

            # 判断是否需要删除历史不符合条件的数据
            # 如果配置不删除，或者传递了制定的股票代码，或者查不到数据，都不需要做删除操作
            # if table_info["delete_old"] and nor_list and not args[1]:
            #     print nor_list
            #     db[table_name].remove({"$nor": nor_list})

            if args[2] != "insert":

                conn = tools.mongo_cursor()
                db = conn[database]
                for i in table_info.get("nesteds", []):
                    filtero = copy.deepcopy(filter)
                    filtero.update({i: None})
                    if db[table_name].find_one(filtero):
                        db[table_name].update(filter, {"$set": {i: {}}}, upsert=True)

                db[table_name].update(filter, {"$set": tmp}, upsert=True, multi=True)
            else:
                data[key] = tmp
        if args[2] == "insert" and data:
            conn = tools.mongo_cursor()
            db = conn[database]
            db[table_name].insert_many(data)
    except Exception, e:
        print e
        #print filter
        upsert_mongo_data(args, database, table_name, data, table_info)


if __name__ == "__main__":
    import sys
    print "start:time:{}!".format(datetime.datetime.now())
    init_args = ["z3dbus.Z3_RESEARCH_REPORT", 0, 0, '']
    for k, v in enumerate(sys.argv[1:]):
        init_args[k] = v
    if init_args[0] in ["z3dbus.Z3_EQUITY_PROFILE",
                        ]:
        # 批量复制 Z3_EQUITY_PROFILE 数据
        main_limit(init_args)

    elif init_args[0] in ["z3dbus.Z3_RESEARCH_REPORT", ]:
        main(init_args)
    elif init_args[0] in ["z3dbus.Z3_INDEX_SAMPLE", ]:
        main2(init_args)
    elif init_args[0] in ["z3dbus.Z3_MNG_HOLD_STK_INFO"]:
        main_holder(init_args)
    elif init_args[0] in ["z3dbus.Z3_EX_FACTOR_ALL"]:
        main_factor(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_NEWS"]:
        main_news(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_XREF_NEWS"]:
        main_xref_news(init_args)
    elif init_args[0] in ["z3dbus.Z3_NEWS"]:
        main_news(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY"]:
        main_equity(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY2"]:
        main_equity(init_args)
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_DAY_INTER_NEW"]:
        if init_args[2] == "timing":
            main_day_inter_timing_new(init_args)
        else:
            main_day_inter_new(init_args)
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_DAY_INTER"]:
        if init_args[2] == "timing":
            main_day_inter_timing(init_args)
        else:
            main_day_inter(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY2"]:
        main_equity_history(init_args, 'make_Z3_EQUITY2_data')
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY"]:
        main_equity_history(init_args, 'make_Z3_EQUITY_data')
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_WEEK_INTER"]:
        # main_inter(init_args, 'ANA_STK_MKT_WEEK')
        if init_args[2] == "timing":
            main_inter_timing(init_args, 'ANA_STK_MKT_WEEK')
        else:
            main_inter(init_args, 'ANA_STK_MKT_WEEK')
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_MONTH_INTER"]:
        if init_args[2] == "timing":
            main_inter_timing(init_args, 'ANA_STK_MKT_MONTH')
        else:
            main_inter(init_args, 'ANA_STK_MKT_MONTH')
    elif init_args[0] in ["z3dbus.Z3_EXCHANGE_CALENDAR"]:
        main_limit(init_args)
        # except Exception, e:
        #     print e.args
        #     print e.message
        #     logger = None
        #     logger.debug(e.message)
    print "finish:time:{}!".format(datetime.datetime.now())

