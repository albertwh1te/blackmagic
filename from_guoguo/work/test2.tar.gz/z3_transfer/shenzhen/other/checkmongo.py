# coding:utf-8
# Created by qinlin.liu at 2017/3/31

from utils.tools import mongo_cursor
from utils.mysqlutil import Mysql
from config import config
import datetime


def get_data():
    cursor = mongo_cursor()
    db = cursor["z3dbus"]
    print db.collection_names()

get_data()

