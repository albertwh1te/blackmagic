# coding:utf-8
# Created by qinlin.liu at 2017/3/14
import copy
import pymongo
from utils import tools
from common import pre_date
from functools import wraps
import datetime, time


def cache(func):
    caches = {}

    @wraps(func)
    def wrap(*args,**kwargs):
        if args not in caches:
            caches[args] = func(*args,**kwargs)
        return caches[args]

    return wrap


class DataSourceCopy():


    def __init__(self, conn, database, table, args, curr_time, logger):
        """
        实例化方法
        :param conn: mysql链接
        :param args:  参数
        """
        self.conn = conn
        self.tdatabase = database  # 目的库
        self.ttable = table  # 目的表
        # self.seconds = args["seconds"]
        self.starttime = args["starttime"]
        self.curr_time = args["endtime"] if args["endtime"] else curr_time
        # stockcode = args["stockcode"]
        # 获取目的表任务信息
        self.task_info = self._get_task_info()
        self.logger = None
        # 获取股票信息
        # self.stock_info = self._get_stock_info(stockcode) if stockcode else {}

    def _get_task_info(self):
        """
        获取 任务 信息
        :return:
        """
        sql = """
            SELECT * FROM pgznty.z3_update_task a WHERE a.TDATABASE=%(tdatabase)s
            AND a.TTABLE = %(ttable)s
        """

        result = self.conn.fetchone(sql, {"tdatabase": self.tdatabase, 'ttable': self.ttable})
        return result if result else {}

    def _get_stock_info(self, stockcode):
        """
        获取股票信息
        :param stockcode: 股票代码 str
        :return:
        """
        # sql = """
        #     SELECT * FROM stk_code a WHERE a.STOCKCODE=%(stockcode)s
        # """
        #
        # results = self.conn.fetchone(sql, {"stockcode": stockcode})
        # if not results:
        #     raise Exception(u"股票代码错误", "")
        # return results
        pass

    def update_taks(self, sql):
        """
        执行 更新任务状态 的sql
        :param sql:
        :return:
        """
        print self.conn.execute(sql)

    def _make_where(self, key, alias_list, key_alias='a'):
        """
        生成sql where条件
        :param key:             str     股票相关代码 字段名
        :param alias_list:      list    过滤时间段表别名列表
        :param key_alias:       str     key参数对应的表(别)名
        :return:
        """
        where_str = ""
        # where_time_model = "%%s.MTIME>SUBDATE(now(),interval %s second)" % self.seconds
        less_curr = " %%(alias)s.MTIME<='%s'" % self.curr_time

        where_last_model = (
            "( %%(alias)s.MTIME>'%s' AND  %s )" % (self.task_info["LASTRUNTIME"], less_curr)) if self.task_info.get(
            "LASTRUNTIME",

            None) else less_curr
        where_last_model = (
            "( %%(alias)s.MTIME>'%s' AND  %s )" % (self.starttime, less_curr)) if self.starttime else where_last_model

        where_list = []
        # if key in self.stock_info:
        #     where_list.append(" AND %s.%s='%s'" % (key_alias, key, self.stock_info[key]))
        # 如果有秒数
        # if self.seconds:
        #     where_list.append(" AND (%s)" % " OR ".join([where_time_model % alias for alias in alias_list]))
        # # 如果有上次更新时间,而且没有传递股票代码
        # elif not self.stock_info:
        #     # where_list.append(where_last_model)

        where_list.append(" AND (%s)" % " OR ".join([where_last_model % {"alias": alias} for alias in alias_list]))

        if where_list:
            where_str = "".join(where_list)
        # print self.task_info,"stock_info"
        return where_str

    def get_history_day_no_equity2(self, c):

        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        return list(db["Z3_EQUITY_HISTORY"].find({"symbol": c["symbol"],
                                                  "mkt2_idx.high_10day": {"$exists":False},
                                                  "trade_date": {
                                                      "$gte": datetime.datetime.strptime('2015-01-01', '%Y-%m-%d'),
                                                   #   "$lt": datetime.datetime.strptime('2016-01-01', '%Y-%m-%d')
                                                   }}
                                                  , {"trade_date": 1,"_id": 0}).sort("trade_date", pymongo.ASCENDING))


    def get_history_day_no_equity16(self, c):

        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        return list(db["Z3_EQUITY_HISTORY"].find({"symbol": c["symbol"],
                                                  "signal_normal.signal_normal_16": {"$exists":False},
                                                  "trade_date": {
                                                      "$gte": datetime.datetime.strptime('2014-01-01', '%Y-%m-%d'),
                                                      "$lt": datetime.datetime.strptime('2017-01-01', '%Y-%m-%d')}}
                                                  , {"trade_date": 1, "_id": 0}).sort("trade_date", pymongo.ASCENDING))


    # @cache
    def get_tradedate_list(self, code, mysql_table, last_trade_date=None):
        where_str = ''
        if last_trade_date:
            where_str = " AND LAST_TRADE_DATE<='%s'" % last_trade_date

        filter = {
            "code": code,
            "mysql_table": mysql_table,
            "where_str": where_str
        }
        sql_tradedate_list_model = """
                SELECT
                  ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
                FROM %(mysql_table)s a
                WHERE a.ISVALID = 1
                      AND a.INNER_CODE = '%(code)s'
                      AND ifnull(TVOLUME, 0) != 0
                      %(where_str)s
                ORDER BY ENDDATE DESC
                LIMIT 279;
            """
        print sql_tradedate_list_model % filter
        results =  self.conn.fetchall(sql_tradedate_list_model % filter)
        if not results:
            print "股票没记录:【{}】".format(code)
        return results


    #@cache
    def get_tradedate_day_list(self, code,last = None):
        where_str = (" AND TRADEDATE <='{}'".format(last)) if last else ''
        sql_tradedate_list_model = """
                SELECT
                  TRADEDATE
                FROM STK_MKT a
                WHERE a.ISVALID = 1
                      AND a.INNER_CODE = %(code)s
                      AND ifnull(TVOLUME, 0) != 0
                      %(where_str)s
                ORDER BY TRADEDATE DESC
                LIMIT 279;
            """

        return self.conn.fetchall(sql_tradedate_list_model % {
            "code": code,
            'where_str':where_str
        })

    def get_history_day_no_equity(self, c):

        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        return list(db["Z3_EQUITY_HISTORY"].find({"symbol": c["symbol"],
                                                  "signal_normal.signal_normal_10": {"$exists":False},
                                                  "trade_date": {
                                                      "$gte": datetime.datetime.strptime('2017-01-01', '%Y-%m-%d'),
                                                      #"$lt": datetime.datetime.strptime('2017-01-01', '%Y-%m-%d')
                                                      }}
                                                  , {"trade_date": 1, "_id": 0}).sort("trade_date", pymongo.ASCENDING))

    def make_Z3_EQUITY_PROFILE_data(self, offset, limit):
        """
        生成 股票基本信息表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c", "d", "e", "f"])
        sql = """
            SELECT
              b.SEC_UNI_ID    _id,
              a.STOCKCODE     symbol,
              a.STOCKSNAME    name,
              CASE when a.TRADE_MKT_REF=2 THEN 'SH' WHEN a.TRADE_MKT_REF=1 THEN 'SZ' END exchange,
              a.STK_TYPE_REF  sec_type,
              a.LIST_SEC_REF  list_sec,
              a.CHI_SPEL      chi_spel,
              d1.DIST_CODE     area_code,
              d1.PROV_NAME     area_name,
              e.SW_INDU_CODE_2014_1 sw_indu_code,
              f.INDU_NAME sw_indu_name,
              e.SW_INDU_CODE_2014_2 sw_indu_code_2,
              g.INDU_NAME sw_indu_name_2
            FROM STK_CODE a
              INNER JOIN pgznty.z3_sec_cons b ON a.INNER_CODE = b.INNER_CODE AND b.ISVALID=1
              LEFT JOIN
              (SELECT *
               FROM STK_COM_DIST_CHNG a
               WHERE ISVALID = 1 AND CHANGEDATE=(
                 SELECT max(CHANGEDATE)
                 FROM STK_COM_DIST_CHNG
                 WHERE ISVALID = 1 AND COMCODE = a.COMCODE) ) c ON a.COMCODE = c.COMCODE
              LEFT JOIN PUB_DIST_REF d ON c.DIST_CODE = d.DIST_CODE AND d.ISVALID=1
              LEFT JOIN PUB_DIST_REF d1 ON d.PROV_NAME = d1.PROV_NAME AND d1.CODE_LEVEL = 1 AND d1.ISVALID=1
              LEFT JOIN STK_COM_INDU_REL e ON a.COMCODE=e.COMCODE AND e.ISVALID =1
              LEFT JOIN PUB_INDU_REF f ON e.SW_INDU_CODE_2014_1 = f.INDU_CODE AND f.INDU_LEVEL=1 AND f.ISVALID=1 and f.INDU_SYS_MARK=15
              LEFT JOIN PUB_INDU_REF g ON e.SW_INDU_CODE_2014_2 = g.INDU_CODE AND g.INDU_LEVEL=2 AND g.ISVALID=1 and g.INDU_SYS_MARK=15
              WHERE a.ISVALID=1 %(where_str)s LIMIT %(offset)s,%(limit)s

        """ % {"where_str": where_str, "offset": offset, "limit": limit}
        #print sql
        results = self.conn.fetchall(sql)
        return results

    def get_INNER_CODE_list(self):
        #print "list"
        try:
            sql = """
            SELECT DISTINCT INNER_CODE,STOCKCODE SECCODE FROM  STK_CODE
            WHERE STK_TYPE_REF=1 AND stk_type_ref = 1
            ORDER BY STOCKCODE;
            """

            innercode_list = self.conn.fetchall(sql)
        except Exception, e:
            print e
            return self.get_INNER_CODE_list()
        return innercode_list

    def get_INNER_CODE_list_tmp(self):
        try:
            sql = """
            SELECT DISTINCT INNER_CODE,STOCKCODE SECCODE FROM  STK_CODE
            WHERE STK_TYPE_REF=1
            AND b.STOCKCODE IN ('000030')

            """

            innercode_list = self.conn.fetchall(sql)
        except Exception, e:
            print e
            return self.get_INNER_CODE_list()
        return innercode_list

    def get_INNER_CODE_list2(self):
        #
        # cursor = tools.mongo_cursor()
        # db=cursor["z3dbus"]
        # list(db.getCollection('Z3_STK_MKT_DAY_INTER').distinct("equity.symbol"))
        sql = """
        SELECT DISTINCT INNER_CODE FROM ANA_STK_MKT_WEEK WHERE ISVALID=1
        """

        innercode_list = self.conn.fetchall(sql)
        return innercode_list

    def get_STOCKINFO_list(self):
        sql = """
        SELECT DISTINCT
          CASE TRADE_MKT_REF WHEN 1 THEN CONCAT(STOCKCODE,'.SZ') ELSE CONCAT(STOCKCODE,'.SH') END innerCode,
          a.STOCKCODE  symbol,
          STOCKSNAME   name,
          COMCODE,
          a.INNER_CODE
        FROM STK_CODE a
        WHERE STK_TYPE_REF = 1 AND a.ISVALID = 1
        AND STOCKCODE IS NOT NULL
        AND TRADE_MKT_REF IS NOT NULL
        AND LIST_DATE <= CURRENT_DATE() and stk_type_ref = 1

        # )
#         AND TRADE_MKT_REF!=1
        #AND STOCKCODE in ('002026','300266','300170','300206','000970','002724','300445')
        #AND STOCKCODE in('300240','601599','300210','300206','601799')

        ORDER BY STOCKCODE;
        """
        seccode_list = self.conn.fetchall(sql)
        return seccode_list

    def getLTD(self,c,today,table):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        if table == 'Z3_STK_MKT_DAY_INTER':
            opendates = list(db["Z3_STK_MKT_DAY_INTER"].find(
                {
                    "equity.innerCode":c["innerCode"],
                    "ex_status":0,
                    "end_date":{"$lt":today["TRADEDATE"]}
                    },{"end_date":1, "_id":0}
                ).sort("end_date", pymongo.DESCENDING).limit(1))
            return opendates[0]["end_date"] if opendates else None
        else:
            opendates = list(db["Z3_STK_MKT_DAY_INTER_NEW"].find(
                {
                    "innerCode":c["innerCode"],
                    "ex_status":0,
                    "end_date":{"$lt":int(today["TRADEDATE"].strftime("%Y%m%d"))}
                    },{"end_date":1, "_id":0}
                ).sort("end_date", pymongo.DESCENDING).limit(1))
            return datetime.datetime.strptime(str(opendates[0]["end_date"]), '%Y%m%d') if opendates else None



    def isLTDeqLOD(self,c,today,table):
        return True if self.getLTD(c,today,table) == self.getLOD(today["TRADEDATE"]) else False

    @cache
    def getLOD(self,today):
        # 连接mongo
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        opendates = list(db["Z3_EXCHANGE_CALENDAR"].find(
            {
                "open_close":1,
                "trade_date":{"$lt":int(today.strftime("%Y%m%d"))}
                },{"trade_date":1,  "_id":0}
            ).sort("trade_date", pymongo.DESCENDING).limit(1))
        return datetime.datetime.strptime(str(opendates[0]["trade_date"]), '%Y%m%d') if opendates else None

    def get_STOCKINFO_list_on(self):
        sql = """
        SELECT DISTINCT
          CASE TRADE_MKT_REF WHEN 1 THEN CONCAT(STOCKCODE,'.SZ') ELSE CONCAT(STOCKCODE,'.SH') END innerCode,
          a.STOCKCODE  symbol,
          STOCKSNAME   name,
          COMCODE,
          a.INNER_CODE
        FROM STK_CODE a
        WHERE STK_TYPE_REF = 1 AND a.ISVALID = 1
        AND STOCKCODE IS NOT NULL
        AND TRADE_MKT_REF IS NOT NULL
        AND LIST_DATE <= CURRENT_DATE()
        AND IFNULL(DATE(LIST_ENDDATE),'2099-12-31' )> CURRENT_DATE() and stk_type_ref = 1

        ORDER BY STOCKCODE;
        """
        seccode_list = self.conn.fetchall(sql)
        return seccode_list

    def get_STOCKINFO_list_all(self):
        sql = """
        SELECT DISTINCT
          CASE TRADE_MKT_REF WHEN 1 THEN CONCAT(STOCKCODE,'.SZ') ELSE CONCAT(STOCKCODE,'.SH') END innerCode,
          a.STOCKCODE  symbol,
          STOCKSNAME   name,
          COMCODE,
          a.INNER_CODE
        FROM STK_CODE a
        WHERE STK_TYPE_REF = 1 AND a.ISVALID = 1
        AND STOCKCODE IS NOT NULL
        AND stk_type_ref = 1
       # AND INNER_CODE NOT IN (
        #   SELECT inner_code from pgznty.z3_sec_cons
        # )
#         AND TRADE_MKT_REF!=1
        #AND STOCKCODE IN ('000415')
        #AND STOCKCODE IN ('300050','002252','002024','000002','000001','000829','000009','600000','600019','600009')
        ORDER BY STOCKCODE;
        """
        seccode_list = self.conn.fetchall(sql)
        return seccode_list

    def make_Z3_EX_FACTOR_ALL_data_timing(self, i):
        # 1.更新当前交易日的数据(收市，stk_mkt有今日数据，)
        # 2.更新历史数据的修改（根据MTIME）

        where_str_ab = self._make_where("SECCODE", ["a", "b"])
        where_str_ac = self._make_where("", ["a", "c"])

        i.update({
            "where_str_ab": where_str_ab,
            "where_str_ac": where_str_ac
        })
        sqlmodel = """
            SELECT *
            FROM   (
                SELECT
                      a.SECCODE  symbol,
                      a.TRADEDATE end_date,
                      b.EX_FACTOR ex_factor,
                      b.CUM_FACTOR cum_factor,
                 CASE WHEN a.TRADEDATE = b.ENDDATE
                   THEN EX_FACTOR
                 ELSE 1 END   ex_factor_today
                FROM STK_MKT a
                  JOIN (select * from STK_EX_FACTOR_MKT b where STOCKCODE='%(SECCODE)s')b   ON a.SECCODE = b.STOCKCODE
                  AND a.TRADEDATE>=b.ENDDATE
                  WHERE a.ISVALID=1 AND b.ISVALID=1 AND a.INNER_CODE='%(INNER_CODE)s'

                %(where_str_ab)s
                ORDER BY B.ENDDATE DESC
              ) A
                GROUP BY symbol,end_date
                UNION
                SELECT
                  c.STOCKCODE  symbol,
                  a.EX_DATE    end_date,
                  a.EX_FACTOR  ex_factor,
                  a.CUM_FACTOR cum_factor,
                  a.EX_FACTOR ex_factor_today
                FROM STK_EX_FACTOR a
                  JOIN
                  (SELECT a.INNER_CODE,
                     max(TRADEDATE) ENDDATE
                          FROM STK_MKT AS a
                            WHERE a.ISVALID=1 AND a.INNER_CODE='%(INNER_CODE)s'
            GROUP BY INNER_CODE  ) b ON a.INNER_CODE = b.INNER_CODE
                      AND a.EX_DATE > b.enddate
                      JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE
                    WHERE a.ISVALID = 1 AND c.ISVALID = 1
                %(where_str_ac)s
        """ % i
        result = self.conn.fetchall(sqlmodel)
        return result

    def make_Z3_EX_FACTOR_ALL_data(self, i, timing=False):
        # 历史数据

        where_str_a = " AND a.TRADEDATE >= CURRENT_DATE() " if timing else ''
        where_str_b = " AND a.EX_DATE >= CURRENT_DATE() " if timing else ''
        where_str_c = " AND b.ENDDATE >= CURRENT_DATE() " if timing else ''

        #where_str_a = " AND a.TRADEDATE >= '2017-06-06' " if timing else ''
        #where_str_b = " AND a.EX_DATE >= '2017-06-06' " if timing else ''

        sql = """
            SELECT * FROM STK_EX_FACTOR_MKT WHERE STOCKCODE='%(SECCODE)s' ORDER BY ENDDATE LIMIT 1
        """ % {
            "SECCODE": i["SECCODE"]
        }
        info = self.conn.fetchone(sql)
        if not info:
            first_where = ""
        else:
            first_where = " AND a.TRADEDATE<'%(first_day)s' " % {
                "first_day": info["ENDDATE"]
            }
        sqlmodel = """
            SELECT
              CASE c.TRADE_MKT_REF WHEN 1 THEN CONCAT(c.STOCKCODE,'.SZ') ELSE CONCAT(c.STOCKCODE,'.SH') END innerCode,
              c.STOCKCODE  symbol,
              a.EX_DATE    end_date,
              a.EX_FACTOR  ex_factor,
              a.CUM_FACTOR cum_factor,
              a.EX_FACTOR  ex_factor_today
            FROM STK_EX_FACTOR a
              JOIN
              (SELECT
                 a.INNER_CODE,
                 max(TRADEDATE) ENDDATE
               FROM STK_MKT AS a
               WHERE a.ISVALID = 1 AND a.INNER_CODE = '%(INNER_CODE)s'

               GROUP BY INNER_CODE) b ON a.INNER_CODE = b.INNER_CODE
                                         AND a.EX_DATE > b.enddate
              JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE

            WHERE a.ISVALID = 1 AND c.ISVALID = 1 AND a.INNER_CODE = '%(INNER_CODE)s'
            %(where_str_b)s

            UNION

            SELECT

              CASE c.TRADE_MKT_REF
              WHEN 1
                THEN CONCAT(c.STOCKCODE, '.SZ')
              ELSE CONCAT(c.STOCKCODE, '.SH') END innerCode,
              c.STOCKCODE                         symbol,
              a.EX_DATE                           end_date,
              a.EX_FACTOR                         ex_factor,
              a.EX_FACTOR * d.CUM_FACTOR          cum_factor,
              a.EX_FACTOR                         ex_factor_today
            FROM STK_EX_FACTOR a

              JOIN (SELECT *
                    FROM STK_EX_FACTOR_MKT d
                    WHERE STOCKCODE = '%(SECCODE)s' AND ISVALID = 1) d ON d.STOCKCODE = a.STOCKCODE
                                                                     AND a.EX_DATE > d.ENDDATE

              JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE
              WHERE a.ISVALID = 1 AND c.ISVALID = 1 AND a.INNER_CODE = '%(INNER_CODE)s'
                  AND d.ENDDATE = (SELECT ENDDATE
                                   FROM STK_EX_FACTOR_MKT
                                   WHERE STOCKCODE = '%(SECCODE)s' AND a.EX_DATE > ENDDATE
                                         AND ISVALID = 1
                                   ORDER BY ENDDATE DESC
                                   LIMIT 1)
            %(where_str_b)s

            UNION

            SELECT CASE c.TRADE_MKT_REF
              WHEN 1
                THEN CONCAT(c.STOCKCODE, '.SZ')
              ELSE CONCAT(c.STOCKCODE, '.SH') END innerCode,
              c.STOCKCODE                         symbol,
              b.ENDDATE                         end_date,
              b.EX_FACTOR                         ex_factor,
              b.CUM_FACTOR                        cum_factor,
              b.EX_FACTOR                         ex_factor_today
            FROM STK_EX_FACTOR_MKT b
              LEFT JOIN STK_CODE c on b.STOCKCODE=c.STOCKCODE
              WHERE b.STOCKCODE = '%(SECCODE)s' AND b.ISVALID=1 and c.ISVALID=1
            %(where_str_c)s

            UNION

            SELECT
              CASE c.TRADE_MKT_REF
              WHEN 1
                THEN CONCAT(c.STOCKCODE, '.SZ')
              ELSE CONCAT(c.STOCKCODE, '.SH') END innerCode,
              c.STOCKCODE                         symbol,
              a.TRADEDATE                         end_date,
              b.EX_FACTOR                         ex_factor,
              b.CUM_FACTOR                        cum_factor,
              CASE WHEN a.TRADEDATE = b.ENDDATE
                THEN EX_FACTOR
              ELSE 1 END                          ex_factor_today
            FROM STK_MKT a
              JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE
              JOIN (SELECT *
                    FROM STK_EX_FACTOR_MKT b
                    WHERE STOCKCODE = '%(SECCODE)s') b ON c.STOCKCODE = b.STOCKCODE
                                                     AND a.TRADEDATE >= b.ENDDATE

            WHERE a.ISVALID = 1 AND b.ISVALID = 1 AND c.ISVALID = 1 AND a.INNER_CODE = '%(INNER_CODE)s'

                  AND b.ENDDATE = (SELECT ENDDATE
                       FROM STK_EX_FACTOR_MKT
                       WHERE STOCKCODE = '%(SECCODE)s' AND a.TRADEDATE >= ENDDATE
                       and ISVALID=1
                       ORDER BY ENDDATE DESC
                       LIMIT 1)
            %(where_str_a)s

            UNION

             SELECT CASE c.TRADE_MKT_REF WHEN 1 THEN CONCAT(c.STOCKCODE,'.SZ') ELSE CONCAT(c.STOCKCODE,'.SH') END innerCode,
               c.STOCKCODE  symbol,
               TRADEDATE end_date,
               1  ex_factor,
               1 cum_factor,
               1  ex_factor_today
             FROM STK_MKT a
             JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE
              WHERE a.INNER_CODE = '%(INNER_CODE)s' AND a.ISVALID=1 and c.ISVALID=1
             %(where_str_a)s
             %(first_where)s

            """ % {
            "SECCODE": i["SECCODE"],
            "INNER_CODE": i["INNER_CODE"],
            "where_str_a": where_str_a,
            "where_str_b": where_str_b,
            "where_str_c": where_str_c,
            "first_where": first_where
        }


        print sqlmodel
        result = self.conn.fetchall(sqlmodel)
        return result



    def get_STK_CODE_comcodes(self):

        sql = """
          SELECT DISTINCT COMCODE FROM STK_CODE WHERE ISVALID=1 and stk_type_ref = 1 and TRADE_MKT_REF IS NOT NULL"""
        return self.conn.fetchall(sql)


    def get_Z3_MNG_HOLD_STK_INFO_comcodes(self):
        sql = """
          SELECT DISTINCT b.COMCODE FROM STK_MNG_TRADE_INFO b left join STK_CODE a on a.COMCODE = b.COMCODE
          WHERE STK_TYPE_REF = 1 AND a.ISVALID = 1
          AND a.STOCKCODE IS NOT NULL
          AND TRADE_MKT_REF IS NOT NULL
          and stk_type_ref = 1
        """
        return self.conn.fetchall(sql)

    def make_Z3_MNG_HOLD_STK_INFO_data(self, c):
        """
        生成 董监高持股变动最新记录表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c"], "c")
        where_str = ''
        sql = """
        SELECT
            concat(b.stockcode,'.',case when b.trade_mkt_ref=1 then 'SZ'
                   when b.trade_mkt_ref=2 then 'SH'
                 end) as innerCode ,

          b.STOCKCODE                    AS symbol,
          b.STOCKSNAME                   AS name,
          a.INDI_ID                      AS mgt_id,
          a.MNG_NAME                     AS mgt_name,
          a.POST                         AS position,
          a.CHNG_RSN                     AS chg_reason,
          a.CHNG_VOL                     AS chg_vol,
          a.CHNG_PCT                     AS chg_pct,
          a.CHEG_EP                      AS chg_ep,
          a.CHNG_VOL * a.CHEG_EP / 10000 AS chg_mon,
          a.END_VOL                      AS end_vol,
          a.CHNG_DATE                    AS chg_date
        FROM (

               SELECT *
               FROM STK_MNG_TRADE_INFO AS a
               WHERE CHNG_DATE = (SELECT max(CHNG_DATE)
                                  FROM STK_MNG_TRADE_INFO
                                  WHERE RELATION = '本人' AND COMCODE='%(COMCODE)s'AND a.COMCODE = COMCODE AND (a.INDI_ID = INDI_ID or (a.INDI_ID IS NULL AND INDI_ID IS NULL)) AND a.ISVALID=1)
             ) a
          JOIN STK_CODE b ON b.COMCODE = a.COMCODE
        WHERE a.RELATION = '本人'AND a.COMCODE='%(COMCODE)s' AND a.ISVALID = 1 AND b.ISVALID = 1 AND b.TRADE_MKT_REF IS NOT NULL
                  and b.stk_type_ref = 1
                  %(where_str)s
        """ % {"where_str": where_str, "COMCODE": c["COMCODE"]}
        print sql
        results = self.conn.fetchall(sql)
        # print len(results)
        return results



    def make_Z3_MNG_HOLD_STK_INFO_data_bak(self, offset, limit):
        """
        生成 董监高持股变动最新记录表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c"], "c")
        where_str = ''
        sql = """
        SELECT
          c.SEC_UNI_ID                   AS innerCode,
          b.STOCKCODE                    AS symbol,
          b.STOCKSNAME                   AS name,
          a.INDI_ID                      AS mgt_id,
          a.MNG_NAME                     AS mgt_name,
          a.POST                         AS position,
          a.CHNG_RSN                     AS chg_reason,
          a.CHNG_VOL                     AS chg_vol,
          a.CHNG_PCT                     AS chg_pct,
          a.CHEG_EP                      AS chg_ep,
          a.CHNG_VOL * a.CHEG_EP / 10000 AS chg_mon,
          a.END_VOL                      AS end_vol,
          a.CHNG_DATE                    AS chg_date
        FROM (

               SELECT *
               FROM STK_MNG_TRADE_INFO AS a
               WHERE CHNG_DATE = (SELECT max(CHNG_DATE)
                                  FROM STK_MNG_TRADE_INFO
                                  WHERE RELATION = '本人' AND a.COMCODE = COMCODE AND a.INDI_ID = INDI_ID AND a.ISVALID=1) and a.MTIME>='2017-01-01'
             ) a
          JOIN STK_CODE b ON b.COMCODE = a.COMCODE
          JOIN pgznty.z3_sec_cons c ON c.INNER_CODE = b.INNER_CODE
        WHERE a.RELATION = '本人' AND a.ISVALID = 1 AND b.ISVALID = 1 AND c.ISVALID = 1 %(where_str)s LIMIT %(offset)s,%(limit)s
        """ % {"where_str": where_str, "offset": offset, "limit": limit}
        print sql
        results = self.conn.fetchall(sql)
        #print len(results)
        return results

    def delete_Z3_EQUITY_XREF_NEWS_data(self, *args, **kwargs):
        """"
        删除Z3_EQUITY_XREF_NEWS中已经作废的数据
        :return:
        """
        print "delete start"
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        where_str = self._make_where("_id", ["b"])

        # 无效关联新闻
        sql = """
            select concat(c.stockcode,'.', case when c.trade_mkt_ref=1 then 'SZ'
                                                   when c.trade_mkt_ref=2 then 'SH'
                                                    end,',',b.guid) as _id
                     ,'新闻' as news_type
             from pgenius.STK_CODE c
             join pgenius.NEWS_STK b on b.comcode=c.comcode
            where c.trade_mkt_ref in(1,2) and c.ISVALID = 1
              and c.stk_type_ref = 1 and c.STOCKCODE not like 'N%%'
              and b.isvalid = 0
              %(where_str)s
            UNION
          select concat(c.stockcode,'.',case when c.trade_mkt_ref=1 then 'SZ'
                                        when c.trade_mkt_ref=2 then 'SH'
                                         end,',',b.disc_id) as _id
                   , '公告' as news_type
             from pgenius.STK_CODE c
             join pgenius.DISC_COM b on b.comcode=c.comcode
              and b.isvalid=0 and b.ctime >= '2014-01-01'
            where c.stk_type_ref = 1
			  and c.TRADE_MKT_REF in (1,2) and c.isvalid = 1
			  and c.STOCKCODE not like 'N%%'
            %(where_str)s
        """ % {"where_str": where_str}

        data = self.conn.fetchall(sql)
        print "delete selected", len(data)
        for row in data:
            db["Z3_EQUITY_XREF_NEWS"].remove(row)

	    return []


    def delete_Z3_NEWS_data(self, *args, **kwargs):
        """
        删除 新闻主表无效数据
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        where_str = self._make_where("_id", ["a"])
        sql = """
            select distinct a.guid as _id
              from pgenius.NEWS_MAIN a
             where a.isvalid=0
               and a.ctime >= '2014-01-01'
               %(where_str)s
             union
            select distinct a.guid as _id
              from pgenius.NEWS_CONTENT a
             where a.isvalid=0
               and a.ctime >= '2014-01-01'
               %(where_str)s
             UNION
            select distinct a.disc_id as _id
              from pgenius.DISC_ACCE_COM a
             where a.isvalid=0
              %(where_str)s
             union
            select distinct a.disc_id as _id
              from pgenius.DISC_MAIN_COM a
             where a.isvalid=0
              %(where_str)s
        """ % {"where_str": where_str}
        bs_data = self.conn.fetchall(sql)

        print "delete_data", len(bs_data)

        # 删除mysql的z3_news_info_search表中的无效数据
        while True:
            part_bs_data = bs_data[:100]
            delete_sql = """
                delete from pgznty.z3_news_info_search where guid in (%s)
                    """ % ",".join(["'%s'" % i["_id"] for i in part_bs_data])
            self.conn.execute(delete_sql)
            bs_data = bs_data[100:]
            if not bs_data: break


        # 删除mongo的新闻主表,个股新闻关系表，主题新闻关系表中的新闻被置为无效数据
        for row in bs_data:
            db["Z3_TOPIC_XREF_NEWS"].remove({"guid": row["_id"]})
            db["Z3_EQUITY_XREF_NEWS"].remove({"guid": row["_id"]})
            db["Z3_NEWS"].remove(row)

        print "delete over"

        return []


    def get_changed_newsid(self, offset, limit):
        """
        获取NEWS_MAIN表和NEWS_CONTENT表修改过的新闻
        :param args:
        :param kwargs:
        :return:
        """
        where_str = self._make_where("guid", ["a"])
        # print "changed", where_str
        sql = """
          select distinct guid
            from (
            select distinct guid
              from pgenius.NEWS_MAIN a
             where ISVALID = 1
               %(where_str)s
             union
            select distinct guid
              from pgenius.NEWS_CONTENT a
             where ISVALID = 1
              %(where_str)s
              ) aa
              limit %(offset)s,%(limit)s
        """ % {"where_str": where_str,"offset":offset, "limit":limit}

        results = self.conn.fetchall(sql)

        print "changed_id", len(results)

        return results


    def get_changed_ggid(self, offset, limit):
        """
        获取DISC_MAIN_COM表和DISC_ACCE_COM表修改过公告的id
        :param args:
        :param kwargs:
        :return:
        """
        print "gonggao start"
        where_str = self._make_where("guid", ["a"])
        # print "changed", where_str
        sql = """
          select distinct _id
            from (
            select distinct a.disc_id as _id
               from pgenius.DISC_MAIN_COM a
              where a.isvalid=1
               %(where_str)s
             union
            select distinct a.disc_id as _id
              from pgenius.DISC_ACCE_COM a
             where a.isvalid=1
              %(where_str)s
             union
            select distinct a.disc_id as _id
              from pgenius.DISC_COM a
             where a.isvalid=1
              %(where_str)s
              ) aa
          LIMIT %(offset)s,%(limit)s

        """ % {"where_str": where_str, "offset": offset, "limit": limit}

        results = self.conn.fetchall(sql)
        print "changed gonggao ",len(results)
        return results


    def make_Z3_NEWS_data2(self, ids):
        """
        获取公告
        """
        if not ids:return []
        sql = """
            select a.disc_id as _id,
                   a.TITLE  as title,
                   a.declaredate as declare_date,
                   a.ctime,
                   null as author_unit,
                   null as author,
                   a.SOURCE  as src_name,
                   NULL  as important,
                   null  as postive_index,
                   null  as summary,
                   null as content,
                   '公告' as news_type,
                   b.ACCE_ROUTE  as acce_route,
                   b.ACCE_TYPE  as acce_type,
                   null as if_imp
              from pgenius.DISC_MAIN_COM a
              join pgenius.DISC_ACCE_COM b on a.disc_id=b.disc_id
              join pgenius.DISC_COM c on a.disc_id=c.disc_id and c.isvalid = 1
              join pgenius.STK_CODE d on c.comcode=d.comcode and d.stk_type_ref = 1
               and d.TRADE_MKT_REF in (1,2) and d.isvalid = 1 and d.STOCKCODE not like 'N%%'
             where a.isvalid=1 and b.isvalid=1
               and a.disc_id in (%(ids)s)
        """ % {"ids": ",".join(["'%s'" % id["_id"].encode("utf-8") for id in ids])}

        results = self.conn.fetchall(sql)
        return results

    def make_Z3_TOPIC_NEWS_ids(self,offset,limit):

        print "topic_id start"

        # cids = self.get_changed_newsid()
        where_str = self._make_where("GUID", ["a","b","c","d"])
        sql = """
                select DISTINCT b.GUID
                 from pgenius.PUB_SECTION_CODE a
                 join pgenius.NEWS_SECTION b on a.SECTION_CODE = b.SECTION_CODE and b.ISVALID =1
                 join pgenius.NEWS_MAIN c on b.GUID=c.GUID and c.ISVALID = 1
                 join pgenius.NEWS_CONTENT d on b.guid = d.guid and d.ISVALID = 1
                where  a.isvalid = 1 and a.SYS_CODE = 5
                  and a.SECTION_CODE not in (select distinct parent_code
                                               from pgenius.PUB_SECTION_CODE
                                              where isvalid = 1 and sys_code = 5)
             --    and b.guid = '0000000000000hc0x7'
               %(where_str)s

        limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "offset": str(offset), "limit": str(limit),
               }
        print "topic_ids sql end"
        #print sql
        return self.conn.fetchall(sql)


    def make_Z3_NEWS_ids(self,offset,limit,ids):

        print offset,limit,"news ids",len(ids)
        data = []
        # 获取个股新闻关系表中变化的guid
        where_str = self._make_where("GUID", ["b"], "c")
        sql = """
            SELECT distinct b.GUID
             from pgenius.NEWS_STK b
             join pgenius.STK_CODE c on b.comcode=c.comcode and c.stk_type_ref = 1
              and c.TRADE_MKT_REF in (1,2) and c.isvalid = 1 and c.STOCKCODE not like 'N%%'
            where b.isvalid=1
               %(where_str)s
           limit %(offset)s,%(limit)s;
        """ % {"where_str": where_str, "offset": str(offset), "limit": str(limit),
               }
        # print sql
        data.extend(self.conn.fetchall(sql))

        # 获取新闻表中变化的guid
        # cids = self.get_changed_newsid()
        #while True:
        #    part_cids = cids[0:500]
        if len(ids) <> 0:
            sql02 = """
              select distinct b.GUID
                from pgenius.NEWS_STK b
                join pgenius.STK_CODE c on b.comcode=c.comcode and c.stk_type_ref = 1
                 and c.TRADE_MKT_REF in (1,2) and c.isvalid = 1 and c.STOCKCODE not like 'N%%'
               where b.isvalid=1
                 and b.guid in (%(cids)s)
            """ % {"cids": ",".join(["'%s'" % id["guid"].encode("utf-8") for id in ids])}

            data.extend(self.conn.fetchall(sql02))
            # cids = cids[500:]
            # if not cids:break

        # 去重
        _tmp = []
        results = []
        for row in data:
            if row["GUID"] not in _tmp:
                results.append(row)
                _tmp.append(row["GUID"])
        print "z3_news ids", len(results)
        return results


    def make_Z3_EQUITY_XREF_NEWS_ids(self, offset, limit):

        print "Z3_EQUITY_XREF_NEWS_ids start"

        where_str = self._make_where("STOCKCODE", ["a"], "c")
        sql = """
        SELECT distinct GUID
          FROM NEWS_STK a
          join stk_code c
            on a.comcode=c.comcode
		 WHERE c.stk_type_ref = 1 and c.TRADE_MKT_REF in (1,2)
		  and c.isvalid=1  and c.STOCKCODE not like 'N%%'
      --    and c.list_date is not null
          AND a.ISVALID=1
          and a.DECLAREDATE >= '2013-01-01'
		%(where_str)s
		limit %(offset)s,%(limit)s;
        """ % {"where_str": where_str, "offset": str(offset), "limit": str(limit)}
        # print sql
        return self.conn.fetchall(sql)


    def insert_z3_news_info_search(self, datas):
        if not datas:return
        for k, row in enumerate(datas):
            datas[k]["summary"] = None if not datas[k]["summary"] else datas[k]["summary"].replace("'","''")
            datas[k]["title"] = None if not datas[k]["title"] else datas[k]["title"].replace("'","''")
            datas[k]["mtime"] = 'now()'
            datas[k]["type"] = 1
            datas[k]["isvalid"] = 1
        value_model = "('%(_id)s','%(title)s','%(summary)s','%(src_name)s','%(ctime)s',%(type)s,%(mtime)s,%(isvalid)s,'%(declare_date)s')"
        value_str = ','.join([value_model % row for row in datas])

        sql = """
            REPLACE into pgznty.z3_news_info_search(guid, title, summary, src_name, ctime, type, mtime, isvalid, declaredate)
            VALUES %(value_str)s
        """ % {"value_str": value_str}
        #print sql
        self.conn.execute(sql.replace('%','%%'))

    def make_Z3_NEWS_data(self, ids):
        if not ids:return []
        where_str = self._make_where("STOCKCODE", ["a", "b", "e"], "c")
        where_str = ''
        sql = """
            select a.guid as _id,
            a.TITLE_MAIN  as title,
            a.declaredate as declare_date,
            a.ctime,
            a.AUTOR_UNIT as author_unit,
            a.autor as author,
            e.SRC_NAME AS src_name,
            a.important,
            a.NEGA_POSI_MARK  as postive_index,
            a.summary,
            b.TXT_CONTENT as content,
            '新闻' as news_type,
            null  as acce_route,
            null  as acce_type,
            null as if_imp
            from pgenius.NEWS_MAIN a
            join pgenius.NEWS_CONTENT b on a.guid=b.guid
            join pgenius.PUB_INFOR_SRC e on a.src_code=e.SRC_CODE
           where a.isvalid=1 and b.isvalid=1 and e.isvalid=1
           --  and a.declaredate >= '2014-01-01'
           --  and a.guid = '0000000000000igpn5'
             AND a.guid in (%(ids)s)

        """ % {"ids":",".join(["'%s'" % id["GUID"].encode("utf-8") for id in ids])}

        #print sql
        return self.conn.fetchall(sql)


    def make_Z3_EQUITY_XREF_NEWS_data(self, ids):
        if not ids:return []
        sql = """
        select concat(c.stockcode,'.',case when c.trade_mkt_ref=1 then 'SZ'
                                           when c.trade_mkt_ref=2 then 'SH'
                                            end,',',a.guid) as _id,
			a.guid as guid,
			concat(c.stockcode,'.',case when c.trade_mkt_ref=1 then 'SZ'
					                    when c.trade_mkt_ref=2 then 'SH'
					                     end) as innerCode ,
			'新闻' as news_type,
			a.ctime as ctime,
			a.declaredate as declare_date,
			a.TITLE_MAIN  as title,
			e.SRC_NAME AS src_name,
			c.stockcode as symbol,
			c.stocksname  as name
        from pgenius.NEWS_MAIN a join pgenius.NEWS_STK b on a.guid=b.guid
        join pgenius.STK_CODE c on b.comcode=c.comcode and c.stk_type_ref = 1
		 and c.TRADE_MKT_REF in (1,2) and c.STOCKCODE not like 'N%%'
        join pgenius.PUB_INFOR_SRC e on a.src_code=e.SRC_CODE
        join pgenius.NEWS_CONTENT d on a.guid=d.guid and d.isvalid = 1
        where a.isvalid=1 and b.isvalid=1 and c.isvalid=1 and e.isvalid=1
        and a.declaredate >= '2014-01-01'
        and a.guid in (%(ids)s)
        """ % {"ids":",".join(["'%s'" % id["GUID"].encode("utf-8") for id in ids])}

        print sql
        results = self.conn.fetchall(sql)
        news_results = []
        equity_xref_news_results = []
        return results

    def make_Z3_EQUITY_XREF_NEWS_data2(self, c):

        where_str = self._make_where("STOCKCODE", ["a", "b", "c"], "c")

        sql = """
            select concat(c.stockcode,'.',case when c.trade_mkt_ref=1 then 'SZ'
                                                 when c.trade_mkt_ref=2 then 'SH'
                                            end,',',a.disc_id) as _id,
                    a.DISC_ID as guid,
                    concat(c.stockcode,'.',case when c.trade_mkt_ref=1 then 'SZ'
                                                 when c.trade_mkt_ref=2 then 'SH'
                                            end) as innerCode ,
                   '公告' as news_type,
                   a.ctime as ctime,
                   a.declaredate as declare_date,
                   a.TITLE  as title,
                   a.SOURCE AS src_name,
                   c.stockcode as symbol,
                   c.stocksname  as name
              from pgenius.DISC_MAIN_COM a
              join pgenius.DISC_COM b on a.disc_id=b.disc_id  and b.comcode='%(COMCODE)s'
              join pgenius.STK_CODE c on b.comcode=c.comcode and c.stk_type_ref = 1
		       and c.TRADE_MKT_REF in (1,2) and c.STOCKCODE not like 'N%%'
              join pgenius.DISC_ACCE_COM e on a.disc_id=e.disc_id and e.isvalid = 1
             where a.isvalid=1 and b.isvalid=1 and c.isvalid=1
               and a.declaredate >= '2014-01-01'
             %(where_str)s
        """ % {"where_str": where_str, "COMCODE": c["COMCODE"]}
        # print sql
        results = self.conn.fetchall(sql)
        print c["COMCODE"], len(results)

        return results

    def get_declare_dates(self):
        where_str = self._make_where("STOCKCODE", ["a"], "c")

        sql = """

        SELECT DISTINCT DECLAREDATE FROM RES_REPORT_MAIN a WHERE 1=1  %(where_str)s and DECLAREDATE >='2013-01-01' order by declaredate;
        """ % {"where_str":where_str}
        print sql


        return self.conn.fetchall(sql)

    def make_Z3_RESEARCH_REPORT_data(self, i):
        print i
        """
        生成 个股研报表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c", "d", "e"], "c")
        where_str=''
        sql = """
        SELECT
          a.RES_ID          _id,
          concat(c.stockcode,'.',case when c.trade_mkt_ref=1 then 'SZ'
             when c.trade_mkt_ref=2 then 'SH'
             end) as innerCode ,

          a.RPT_TITLE       title,
          a.DECLAREDATE     declare_date,
          e.REF_NAME     AS res_type,
          a.ORGNAME as src_name,
          ifnull((select CSName from ORG_PROFILE where ISVALID=1 and ORGCODE=a.ORGCODE),'') AS src_sname,
          c.STOCKCODE       symbol,
          c.STOCKSNAME      name,
          a.RPT_ABSTRACT AS summary,
          a.ACCE_ROUTE      aace_route
        FROM RES_REPORT_MAIN a
          JOIN RES_SEC_CODE b ON b.res_id = a.res_id
          JOIN STK_CODE c ON b.INNER_CODE = c.INNER_CODE
          LEFT JOIN GEN_REF e ON e.CLS_CODE = 5041 AND e.REF_CODE = a.RPT_TYPE AND e.isvalid = 1
        WHERE a.isvalid = 1 AND b.isvalid = 1 AND c.isvalid = 1 AND ifnull(a.RPT_ABSTRACT,'') != '' AND a.DECLAREDATE='%(DECLAREDATE)s'  %(where_str)s


        """ % {"where_str": where_str, "DECLAREDATE": i["DECLAREDATE"]}
        print sql
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["_id"]
            _t = copy.deepcopy(row)
            del _t["innerCode"]
            del _t["symbol"]
            del _t["name"]

            if key not in tmp:
                tmp.setdefault(
                    key, {
                        "equity": []
                    })
                tmp[key].update(_t)

            tmp[key]["equity"].append({
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
            })
        return tmp.values()
        # return results

    def get_last5_enddate(self, tradedate='NOW()'):
        """
        获取前5个交易日的日期
        :return:
        """

        where_str = " ENDDATE <= '%s' " % tradedate if tradedate else " ENDDATE <= NOW() "
        sql = """
            SELECT MIN(ENDDATE) ENDDATE
            FROM (
              SELECT ENDDATE
              FROM  PUB_EXCHANGE_CALENDAR
              WHERE MKT_TYPE = 1 AND OPEN_CLOSE = 1 AND %(where_str)s
              ORDER BY ENDDATE DESC
              LIMIT 5
            ) b;
            """ % {"where_str": where_str}
        raw = self.conn.fetchone(sql)
        return raw["ENDDATE"] if raw else None

    def is_tradeon(self,c,d):
        sql="""
        select * from STK_STP_CALENDAR where stopdate='%(TRADEDATE)s' and isvalid=1 and SEC_CODE='%(symbol)s';
        """
        #print sql % {"TRADEDATE":d["TRADEDATE"],"symbol":c["symbol"]}
        return len(self.conn.fetchall(sql % {"TRADEDATE":d["TRADEDATE"],"symbol":c["symbol"]}))

    def isReTrade(self,c,d):
        sql = """
            select 1 from NEWS_ESP_HINT where INNER_CODE=%(INNER_CODE)s and OPN_DT='%(OPN_DT)s'
        """ % {"INNER_CODE":c["INNER_CODE"],"OPN_DT":d["TRADEDATE"]}
        return len(self.conn.fetchall(sql))

    def is_tradedate(self,d):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        return True if db['Z3_EXCHANGE_CALENDAR'].find({
            "open_close":1,
            "trade_date":int(d.strftime("%Y%m%d"))
        }).count() else False


    def get_TRADEDATE_listp(self, c, limit=0, first_day=None):
        '''
        获取股票前161个交易日日期
        :param c:
        :return:
        '''
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        #db["Z3_STK_MKT_DAY_INTER"].remove({"equity.innerCode": c["innerCode"],"end_date":{"$ne":datetime.datetime.strptime('2017-06-12', '%Y-%m-%d')},"ex_status":{"$in":[0,2,    3]}})        #db["Z3_STK_MKT_DAY_INTER"].remove({"equity.innerCode": c["innerCode"],"ex_status":1})

        where_no_dates = ''
        where_str = ' LIMIT %s' % str(limit) if limit else ''
        where_firstday = "AND TRADEDATE>='%s'" % first_day if first_day else ''
        sql = """
            SELECT *
            FROM (
              SELECT DISTINCT TRADEDATE
              FROM STK_MKT
                        WHERE ISVALID = 1 AND INNER_CODE = '%(INNER_CODE)s'
                        AND ifnull(TVOLUME, 0) != 0
                        #AND TRADEDATE='2016-01-27'
                        #AND TRADEDATE>='2005-01-01'
                        #AND TRADEDATE<'2014-01-01'
                        AND TRADEDATE>='2007-01-01'
                        %(where_firstday)s

             UNION
             SELECT * FROM (

                  SELECT DISTINCT TRADEDATE
                  FROM STK_MKT
                  WHERE ISVALID = 1 AND INNER_CODE = '%(INNER_CODE)s'
                  AND ifnull(TVOLUME, 0) != 0
                  #AND TRADEDATE='2017-05-19'
                  #AND TRADEDATE>='2005-01-01'
                  AND TRADEDATE<'2007-01-01' ORDER BY TRADEDATE DESC
                  LIMIT 250
                ) as c
             order by tradedate desc
              %(where_str)s
            ) b  %(no_dates)s ORDER BY TRADEDATE
        """ % {"INNER_CODE": c["INNER_CODE"], "where_str": where_str, "where_firstday": where_firstday,"no_dates":where_no_dates}
        print sql
        result = self.conn.fetchall(sql)
        return result

    def get_TRADEDATE_list(self, c, limit=0, first_day=None):
        '''
        获取股票前161个交易日日期
        :param c:
        :return:
        '''

        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        #db["Z3_STK_MKT_DAY_INTER"].remove({"equity.innerCode": c["innerCode"],"end_date":{"$ne":datetime.datetime.strptime('2017-06-12', '%Y-%m-%d')},"ex_status":{"$in":[0,2,    3]}})
        #db["Z3_STK_MKT_DAY_INTER"].remove({"equity.innerCode": c["innerCode"],"ex_status":1})

        where_no_dates = ''
        where_str = ' LIMIT %s' % str(limit) if limit else ''
        where_firstday = "AND TRADEDATE>='%s'" % first_day if first_day else ''
        sql = """
            SELECT *
            FROM (
              SELECT DISTINCT TRADEDATE
              FROM STK_MKT
                        WHERE ISVALID = 1 AND INNER_CODE = '%(INNER_CODE)s'
                        AND ifnull(TVOLUME, 0) != 0
                        %(where_firstday)s
             order by tradedate desc
              %(where_str)s
            ) b  %(no_dates)s ORDER BY TRADEDATE
        """ % {"INNER_CODE": c["INNER_CODE"], "where_str": where_str, "where_firstday": where_firstday,"no_dates":where_no_dates}
        print sql
        result = self.conn.fetchall(sql)

        return result

    def get_enddate_list(self, mysql_table, c):
        c.update({"mysql_table": mysql_table})
        sql = """
            SELECT *
            FROM (

            SELECT DISTINCT ENDDATE TRADEDATE FROM %(mysql_table)s
             WHERE ISVALID=1 AND INNER_CODE = '%(INNER_CODE)s'
              AND ifnull(TVOLUME, 0) != 0

             ORDER BY TRADEDATE DESC
              LIMIT 279
            ) b ORDER BY TRADEDATE
        """ % c
        result = self.conn.fetchall(sql)

        return result

    def get_month_enddate_list(self):
        sql = """
        SELECT DISTINCT ENDDATE FROM ana_stk_mkt_month
         WHERE ISVALID=1
         ORDER BY enddate ;

        """
        result = self.conn.fetchall(sql)

        return result

    def make_Z3_EQUITY2_data(self, seccode_list, tradedate=None):
        #print 111
        min_low = lambda infolist: min([r["low_px"] for r in infolist]) if len(infolist) else None
        max_high = lambda infolist: max([r["high_px"] for r in infolist]) if len(infolist) else None
        min_close = lambda infolist: min([r["close_px"] for r in infolist]) if len(infolist) else None
        max_close = lambda infolist: max([r["close_px"] for r in infolist]) if len(infolist) else None
        # get_factor_info = lambda r: db["Z3_EX_FACTOR_ALL"].find_one(
        #     {
        #         "equity.symbol": r["STOCKCODE"],
        #         "end_date": r["EX_DIVI_DATE"],
        #     }, {"ex_factor": 1, "cum_factor": 1}
        # )
        get_factor_info = lambda r: self.conn.fetchone("""
        SELECT b.EX_FACTOR,b.CUM_FACTOR  FROM STK_CODE a,STK_EX_FACTOR b
        WHERE a.ISVALID=1  AND b.ISVALID=1 AND a.INNER_CODE=b.INNER_CODE
        AND a.COMCODE='%(COMCODE)s'
        AND b.EX_DATE='%(EX_DIVI_DATE)s'
        """ % r)
        get_factor_info_last = lambda r: self.conn.fetchone("""
        SELECT b.EX_FACTOR,b.CUM_FACTOR  FROM STK_CODE a,STK_EX_FACTOR b
        WHERE a.ISVALID=1  AND b.ISVALID=1 AND a.INNER_CODE=b.INNER_CODE
        AND a.COMCODE='%(COMCODE)s'
        AND b.EX_DATE<'%(EX_DIVI_DATE)s' ORDER BY EX_DATE DESC LIMIT 1
        """ % r)

        data_list = []
        ps_cash_bt_1year_model = """
        SELECT *
        FROM (

          SELECT
            COMCODE,
            PERIODDATE,
            EX_DIVI_DATE,
            CASE EX_DIVI_DATE WHEN NULL THEN '' ELSE year(EX_DIVI_DATE) END y,
            ifnull((CASH_BT) / 10,0) CASH_BT10
          FROM STK_DIV_INFO a
          WHERE isvalid = 1 AND PRG_CODE IN (1, 3)
                AND DIV_TYPE_CODE IN (1, 3) AND year(PERIODDATE) = year(%(tradedate)s) - 1 AND stk_type_code = 1
                AND DIR_DCL_DATE = (
            SELECT max(DIR_DCL_DATE)
            FROM STK_DIV_INFO
            WHERE isvalid = 1 AND PRG_CODE IN (1, 3)
                  AND DIV_TYPE_CODE IN (1, 3) AND YEAR(PERIODDATE) = YEAR(%(tradedate)s) - 1
                  AND a.PERIODDATE = PERIODDATE AND a.COMCODE = COMCODE
          ) AND  COMCODE=%(COMCODE)s
          UNION
          SELECT
            COMCODE,
            PERIODDATE,
            EX_DIVI_DATE,
            CASE EX_DIVI_DATE WHEN NULL THEN '' ELSE year(EX_DIVI_DATE) END y,
            ifnull((CASH_BT) / 10,0) CASH_BT10
          FROM STK_DIV_INFO
          WHERE isvalid = 1 AND PRG_CODE IN (4, 6, 29)
                AND DIV_TYPE_CODE IN (1, 3) AND YEAR(PERIODDATE) = YEAR(%(tradedate)s) - 1 AND stk_type_code = 1 AND  COMCODE=%(COMCODE)s

        ) a

         ORDER BY PERIODDATE

        """
        # net_asset
        net_asset_mic_lyr_model = """
            SELECT
            ifnull(F110301,0) F110301 ,
            ifnull(F110101,0) F110101 ,COMCODE
            FROM STK_FIN_IDX a
            WHERE RPT_DATE = ENDDATE
                  AND DATE_FORMAT(RPT_DATE, '%%Y-%%m-%%d') LIKE '%%-12-31' AND ISVALID = 1
                  AND RPT_DATE = (
              SELECT max(RPT_DATE)
              FROM STK_FIN_IDX
              WHERE RPT_DATE = ENDDATE
                    AND DATE_FORMAT(RPT_DATE, '%%Y-%%m-%%d') LIKE '%%-12-31' AND ISVALID = 1 AND COMCODE = a.COMCODE
                    AND ENDDATE<=%(tradedate)s
            ) AND COMCODE=%(COMCODE)s
        """
        cash_mic_ttm_model = """
        SELECT
          ifnull(INC_MI,0) INC_MI,
          ifnull(CAS_OPE,0) CAS_OPE
        FROM ANA_STK_TWE_IDX a
        WHERE isvalid = 1 AND ENDDATE = (
          SELECT max(ENDDATE)
          FROM ANA_STK_TWE_IDX
          WHERE isvalid = 1 AND a.COMCODE = COMCODE
          AND ENDDATE<=%(tradedate)s
        ) AND COMCODE=%(COMCODE)s
        """
        for i in seccode_list:
            i.update({"tradedate": "'%s'" % tradedate}) if tradedate else i.update({"tradedate": 'NOW()'})

            conn = tools.mongo_cursor()
            db = conn["z3dbus"]
            # lclose_week
            tmp = {}
            print '***************************************************',tradedate
            results = list(db["Z3_STK_MKT_DAY_INTER"].find({
                "equity.innerCode": i["innerCode"],
                "ex_status": 1,
                "end_date": {"$lte": pre_date(7, tradedate)}
                }, {"close_px": 1,  "_id":0}).sort("end_date", pymongo.DESCENDING).limit(1))
            # print pre_date(7,tradedate)
            # print pre_date(0,tradedate)
            tmp["lclose_week"] = float(results[0]["close_px"]) if results else None
            if not tradedate:
                results_9 = list(db["Z3_STK_MKT_DAY_INTER"].find({
                    "equity.innerCode": i["innerCode"],
                    "ex_status": 1,
                    "end_date": {"$lte": pre_date(0, tradedate)}
                    }, {"close_px": 1, "_id":0}).sort("end_date", pymongo.DESCENDING).limit(119))

                result_list = [results_9[:9], results_9[:19], results_9[:29], results_9[:59], results_9]
                low_key_list = ["%s" % k for k in [
                    "low_9day",
                    "low_19day",
                    "low_29day",
                    "low_59day",
                    "low_119day"
                ]]
                high_key_list = ["%s" % k for k in [
                    "high_9day",
                    "high_19day",
                    "high_29day",
                    "high_59day",
                    "high_119day"
                ]]
                tmp.update(dict(zip(low_key_list, map(min_close, result_list))))
                tmp.update(dict(zip(high_key_list, map(max_close, result_list))))

            results = list(db["Z3_STK_MKT_DAY_INTER"].find({
                "equity.innerCode": i["innerCode"],
                "ex_status": 1,
                "end_date": {"$lte": pre_date(0, tradedate)}
                }, {"low_px": 1, "end_date":1,"high_px": 1, "_id":0}).sort("end_date", pymongo.DESCENDING).limit(120))
            results_52 = list(db["Z3_STK_MKT_DAY_INTER"].find({
                "equity.innerCode": i["innerCode"],
                "ex_status": 1,
                "end_date": {"$gte": pre_date(364, tradedate),"$lte":  pre_date(0,tradedate)}
                }, {"low_px": 1, "high_px": 1, "_id":0}))

            result_list = [results[:10], results[:20], results[:30], results[:60], results]
            # low_key_list = [
            #     "low_10day",
            #     "low_20day",
            #     "low_30day",
            #     "low_60day",
            #     "low_120day",
            #     "low_52week",
            # ]
            low_key_list = ["%s" % k for k in [
                "low_10day",
                "low_20day",
                "low_30day",
                "low_60day",
                "low_120day"
            ]]
            high_key_list = ["%s" % k for k in [
                "high_10day",
                "high_20day",
                "high_30day",
                "high_60day",
                "high_120day"
            ]]
            tmp.update(dict(zip(low_key_list, map(min_low, result_list))))
            tmp.update(dict(zip(high_key_list, map(max_high, result_list))))
            tmp.update({"low_52week": min([r["low_px"] for r in results_52]) if results_52 else None})
            tmp.update({"high_52week": max([r["high_px"] for r in results_52]) if results_52 else None})
            # print tradedate
            # ps_cash_bt_1year
            #print ps_cash_bt_1year_model % i
            results = self.conn.fetchall(ps_cash_bt_1year_model % i)
            #print results
            #print len(results)
            if not results:
                tmp["ps_cash_bt_1year"] = 0
            elif len(results) == 1:

                tmp["ps_cash_bt_1year"] = round(float(results[0]["CASH_BT10"]), 4)
            else:
                if not results[0]["EX_DIVI_DATE"]:
                    base_ex_factor = 1
                    base_cum_factor = 1
                elif results[0]['y'] == results[1]['y']:
                    nobase = get_factor_info(results[0])
                    A = float(nobase["CUM_FACTOR"]) if nobase else 1
                    base = get_factor_info(results[1])
                    B = float(base["CUM_FACTOR"]) if base else 1
                    ps_cash_bt_1year = float(results[1]["CASH_BT10"]) + float(results[0]["CASH_BT10"]) / (B / A)
                    tmp["ps_cash_bt_1year"] = round(ps_cash_bt_1year, 4)
                    # tmp["ps_cash_bt_1year"] = ps_cash_bt_1year
                else:
                    nobase = get_factor_info(results[0])
                    A = float(nobase["CUM_FACTOR"]) if nobase else 1
                    #print "A", A
                    base = get_factor_info_last(results[0])
                    B = float(base["CUM_FACTOR"]) if base else 1
                    #print "B", B
                    #print results[0]
                    #print results[1]
                    ps_cash_bt_1year = float(results[1]["CASH_BT10"]) + float(results[0]["CASH_BT10"]) / (A / B)
                    tmp["ps_cash_bt_1year"] = round(ps_cash_bt_1year, 4)
                    # tmp["ps_cash_bt_1year"] = ps_cash_bt_1year

            # cash_ttm

            results = self.conn.fetchall(cash_mic_ttm_model % i)
            tmp["cash_ttm"] = float(results[0]["CAS_OPE"]) if results else None
            tmp["mic_ttm"] = float(results[0]["INC_MI"]) if results else None

            # net_asset,mic_lyr
            results = self.conn.fetchall(net_asset_mic_lyr_model % i)
            # tmp["net_asset"] = float(results[0]["F110301"]) if results else None
            tmp["mic_lyr"] = float(results[0]["F110101"]) if results else None
            #
            tmp = {("mkt2_idx.%s" % k): v for k, v in tmp.items()}
            if tradedate:

                close_today = db["Z3_STK_MKT_DAY_INTER"].find_one({
                    "equity.innerCode": i["innerCode"],
                    "ex_status": 1,
                    "end_date": tradedate
                }, {"close_px": 1})
                # close_today_sql = """
                #     SELECT TCLOSE close_px FROM STK_MKT
                #     WHERE INNER_CODE = %(INNER_CODE)s
                #     AND TRADEDATE = %(TRADEDATE)s
                # """
                # close_today = self.conn.fetchone(close_today_sql,
                #                                  {"INNER_CODE": i["INNER_CODE"], "TRADEDATE": tradedate})
                # if not close_today:
                #     # print tradedate, "null"
                #     return []
                close_today = float(close_today["close_px"]) if close_today else None
                for k in low_key_list:
                    # print i, close_today, tmp[i], type(tmp[i]), type(None)
                    # print type(tmp["mkt2_idx.%s" % k]), type(close_today)
                    tmp.update({
                        "mkt_idx.rela_%s" % k: None if type(tmp.get("mkt2_idx.%s" % k, None)) == type(None) or type(close_today) == type(None) else (
                            (close_today -
                             tmp[
                                 "mkt2_idx.%s" % k]) /
                            tmp[
                                "mkt2_idx.%s" % k] if tmp["mkt2_idx.%s" %k] !=0  else 0)
                    })

                for k in high_key_list:

                    tmp.update({
                        "mkt_idx.rela_%s" % k: None if type(tmp.get("mkt2_idx.%s" % k, None)) == type(None) or type(close_today) == type(None) else (
                            (close_today -
                             tmp[
                                 "mkt2_idx.%s" % k]) /
                            tmp[
                                "mkt2_idx.%s" % k] if tmp["mkt2_idx.%s" %k] !=0  else 0)
                    })

                if tmp["mkt2_idx.low_52week"]:
                    tmp.update(
                    {"mkt_idx.rela_low_52week": None if type(tmp.get("mkt2_idx.low_52week",None)) == type(None)  or type(close_today) == type(None)  else (close_today-tmp["mkt2_idx.low_52week"])/tmp["mkt2_idx.low_52week"] if tmp["mkt2_idx.low_52week"] !=0 else 0 })
                else:
                    tmp.update({"mkt_idx.rela_low_52week":0})
                if tmp["mkt2_idx.high_52week"]:
                    tmp.update(
                    {"mkt_idx.rela_high_52week": None if type(tmp.get("mkt2_idx.high_52week",None)) == type(None) or type(close_today) == type(None) else (close_today-tmp["mkt2_idx.high_52week"])/tmp["mkt2_idx.high_52week"] if tmp["mkt2_idx.high_52week"]!=0 else 0 })
                else:
                    tmp.update({"mkt_idx.rela_high_52week":0})
                tmp.update({
                    "trade_date": tradedate,
                    "innerCode": i["innerCode"],
                    "symbol": i["symbol"],
                    "name": i["name"], })
            else:
                tmp.update({"_id": i["innerCode"]})
            data_list.append(tmp)
            # print tmp
        #print 222
        return data_list

        # get_max_high = lambda

    def make_Z3_EQUITY_data(self, seccode_list, tradedate=None):
        """
        获取信号信息
        :param seccode_list:
        :return:
        """

        last5_enddate = self.get_last5_enddate(tradedate)
	#print 'a'
        # 连续上涨,连续下跌
        where_str = " AND TRADEDATE<='%s' " % tradedate if tradedate else ''
        # print where_str

        #print "ok1"
        sql_ups_and_downs_model = """
           SELECT
             sum(CASE WHEN TCLOSE > LCLOSE
               THEN 1
                 ELSE 0 END) ups,
             sum(CASE WHEN TCLOSE < LCLOSE
               THEN 1
                 ELSE 0 END) downs

           FROM
             (
               SELECT
                 TCLOSE,
                 LCLOSE
               FROM

                 STK_MKT a
               WHERE a.INNER_CODE = %(INNER_CODE)s AND a.ISVALID = 1
               %(where_str)s
               ORDER BY TRADEDATE DESC
               LIMIT 5
             ) a;
       """
        # 业绩公告前
        sql_pa_defore = """
           SELECT 1
           FROM STK_PRE_DISCLOSURE
           WHERE ACT_DATE IS NULL AND ifnull(ifnull(CHNG_DATE3, ifnull(CHNG_DATE2, CHNG_DATE1)),PRE_DATE) <date_add(now(),INTERVAL 30 DAY)  AND ISVALID = 1 AND COMCODE=%(COMCODE)s
           LIMIT 1;
       """
        if tradedate:
            sql_pa_defore = """
                SELECT 1
                FROM STK_PRE_DISCLOSURE
                WHERE ACT_DATE  <date_add('%(tradedate)s',INTERVAL 30 DAY)
                AND  ACT_DATE  >'%(tradedate)s'
                AND ISVALID = 1 AND COMCODE=%%(COMCODE)s
                AND date_add(perioddate,INTERVAL 122 DAY)>'%(tradedate)s'
                AND '%(tradedate)s'> perioddate
                LIMIT 1;
            """ % {"tradedate": tradedate}
        # 业绩公告后
        sql_pa_after = """
           SELECT 1
           FROM STK_PRE_DISCLOSURE
           WHERE ACT_DATE > date_sub(now(),INTERVAL 30 DAY)  AND ISVALID = 1 AND COMCODE=%(COMCODE)s
           LIMIT 1;
       """
        if tradedate:
            sql_pa_after = """
               SELECT 1
               FROM STK_PRE_DISCLOSURE
               WHERE ACT_DATE > date_sub('%(tradedate)s',INTERVAL 30 DAY)  AND ISVALID = 1 AND COMCODE=%%(COMCODE)s

                AND '%(tradedate)s'> ACT_DATE
                AND date_add(perioddate,INTERVAL 122 DAY)>'%(tradedate)s'
                AND '%(tradedate)s'> perioddate
               LIMIT 1;
            """ % {"tradedate": tradedate}
        # 近期内部买入
        sql_inner_buy = """
       SELECT 1
       FROM STK_MNG_TRADE_INFO a
       WHERE a.ISVALID = 1
             AND COMCODE = %(COMCODE)s
             AND a.STK_CODE = %(symbol)s
             AND RELATION = '本人'
             AND CHNG_DATE > date_sub(CURRENT_DATE(),INTERVAL 30 DAY)
             AND CHNG_DATE <= CURRENT_DATE()
             AND CHNG_VOL > 0 LIMIT 1

       """
        if tradedate:
            sql_inner_buy = """
           SELECT 1
           FROM STK_MNG_TRADE_INFO a
           WHERE a.ISVALID = 1
                 AND COMCODE = %%(COMCODE)s
                 AND a.STK_CODE = %%(symbol)s
                 AND RELATION = '本人'
                 AND CHNG_DATE > date_sub('%(tradedate)s',INTERVAL 30 DAY)
                 AND CHNG_DATE <= '%(tradedate)s'
                 AND CHNG_VOL > 0 LIMIT 1

            """ % {"tradedate": tradedate}
        # 近期内部卖出
        sql_inner_sell = """
       SELECT 1
       FROM STK_MNG_TRADE_INFO a
       WHERE a.ISVALID = 1
             AND COMCODE = %(COMCODE)s
             AND a.STK_CODE = %(symbol)s
             AND RELATION = '本人'
             AND CHNG_DATE > date_sub(CURRENT_DATE(),INTERVAL 30 DAY)
             AND CHNG_DATE <= CURRENT_DATE()
             AND CHNG_VOL < 0 LIMIT 1
       """
        if tradedate:
            sql_inner_sell = """
           SELECT 1
           FROM STK_MNG_TRADE_INFO a
           WHERE a.ISVALID = 1
                 AND COMCODE = %%(COMCODE)s
                 AND a.STK_CODE = %%(symbol)s
                 AND RELATION = '本人'
                 AND CHNG_DATE > date_sub('%(tradedate)s',INTERVAL 30 DAY)
                 AND CHNG_DATE <= '%(tradedate)s'
                 AND CHNG_VOL < 0 LIMIT 1

            """ % {"tradedate": tradedate}
        # 重大事项
        sql_majorissue = """
    SELECT 1
    FROM STK_GREATE_EVENT
    WHERE isvalid = 1 AND DECLAREDATE >= %(last5_enddate)s AND EVENT_CODE IN (1, 2, 3, 4, 5, 8, 10) AND
          (ORG_CODE = %(COMCODE)s OR stockcode = %(symbol)s)
    UNION
    SELECT 1
    FROM STK_REPURCHASE
    WHERE isvalid = 1 AND comcode = %(COMCODE)s AND DECLAREDATE >= %(last5_enddate)s
    UNION
    SELECT 1
    FROM STK_TENDER_OFFER_INFO
    WHERE
      isvalid = 1 AND comcode = %(COMCODE)s AND FIRST_DATE >= %(last5_enddate)s
    UNION
    SELECT 1
    FROM STK_MERG_INFO
    WHERE isvalid = 1 AND comcode = %(COMCODE)s AND DECLAREDATE >= %(last5_enddate)s LIMIT 1;
       """
        # 近期机构买入
        sql_ins_buy = """
       SELECT 1
       FROM STK_ADD_HOLD a
         JOIN ORG_PROFILE b ON a.ADD_CODE = b.ORGCODE AND b.ORG_TYPE NOT IN (700, 800)
       WHERE
         a.ISVALID = 1 AND b.ISVALID = 1
         AND a.comcode = %(COMCODE)s
         AND ADD_SUB_TYPE = 1 AND ACTU_DATE > date_sub(CURRENT_DATE(),INTERVAL 30 DAY)
         AND ACTU_DATE <= CURRENT_DATE()
       UNION
       SELECT 1
       FROM STK_EXCRA_INFO_MAIN a
         JOIN STK_EXCRA_BRANCH_LIST b ON a.seq = b.p_seq
       WHERE a.ISVALID = 1 AND b.ISVALID = 1
             AND a.INNER_CODE = %(INNER_CODE)s
             AND a.RANK_CLS = 1 AND b.BRANCH_CODE = 200513872 AND ENDDATE > date_sub(CURRENT_DATE(),INTERVAL 30 DAY)
             AND ENDDATE <= CURRENT_DATE()
       LIMIT 1;

       """
        if tradedate:
            sql_ins_buy = """
           SELECT 1
           FROM STK_ADD_HOLD a
             JOIN ORG_PROFILE b ON a.ADD_CODE = b.ORGCODE AND b.ORG_TYPE !=700 AND b.ORG_TYPE !=800
           WHERE
             a.ISVALID = 1 AND b.ISVALID = 1
             AND a.comcode = %%(COMCODE)s
             AND ADD_SUB_TYPE = 1 AND ACTU_DATE > date_sub('%(tradedate)s',INTERVAL 30 DAY)
             ACTU_DATE <= '%(tradedate)s'
            union
           SELECT 1
           FROM STK_EXCRA_INFO_MAIN a
             JOIN STK_EXCRA_BRANCH_LIST b ON a.seq = b.p_seq
           WHERE a.ISVALID = 1 AND b.ISVALID = 1
                 AND a.INNER_CODE = %%(INNER_CODE)s
                 AND a.RANK_CLS = 1 AND b.BRANCH_CODE = 200513872 AND ENDDATE > date_sub('%(tradedate)s',INTERVAL 30 DAY)
                 AND ENDDATE <= '%(tradedate)s'
           LIMIT 1;

            """ % {"tradedate": tradedate}

        # 近期机构卖出
        sql_ins_sell = """
       SELECT 1
       FROM STK_ADD_HOLD a
         JOIN ORG_PROFILE b ON a.ADD_CODE = b.ORGCODE AND b.ORG_TYPE NOT IN (700, 800)
       WHERE
         a.ISVALID = 1 AND b.ISVALID = 1
         AND a.comcode = %(COMCODE)s
         AND ADD_SUB_TYPE = 2 AND ACTU_DATE > date_sub(CURRENT_DATE(),INTERVAL 30 DAY)
         AND ACTU_DATE <= CURRENT_DATE()

       UNION
       SELECT 1
       FROM STK_EXCRA_INFO_MAIN a
         JOIN STK_EXCRA_BRANCH_LIST b ON a.seq = b.p_seq
       WHERE a.ISVALID = 1 AND b.ISVALID = 1
             AND a.INNER_CODE = %(INNER_CODE)s
             AND a.RANK_CLS = 2 AND b.BRANCH_CODE = 200513872 AND ENDDATE > date_sub(CURRENT_DATE(),INTERVAL 30 DAY)
             AND ENDDATE <= CURRENT_DATE()
       LIMIT 1;
       """
        if tradedate:
            sql_ins_sell = """
           SELECT 1
           FROM STK_ADD_HOLD a
             JOIN ORG_PROFILE b ON a.ADD_CODE = b.ORGCODE AND b.ORG_TYPE !=700 AND b.ORG_TYPE !=800
           WHERE
             a.ISVALID = 1 AND b.ISVALID = 1
             AND a.comcode = %%(COMCODE)s
             AND ADD_SUB_TYPE = 2 AND ACTU_DATE > date_sub('%(tradedate)s',INTERVAL 30 DAY)
             AND ACTU_DATE <= '%(tradedate)s'
            union
           SELECT 1
           FROM STK_EXCRA_INFO_MAIN a
             JOIN STK_EXCRA_BRANCH_LIST b ON a.seq = b.p_seq
           WHERE a.ISVALID = 1 AND b.ISVALID = 1
                 AND a.INNER_CODE = %%(INNER_CODE)s
                 AND a.RANK_CLS = 2 AND b.BRANCH_CODE = 200513872 AND ENDDATE > date_sub('%(tradedate)s',INTERVAL 30 DAY)
                 AND ENDDATE <= '%(tradedate)s'
           LIMIT 1;

            """ % {"tradedate": tradedate}


        # 波动最大 获取Z3_EQUITY 5% 的 stockcode
        #print 'cc'
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        if tradedate:
            count = db[self.ttable].find(
                {"trade_date": tradedate}
            ).count() * 5 / 100
        else:
            count = db["Z3_EQUITY"].count() * 5 / 100
	#print 'b'
        filter = {}
        if tradedate:
            filter = {"trade_date": tradedate}
        wave_list = db[self.ttable].find(
                filter, {"symbol": 1, "_id":0}
        ).sort("perf_idx.volat_mon", pymongo.DESCENDING).limit(count)
        wave_list = [k["symbol"] for k in wave_list if "symbol" in k]
        wave_list = list(set(wave_list))
        result = []
        #print "ok2"
        #print len(seccode_list)
        for i in seccode_list:
            filter = {"symbol": i["symbol"]}
            #print 'zzzzz'
            if tradedate:
                filter.update({"trade_date": tradedate})
            baseinfo = db[self.ttable].find_one(filter)
            baseinfo = baseinfo if baseinfo else {}
            tmp = {}
            i.update({"where_str": where_str})
            i.update({"tradedate": tradedate})
            i.update({"last5_enddate": last5_enddate})
            raw = self.conn.fetchone(sql_ups_and_downs_model % i)
            #print '+++'
            tmp["signal_normal_10"] = True if raw["ups"] == 5 else False
            tmp["signal_normal_11"] = True if raw["downs"] == 5 else False
            raw = self.conn.fetchone(sql_pa_defore, i)
            tmp["signal_normal_12"] = True if raw else False

            #print"uuu"
            raw = self.conn.fetchone(sql_pa_after, i)
            #print"ooo"
            tmp["signal_normal_13"] = True if raw else False
            raw = self.conn.fetchone(sql_inner_buy, i)
            #print 'ppp'
            tmp["signal_normal_14"] = True if raw else False

            #print 'qqq'
            raw = self.conn.fetchone(sql_inner_sell, i)
            #print 'hhh'

            tmp["signal_normal_15"] = True if raw else False
            #print 'iii'

            raw = self.conn.fetchone(sql_majorissue, i)
            #print 'fffu'

            tmp["signal_normal_16"] = True if raw else False

            raw = self.conn.fetchone(sql_ins_buy, i)
            #print 'jjj'

            tmp["signal_normal_18"] = True if raw else False
            #print 'kkk'

            raw = self.conn.fetchone(sql_ins_sell, i)
            tmp["signal_normal_19"] = True if raw else False

            tmp["signal_normal_5"] = True if i["symbol"] in wave_list else False
            # 市场同步
            # print baseinfo
            tmp["signal_normal_32"] = True if 0.95 < baseinfo.get("perf_idx", {}).get("beta", 0) < 1.05 else False
            cp = baseinfo.get("perf_idx", {}).get("close_px", None)
            ps_cash = baseinfo.get("mkt2_idx", {}).get("ps_cash_bt_1year",0)

            if cp and str(ps_cash).isdigit():
                cp = float(cp)

                tmp["signal_normal_33"] = True if ps_cash / cp * 100 > 2 else False
            else:
                tmp["signal_normal_33"] = None

            # 买入或增持
            tmp["signal_normal_34"] = True if baseinfo.get("fcst_idx", {}).get("rating_syn", 0) in [1, 2] else False
            # 卖出或减持
            tmp["signal_normal_35"] = True if baseinfo.get("fcst_idx", {}).get("rating_syn", 0) in [4, 5] else False

            tmp = {("signal_normal.%s" % i): tmp[i] for i in tmp}
            if tradedate:
                tmp["innerCode"] = i["innerCode"]
                tmp["trade_date"] = tradedate
            else:
                tmp["_id"] = i["innerCode"]
            #print tmp
            result.append(tmp)

        #print "ok3"
        return result

    def get_indx_code_list(self):
        sql = """
        SELECT DISTINCT INDX_CODE FROM INDX_GEN_INFO  b WHERE b.isvalid = 1
        """
        return self.conn.fetchall(sql)

    def make_Z3_EXCHANGE_CALENDAR_data(self, offset, limit):
        where_str = self._make_where("", ["a", ])
        sql = """
        SELECT
          CONVERT(date_format(ENDDATE, '%%Y%%m%%d'),SIGNED) AS trade_date,
          CASE WHEN MKT_TYPE = 1
            THEN 'SZ'
          WHEN MKT_TYPE = 2
            THEN 'SH' END AS exchange,
          OPEN_CLOSE      AS open_close
        FROM PUB_EXCHANGE_CALENDAR a
        WHERE isvalid = 1 AND MKT_TYPE IN (1, 2) %(where_str)s LIMIT %(offset)s,%(limit)s
        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        results = self.conn.fetchall(sql)
        return results


    def make_Z3_INDEX_SAMPLE_data(self, i):
        """
        生成 指数样本表 表数据
        :return:
        """
        where_str = self._make_where("INNER_CODE", ["a", "b", "c", "d"])
        where_str = ''

        sql = """
        SELECT
        CASE b.PUB_ORG WHEN 200021616 THEN CONCAT(b.INDX_CODE,'.SH') WHEN 200021637 THEN CONCAT(b.INDX_CODE,'.SZ') ELSE (CASE b.INDX_CODE WHEN '000852' THEN '000852.SH'         ELSE b.INDX_CODE END) END _id,

          b.INDX_SNAME AS name,
          CASE c.TRADE_MKT_REF WHEN 1 THEN CONCAT(c.STOCKCODE,'.SZ') ELSE CONCAT(c.STOCKCODE,'.SH') END AS samples_innerCode,
          c.STOCKCODE  AS samples_symbol,
          c.STOCKSNAME AS samples_name

        FROM INDX_SAMP_INFO a
          JOIN INDX_GEN_INFO b ON a.INNER_CODE = b.INNER_CODE
          JOIN STK_CODE c ON a.SEC_INNER_CODE = c.INNER_CODE

        WHERE a.isvalid = 1 AND b.isvalid = 1 AND c.isvalid = 1 and c.STK_TYPE_REF=1 AND c.stk_type_ref = 1
              AND ifnull(a.STARTDATE, '1900-01-01') <= now()
              AND ifnull(a.ENDDATE, '2999-12-31') > now()
              AND b.INDX_CODE='%(INDX_CODE)s'
              %(where_str)s

        """ % {"where_str": where_str, "INDX_CODE": i["INDX_CODE"]}
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["_id"]
            tmp.setdefault(
                key, {
                    "_id": row["_id"],
                    "name": row["name"],
                    "samples": []
                })
            tmp[key]["samples"].append({
                "innerCode": row["samples_innerCode"],
                "symbol": row["samples_symbol"],
                "name": row["samples_name"],
            })
        return tmp.values()


    def make_Z3_INDEX_SAMPLE_data_bak(self, offset, limit):
        """
        生成 指数样本表 表数据
        :return:
        """
        where_str = self._make_where("INNER_CODE", ["a", "b", "c", "d"])
        sql = """
        SELECT
          b.INDX_CODE  AS symbol,
          b.INDX_SNAME AS name,
          d.sec_uni_id AS samples_innerCode,
          c.STOCKCODE  AS samples_symbol,
          c.STOCKSNAME AS samples_name

        FROM INDX_SAMP_INFO a
          JOIN INDX_GEN_INFO b ON a.INNER_CODE = b.INNER_CODE
          JOIN STK_CODE c ON a.SEC_INNER_CODE = c.INNER_CODE
          JOIN pgznty.z3_sec_cons d ON c.INNER_CODE = d.INNER_CODE
        WHERE a.isvalid = 1 AND b.isvalid = 1 AND c.isvalid = 1 AND d.isvalid = 1
              AND ifnull(a.STARTDATE, '1900-01-01') <= now()
              AND ifnull(a.ENDDATE, '2999-12-31') > now()
              %(where_str)s
              # Limit %(offset)s,%(limit)s

        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["symbol"]
            tmp.setdefault(
                key, {
                    "symbol": row["symbol"],
                    "name": row["name"],
                    "samples": []
                })
            tmp[key]["samples"].append({
                "innerCode": row["samples_innerCode"],
                "symbol": row["samples_symbol"],
                "name": row["samples_name"],
            })
        return tmp.values()

    @cache
    def DAY_INTER_base(self, tradedate, inner_code):
        """
        获取某支股票的日级基础信息
        :return:
        """
        sql = """
        SELECT
        CASE c.TRADE_MKT_REF WHEN 1 THEN CONCAT(c.STOCKCODE,'.SZ') ELSE CONCAT(c.STOCKCODE,'.SH') END innerCode,
        a.TRADEDATE  end_date,
        0            ex_status,
        c.STOCKCODE  symbol,
        c.STOCKSNAME name,
        1            cum_factor_inter,
        round(a.TOPEN,2)      open_px,
        round(a.THIGH,2)      high_px,
        round(a.TLOW,2)       low_px,
        round(a.TCLOSE,2)     close_px,
        round(a.LCLOSE,2)     prev_close_px,
        round(a.CHNG,2)       chg,
        round(a.CHNG_PCT,4)   chg_pct,
        round(a.TVOLUME,0)    volume,
        round(a.TVALUE,4)     amount
        FROM STK_MKT a
          JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE AND c.STK_TYPE_REF=1
        WHERE a.ISVALID = 1 AND c.ISVALID = 1
        AND TRADEDATE=%(tradedate)s AND a.INNER_CODE=%(inner_code)s
        ORDER BY a.TRADEDATE DESC;
           """

        try:

            results = self.conn.fetchone(sql, {"tradedate": tradedate, "inner_code": inner_code})
        except Exception, e:
            print e
            return self.DAY_INTER_base(tradedate, inner_code)

        return results

    def WEEK_INTER_base(self, tradedate, inner_code, mysql_table):
        """
        周行情表基础数据
        :return:
        """
        sql = """
        SELECT
        CASE c.TRADE_MKT_REF WHEN 1 THEN CONCAT(c.STOCKCODE,'.SZ') ELSE CONCAT(c.STOCKCODE,'.SH') END innerCode,
        a.ENDDATE  end_date,
        0            ex_status,
        c.STOCKCODE  symbol,
        c.STOCKSNAME name,
        a.FIRST_TRADE_DATE first_trade_date,
        a.LAST_TRADE_DATE last_trade_date,
        a.FAC_THIGH_DATE thigh_date,
        a.FAC_TLOW_DATE tlow_date,
        round(a.TOPEN,2) open_px,
        round(a.THIGH,2)      high_px,
        round(a.TLOW,2)       low_px,
        round(a.TCLOSE,2)     close_px,
        round(a.CHNG_PCT,4)   chg_pct,
        a.TVOLUME    volume,
        a.TVALUE     amount

        FROM %(mysql_table)s a

          JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE and c.STK_TYPE_REF=1
        WHERE a.ISVALID = 1 AND c.ISVALID = 1
        AND ENDDATE='%(tradedate)s' AND a.INNER_CODE='%(inner_code)s'
        AND ifnull(TVOLUME,0)!=0
        ORDER BY a.ENDDATE DESC;
           """ % {"tradedate": tradedate,
                  "inner_code": inner_code,
                  "mysql_table": mysql_table}
        results = self.conn.fetchall(sql)
        # print results, "------------"
        return results

    def make_Z3_TOPIC_SAMPLE_data(self, offset, limit):
        """
        生成 概念板块样本表 表数据
        :return:
        """

        where_str = self._make_where("INNER_CODE", ["a", "b", "c", "d"])
        sql = """
         SELECT
          b.SECTION_CODE AS topic_code,
          b.SECTION_NAME AS topic_name,
          d.SEC_UNI_ID AS innerCode,
          c.STOCKCODE AS symbol,
          c.STOCKSNAME AS name
         FROM PUB_SECTION_CODE b
          LEFT JOIN  PUB_SECTION_REL a ON a.isvalid = 1 AND a.SECTION_CODE = b.SECTION_CODE  AND ifnull(a.EN_TIME, '1900-01-01') <= now() AND ifnull(a.REJE_TIME, '2999-12-31') > now()
          LEFT JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE AND c.isvalid = 1
          LEFT JOIN pgznty.z3_sec_cons d ON a.INNER_CODE = d.INNER_CODE AND d.isvalid = 1

        WHERE  b.isvalid = 1 AND b.sys_code = 5 %(where_str)s

        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        #print sql
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["topic_code"]
            tmp.setdefault(
                key, {
                    "topic_code": row["topic_code"],
                    "topic_name": row["topic_name"],
                    "samples": []
                })
            tmp[key]["samples"].append({
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
            })
        for pid in tmp.keys():
            # 获取 该主题的所有子主题
            child_topics = self.get_topic_childs(pid)
            for cid in child_topics:
                tmp[pid]["samples"].extend([i for i in tmp[cid]["samples"] if i not in tmp[pid]["samples"]])
        return tmp.values()

    def get_topic_childs(self, pid):
        tmp = []
        sql = """
          SELECT SECTION_CODE
          FROM PUB_SECTION_CODE
          WHERE PARENT_CODE = %s AND ISVALID = 1
        """ % pid
        result = self.conn.fetchall(sql)
        # tmp = [i["SECTION_CODE"] for i in result]
        for i in result:
            cid = i["SECTION_CODE"]
            tmp.append(cid)
            # 递归获取子主题
            tmp.extend(self.get_topic_childs(cid))
        return tmp

    def update_sum_bak(self, row, data120):
        data119 = data120[:119]
        data59 = data120[:59]
        data29 = data120[:29]
        data19 = data120[:19]
        data9 = data120[:9]
        data4 = data120[:4]
        # if len(data119) == 119:
        #     print len(data119)
        row["SUM119"] = None if len(data119) < 119 else round(sum([i["close_px"] for i in data119]), 2)
        row["SUM59"] = None if len(data59) < 59 else round(sum([i["close_px"] for i in data59]), 2)
        row["SUM29"] = None if len(data29) < 29 else round(sum([i["close_px"] for i in data29]), 2)
        row["SUM19"] = None if len(data19) < 19 else round(sum([i["close_px"] for i in data19]), 2)
        row["SUM9"] = None if len(data9) < 9 else round(sum([i["close_px"] for i in data9]), 2)
        row["SUM4"] = None if len(data4) < 4 else round(sum([i["close_px"] for i in data4]), 2)

    def update_sum_non_cur(self, row, data250):

        data249 = data250[:249]
        data119 = data249[:119]
        data59 = data119[:59]
        data29 = data59[:29]
        data19 = data29[:19]
        data9 = data19[:9]
        data4 = data9[:4]
        # if len(data119) == 119:
        #     print len(data119)
        row["sum249_non_cur"] = None if len(data249) < 249 else round(sum([i["close_px"] for i in data249]), 2)
        row["sum119_non_cur"] = None if len(data119) < 119 else round(sum([i["close_px"] for i in data119]), 2)
        row["sum59_non_cur"] = None if len(data59) < 59 else round(sum([i["close_px"] for i in data59]), 2)
        row["sum29_non_cur"] = None if len(data29) < 29 else round(sum([i["close_px"] for i in data29]), 2)
        row["sum19_non_cur"] = None if len(data19) < 19 else round(sum([i["close_px"] for i in data19]), 2)
        row["sum9_non_cur"] = None if len(data9) < 9 else round(sum([i["close_px"] for i in data9]), 2)
        row["sum4_non_cur"] = None if len(data4) < 4 else round(sum([i["close_px"] for i in data4]), 2)

    def update_mas(self, row, data250):

        data120 = data250[:120]
        data60 = data120[:60]
        data30 = data60[:30]
        data20 = data30[:20]
        data10 = data20[:10]
        data5 = data10[:5]
        row["ma250"] = None if len(data250) < 250 else round(sum([i["close_px"] for i in data250]) / 250, 2)
        row["ma120"] = None if len(data120) < 120 else round(sum([i["close_px"] for i in data120]) / 120, 2)
        row["ma60"] = None if len(data60) < 60 else round(sum([i["close_px"] for i in data60]) / 60, 2)
        row["ma30"] = None if len(data30) < 30 else round(sum([i["close_px"] for i in data30]) / 30, 2)
        row["ma20"] = None if len(data20) < 20 else round(sum([i["close_px"] for i in data20]) / 20, 2)
        row["ma10"] = None if len(data10) < 10 else round(sum([i["close_px"] for i in data10]) / 10, 2)
        row["ma5"] = None if len(data5) < 5 else round(sum([i["close_px"] for i in data5]) / 5, 2)



    def update_sums(self,row,data250):
        data249 = data250[:249]
        data119 = data249[:119]
        data59 = data119[:59]
        data29 = data59[:29]
        data19 = data29[:19]
        data9 = data19[:9]
        data4 = data9[:4]


        row["sum249"] = None if len(data249) < 249 else round(sum([i["close_px"] for i in data249]), 2)
        row["sum119"] = None if len(data119) < 119 else round(sum([i["close_px"] for i in data119]), 2)
        row["sum59"] = None if len(data59) < 59 else round(sum([i["close_px"] for i in data59]), 2)
        row["sum29"] = None if len(data29) < 29 else round(sum([i["close_px"] for i in data29]), 2)
        row["sum19"] = None if len(data19) < 19 else round(sum([i["close_px"] for i in data19]), 2)
        row["sum9"] = None if len(data9) < 9 else round(sum([i["close_px"] for i in data9]), 2)
        row["sum4"] = None if len(data4) < 4 else round(sum([i["close_px"] for i in data4]), 2)



    def update_sum(self,row,data250):
        data249 = data250[:249]
        data119 = data249[:119]
        data59 = data119[:59]
        data29 = data59[:29]
        data19 = data29[:19]
        data9 = data19[:9]
        data4 = data9[:4]
        # if len(data119) == 119:
        #     print len(data119)
        row["SUM249"] = None if len(data249) < 249 else round(sum([i["close_px"] for i in data249]), 2)
        row["SUM119"] = None if len(data119) < 119 else round(sum([i["close_px"] for i in data119]), 2)
        row["SUM59"] = None if len(data59) < 59 else round(sum([i["close_px"] for i in data59]), 2)
        row["SUM29"] = None if len(data29) < 29 else round(sum([i["close_px"] for i in data29]), 2)
        row["SUM19"] = None if len(data19) < 19 else round(sum([i["close_px"] for i in data19]), 2)
        row["SUM9"] = None if len(data9) < 9 else round(sum([i["close_px"] for i in data9]), 2)
        row["SUM4"] = None if len(data4) < 4 else round(sum([i["close_px"] for i in data4]), 2)

    def update_ma_bak(self, row, data120):
        # print "len(data120)",len(data120)
        row["MA120"] = None if len(data120) < 120 else round(sum([i["close_px"] for i in data120]) / 120, 2)
        data60 = data120[:60]
        row["MA60"] = None if len(data60) < 60 else round(sum([i["close_px"] for i in data60]) / 60, 2)
        data30 = data120[:30]
        row["MA30"] = None if len(data30) < 30 else round(sum([i["close_px"] for i in data30]) / 30, 2)
        data20 = data120[:20]
        row["MA20"] = None if len(data20) < 20 else round(sum([i["close_px"] for i in data20]) / 20, 2)
        data10 = data120[:10]
        row["MA10"] = None if len(data10) < 10 else round(sum([i["close_px"] for i in data10]) / 10, 2)
        data5 = data120[:5]
        row["MA5"] = None if len(data5) < 5 else round(sum([i["close_px"] for i in data5]) / 5, 2)

    def update_ma(self, row, data250):
        # print "len(data120)",len(data120)
        data120 = data250[:120]
        data60 = data120[:60]
        data30 = data60[:30]
        data20 = data30[:20]
        data10 = data20[:10]
        data5 = data10[:5]
        row["MA250"] = None if len(data250) < 250 else round(sum([i["close_px"] for i in data250]) / 250, 2)
        row["MA120"] = None if len(data120) < 120 else round(sum([i["close_px"] for i in data120]) / 120, 2)
        row["MA60"] = None if len(data60) < 60 else round(sum([i["close_px"] for i in data60]) / 60, 2)
        row["MA30"] = None if len(data30) < 30 else round(sum([i["close_px"] for i in data30]) / 30, 2)
        row["MA20"] = None if len(data20) < 20 else round(sum([i["close_px"] for i in data20]) / 20, 2)
        row["MA10"] = None if len(data10) < 10 else round(sum([i["close_px"] for i in data10]) / 10, 2)
        row["MA5"] = None if len(data5) < 5 else round(sum([i["close_px"] for i in data5]) / 5, 2)

    def get_week_120(self, db, row, table):
        # return []
        data120 = db[table].find({
            "equity.innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": row["end_date"]}
            }, {"close_px": 1, "_id":0})
        data120.sort([
            ('end_date', pymongo.DESCENDING)]).limit(119)
        data120 = list(data120)
        data120.insert(0,{"close_px": row["close_px"]})
        return data120

    def get_week_121(self, db, row, table):
        # return []
        data120 = db[table].find({
            "innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": int(row["end_date"].strftime("%Y%m%d"))}
            }, {"close_px": 1, "_id":0})
        data120.sort([
            ('end_date', pymongo.DESCENDING)]).limit(120)
        data120 = list(data120)
        data120.insert(0,{"close_px": row["close_px"]})
        return data120


    def get_day_new_120(self, db, row):
        #print row
        datas = db["Z3_STK_MKT_DAY_INTER_NEW"].find({
            "innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": int(row["end_date"].strftime("%Y%m%d"))}
            }, {"close_px": 1, "_id":0})

        datas.sort([
            ('end_date', pymongo.DESCENDING)]).limit(119)
        datas = list(datas)
        datas.insert(0,{"close_px": row["close_px"]})
        return datas

    def get_day_120(self, db, row):
        #print row
        datas = db["Z3_STK_MKT_DAY_INTER"].find({
            "equity.innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": row["end_date"]}
            }, {"close_px": 1, "_id":0})
        datas.sort([
            ('end_date', pymongo.DESCENDING)]).limit(119)
        datas = list(datas)
        datas.insert(0,{"close_px": row["close_px"]})
        return datas


    def get_day_new_250(self, db, row):

        datas = db["Z3_STK_MKT_DAY_INTER_NEW"].find({
           "innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": int(row["end_date"].strftime("%Y%m%d"))}
            }, {"close_px": 1, "_id":0})
        datas.sort([
            ('end_date', pymongo.DESCENDING)]).limit(249)
        datas = list(datas)
        datas.insert(0,{"close_px": row["close_px"]})
        return datas



    def get_day_250(self, db, row):
        datas = db["Z3_STK_MKT_DAY_INTER"].find({
            "equity.innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": row["end_date"]}
            }, {"close_px": 1, "_id":0})
        datas.sort([
            ('end_date', pymongo.DESCENDING)]).limit(249)
        datas = list(datas)
        datas.insert(0,{"close_px": row["close_px"]})
        return datas


    def get_factor_day_between(self, symbol, start_date,  end_date):
        # 替换symbol
        cursor = tools.mongo_cursor()
        db = cursor["z3dbus"]

        info = db["Z3_EX_FACTOR_ALL"].find(
                {
                    "equity.symbol": symbol,
                    "end_date": {"$gte":start_date,"$lte":end_date},
                    "ex_factor_today":{"$ne":1}
            }).count()
        return 1.1 if info else 1


    def get_factor_day(self, symbol, end_date):
        # 替换symbol
        cursor = tools.mongo_cursor()
        db = cursor["z3dbus"]
        try:
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.symbol": symbol,
                    "end_date": end_date
                })
            if info:

                return info["ex_factor_today"] if info["ex_factor_today"]  else 1
            else:
                return 1
        except Exception, e:
            print e
            return self.get_factor_day(symbol, end_date)

    def make_Z3_STK_MKT_DAY_INTER_NEW_data(self, tradedate, code, mongo_table='', mysql_table=''):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        result = copy.deepcopy(self.DAY_INTER_base(tradedate, code))

        if not result:
            print code, "no results"
            return []
        sql_tradedate_list_model = """
                SELECT
                  TRADEDATE
                FROM STK_MKT a
                WHERE a.ISVALID = 1
                      AND a.INNER_CODE = %(INNER_CODE)s
                      AND ifnull(TVOLUME, 0) != 0
                ORDER BY TRADEDATE DESC
                LIMIT 279;
            """
        tmp = {}
        result = [result, ]

        result_1 = []
        result_2 = []
        result_3 = []
        for row in result:
            # 获取历史279交易日列表 128ms
            tradedate_list = self.conn.fetchall(sql_tradedate_list_model, {"INNER_CODE": code})
            # 获取计算所需数据
            tmp = {}
            # print row["trade_date"]
            tmp["end_date"] = row["end_date"]
            tmp["DATE_MAX"] = tradedate_list[0]["TRADEDATE"]
            tmp["DATE_MIN_60"] = tradedate_list[:179][-1]["TRADEDATE"]
            tmp["DATE_MIN_160"] = tradedate_list[:279][-1]["TRADEDATE"]

            # 获取计算的交易日的复权因子信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["end_date"]
                })
            if not self.check_info(info,row,tmp["end_date"]):return []
            tmp["CUM_FAC"] = info["cum_factor"] if info else 1
            tmp["EX_FAC"] = info["ex_factor_today"] if info else 1
            # 获取最大交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MAX"]
                })
            if not self.check_info(info,row,tmp["DATE_MAX"]):return []
            # print info
            tmp["CUM_FAC_MAX"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MAX"] = info["ex_factor"] if info else 1
            # 获取前60交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MIN_60"]
                })
            if not self.check_info(info,row,tmp["DATE_MIN_60"]):return []
            # print info
            tmp["CUM_FAC_MIN_60"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MIN_60"] = info["ex_factor"] if info else 1
            # 获取前160交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MIN_160"]
                })
            if not self.check_info(info,row,tmp["DATE_MIN_160"]):return []
            # print info
            tmp["CUM_FAC_MIN_160"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MIN_160"] = info["ex_factor"] if info else 1
            # 计算前复权,后复权60，后复权160 数据
            row_1 = copy.deepcopy(row)
            row_2 = copy.deepcopy(row)
            row_3 = copy.deepcopy(row)
            rows = [row, row_1, row_2, row_3]
            for index, rr in enumerate(rows):
                rr["ex_status"] = index

            CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["end_date"] else tmp["CUM_FAC_MAX"] / tmp["CUM_FAC"]
            CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_60"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
                "CUM_FAC_MIN_60"]
            CUM_FACTOR_AFT_160 = 1 if tmp["DATE_MIN_160"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
                "CUM_FAC_MIN_160"]

            row_1["cum_factor_inter"] = CUM_FACTOR_BEF
            row_2["cum_factor_inter"] = CUM_FACTOR_AFT_60
            row_3["cum_factor_inter"] = CUM_FACTOR_AFT_160
            row_1["open_px"] = round(row_1["open_px"] / row_1["cum_factor_inter"], 2)
            row_2["open_px"] = round(row_2["open_px"] * row_2["cum_factor_inter"], 2)
            row_3["open_px"] = round(row_3["open_px"] * row_3["cum_factor_inter"], 2)
            row_1["high_px"] = round(row_1["high_px"] / row_1["cum_factor_inter"], 2)
            row_2["high_px"] = round(row_2["high_px"] * row_2["cum_factor_inter"], 2)
            row_3["high_px"] = round(row_3["high_px"] * row_3["cum_factor_inter"], 2)
            row_1["low_px"] = round(row_1["low_px"] / row_1["cum_factor_inter"], 2)
            row_2["low_px"] = round(row_2["low_px"] * row_2["cum_factor_inter"], 2)
            row_3["low_px"] = round(row_3["low_px"] * row_3["cum_factor_inter"], 2)
            row_1["close_px"] = round(row_1["close_px"] / row_1["cum_factor_inter"], 2)
            row_2["close_px"] = round(row_2["close_px"] * row_2["cum_factor_inter"], 2)
            row_3["close_px"] = round(row_3["close_px"] * row_3["cum_factor_inter"], 2)
            row_1["prev_close_px"] = round(row_1["prev_close_px"] / row_1["cum_factor_inter"], 2)
            row_2["prev_close_px"] = round(row_2["prev_close_px"] * row_2["cum_factor_inter"], 2)
            row_3["prev_close_px"] = round(row_3["prev_close_px"] * row_3["cum_factor_inter"], 2)
            row_1["chg"] = round(row_1["chg"] / row_1["cum_factor_inter"], 4)
            row_2["chg"] = round(row_2["chg"] * row_2["cum_factor_inter"], 4)
            row_3["chg"] = round(row_3["chg"] * row_3["cum_factor_inter"], 4)
            for index, rr in enumerate(rows):
                data120 = self.get_day_new_120(db, rr)
                self.update_mas(rr, data120)
                self.update_sums(rr, data120)
                rr["end_date"] = int(rr["end_date"].strftime("%Y%m%d"))
                rr["_id"]='{}-{}-{}'.format(rr["innerCode"],rr["end_date"],rr["ex_status"])

            result_1.append(row_1)
            result_2.append(row_2)
            result_3.append(row_3)

        result.extend(result_1)
        result.extend(result_2)
        result.extend(result_3)
        return result

    def make_Z3_STK_MKT_DAY_INTER_data(self, tradedate, code, mongo_table='', mysql_table=''):
        # return []
        # 只获取单个交易日
        # 获取股票行情基础信息
        # 某天数据时需要取该交易日的前xxx天的数据
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        result = copy.deepcopy(self.DAY_INTER_base(tradedate, code))

        if not result:
            print code, "no results"
            return []
        sql_tradedate_list_model = """
                SELECT
                  TRADEDATE
                FROM STK_MKT a
                WHERE a.ISVALID = 1
                      AND a.INNER_CODE = %(INNER_CODE)s
                      AND ifnull(TVOLUME, 0) != 0
                ORDER BY TRADEDATE DESC
                LIMIT 279;
            """
        tmp = {}
        result = [result, ]

        result_1 = []
        result_2 = []
        result_3 = []
        for row in result:
            # 获取历史279交易日列表 128ms
            tradedate_list = self.conn.fetchall(sql_tradedate_list_model, {"INNER_CODE": code})
            # 获取计算所需数据
            tmp = {}
            # print row["trade_date"]
            tmp["end_date"] = row["end_date"]
            tmp["DATE_MAX"] = tradedate_list[0]["TRADEDATE"]
            tmp["DATE_MIN_60"] = tradedate_list[:179][-1]["TRADEDATE"]
            tmp["DATE_MIN_160"] = tradedate_list[:279][-1]["TRADEDATE"]

            # 获取计算的交易日的复权因子信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["end_date"]
                })
            if not self.check_info(info,row,tmp["end_date"]):return []
            tmp["CUM_FAC"] = info["cum_factor"] if info else 1
            tmp["EX_FAC"] = info["ex_factor_today"] if info else 1
            # 获取最大交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MAX"]
                })
            if not self.check_info(info,row,tmp["DATE_MAX"]):return []
            # print info
            tmp["CUM_FAC_MAX"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MAX"] = info["ex_factor"] if info else 1
            # 获取前60交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MIN_60"]
                })
            if not self.check_info(info,row,tmp["DATE_MIN_60"]):return []
            # print info
            tmp["CUM_FAC_MIN_60"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MIN_60"] = info["ex_factor"] if info else 1
            # 获取前160交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MIN_160"]
                })
            if not self.check_info(info,row,tmp["DATE_MIN_160"]):return []
            # print info
            tmp["CUM_FAC_MIN_160"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MIN_160"] = info["ex_factor"] if info else 1
            # 计算前复权,后复权60，后复权160 数据
            row_1 = copy.deepcopy(row)
            row_2 = copy.deepcopy(row)
            row_3 = copy.deepcopy(row)
            rows = [row, row_1, row_2, row_3]
            for index, rr in enumerate(rows):
                rr["ex_status"] = index

            CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["end_date"] else tmp["CUM_FAC_MAX"] / tmp["CUM_FAC"]
            # CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["TRADEDATE"] else tmp["CUM_FAC_MAX"] / (
            #     tmp["CUM_FAC"] / tmp["EX_FAC"])
            # 24.043369(24.043369/)
            CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_60"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
                "CUM_FAC_MIN_60"]
            CUM_FACTOR_AFT_160 = 1 if tmp["DATE_MIN_160"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
                "CUM_FAC_MIN_160"]

            #print """tmp["CUM_FAC"]""",tmp["CUM_FAC"]
            #print """tmp["EX_FAC"]""",tmp["EX_FAC"]
            #print """tmp["end_date"]""",tmp["end_date"]
            #print """tmp["CUM_FAC"]""",tmp["CUM_FAC"]

            #print """tmp["CUM_FAC_MIN_60"]""",tmp["CUM_FAC_MIN_60"]
            #print """tmp["EX_FAC_MIN_160"]""",tmp["EX_FAC_MIN_160"]




            #print """tmp["CUM_FAC_MAX"]""",tmp["CUM_FAC_MAX"]

            #print """tmp["DATE_MIN_60"]""",tmp["DATE_MIN_60"]
            #print "CUM_FACTOR_BEF",CUM_FACTOR_BEF
            #print "CUM_FACTOR_AFT_60",CUM_FACTOR_AFT_60
            #print "CUM_FACTOR_AFT_160",CUM_FACTOR_AFT_160
            row_1["cum_factor_inter"] = CUM_FACTOR_BEF
            row_2["cum_factor_inter"] = CUM_FACTOR_AFT_60
            row_3["cum_factor_inter"] = CUM_FACTOR_AFT_160
            #print row_1["cum_factor_inter"]
            #print row_2["cum_factor_inter"]

            #print row_3["cum_factor_inter"]

            row_1["open_px"] = round(row_1["open_px"] / row_1["cum_factor_inter"], 2)
            row_2["open_px"] = round(row_2["open_px"] * row_2["cum_factor_inter"], 2)
            row_3["open_px"] = round(row_3["open_px"] * row_3["cum_factor_inter"], 2)
            row_1["high_px"] = round(row_1["high_px"] / row_1["cum_factor_inter"], 2)
            row_2["high_px"] = round(row_2["high_px"] * row_2["cum_factor_inter"], 2)
            row_3["high_px"] = round(row_3["high_px"] * row_3["cum_factor_inter"], 2)
            row_1["low_px"] = round(row_1["low_px"] / row_1["cum_factor_inter"], 2)
            row_2["low_px"] = round(row_2["low_px"] * row_2["cum_factor_inter"], 2)
            row_3["low_px"] = round(row_3["low_px"] * row_3["cum_factor_inter"], 2)
            row_1["close_px"] = round(row_1["close_px"] / row_1["cum_factor_inter"], 2)
            row_2["close_px"] = round(row_2["close_px"] * row_2["cum_factor_inter"], 2)
            row_3["close_px"] = round(row_3["close_px"] * row_3["cum_factor_inter"], 2)
            row_1["prev_close_px"] = round(row_1["prev_close_px"] / row_1["cum_factor_inter"], 2)
            row_2["prev_close_px"] = round(row_2["prev_close_px"] * row_2["cum_factor_inter"], 2)
            row_3["prev_close_px"] = round(row_3["prev_close_px"] * row_3["cum_factor_inter"], 2)
            row_1["chg"] = round(row_1["chg"] / row_1["cum_factor_inter"], 4)
            row_2["chg"] = round(row_2["chg"] * row_2["cum_factor_inter"], 4)
            row_3["chg"] = round(row_3["chg"] * row_3["cum_factor_inter"], 4)
            # print row["close_px"]
            # print row_1["close_px"]
            # print row_2["close_px"]
            # print row_3["close_px"]
            # MA数据 从mongo获取历史数据
            #print row_1,row_2,row_3
	    #print rows
            for index, rr in enumerate(rows):
                data120 = self.get_day_120(db, rr)
                self.update_ma(rr, data120)
                self.update_sum(rr, data120)
                rr["_id"]='{}{}{}'.format(rr["symbol"],rr["end_date"].strftime("%Y%m%d"),rr["ex_status"])
                print "rr[id]",rr["_id"]


            result_1.append(row_1)
            result_2.append(row_2)
            result_3.append(row_3)

        #result.extend(result_1)
        result.extend(result_2)
        result.extend(result_3)
        #print result
        return result

    def make_Z3_STK_MKT_DAY_INTER_NEW_data_no_factor(self, result, tradedate, code, get_ma=False, mongo_table='',
                                                 mysql_table=''):
        """
        计算不复权数据
        :param result:
        :param tradedate:
        :param code:
        :param get_ma:
        :param mongo_table:
        :param mysql_table:
        :return:
        """

        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]

        row = results[0]

        row["ex_status"] = 0
        # print "no_factor"
        data120 = self.get_day_new_120(db, row)
        self.update_mas(row, data120)
        self.update_sums(row, data120)
        row["end_date"] = int(row["end_date"].strftime("%Y%m%d"))
        row["_id"]='{}-{}-{}'.format(row["innerCode"],row["end_date"],row["ex_status"])

        return [row, ]

    def make_Z3_STK_MKT_DAY_INTER_data_no_factor(self, result, tradedate, code, get_ma=False, mongo_table='',
                                                 mysql_table=''):
        """
        计算不复权数据
        :param result:
        :param tradedate:
        :param code:
        :param get_ma:
        :param mongo_table:
        :param mysql_table:
        :return:
        """

        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]

        row = results[0]

        row["ex_status"] = 0
        # print "no_factor"
        data120 = self.get_day_120(db, row)
        self.update_ma(row, data120)
        self.update_sum(row, data120)
        return [row, ]

    def make_Z3_STK_MKT_DAY_INTER_NEW_data_after_60_factor(self, mdate, result, tradedate, code, get_ma=False, mongo_table='',
                                                       mysql_table=''):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]

        row = results[0]
        # print "after60_factor"
        # 获取历史279交易日列表 128ms
        #tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MIN_60"] = mdate

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            })
        if not info:return []

        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1

        # 获取前60交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(

            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MIN_60"]
            })
        if not self.check_info(info,row,tmp["DATE_MIN_60"]):return []

        tmp["CUM_FAC_MIN_60"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MIN_60"] = info["ex_factor"] if info else 1

        # 计算前复权数据
        row_2 = copy.deepcopy(row)
        row_2["ex_status"] = 2
        CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_60"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
            "CUM_FAC_MIN_60"]
        row_2["cum_factor_inter"] = CUM_FACTOR_AFT_60
        row_2["open_px"] = round(row_2["open_px"] * row_2["cum_factor_inter"], 2)
        row_2["high_px"] = round(row_2["high_px"] * row_2["cum_factor_inter"], 2)
        row_2["low_px"] = round(row_2["low_px"] * row_2["cum_factor_inter"], 2)
        # print row["close_px"]
        # print row_1["close_px"]
        row_2["close_px"] = round(row_2["close_px"] * row_2["cum_factor_inter"], 2)
        row_2["prev_close_px"] = round(row_2["prev_close_px"] * row_2["cum_factor_inter"], 2)
        row_2["chg"] = round(row_2["chg"] * row_2["cum_factor_inter"], 4)
        # MA数据 从mongo获取历史数据


        data120 = self.get_day_new_120(db, row_2)
        self.update_mas(row_2, data120)
        self.update_sums(row_2, data120)
        row_2["end_date"] = int(row_2["end_date"].strftime("%Y%m%d"))
        row_2["_id"]='{}-{}-{}'.format(row_2["innerCode"],row_2["end_date"],row_2["ex_status"])

        return [row_2, ]

    def make_Z3_STK_MKT_DAY_INTER_data_after_60_factor(self, mdate, result, tradedate, code, get_ma=False, mongo_table='',
                                                       mysql_table=''):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]

        row = results[0]
        # print "after60_factor"
        # 获取历史279交易日列表 128ms
        #tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MIN_60"] = mdate

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            })
        if not info:return []

        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1

        # 获取前60交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(

            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MIN_60"]
            })
        if not self.check_info(info,row,tmp["DATE_MIN_60"]):return []

        tmp["CUM_FAC_MIN_60"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MIN_60"] = info["ex_factor"] if info else 1

        # 计算前复权数据
        row_2 = copy.deepcopy(row)
        row_2["ex_status"] = 2
        CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_60"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
            "CUM_FAC_MIN_60"]
        row_2["cum_factor_inter"] = CUM_FACTOR_AFT_60
        row_2["open_px"] = round(row_2["open_px"] * row_2["cum_factor_inter"], 2)
        row_2["high_px"] = round(row_2["high_px"] * row_2["cum_factor_inter"], 2)
        row_2["low_px"] = round(row_2["low_px"] * row_2["cum_factor_inter"], 2)
        # print row["close_px"]
        # print row_1["close_px"]
        row_2["close_px"] = round(row_2["close_px"] * row_2["cum_factor_inter"], 2)
        row_2["prev_close_px"] = round(row_2["prev_close_px"] * row_2["cum_factor_inter"], 2)
        row_2["chg"] = round(row_2["chg"] * row_2["cum_factor_inter"], 4)
        # MA数据 从mongo获取历史数据

        data120 = self.get_day_120(db, row_2)
        self.update_ma(row_2, data120)
        self.update_sum(row_2, data120)

        return [row_2, ]

    def make_Z3_STK_MKT_DAY_INTER_NEW_data_after_160_factor(self, mdate, result, tradedate, code, get_ma=False, mongo_table='',
                                                        mysql_table=''):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]

        row = results[0]
        # print "after_160_factor"
        # 获取历史279交易日列表 128ms
        #tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MIN_160"] = mdate

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            })
        if not self.check_info(info,row,tmp["end_date"]):return []
        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1

        # 获取前160交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MIN_160"]
            })
        if not self.check_info(info,row,tmp["DATE_MIN_160"]):return []
        tmp["CUM_FAC_MIN_160"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MIN_160"] = info["ex_factor"] if info else 1

        # 计算前复权数据
        row_3 = copy.deepcopy(row)
        row_3["ex_status"] = 3
        CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_160"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
            "CUM_FAC_MIN_160"]
        row_3["cum_factor_inter"] = CUM_FACTOR_AFT_60
        row_3["open_px"] = round(row_3["open_px"] * row_3["cum_factor_inter"], 2)
        row_3["high_px"] = round(row_3["high_px"] * row_3["cum_factor_inter"], 2)
        row_3["low_px"] = round(row_3["low_px"] * row_3["cum_factor_inter"], 2)
        # print row["close_px"]
        # print row_1["close_px"]
        row_3["close_px"] = round(row_3["close_px"] * row_3["cum_factor_inter"], 2)
        row_3["prev_close_px"] = round(row_3["prev_close_px"] * row_3["cum_factor_inter"], 2)
        row_3["chg"] = round(row_3["chg"] * row_3["cum_factor_inter"], 4)
        # MA数据 从mongo获取历史数据

        data120 = self.get_day_new_120(db, row_3)
        self.update_mas(row_3, data120)
        self.update_sums(row_3, data120)
        row_3["end_date"] = int(row_3["end_date"].strftime("%Y%m%d"))
        row_3["_id"]='{}-{}-{}'.format(row_3["innerCode"],row_3["end_date"],row_3["ex_status"])


        return [row_3, ]

    def make_Z3_STK_MKT_DAY_INTER_data_after_160_factor(self, mdate, result, tradedate, code, get_ma=False, mongo_table='',
                                                        mysql_table=''):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]

        row = results[0]
        # print "after_160_factor"
        # 获取历史279交易日列表 128ms
        #tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MIN_160"] = mdate

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            })
        if not self.check_info(info,row,tmp["end_date"]):return []
        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1

        # 获取前160交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MIN_160"]
            })
        if not self.check_info(info,row,tmp["DATE_MIN_160"]):return []
        tmp["CUM_FAC_MIN_160"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MIN_160"] = info["ex_factor"] if info else 1

        # 计算前复权数据
        row_3 = copy.deepcopy(row)
        row_3["ex_status"] = 3
        CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_160"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
            "CUM_FAC_MIN_160"]
        row_3["cum_factor_inter"] = CUM_FACTOR_AFT_60
        row_3["open_px"] = round(row_3["open_px"] * row_3["cum_factor_inter"], 2)
        row_3["high_px"] = round(row_3["high_px"] * row_3["cum_factor_inter"], 2)
        row_3["low_px"] = round(row_3["low_px"] * row_3["cum_factor_inter"], 2)
        # print row["close_px"]
        # print row_1["close_px"]
        row_3["close_px"] = round(row_3["close_px"] * row_3["cum_factor_inter"], 2)
        row_3["prev_close_px"] = round(row_3["prev_close_px"] * row_3["cum_factor_inter"], 2)
        row_3["chg"] = round(row_3["chg"] * row_3["cum_factor_inter"], 4)
        # MA数据 从mongo获取历史数据

        data120 = self.get_day_120(db, row_3)
        self.update_ma(row_3, data120)
        self.update_sum(row_3, data120)

        return [row_3, ]

    def make_Z3_STK_MKT_DAY_INTER_data_pre_factor(self, mdate, result, tradedate, code, get_ma=False, mongo_table='',
                                                  mysql_table=''):
        """
        计算前复权数据
        :param result:
        :param tradedate:
        :param code:
        :param get_ma:
        :param mongo_table:
        :param mysql_table:
        :return:
        """
        # return []
        # 只获取单个交易日
        # 获取股票行情基础信息
        # 某天数据时需要取该交易日的前xxx天的数据
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # conn = tools.mongo_cursor()
        # db2 = conn["z3dbus"]

        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results=={}==".format(tradedate)
            return []
        tmp = {}

        row = result

        # print "pre_factor"
        # 获取历史279交易日列表 128ms
        tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MAX"] = mdate if mdate else tradedate_list[0]["TRADEDATE"]
        # tmp["DATE_MAX"] = tradedate_list[0]["TRADEDATE"]

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            }, {"_id": False})


        if not self.check_info(info, row, tmp["end_date"]): return []

        # if not info:return []
        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1
        # 获取最大交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MAX"]
            }, {"_id": False})

        if not self.check_info(info, row, tmp["DATE_MAX"]): return []
        tmp["CUM_FAC_MAX"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MAX"] = info["ex_factor"] if info else 1
        # 计算前复权数据
        row_1 = copy.deepcopy(row)
        row_1["ex_status"] = 1

        CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["end_date"] else tmp["CUM_FAC_MAX"] / tmp["CUM_FAC"]
        row_1["cum_factor_inter"] = CUM_FACTOR_BEF
        row_1["open_px"] = round(row_1["open_px"] / row_1["cum_factor_inter"], 2)
        row_1["high_px"] = round(row_1["high_px"] / row_1["cum_factor_inter"], 2)
        row_1["low_px"] = round(row_1["low_px"] / row_1["cum_factor_inter"], 2)
        row_1["close_px"] = round(row_1["close_px"] / row_1["cum_factor_inter"], 2)
        row_1["prev_close_px"] = round(row_1["prev_close_px"] / row_1["cum_factor_inter"], 2)
        row_1["chg"] = round(row_1["chg"] / row_1["cum_factor_inter"], 4)

        # data120 = self.get_day_120(db, row_1)
        data250 = self.get_day_250(db, row_1)
        self.update_ma(row_1, data250)
        self.update_sum(row_1, data250)
        # if get_ma:
        #    row_1["_id"]='{}{}{}'.format(row_1["symbol"],row_1["end_date"].strftime("%Y%m%d"),row_1["ex_status"])
        # print "row_1[id]",row_1["_id"]


        return [row_1, ]




    def make_Z3_STK_MKT_DAY_INTER_NEW_data_pre_factor(self, mdate, result, tradedate, code, get_ma=False, mongo_table='',
                                                  mysql_table=''):
        """
        计算前复权数据
        :param result:
        :param tradedate:
        :param code:
        :param get_ma:
        :param mongo_table:
        :param mysql_table:
        :return:
        """
        # return []
        # 只获取单个交易日
        # 获取股票行情基础信息
        # 某天数据时需要取该交易日的前xxx天的数据
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # conn = tools.mongo_cursor()
        # db2 = conn["z3dbus"]

        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results=={}==".format(tradedate)
            return []
        tmp = {}

        row = result

        # print "pre_factor"
        # 获取历史279交易日列表 128ms
        tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        print '******************************',row
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MAX"] = mdate if mdate else tradedate_list[0]["TRADEDATE"]
        # tmp["DATE_MAX"] = tradedate_list[0]["TRADEDATE"]

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            }, {"_id": False})


        if not self.check_info(info, row, tmp["end_date"]): return []

        # if not info:return []
        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1
        # 获取最大交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MAX"]
            }, {"_id": False})

        if not self.check_info(info, row, tmp["DATE_MAX"]): return []
        tmp["CUM_FAC_MAX"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MAX"] = info["ex_factor"] if info else 1
        # 计算前复权数据
        row_1 = copy.deepcopy(row)
        row_1["ex_status"] = 1

        CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["end_date"] else tmp["CUM_FAC_MAX"] / tmp["CUM_FAC"]
        row_1["cum_factor_inter"] = CUM_FACTOR_BEF
        row_1["open_px"] = round(row_1["open_px"] / row_1["cum_factor_inter"], 2)
        row_1["high_px"] = round(row_1["high_px"] / row_1["cum_factor_inter"], 2)
        row_1["low_px"] = round(row_1["low_px"] / row_1["cum_factor_inter"], 2)
        row_1["close_px"] = round(row_1["close_px"] / row_1["cum_factor_inter"], 2)
        row_1["prev_close_px"] = round(row_1["prev_close_px"] / row_1["cum_factor_inter"], 2)
        row_1["chg"] = round(row_1["chg"] / row_1["cum_factor_inter"], 4)

        # data120 = self.get_day_120(db, row_1)
        data250 = self.get_day_new_250(db, row_1)
        self.update_mas(row_1, data250)
        self.update_sums(row_1, data250)
        row_1["end_date"] = int(row_1["end_date"].strftime("%Y%m%d"))
        row_1["_id"]='{}-{}-{}'.format(row_1["innerCode"],row_1["end_date"],row_1["ex_status"])
        # if get_ma:
        #    row_1["_id"]='{}{}{}'.format(row_1["symbol"],row_1["end_date"].strftime("%Y%m%d"),row_1["ex_status"])
        # print "row_1[id]",row_1["_id"]


        return [row_1, ]


    def get_spe_pxes(self, spe_days, seccode):
        sql = """
        select TOPEN,TCLOSE,THIGH,TLOW,TRADEDATE from STK_MKT WHERE ISVALID=1
        AND TRADEDATE IN (%(spe_days)s) and SECCODE='%(seccode)s'
        """ % {
            'spe_days': ",".join(["'%s'" % i for i in spe_days]),
            'seccode': seccode
        }
        # print sql
        results = self.conn.fetchall(sql)
        tmp = {}
        for i in results:
            tmp[i["TRADEDATE"]] = i
        return tmp


    def check_info(self,info,row,x):
        if not info:
            print "未找到复权因子【{}】【{}】".format(row["innerCode"],x)
            return False
        return True

    def make_INTER_data(self, tradedate, code, mongo_table, mysql_table):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        result = self.WEEK_INTER_base(tradedate, code, mysql_table)
        if not result:
            return []

        # sql_tradedate_list_model = """
        #     SELECT
        #       ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
        #     FROM %(mysql_table)s a
        #     WHERE a.ISVALID = 1
        #           AND a.STOCKCODE = '%(symbol)s'
        #     ORDER BY ENDDATE DESC
        #     LIMIT 279;
        # """
        tmp = {}

        result_1 = []
        result_2 = []
        result_3 = []
        for row in result:
            row.update({"mysql_table": mysql_table})
            tradedate_list = self.get_tradedate_list(code, mysql_table)  # 获取计算所需数据
            del row["mysql_table"]
            if not tradedate_list:
                print tradedate
                continue
            tmp = {}
            # print "get n5 use:", datetime.datetime.now() - n5
            n6 = datetime.datetime.now()
            # print row["trade_date"]
            tmp["END_DATE"] = row["end_date"]
            tmp["DATE_MAX"] = tradedate_list[0]["LAST_TRADE_DATE"]
            tmp["WEEK_MIN_60"] = tradedate_list[:179][-1]["FIRST_TRADE_DATE"]
            tmp["WEEK_MIN_160"] = tradedate_list[:279][-1]["FIRST_TRADE_DATE"]

            row_1 = copy.deepcopy(row)
            row_2 = copy.deepcopy(row)
            row_3 = copy.deepcopy(row)
            rows = [row, row_1, row_2, row_3]

            for index, rr in enumerate(rows):
                rr["ex_status"] = index

            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MAX"]
                })
            if not self.check_info(info,row,tmp["DATE_MAX"]):return []
            # print "get n6 use:", datetime.datetime.now() - n5

            CUM_FAC_MAX = info.get("cum_factor", 1) if info else 1
            EX_FAC_MAX = info.get("ex_factor", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["WEEK_MIN_60"]
                })
            if not self.check_info(info,row,tmp["WEEK_MIN_60"]):return []

            # print "get n7 use:", datetime.datetime.now() - n5
            CUM_FAC_MIN_60 = info.get("cum_factor", 1) if info else 1
            EX_FAC_MIN_60 = info.get("ex_factor", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["WEEK_MIN_160"]
                })
            if not self.check_info(info,row,tmp["WEEK_MIN_160"]):return []
            CUM_FAC_MIN_160 = info.get("cum_factor", 1) if info else 1
            EX_FAC_MIN_160 = info.get("ex_factor", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["thigh_date"]
                })
            if not self.check_info(info,row,row["thigh_date"]):return []
            # print "get n8 use:", datetime.datetime.now() - n5
            CUM_FAC_THIGH = info.get("cum_factor", 1) if info else 1
            EX_FAC_THIGH = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["tlow_date"]
                })
            if not self.check_info(info,row,row["tlow_date"]):return []
            # print "get n9 use:", datetime.datetime.now() - n5
            CUM_FAC_TLOW = info.get("cum_factor", 1) if info else 1
            EX_FAC_TLOW = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["first_trade_date"]
                })
            if not self.check_info(info,row,row["first_trade_date"]):return []
            # print "get n10 use:", datetime.datetime.now() - n5
            CUM_FAC_TOPEN = info.get("cum_factor", 1) if info else 1
            EX_FAC_TOPEN = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["last_trade_date"]
                })
            if not self.check_info(info,row,row["last_trade_date"]):return []
            # print "get n11 use:", datetime.datetime.now() - n5
            CUM_FAC_TCLOSE = info.get("cum_factor", 1) if info else 1
            EX_FAC_TCLOSE = info.get("ex_factor_today", 1) if info else 1

            # open_px
            CUM_FACTOR_BEF = 1 if row["first_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TOPEN
            # CUM_FACTOR_BEF = 1 if row["first_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TOPEN / EX_FAC_TOPEN)
            # print "equity.symbol", row["symbol"]
            # print "first_trade_date", row["first_trade_date"]
            # print "end_date", row["end_date"]
            # print "CUM_FAC_MAX", CUM_FAC_MAX
            # print "CUM_FAC_TOPEN", CUM_FAC_TOPEN
            # print "EX_FAC_TOPEN", EX_FAC_TOPEN
            # print "CUM_FAC_MIN_160", CUM_FAC_MIN_160
            # print "CUM_FAC_MIN_60", CUM_FAC_MIN_60
            # print "CUM_FACTOR_BEF", CUM_FACTOR_BEF

            CUM_FACTOR_AFT_60 = 1 if row["first_trade_date"] == tmp[
                "WEEK_MIN_60"] else CUM_FAC_TOPEN / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["first_trade_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TOPEN / CUM_FAC_MIN_160
            # print type(row_1["open_px"])
            # print type(CUM_FACTOR_BEF)
            row_1["open_px"] = round(row_1["open_px"] / CUM_FACTOR_BEF, 2) if row_1["open_px"]  else None
            row_2["open_px"] = round(row_2["open_px"] * CUM_FACTOR_AFT_60, 2) if row_2["open_px"]  else None
            row_3["open_px"] = round(row_3["open_px"] * CUM_FACTOR_AFT_160, 2) if row_3["open_px"]  else None

            # high_px
            CUM_FACTOR_BEF = 1 if row["thigh_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_THIGH
            # CUM_FACTOR_BEF = 1 if row["thigh_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_THIGH / EX_FAC_THIGH)

            CUM_FACTOR_AFT_60 = 1 if row["thigh_date"] == tmp["WEEK_MIN_60"] else CUM_FAC_THIGH / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["thigh_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_THIGH / CUM_FAC_MIN_160

            row_1["high_px"] = round(row_1["high_px"] / CUM_FACTOR_BEF, 2) if row_1["high_px"]  else None
            row_2["high_px"] = round(row_2["high_px"] * CUM_FACTOR_AFT_60, 2) if row_2["high_px"]  else None
            row_3["high_px"] = round(row_3["high_px"] * CUM_FACTOR_AFT_160, 2) if row_3["high_px"]  else None

            # low_px
            CUM_FACTOR_BEF = 1 if row["tlow_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TLOW
            # CUM_FACTOR_BEF = 1 if row["tlow_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TLOW / EX_FAC_TLOW)

            CUM_FACTOR_AFT_60 = 1 if row["tlow_date"] == tmp["WEEK_MIN_60"] else CUM_FAC_TLOW / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["tlow_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TLOW / CUM_FAC_MIN_160

            row_1["low_px"] = round(row_1["low_px"] / CUM_FACTOR_BEF, 2) if row_1["low_px"]  else None
            row_2["low_px"] = round(row_2["low_px"] * CUM_FACTOR_AFT_60, 2) if row_2["low_px"]  else None
            row_3["low_px"] = round(row_3["low_px"] * CUM_FACTOR_AFT_160, 2) if row_3["low_px"]  else None

            # close_px
            CUM_FACTOR_BEF = 1 if row["last_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TCLOSE
            # CUM_FACTOR_BEF = 1 if row["last_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TCLOSE / EX_FAC_TCLOSE)

            CUM_FACTOR_AFT_60 = 1 if row["last_trade_date"] == tmp[
                "WEEK_MIN_60"] else CUM_FAC_TCLOSE / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["last_trade_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TCLOSE / CUM_FAC_MIN_160

            row_1["close_px"] = round(row_1["close_px"] / CUM_FACTOR_BEF, 2) if row_1["close_px"]  else None
            row_2["close_px"] = round(row_2["close_px"] * CUM_FACTOR_AFT_60, 2) if row_2["close_px"]  else None
            row_3["close_px"] = round(row_3["close_px"] * CUM_FACTOR_AFT_160, 2) if row_3["close_px"]  else None

            # prev_close_px
            # print "get n12 use:", datetime.datetime.now() - n5
            for index, rr in enumerate(rows):
                last_info = self.get_w_prev_close_px(rr, db, mongo_table)
                rr["prev_close_px"] = last_info.get("close_px", None)
                rr["chg"] = rr["close_px"] - rr["prev_close_px"] if rr["prev_close_px"] else None
                # print "get n13 use:", datetime.datetime.now() - n5
                # 更新ma,sum
                #data120 = self.get_week_120(db, rr, mongo_table)
                data121 = self.get_week_121(db, rr, mongo_table)
                data120 = data121[0:120]
                # print "get n14 use:", datetime.datetime.now() - n5
                self.update_ma(rr, data120)
                self.update_sum(rr, data120)
                self.update_sum_non_cur(rr, data121[1:])


            result_1.append(row_1)
            result_2.append(row_2)
            result_3.append(row_3)
            # print "get uuuu use:", datetime.datetime.now() - n5
        result.extend(result_1)
        result.extend(result_2)
        result.extend(result_3)
        # print "get UUUUU use:", datetime.datetime.now() - n5
        # print result
        return result

    def make_INTER_data_after_160_factor(self, tradedate, code, mongo_table, mysql_table):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        n5 = datetime.datetime.now()
        result = self.WEEK_INTER_base(tradedate, code, mysql_table)

        if not result:
            return []

        # sql_tradedate_list_model = """
        #     SELECT
        #       ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
        #     FROM %(mysql_table)s a
        #     WHERE a.ISVALID = 1
        #           AND a.STOCKCODE = '%(symbol)s'
        #     ORDER BY ENDDATE DESC
        #     LIMIT 279;
        # """
        tmp = {}
        for row in result:
            row.update({"mysql_table": mysql_table})
            n6 =  datetime.datetime.now()

            tradedate_list = self.get_tradedate_list(code, mysql_table)  # 获取计算所需数据
            del row["mysql_table"]
            if not tradedate_list:
                print tradedate
                continue
            tmp = {}

            n6 = datetime.datetime.now()
            # print row["trade_date"]
            end_date =int(row["end_date"].strftime("%Y%m%d"))
            tmp["END_DATE"] = row["end_date"]
            tmp["WEEK_MIN_160"] = tradedate_list[:279][-1]["FIRST_TRADE_DATE"]
            #print "b"
            row_3 = copy.deepcopy(row)
            # 从日行情取topen,tclose,tlow,thigh
            spe_days = [row["first_trade_date"],row["thigh_date"],row["tlow_date"],row["last_trade_date"]]
            spe_pxes = self.get_spe_pxes(spe_days,row["symbol"])

            #print spe_pxes
            for rrr in [row_3,]:
                rrr["open_px"] = spe_pxes[row["first_trade_date"]]["TOPEN"]
                rrr["high_px"] = spe_pxes[row["thigh_date"]]["THIGH"]
                rrr["low_px"] = spe_pxes[row["tlow_date"]]["TLOW"]
                rrr["close_px"] = spe_pxes[row["last_trade_date"]]["TCLOSE"]
            row_3["ex_status"] = 3

            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["WEEK_MIN_160"]
                })

            if not self.check_info(info,row,tmp["WEEK_MIN_160"]):return []
            CUM_FAC_MIN_160 = info.get("cum_factor", 1) if info else 1
            EX_FAC_MIN_160 = info.get("ex_factor", 1) if info else 1
            #print "c"
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["thigh_date"]
                })

            #print "uuuuuuuuuuuuuuu",info

            if not self.check_info(info,row,row["thigh_date"]):return []
            #print "0000000000000000000000000000"

            CUM_FAC_THIGH = info.get("cum_factor", 1) if info else 1
            EX_FAC_THIGH = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["tlow_date"]
                })
            #print "e",row

            if not self.check_info(info,row,row["tlow_date"]):return []

            CUM_FAC_TLOW = info.get("cum_factor", 1) if info else 1
            EX_FAC_TLOW = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["first_trade_date"]
                })
            if not self.check_info(info,row,row["first_trade_date"]):return []

            CUM_FAC_TOPEN = info.get("cum_factor", 1) if info else 1
            EX_FAC_TOPEN = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["last_trade_date"]
                })
            if not self.check_info(info,row,row["last_trade_date"]):return []

            CUM_FAC_TCLOSE = info.get("cum_factor", 1) if info else 1
            EX_FAC_TCLOSE = info.get("ex_factor_today", 1) if info else 1

            # open_p


            CUM_FACTOR_AFT_160 = 1 if row["first_trade_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TOPEN / CUM_FAC_MIN_160

            row_3["open_px"] = round(row_3["open_px"] * CUM_FACTOR_AFT_160, 2) if row_3["open_px"]  else None
            row_3["open_factor_inter"]=CUM_FACTOR_AFT_160
            # high_px


            CUM_FACTOR_AFT_160 = 1 if row["thigh_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_THIGH / CUM_FAC_MIN_160

            row_3["high_px"] = round(row_3["high_px"] * CUM_FACTOR_AFT_160, 2) if row_3["high_px"]  else None

            row_3["high_factor_inter"]=CUM_FACTOR_AFT_160

            # low_px

            CUM_FACTOR_AFT_160 = 1 if row["tlow_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TLOW / CUM_FAC_MIN_160
            row_3["low_px"] = round(row_3["low_px"] * CUM_FACTOR_AFT_160, 2) if row_3["low_px"]  else None

            row_3["low_factor_inter"]=CUM_FACTOR_AFT_160
            # close_px


            CUM_FACTOR_AFT_160 = 1 if row["last_trade_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TCLOSE / CUM_FAC_MIN_160

            row_3["close_px"] = round(row_3["close_px"] * CUM_FACTOR_AFT_160, 2) if row_3["close_px"]  else None

            row_3["close_factor_inter"]=CUM_FACTOR_AFT_160

            # prev_close_px

            for index, rr in enumerate([row_3,]):
                last_info = self.get_w_prev_close_px(rr, db, mongo_table)
                rr["prev_close_px"] = last_info.get("close_px", None)
                rr["chg"] = rr["close_px"] - rr["prev_close_px"] if rr["prev_close_px"] else None

                # 更新ma,sum
                #data120 = self.get_week_120(db, rr, mongo_table)
                data121 = self.get_week_121(db, rr, mongo_table)
                #print "xxxxxxxxxxxxx",data121
                data120 = data121[0:120]

                self.update_mas(rr, data120)
                self.update_sums(rr, data120)
                self.update_sum_non_cur(rr, data121[1:])
                rr["_id"] = "{}-{}-{}".format(rr["innerCode"],end_date,3)
                rr["end_date"] = end_date
                rr["first_trade_date"] = int(rr["first_trade_date"].strftime("%Y%m%d"))
                rr["last_trade_date"] = int(rr["last_trade_date"].strftime("%Y%m%d"))
                rr["thigh_date"] = int(rr["thigh_date"].strftime("%Y%m%d"))
                rr["tlow_date"] = int(rr["tlow_date"].strftime("%Y%m%d"))
                del rr["symbol"]
                #print rr
        return [row_3,]

    def make_INTER_data_after_60_factor(self, tradedate, code, mongo_table, mysql_table):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        n5 = datetime.datetime.now()
        result = self.WEEK_INTER_base(tradedate, code, mysql_table)

        if not result:
            return []

        # sql_tradedate_list_model = """
        #     SELECT
        #       ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
        #     FROM %(mysql_table)s a
        #     WHERE a.ISVALID = 1
        #           AND a.STOCKCODE = '%(symbol)s'
        #     ORDER BY ENDDATE DESC
        #     LIMIT 279;
        # """
        tmp = {}

        for row in result:
            row.update({"mysql_table": mysql_table})
            n6 =  datetime.datetime.now()

            tradedate_list = self.get_tradedate_list(code, mysql_table)  # 获取计算所需数据
            del row["mysql_table"]
            if not tradedate_list:
                print tradedate
                continue
            tmp = {}

            n6 = datetime.datetime.now()
            # print row["trade_date"]
            end_date =int(row["end_date"].strftime("%Y%m%d"))
            tmp["END_DATE"] = row["end_date"]
            tmp["WEEK_MIN_60"] = tradedate_list[:179][-1]["FIRST_TRADE_DATE"]
            #print "b"
            row_2 = copy.deepcopy(row)
            # 从日行情取topen,tclose,tlow,thigh
            spe_days = [row["first_trade_date"],row["thigh_date"],row["tlow_date"],row["last_trade_date"]]
            spe_pxes = self.get_spe_pxes(spe_days,row["symbol"])

            #print spe_pxes
            for rrr in [row_2,]:
                rrr["open_px"] = spe_pxes[row["first_trade_date"]]["TOPEN"]
                rrr["high_px"] = spe_pxes[row["thigh_date"]]["THIGH"]
                rrr["low_px"] = spe_pxes[row["tlow_date"]]["TLOW"]
                rrr["close_px"] = spe_pxes[row["last_trade_date"]]["TCLOSE"]
            row_2["ex_status"] = 2

            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["WEEK_MIN_60"]
                })
            if not self.check_info(info,row,tmp["WEEK_MIN_60"]):return []


            CUM_FAC_MIN_60 = info.get("cum_factor", 1) if info else 1
            EX_FAC_MIN_60 = info.get("ex_factor", 1) if info else 1

            #print "c"
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["thigh_date"]
                })

            #print "uuuuuuuuuuuuuuu",info

            if not self.check_info(info,row,row["thigh_date"]):return []
            #print "0000000000000000000000000000"

            CUM_FAC_THIGH = info.get("cum_factor", 1) if info else 1
            EX_FAC_THIGH = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["tlow_date"]
                })
            #print "e",row

            if not self.check_info(info,row,row["tlow_date"]):return []

            CUM_FAC_TLOW = info.get("cum_factor", 1) if info else 1
            EX_FAC_TLOW = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["first_trade_date"]
                })
            if not self.check_info(info,row,row["first_trade_date"]):return []

            CUM_FAC_TOPEN = info.get("cum_factor", 1) if info else 1
            EX_FAC_TOPEN = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["last_trade_date"]
                })
            if not self.check_info(info,row,row["last_trade_date"]):return []

            CUM_FAC_TCLOSE = info.get("cum_factor", 1) if info else 1
            EX_FAC_TCLOSE = info.get("ex_factor_today", 1) if info else 1

            # open_px
            # CUM_FACTOR_BEF = 1 if row["first_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TOPEN / EX_FAC_TOPEN)
            # print "equity.symbol", row["symbol"]
            # print "first_trade_date", row["first_trade_date"]
            # print "end_date", row["end_date"]
            # print "CUM_FAC_MAX", CUM_FAC_MAX
            # print "CUM_FAC_TOPEN", CUM_FAC_TOPEN
            # print "EX_FAC_TOPEN", EX_FAC_TOPEN
            # print "CUM_FAC_MIN_160", CUM_FAC_MIN_160
            # print "CUM_FAC_MIN_60", CUM_FAC_MIN_60
            # print "CUM_FACTOR_BEF", CUM_FACTOR_BEF

            CUM_FACTOR_AFT_60 = 1 if row["first_trade_date"] == tmp[
                "WEEK_MIN_60"] else CUM_FAC_TOPEN / CUM_FAC_MIN_60

            # print type(row_1["open_px"])
            # print type(CUM_FACTOR_BEF)
            row_2["open_px"] = round(row_2["open_px"] * CUM_FACTOR_AFT_60, 2) if row_2["open_px"]  else None
            row_2["open_factor_inter"]=CUM_FACTOR_AFT_60
            # high_px
            # CUM_FACTOR_BEF = 1 if row["thigh_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_THIGH / EX_FAC_THIGH)

            CUM_FACTOR_AFT_60 = 1 if row["thigh_date"] == tmp["WEEK_MIN_60"] else CUM_FAC_THIGH / CUM_FAC_MIN_60


            row_2["high_px"] = round(row_2["high_px"] * CUM_FACTOR_AFT_60, 2) if row_2["high_px"]  else None

            row_2["high_factor_inter"]=CUM_FACTOR_AFT_60

            # low_px
            # CUM_FACTOR_BEF = 1 if row["tlow_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TLOW / EX_FAC_TLOW)

            CUM_FACTOR_AFT_60 = 1 if row["tlow_date"] == tmp["WEEK_MIN_60"] else CUM_FAC_TLOW / CUM_FAC_MIN_60

            row_2["low_px"] = round(row_2["low_px"] * CUM_FACTOR_AFT_60, 2) if row_2["low_px"]  else None

            row_2["low_factor_inter"]=CUM_FACTOR_AFT_60
            # close_px
            # CUM_FACTOR_BEF = 1 if row["last_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TCLOSE / EX_FAC_TCLOSE)

            CUM_FACTOR_AFT_60 = 1 if row["last_trade_date"] == tmp[
                "WEEK_MIN_60"] else CUM_FAC_TCLOSE / CUM_FAC_MIN_60


            row_2["close_px"] = round(row_2["close_px"] * CUM_FACTOR_AFT_60, 2) if row_2["close_px"]  else None

            row_2["close_factor_inter"]=CUM_FACTOR_AFT_60

            # prev_close_px

            for index, rr in enumerate([row_2,]):
                last_info = self.get_w_prev_close_px(rr, db, mongo_table)
                rr["prev_close_px"] = last_info.get("close_px", None)
                rr["chg"] = rr["close_px"] - rr["prev_close_px"] if rr["prev_close_px"] else None

                # 更新ma,sum
                #data120 = self.get_week_120(db, rr, mongo_table)
                data121 = self.get_week_121(db, rr, mongo_table)
                #print "xxxxxxxxxxxxx",data121
                data120 = data121[0:120]

                self.update_mas(rr, data120)
                self.update_sums(rr, data120)
                self.update_sum_non_cur(rr, data121[1:])
                rr["_id"] = "{}-{}-{}".format(rr["innerCode"],end_date,2)
                rr["end_date"] = end_date
                rr["first_trade_date"] = int(rr["first_trade_date"].strftime("%Y%m%d"))
                rr["last_trade_date"] = int(rr["last_trade_date"].strftime("%Y%m%d"))
                rr["thigh_date"] = int(rr["thigh_date"].strftime("%Y%m%d"))
                rr["tlow_date"] = int(rr["tlow_date"].strftime("%Y%m%d"))
                del rr["symbol"]
                #print rr


        # print result

        return [row_2,]

    def make_INTER_data_pre_factor(self, tradedate, code, mongo_table, mysql_table):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        n5 = datetime.datetime.now()
        result = self.WEEK_INTER_base(tradedate, code, mysql_table)

        if not result:
            return []

        # sql_tradedate_list_model = """
        #     SELECT
        #       ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
        #     FROM %(mysql_table)s a
        #     WHERE a.ISVALID = 1
        #           AND a.STOCKCODE = '%(symbol)s'
        #     ORDER BY ENDDATE DESC
        #     LIMIT 279;
        # """
        tmp = {}

        result_1 = []
        for row in result:
            row.update({"mysql_table": mysql_table})
            n6 =  datetime.datetime.now()

            tradedate_list = self.get_tradedate_list(code, mysql_table)  # 获取计算所需数据
            del row["mysql_table"]
            if not tradedate_list:
                print tradedate
                continue
            tmp = {}

            n6 = datetime.datetime.now()
            # print row["trade_date"]
            end_date =int(row["end_date"].strftime("%Y%m%d"))
            tmp["END_DATE"] = row["end_date"]
            tmp["DATE_MAX"] = tradedate_list[0]["LAST_TRADE_DATE"]
            #print "b"
            row_1 = copy.deepcopy(row)
            rows = [row_1,]
            # 从日行情取topen,tclose,tlow,thigh
            spe_days = [row["first_trade_date"],row["thigh_date"],row["tlow_date"],row["last_trade_date"]]
            spe_pxes = self.get_spe_pxes(spe_days,row["symbol"])

            #print spe_pxes
            for rrr in [row_1,]:
                rrr["open_px"] = spe_pxes[row["first_trade_date"]]["TOPEN"]
                rrr["high_px"] = spe_pxes[row["thigh_date"]]["THIGH"]
                rrr["low_px"] = spe_pxes[row["tlow_date"]]["TLOW"]
                rrr["close_px"] = spe_pxes[row["last_trade_date"]]["TCLOSE"]
            row_1["ex_status"] = 1

            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MAX"]
                })
            if not self.check_info(info,row,tmp["DATE_MAX"]):return []


            CUM_FAC_MAX = info.get("cum_factor", 1) if info else 1
            EX_FAC_MAX = info.get("ex_factor", 1) if info else 1
            #print "c"
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["thigh_date"]
                })

            #print "uuuuuuuuuuuuuuu",info

            if not self.check_info(info,row,row["thigh_date"]):return []
            #print "0000000000000000000000000000"

            CUM_FAC_THIGH = info.get("cum_factor", 1) if info else 1
            EX_FAC_THIGH = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["tlow_date"]
                })
            #print "e",row

            if not self.check_info(info,row,row["tlow_date"]):return []

            CUM_FAC_TLOW = info.get("cum_factor", 1) if info else 1
            EX_FAC_TLOW = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["first_trade_date"]
                })
            if not self.check_info(info,row,row["first_trade_date"]):return []

            CUM_FAC_TOPEN = info.get("cum_factor", 1) if info else 1
            EX_FAC_TOPEN = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["last_trade_date"]
                })
            if not self.check_info(info,row,row["last_trade_date"]):return []

            CUM_FAC_TCLOSE = info.get("cum_factor", 1) if info else 1
            EX_FAC_TCLOSE = info.get("ex_factor_today", 1) if info else 1

            # open_px
            CUM_FACTOR_BEF = 1 if row["first_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TOPEN
            # CUM_FACTOR_BEF = 1 if row["first_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TOPEN / EX_FAC_TOPEN)

            # print type(row_1["open_px"])
            # print type(CUM_FACTOR_BEF)
            row_1["open_px"] = round(row_1["open_px"] / CUM_FACTOR_BEF, 2) if row_1["open_px"]  else None
            row_1["open_factor_inter"]=CUM_FACTOR_BEF
            # high_px
            CUM_FACTOR_BEF = 1 if row["thigh_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_THIGH
            # CUM_FACTOR_BEF = 1 if row["thigh_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_THIGH / EX_FAC_THIGH)
            row_1["high_px"] = round(row_1["high_px"] / CUM_FACTOR_BEF, 2) if row_1["high_px"]  else None
            row_1["high_factor_inter"]=CUM_FACTOR_BEF

            # low_px
            CUM_FACTOR_BEF = 1 if row["tlow_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TLOW
            # CUM_FACTOR_BEF = 1 if row["tlow_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TLOW / EX_FAC_TLOW)

            row_1["low_px"] = round(row_1["low_px"] / CUM_FACTOR_BEF, 2) if row_1["low_px"]  else None

            row_1["low_factor_inter"]=CUM_FACTOR_BEF
            # close_px
            CUM_FACTOR_BEF = 1 if row["last_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TCLOSE
            # CUM_FACTOR_BEF = 1 if row["last_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TCLOSE / EX_FAC_TCLOSE)


            row_1["close_px"] = round(row_1["close_px"] / CUM_FACTOR_BEF, 2) if row_1["close_px"]  else None

            row_1["close_factor_inter"]=CUM_FACTOR_BEF

            # prev_close_px

            for index, rr in enumerate([row_1,]):
                last_info = self.get_w_prev_close_px(rr, db, mongo_table)
                rr["prev_close_px"] = last_info.get("close_px", None)
                rr["chg"] = rr["close_px"] - rr["prev_close_px"] if rr["prev_close_px"] else None

                # 更新ma,sum
                #data120 = self.get_week_120(db, rr, mongo_table)
                data121 = self.get_week_121(db, rr, mongo_table)
                #print "xxxxxxxxxxxxx",data121
                data120 = data121[0:120]

                self.update_mas(rr, data120)
                self.update_sums(rr, data120)
                self.update_sum_non_cur(rr, data121[1:])
                rr["_id"] = "{}-{}-{}".format(rr["innerCode"],end_date,1)
                rr["end_date"] = end_date
                rr["first_trade_date"] = int(rr["first_trade_date"].strftime("%Y%m%d"))
                rr["last_trade_date"] = int(rr["last_trade_date"].strftime("%Y%m%d"))
                rr["thigh_date"] = int(rr["thigh_date"].strftime("%Y%m%d"))
                rr["tlow_date"] = int(rr["tlow_date"].strftime("%Y%m%d"))
                del rr["symbol"]
                #print rr

        return [row_1,]

    def make_INTER_data_no_factor(self, tradedate, code, mongo_table, mysql_table):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        n5 = datetime.datetime.now()
        result = self.WEEK_INTER_base(tradedate, code, mysql_table)

        if not result:
            return []

        # sql_tradedate_list_model = """
        #     SELECT
        #       ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
        #     FROM %(mysql_table)s a
        #     WHERE a.ISVALID = 1
        #           AND a.STOCKCODE = '%(symbol)s'
        #     ORDER BY ENDDATE DESC
        #     LIMIT 279;
        # """
        tmp = {}
        for row in result:

            end_date =int(row["end_date"].strftime("%Y%m%d"))

            row["open_factor_inter"]=1
            row["close_factor_inter"]=1
            row["low_factor_inter"]=1
            row["high_factor_inter"]=1

            for index, rr in enumerate([row,]):
                last_info = self.get_w_prev_close_px(rr, db, mongo_table)
                rr["prev_close_px"] = last_info.get("close_px", None)
                rr["chg"] = rr["close_px"] - rr["prev_close_px"] if rr["prev_close_px"] else None

                # 更新ma,sum
                #data120 = self.get_week_120(db, rr, mongo_table)
                data121 = self.get_week_121(db, rr, mongo_table)
                #print "xxxxxxxxxxxxx",data121
                data120 = data121[0:120]

                self.update_mas(rr, data120)
                self.update_sums(rr, data120)
                self.update_sum_non_cur(rr, data121[1:])
                rr["_id"] = "{}-{}-{}".format(rr["innerCode"],end_date,index)
                rr["end_date"] = end_date
                rr["first_trade_date"] = int(rr["first_trade_date"].strftime("%Y%m%d"))
                rr["last_trade_date"] = int(rr["last_trade_date"].strftime("%Y%m%d"))
                rr["thigh_date"] = int(rr["thigh_date"].strftime("%Y%m%d"))
                rr["tlow_date"] = int(rr["tlow_date"].strftime("%Y%m%d"))
                del rr["symbol"]
                #print rr

        return [row,]

    def get_w_prev_close_px(self, row, db, mongo_table):
        last_info = db[mongo_table].find_one({
            "innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": int(row["first_trade_date"].strftime("%Y%m%d"))}
        }, {"close_px": 1}, sort=[("end_date", pymongo.DESCENDING)]
        )
        return last_info if last_info else {}


if __name__ == "__main__":
    pass
