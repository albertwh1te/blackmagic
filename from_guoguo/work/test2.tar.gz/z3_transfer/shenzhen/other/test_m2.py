# coding:utf-8
# Created by qinlin.liu at 2017/3/31

from utils.tools import mongo_cursor
from utils.mysqlutil import Mysql
from config import config
import datetime
from common import get_mysql, format_data
from convert_config import config as table_prkey_config
from main import upsert_mongo_data


def main_other_news(args):
    mysql = get_mysql()
    sql = """
        SELECT GUID FROM NEWS_STK a WHERE
a.mtime>='%(start)s-01-01'
    AND
    a.mtime<'%(end)s-01-01'
    AND a.ISVALID=1 limit %(offset)s,%(limit)s;
    """
    sql_zt="""

    select distinct t.GUID
              from
                  (select SECTION_CODE
                          ,GUID
                          ,TITLE
                          ,src_name
                          ,DECLAREDATE
                          ,t.ctime
                          ,t.SECTION_LEVEL
                          ,if(@section_code=section_code, @rank:=@rank+1, @rank:=1) as rank
                          ,@section_code:=section_code
                    from
                      (select DISTINCT
                             a.section_code as SECTION_CODE
                            ,a.SECTION_LEVEL
                            ,c.TITLE_MAIN AS TITLE
                            ,(select SRC_NAME from pgenius.PUB_INFOR_SRC
                               where isvalid=1 and c.src_code=SRC_CODE) AS src_name
                            ,c.GUID
                            ,c.DECLAREDATE
                            ,c.ctime
                        from pgenius.PUB_SECTION_CODE a
                            ,pgenius.NEWS_SECTION b
                            ,pgenius.NEWS_MAIN c
                            ,(select @section_code:=0,@rank:=0) t
                        where b.GUID=c.GUID
                          and a.section_code=b.section_code
                          and a.SYS_CODE=5
                          and a.isvalid = 1 and b.isvalid = 1 and c.ISVALID = 1
                        order by a.SECTION_CODE asc,c.ctime desc,c.DECLAREDATE desc
                      ) t
                      )t
                  where  t.rank<=100

    """

    sql_2 = """
                SELECT a.guid AS _id,
                a.TITLE_MAIN  AS title,
                a.declaredate AS declare_date,
                a.ctime,
                a.AUTOR_UNIT AS author_unit,
                a.autor AS author,
                e.SRC_NAME AS src_name,
                a.important,
                a.NEGA_POSI_MARK  AS postive_index,
                a.summary,
                b.TXT_CONTENT AS content,
                '新闻' AS news_type,
                NULL  AS acce_route,
                NULL  AS acce_type,
                NULL AS if_imp
                FROM pgenius.NEWS_MAIN a JOIN pgenius.NEWS_CONTENT b ON a.guid=b.guid
                JOIN pgenius.PUB_INFOR_SRC e ON a.src_code=e.SRC_CODE
                WHERE a.isvalid=1 AND b.isvalid=1 AND e.isvalid=1 AND a.GUID IN (%(ids)s)

    """
    #results = mysql.fetchall(sql)
    #print len(results)
    conn = mongo_cursor()
    db = conn['z3dbus']
    lists = [
        (2017, 2018),
        (2016, 2017),
        (2015, 2016),
        (2014, 2015),

        ]
    #lists=[
    #    (1989,1990)
    #        ]
    for year in lists:
        offset = 0
        limit = 1000
        while True:

            rows = mysql.fetchall(sql % {"offset": offset, "limit": limit, "start": str(year[0]), "end": str(year[1])})
            print offset, limit
            print len(rows)
            offset += limit

            if not len(rows): break
            _ids = [r["GUID"] for r in rows]
            _eids = list(db["Z3_NEWS"].find(
                {"_id": {"$in": _ids}}, {"_id": 1}))
            _eids = [r["_id"] for r in _eids]
            ids = list(set(_ids) - set(_eids))
            # print ",".join(["'%s'" % i for i in ids])
            if not len(ids): continue
            _sql = sql_2 % {"ids": ",".join(["'%s'" % i.encode("utf-8") for i in ids])}
            datas = mysql.fetchall(_sql)
            print len(datas)
            format_data(datas)
            # print len(datas)

            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config['Z3_NEWS']

            # print table_info
            upsert_mongo_data(args, 'z3dbus', 'Z3_NEWS', datas, table_info)
            if len(rows) < 1000: break
        print "finish({}--{})".format(year[0], year[1])
    print "finish"

main_other_news([1,1,'insert',1,1,1])

