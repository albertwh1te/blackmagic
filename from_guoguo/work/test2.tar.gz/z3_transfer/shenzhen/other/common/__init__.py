# coding:utf-8
# Created by qinlin.liu at 2017/3/14

import decimal, types
import time
import datetime
from config import config
from utils.mysqlutil import Mysql


def _change_data(v):
    """
    转换mysql数据，用于插入mongo
    :param v:
    :return:
    """
    if type(v) == decimal.Decimal:
        return float(v)
    elif type(v) == types.UnicodeType:
        return v
        # elif type(v) == datetime:
        #     return datetime.utcfromtimestamp(time.mktime(v.timetuple()))
        # return v.strftime('%Y-%m-%d %H:%M:%S')
        # return datetime.utcfromtimestamp(time.mktime(v))
        # da\tetime.utc
    return v


def format_data(data):
    """
    格式当行记录
    :param data:
    :return:
    """
    for i, row in enumerate(data):
        for k in row:
            row[k] = _change_data(row[k])
        data[i] = row


def get_mysql():
    try:
        return Mysql(config["mysql_test"])
    except Exception, e:
        print e
        time.sleep(5)
        return get_mysql()


def pre_date(days=0, base_day=None):
    """
    获取当前时间的日期 前天日期
    :return: datetime
    """
    # print type(time.localtime(time.time()))
    # print type(base_day)
    if base_day:
        base_day = base_day.strftime('%Y-%m-%d')
    else:
        base_day = time.strftime('%Y-%m-%d', time.localtime(time.time()))
    return datetime.datetime.strptime(base_day,
                                      '%Y-%m-%d') - datetime.timedelta(days=days)

    if __name__ == "__main__":
        pass
