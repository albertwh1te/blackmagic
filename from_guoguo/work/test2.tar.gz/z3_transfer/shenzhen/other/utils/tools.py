# coding:utf-8
# Created by qinlin.liu at 2017/3/28

import pymongo
import logging, logging.handlers
from config import config

def mongo_cursor():
    # conn = pymongo.MongoClient(**config["mongodb_test"])
    conn = pymongo.MongoClient(config["mongodb_test"]["uri"])
    return conn

def mongo_cursor2():
    # conn = pymongo.MongoClient(**config["mongodb_test"])
    conn = pymongo.MongoClient(config["mongodb_test"]["uri2"])
    return conn


if __name__ == "__main__":
    pass


class SMTPSSLHandler(logging.handlers.SMTPHandler):
    def emit(self, record):
        """
              Emit a record.

              Format the record and send it to the specified addressees.
              """
        try:
            import smtplib
            from email.utils import formatdate
            port = self.mailport
            if not port:
                port = smtplib.SMTP_PORT
            smtp = smtplib.SMTP_SSL(self.mailhost, port, timeout=self._timeout)
            msg = self.format(record)
            msg = "From: %s\r\nTo: %s\r\nSubject: %s\r\nDate: %s\r\n\r\n%s" % (
                self.fromaddr,
                ",".join(self.toaddrs),
                self.getSubject(record),
                formatdate(), msg)
            if self.username:
                if self.secure is not None:
                    smtp.ehlo()
                    smtp.starttls(*self.secure)
                    smtp.ehlo()
                smtp.login(self.username, self.password)
            smtp.sendmail(self.fromaddr, self.toaddrs, msg)
            smtp.quit()
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            self.handleError(record)


def init_log():
    logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                        datefmt='%a, %d %b %Y %H:%M:%S',
                        filename='test.log',
                        filemode='w')
    # return logging.getLogger()
    root = logging.getLogger()
    sh = SMTPSSLHandler(
        mailhost=('smtp.exmail.qq.com', 465),
        fromaddr='qinlin.liu@genius.com.cn',
        toaddrs='qinlin.liu@genius.com.cn',
        subject='Logged Event',
        credentials=('qinlin.liu@genius.com.cn', '123.comA'))
    root.addHandler(sh)
    return root
