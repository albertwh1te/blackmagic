# coding:utf-8
# Created by qinlin.liu at 2017/3/15
"""
mongo表对应的过滤字段
"""
config = {
    "Z3_EQUITY_PROFILE": {
        "pri_key": ["innerCode"],
        "delete_old": True
    },
    "Z3_INDEX_SAMPLE": {
        "pri_key": ["symbol"],
        "delete_old": True
    },
    "Z3_TOPIC_SAMPLE": {
        "pri_key": ["topic_code"],
        "delete_old": True
    },
    "Z3_EQUITY_NEWS": {
        "pri_key": ["guid"],
        "delete_old": False
    },
    "Z3_EX_FACTOR_ALL": {
        "pri_key": ["symbol", "end_date"],
        "delete_old": False,
        "equity": True
    },
    "Z3_MNG_HOLD_STK_INFO": {
        "pri_key": ["innerCode", "mgt_id"],
        "delete_old": False,
        "equity": True
    },
    "Z3_RESEARCH_REPORT": {
        "pri_key": ["res_id"],
        "delete_old": False,
        "equity": True
    },
    "Z3_STK_MKT_DAY_INTER": {
        "pri_key": ["innerCode", "end_date", "ex_status"],
        "delete_old": False,
        "equity": True
    },
    "Z3_STK_MKT_WEEK_INTER": {
        "pri_key": ["innerCode", "end_date", "ex_status"],
        "delete_old": False,
        "equity": True
    },
    "Z3_STK_MKT_MONTH_INTER": {
        "pri_key": ["innerCode", "end_date", "ex_status"],
        "delete_old": False,
        "equity": True
    },
    "Z3_EQUITY": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "nesteds": ["mkt2_idx", "signal_normal"]
    },
    "Z3_EQUITY2": {
        "pri_key": ["_id", ],
        "delete_old": False
    },
    "Z3_EXCHANGE_CALENDAR": {
        "pri_key": ["trade_date", "exchange"],
        "delete_old": False

    },
    "Z3_EQUITY_HISTORY":{
        "pri_key": ["_id", ],
        "delete_old": False
    }
}
if __name__ == "__main__":
    pass
