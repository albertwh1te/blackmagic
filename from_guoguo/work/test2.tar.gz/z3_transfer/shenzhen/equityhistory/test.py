# coding:utf-8
# Created by qinlin.liu at 2017/3/31

from utils.tools import mongo_cursor
from utils.mysqlutil import Mysql
from config import config
import datetime


def get_data():
    cursor = mongo_cursor()
    db = cursor["z3dbus"]
    results =  db["Z3_STK_MKT_MONTH_INTER"].find().limit(10)
    print list(results)
    # ("equity.symbol",
    #                                               {"trade_date": datetime.datetime.strptime("2017-03-31", "%Y-%m-%d")})
    return
    results = list(results)
    print results
    sql = """
        SELECT DISTINCT INNER_CODE FROM stk_mkt WHERE  SECCODE not in(
        %s
        )
    """ % ",".join(["'%s'" % i for i in results])
    print sql
    mysql = Mysql(config["mysql_test"])
    print  mysql.fetchall(sql)


# stks = ['000003', '000005', '200015', '000022', '600604', '600605', '600606', '600607', '600608', '600653']
get_data()
