# coding:utf-8
# Created by qinlin.liu at 2017/3/14


import pymysql.err


class Mysql:
    def __init__(self, config):
        self._db = pymysql.connect(**config)
        self._cursor = self._db.cursor()
        pass

    def fetchall(self, query, args=None):
        # print query
        self._cursor.execute(query, args)
        result = self._cursor.fetchall()
        return result

    def fetchone(self, query, args=None):
        # print query
        self._cursor.execute(query, args)
        result = self._cursor.fetchone()
        return result

    def execute(self, query, parameters=tuple()):
        """
        执行一条sql，比如update, insert, delete等操作。查询select请使用 query，get, iter
        last_row_id = db.execute("update user set name = ':name' where uid = :uid", "boyaa", 5)
        print last_row_id
        """
        return self.execute_lastrowid(query, parameters)

    def execute_lastrowid(self, query, parameters=tuple()):
        cursor = self._cursor

        try:
            self._execute(cursor, query, parameters)
            return cursor.lastrowid
        finally:
            cursor.close()

    def _execute(self, cursor, query, parameters):
        try:
            cursor.execute(query, parameters)
            self._db.commit()
        except pymysql.err.OperationalError as e:
            self._db.rollback()
            raise Exception(
                """errr_info:%s \n           sql: %s""" % (str(e), query))

    def commit(self):
        pass


if __name__ == "__main__":
    pass
