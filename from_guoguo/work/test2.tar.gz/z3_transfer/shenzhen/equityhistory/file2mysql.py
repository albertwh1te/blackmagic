# coding:utf-8
# Created by qinlin.liu at 2017/4/1

import re
from utils.mysqlutil import Mysql
from config import config

common_matchs = {

    "PGenius.dbo.": "",
    "0x00000.*?,": "now(),",
}
d = {
    "INDX_SAMP_INFO": {
        "path": r" ",
        "matchs": {
            "INSERT INTO INDX_SAMP_INFO \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, INNER_CODE, INDX_ID, INDX_CODE, INDX_CNAME, INDX_SNAME, SEC_CLS_CODE, SEC_CLS, SEC_INNER_CODE, SEC_CODE, SEC_SNAME, MKT_TYPE_CODE, MKT_TYPE, STARTDATE, ENDDATE, SAMP_STATUS\) VALUES ": ","
        }
    },
    "INDX_GEN_INFO": {
        "path": r"E:\kylin_doc\SELECT_t___FROM_PGenius_dbo_INDX_GEN_INF.sql",
        "matchs": {
            "INSERT INTO INDX_GEN_INFO \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, INNER_CODE, ISIN, INDX_CODE, INDX_ID, INDX_CNAME, INDX_ENAME, INDX_SNAME, PY_SNAME, PUB_DATE, PUB_ORGNAME, PUB_ORG, AUTH_ORGNAME, AUTH_ORG, BASE_DATE, BASE_POINT, SEC_NUM, SEC_CLS_CODE, SEC_CLS, SAMP_CLS, SAMP_MKT_CLS, ORIENT_CLS_CODE, ORIENT_CLS, ORG_CLS, SAMP_SCOPE, SAMP_STD, SAMP_METH, WHG_METH_CODE, WHG_METH, CALCU_METH, ADJ_FREQ_CODE, ADJ_FREQ, ADJ_METH, MAINTAIN_STATUS, USE_STATUS, END_DATE, INDX_INTRO, IS_MKT, IS_SAMPE\) VALUES ": ","
        }
    },
    "PUB_SECTION_REL": {
        "path": r"E:\kylin_doc\SELECT_t___FROM_PGenius_dbo_PUB_SECTION_.sql.bak",
        "matchs": {
            "INSERT INTO PUB_SECTION_REL \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, SECTION_CODE, INNER_CODE, SEC_NAME, SEC_SNAME, SECTION_NAME, SYS_NAME, MKT_CODE, COM_MENT, SYS_CODE, EN_TIME, REJE_TIME\) VALUES": ","
        }
    },
    "STK_MKT": {
        "path": r"E:\kylin_doc\SECCODE____3.sql",
        "matchs": {
            "INSERT INTO STK_MKT \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, INNER_CODE, SECCODE, TRADEDATE, TRADE_MKT, LIST_SEC, STK_TYPE, STOCKSNAME, LCLOSE, TOPEN, TCLOSE, THIGH, TLOW, TVOLUME, TVALUE, DEAL, CHNG, CHNG_PCT, BP1, BV1, SP1, SV1, BP2, BV2, SP2, SV2, BP3, BV3, SP3, SV3, BP4, BV4, SP4, SV4, BP5, BV5, SP5, SV5\) VALUES ": ","
        }
    },
    "PUB_SECTION_CODE": {
        "path": r"E:\kylin_doc\SELECT_t___FROM_PGenius_dbo_PUB_SECTION_.sql",
        "matchs": {
            "INSERT INTO PUB_SECTION_CODE \(SEQ, CTIME, MTIME, ISVALID, SECTION_CODE, SECTION_NAME, SECTION_MEANING, SYS_CODE, SECTION_LEVEL, PARENT_CODE, IS_USED\) VALUES": ","
        }
    },
    "STK_MNG_TRADE_INFO": {
        "path": r"E:\kylin_doc\TRAD.sql",
        "matchs": {
            "INSERT INTO STK_MNG_TRADE_INFO \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, COMCODE, A_STOCKCODE, A_STOCKSNAME, B_STOCKCODE, B_STOCKSNAME, ITEM_ID, STK_CODE, STK_SN, STK_CLS, MNG_NAME, INDI_ID, POST, HOLDER, RELATION, BEGIN_VOL, CHNG_VOL, CHNG_PCT, END_VOL, CHNG_RSN, CHNG_DATE, FILL_DATE, CHEG_EP, CURNCY, HOLDER_CODE, IS_SHORT_TRADE\) VALUES": ","
        }
    },
    "STK_EXCRA_BRANCH_LIST": {
        "path": r"E:\kylin_doc\SELECT_t___FROM_PGenius_dbo_STK_EXCRA_BR.sql",
        "matchs": {
            "INSERT INTO STK_EXCRA_BRANCH_LIST \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, ORDERID, P_SEQ, BRANCH_CODE, BRANCH_NAME, TVALUE, BVALUE, SVALUE\) VALUES ": ","
        }
    },
    "ORG_PROFILE": {
        "path": r"E:\kylin_doc\org.sql",
        "matchs": {
            "INSERT INTO ORG_PROFILE \(ISVALID, ORGCODE, ORG_TYPE, CSName\) VALUES": ","
        }
    },
    "STK_EX_FACTOR_MKT": {
        "path": r"E:\kylin_doc\STK_EX_FACTOxx.sql",
        "matchs": {
            "INSERT INTO STK_EX_FACTOR_MKT \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, STOCKCODE, ENDDATE, EX_FACTOR, CUM_FACTOR, IS_NON_TRD\) VALUES": ","
        }
    },
    "ANA_STK_MKT_WEEK": {
        "path": r"E:\kylin_doc\PGenius_dbo_ANA_STK_MKT_week.sql",
        "matchs": {
            "INSERT INTO ANA_STK_MKT_WEEK \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, INNER_CODE, STOCKCODE, STOCKSNAME, ENDDATE, TRADE_DAYS, LCLOSE, TOPEN, THIGH, TLOW, TCLOSE, TCLOSE_HIGH, TCLOSE_LOW, AVG_PRC, CHNG, CHNG_PCT, LOG_YLD, EXCHR, AVG_EXCHR, TVOLUME, TVALUE, SWG, THIGH_DATE, TLOW_DATE, TCLOSE_HIGH_DATE, TCLOSE_LOW_DATE, FIRST_TRADE_DATE, LAST_TRADE_DATE, VOLAT_100_WEEK, BETA_100_WEEK, YLD_100_WEEK, FAC_LCLOSE, FAC_TOPEN, FAC_THIGH, FAC_THIGH_DATE, FAC_TLOW_DATE, FAC_TLOW, FAC_TCLOSE, FAC_TCLOSE_HIGH, FAC_TCLOSE_LOW, FAC_TCLOSE_HIGH_DATE, FAC_TCLOSE_LOW_DATE\) VALUES": ","
        }
    },
    "ANA_STK_MKT_MONTH": {
        "path": r"E:\kylin_doc\PGenius_dbo_ANA_STK_MKT_MONTH.sql",
        "matchs": {
            "INSERT INTO ANA_STK_MKT_MONTH \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, INNER_CODE, STOCKCODE, STOCKSNAME, ENDDATE, TRADE_DAYS, LCLOSE, TOPEN, THIGH, TLOW, TCLOSE, TCLOSE_HIGH, TCLOSE_LOW, AVG_PRC, CHNG, CHNG_PCT, LOG_YLD, EXCHR, AVG_EXCHR, TVOLUME, TVALUE, SWG, THIGH_DATE, TLOW_DATE, TCLOSE_HIGH_DATE, TCLOSE_LOW_DATE, FIRST_TRADE_DATE, LAST_TRADE_DATE, VOLAT_24_MON, VOLAT_60_MON, BETA_24_MON, BETA_60_MON, YLD_24_MON, YLD_60_MON, FAC_LCLOSE, FAC_TOPEN, FAC_THIGH, FAC_THIGH_DATE, FAC_TLOW_DATE, FAC_TLOW, FAC_TCLOSE, FAC_TCLOSE_HIGH, FAC_TCLOSE_LOW, FAC_TCLOSE_HIGH_DATE, FAC_TCLOSE_LOW_DATE\) VALUES": ","
        }
    },
    "DISC_COM": {
        "path": r"E:\kylin_doc\PGenius_dbo_DISC_COM_t.sql",
        "matchs": {
            "INSERT INTO DISC_COM \(SEQ, CTIME, MTIME, ISVALID, DISC_ID, COMCODE, DECLAREDATE\) VALUES": ","}

    },
    "STK_EXCRA_INFO_MAIN": {
        "path": r"E:\kylin_doc\EXCRA_IN.sql",
        "matchs": {
            "INSERT INTO STK_EXCRA_INFO_MAIN \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, ENDDATE, INNER_CODE, EXCHANGE, EXCH_NAME, INFO_CLS_CODE, INFO_CLS_NAME, SEC_TYPE, SEC_NAME, RANK_CLS, RANK_NAME, DES_VAL, VOLUME, VALUE, SPL_STA_DATE, SPL_END_DATE\) VALUES": ","}

    },
    "DISC_MAIN_COM": {
        "path": r"E:\kylin_doc\PGenius_dbo_DISC_MAIN_CO.sql",
        "matchs": {
            "INSERT INTO DISC_MAIN_COM \(SEQ, CTIME, MTIME, ISVALID, DISC_ID, DECLAREDATE, TITLE, SOURCE, QJ_NUM, IS_ACCE, ENDDATE, IS_CONTENT\) VALUES": ","}

    },
    "DISC_ACCE_COM": {
        "path": r"E:\kylin_doc\PGenius_dbo_DISC_ACCE_CO.sql",
        "matchs": {
            "INSERT INTO DISC_ACCE_COM \(SEQ, CTIME, MTIME, ISVALID, DISC_ID, ACCE_ORDER, ACCE_ROUTE, ACCE_TYPE, ACCE_TITLE, ACCE_ROUTE_MD5, ACCE_FTP_ROUTE, ACCE_ID\) VALUES": ","}

    },
    "ANA_STK_TWE_IDX": {
        "path": r"E:\kylin_doc\SELECT_t___FROM_PGenius_dbo_ANA_STK_TWE_.sql",
        "matchs": {
            "INSERT INTO ANA_STK_TWE_IDX \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, COMCODE, ENDDATE, EPS, PS_NET_VAL, PS_OR, PS_CN, ROE, ROA, ROA_NP, SEL_NINT, SEL_RINT, SEL_FEE, TR_NP, TR_TP, TR_TC, TR_OF, TR_MF, TR_FF, TR_AE, TP_ONI, TP_VNI, TP_OON, OR_SEL, OR_OC, OR_OCN, INC_GRO, INC_REV, INC_OPE, INC_GEN, INC_IN, INC_SAL, INC_MAN, INC_FAN, INC_ASS, INC_OPN, INC_VCN, INC_OI, INC_OON, INC_TAX, INC_GI, INC_NI, INC_MI, CAS_SAL, CAS_OPE, CAS_INV, CAS_FIN, CAS_NET, A_STOCKCODE, A_STOCKSNAME, B_STOCKCODE, B_STOCKSNAME, TR_TAX, INC_OUT\) VALUES": ","
        }
    },
    "STK_GREATE_EVENT": {
        "path": r"E:\kylin_doc\SELECT_GREATE_EVENT.sql",
        "matchs": {
            "INSERT INTO STK_GREATE_EVENT\(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, EVENT_ID, DECLAREDATE, ITEM_ID, EVENT_CODE, EVENT, DISC, TRD_CAP, RLT_TRD, PRG_CODE, PRG, TRD_INFO, ORG_CODE, ORG_NAME, TRD_DRC_CODE, TRD_DRC, CURNCY, IF_REOG, TRD_EFF, STOCKCODE, PAY_CLS, OBJECT_TYPE\) VALUES": ","
        }
    },
    "STK_PRE_DISCLOSURE": {
        "path": r"E:\kylin_doc\DISC.sql",
        "matchs": {
            "INSERT INTO STK_PRE_DISCLOSURE \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, COMCODE, A_STOCKCODE, A_STOCKSNAME, B_STOCKCODE, B_STOCKSNAME, PERIODDATE, PRE_DATE, CHNG_DATE1, CHNG_DATE2, CHNG_DATE3, ACT_DATE\) VALUES": ","
        }
    },
    "STK_REPURCHASE": {
        "path": r"E:\kylin_doc\PGenius_dbo_STK_REPURCHA.sql",
        "matchs": {
            "INSERT INTO STK_REPURCHASE \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, COMCODE, ITEM_NUM, DECLAREDATE, SH_DCL_DATE, PRG, REPU_VAL_MAX, REPU_VAL_MIN, REPU_NUM_MAX, REPU_NUM_MIN, PRC_MAX, PRC_MIN, REPU_SRC, REPU_PURPOSE, REPU_CLS, REPU_ACT_DATE, REPU_STARTDATE, REPU_ENDDATE, REPU_ACT_VAL, CURNCY, ACT_NUM, ACT_PRC_MAX, ACT_PRC_MIN, CHNG_TYPE, CHNG_DATE, CHNG_INFO, SHR_TYPE\) VALUES": ","
        }
    },
    "STK_ADD_HOLD": {
        "path": r"E:\kylin_doc\UUUAA.sql",
        "matchs": {
            "INSERT INTO STK_ADD_HOLD\(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, COMCODE, ITEM_NUM, A_STOCKCODE, A_STOCKSNAME, B_STOCKCODE, B_STOCKSNAME, DECLAREDATE, ACTU_DATE, PRG, ADD_NAME, ADD_CODE, STK_TYPE, ADD_NUM, ADD_PCT, AVG_PRC, PROMISE, STARTDATE, ENDDATE, BEF_HOLD_NUM, BEF_HOLD_PCT, END_HOLD_NUM, END_HOLD_PCT, ACC_HOLD_NUM, ACC_ADD_PCT, ACC_AVG_PRC, PURPOSE_PLAN, ADD_SUB_TYPE, ADD_SUB_CLS, BEF_UNLTD_NUM, END_UNLTD_NUM, BEF_UNLTD_PCT, END_UNLTD_PCT, BEF_LTD_NUM, END_LTD_NUM, BEF_LTD_PCT, END_LTD_PCT, DISC_ID, IS_FIRST_HOLDER, CAP_NAME, PLAN_DECLAREDATE, ADD_OBJ_TYPE, IS_UNCOND, MAX_VAL, MIN_VAL, CAP_CODE, IS_OVER_FIVE, CAP_RMK, TRAN_VAL\) VALUES": ","
        }
    },
    "STK_EX_FACTOR": {
        "path": r"E:\kylin_doc\STK_EX_FACTO.sql",
        "matchs": {
            "INSERT INTO STK_EX_FACTOR \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, INNER_CODE, STOCKCODE, STOCKNAME, EX_DATE, REGI_DATE, REGI_DT_CLOSE_PRC, EX_DT_CLOSE_PRC, CASH, DIV_SHR, TRAN_SHR, ISS_SHR, ISS_PRC, EX_FACTOR, CUM_FACTOR, ENDDATE\) VALUES": ","
        }
    },
    "STK_EXCRA_BRANCH_LIST": {
        "path": r"E:\kylin_doc\BR.sql",
        "matchs": {
            "INSERT INTO STK_EXCRA_BRANCH_LIST \(SEQ, CTIME, MTIME, ISVALID, GENIUS_UID, ORDERID, P_SEQ, BRANCH_CODE, BRANCH_NAME, TVALUE, BVALUE, SVALUE\) VALUES": ","
        }
    },
    "MY_TABLE": {
        "path": r"E:\kylin_doc\REMAR.sql",
        "matchs": {
            "INSERT INTO MY_TABLE\(SEQ, CTIME, MTIME, ISVALID, REMARK, ORGCODE, DECLAREDATE, CNAME, CSNAME, CSPELL, ENAME, ESNAME, REGI_CAP, CURNCY, REGI_ADDR, OFFICE_ADDR, WEB_SITE, POSTCODE, LEG_PERSON, GEN_MANAGER, DISTRICT_NO, TEL, FAX, EMAIL, CONTACT_PERSON, BOARD_SECTRY, SECTRY_TEL, SECTRY_FAX, CONTACT_ADDR, SECTRY_EMAIL, REPR, REPR_TEL, REPR_FAX, REPR_ADDR, REPR_EMAIL, BRIEF_INTRO, PRI_BIZ, NON_PRI_BIZ, STAFF_NUM, MSTAFF_NUM, TSTAFF_NUM, DISCL_PAPER, DISCL_WEBSITE, BUILD_DATE, CLOSE_DATE, CLOSE_REASON, ORG_STATUS, REGI_NO, NTAX_NO, LTAX_NO, LISTED, ISSUE_BOND, NATION, REGION, ORG_TYPE, ORG_MTYPE, ORG_STYPE, ORG_FORM, MOTHER_CODE, TOPCODE, PARENTCODE, LAYERCODE, MOTHER_NAME, TOP_NAME, PARENT_NAME, GENIUS_UID, SERVICE_TEL, PROVINCE, CITY, REGION_CODE, STATUS_NAME, CURNCY_NAME, NATION_NAME, REGION_NAME, TYPE_NAME, MTYPE_NAME, STYPE_NAME, FORM_NAME\) VALUES": ","
        }
    }
}


# result, number  =  re .subn(re.compile('wo.'), "uu", "hello word")


def insert_data(sql_str):
    mysql = Mysql(config["mysql_test"])
    print sql_str
    mysql.execute(sql_str.decode("utf-8"))


def truncate_data(key):
    mysql = Mysql(config["mysql_test"])
    mysql.execute(""" truncate table %s""" % key)


def do_insert(ll, key):
    sql_str = "".join(ll)
    sql_str = sql_str.replace("%", "%%")
    try:
        insert_data(sql_str)
    except:
        # 写到错误文件
        with open("ERROR_%s" % key, "a+") as ff:
            ff.write(sql_str + "\n")
        # print sql_str
        pass


def main(key):
    info = d.get(key)
    truncate_data(key)
    ll = []
    with open(info["path"]) as f:
        index = 0
        ll = []
        for i in f:
            i = i.replace("\n", "")
            # i = i.strip()
            if i:
                for reg, reg_replace in common_matchs.items():
                    i, number = re.subn(re.compile(reg), reg_replace, i)
            # 判断是否是INSERT INTO 开头
            insert_head = "^((?!INSERT INTO).)*$"
            if re.match(insert_head, i):
                i = i.replace(");", ")")

                ll[-1] = ll[-1] + i
            else:

                if index >= 1000:
                    index = 0
                    do_insert(ll, key)
                    ll = []

                i = i[:-1]
                if index:
                    for reg, reg_replace in info["matchs"].items():
                        i, number = re.subn(re.compile(reg), reg_replace, i)
                ll.append(i)
                index += 1
    if ll:
        do_insert(ll, key)


if __name__ == "__main__":
    main("ORG_PROFILE")
