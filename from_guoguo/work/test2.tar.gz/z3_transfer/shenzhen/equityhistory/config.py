# coding:utf-8
# Created by qinlin.liu at 2017/3/14
import pymysql

config = {
    "mysql_release": {
        "host": "172.18.3.7",
        "user": "root",
        "password": "123456",
        "db": "pgenius",
        "charset": 'utf8mb4',
        "cursorclass": pymysql.cursors.DictCursor
    },
        "mysql_test": {
            "host": "10.77.4.8",
            "port": 3306,
            "user": "z3python",
            "password": "z3python",
            "db": "pgenius",
            "charset": 'utf8mb4',
            "cursorclass": pymysql.cursors.DictCursor
        },
    "mysql_test_y": {
        "host": "10.88.3.178",
        "port": 3307,
        "user": "JRJ_JuLing",
        "password": "5um5HwHDn2vqnFwwGOis",
        "db": "pgenius",
        "charset": 'utf8mb4',
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mysql_local": {
        "host": "localhost",
        "user": "root",
        "password": "root",
        "db": "test",
        "charset": 'utf8mb4',
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mongodb_release": {
        "host": "172.18.3.133",
        "replicaset": "athena"
    },
    "mongodb_test": {
        "host": "117.121.98.91",
        "replicaset": "athena",
        "uri": "mongodb://z3dbusadmin:z3dbusadmin@117.121.98.91:27017/z3dbus?authMechanism=SCRAM-SHA-1"
    },
    "mongodb_local": {
        "host": "127.0.0.1"
    },
}
