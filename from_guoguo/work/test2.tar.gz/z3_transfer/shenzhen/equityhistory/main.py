# coding:utf-8 # Created by qinlin.liu at 2017/3/14
import pymongo
import datetime
import copy
from utils.mysqlutil import Mysql
from utils import tools
from config import config
from convert_config import config as table_prkey_config
from common import format_data, pre_date
from data_source_copy import DataSourceCopy
from data_source_copy.cal_history import CopyHistory
import time
import multiprocessing as mp

def insetf1(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.insertRelavolume()
    except Exception as e:
            print(e)

def insetf2(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.calRsi14()
    except Exception as e:
            print(e)

def insetf3(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.cal_tendency()
    except Exception as e:
            print(e)

def insetf4(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.cal_tencyrank()
    except Exception as e:
            print(e)

def insetf5(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        print(starttime,endtime)
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        # print(CH)
        CH.cal_limit()
    except Exception as e:
            print(e)

def insetf6(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        print(starttime,endtime)
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        # print(CH)
        CH.cal_chng_pct_from_open()
    except Exception as e:
            print(e)

def insetf7(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        print(starttime,endtime)
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.cal_chng_pct_week()
    except Exception as e:
            print(e)

def insetf8(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        print(starttime,endtime)
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.cal_gap()
    except Exception as e:
            print(e)

def insetf9(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.cal_max_cross()
    except Exception as e:
            print(e)

def insetf10(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.cal_high_low()
    except Exception as e:
            print(e)

def insetf11(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        CH.sig_6()
    except Exception as e:
            print(e)


def insertOnesqlpart(timeinfo):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    # database, table_name = args[0].split(".")
    database = "test"
    table_name = "test"
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = timeinfo[0]
    endtime = timeinfo[1]
    try:
        print(starttime,endtime)
        CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
        # print(CH)
        CH.insertRelavolume()
        CH.calRsi14()
        CH.cal_tendency()
        # CH.cal_tencyrank()
        # CH.cal_limit()
        # CH.cal_chng_pct_from_open()
        # CH.cal_chng_pct_week()
        # CH.cal_gap()
        # CH.cal_max_cross()
        # CH.cal_high_low()
        # CH.del_the_b()
        CH.sig_6()
    except Exception as e:
            print(e)

def gen_datetime(year,month):
    return datetime.datetime(year,month,1)

def copy_final(args):
    num = int(args[1])
    func_list = [insetf1,insetf2,insetf3,insetf4,insetf5,insetf6,insetf7,insetf8,insetf9,insetf10,insetf11]
    func = func_list[num-1]

    # month_list = [i for i in range(1,12)]
    month_list = [1]
    # year_list = [2014]
    year_list = [2015]

    year_month_list = [( gen_datetime(y,m),gen_datetime(y,m+1)) for y in year_list for m in month_list]
    # year_month_list.append((datetime.datetime(2014,12,1),datetime.datetime(2015,1,1)))

    print(year_month_list)
    print(func)
    pool = mp.Pool(50)
    # map(func,year_month_list)
    pool.map(func,year_month_list)

def copy_history_sql_2(args):

    # starttime = datetime.datetime(2015,01,01)
    # starttime = datetime.datetime(2014,12,30)
    # endtime = datetime.datetime(2015,02,01)

    # month_list = [i for i in range(1,12)]
    month_list = [1]
    # year_list = [2014]
    year_list = [2015]

    year_month_list = [( gen_datetime(y,m),gen_datetime(y,m+1)) for y in year_list for m in month_list]
    # year_month_list.append((datetime.datetime(2014,12,1),datetime.datetime(2015,1,1)))

    print(year_month_list)
    pool = mp.Pool(100)
    # pool.map(insertOnesqlpart,year_month_list)
    map(insertOnesqlpart,year_month_list)

def copy_history_no_sql(args):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    starttime = datetime.datetime(2015,01,01)
    endtime = datetime.datetime(2015,02,01)


    CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
    CH.insertNosqlpart()

def copy_history_sql(args):
    mysql = Mysql(config["mysql_test"])
    # mysql = Mysql(config["mysql_release"])
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    starttime = datetime.datetime(2015,01,01)
    endtime = datetime.datetime(2015,02,01)

    CH = CopyHistory(mysql, database, table_name, {"starttime": starttime, "endtime": endtime}, curr_time, None)
    CH.insertVolumeprice()

def main_muti(args):
    try:
        # mysql = Mysql(config["mysql_test"])
        mysql = Mysql(config["mysql_release"])
    except Exception as e:
        print e,
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    # if args[2]:
    #     curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    ds.help_muti()

def get_some_trade_date(start_time,end_time):
    a = [i for i in range(1,13)]
    conn = tools.mongo_cursor()
    db = conn["z3dbus"]
    # start_time = datetime.datetime(2014,01,01)
    time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('trade_date')
    # print(time_list[:10])
    # print(len(time_list))
    return time_list

def get_fuck_list(start_time,end_time):
    a = [i for i in range(1,13)]
    conn = tools.mongo_cursor()
    db = conn["z3dbus"]
    # start_time = datetime.datetime(2014,01,01)
    time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('trade_date')
    stock_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('innerCode')
    print(stock_list[:10])
    # print(time_list[:10])
    # print(len(time_list))
    fuck_list = [(time,stock) for time in time_list for stock in stock_list]
    print(fuck_list[:10])
    return fuck_list

def fuck_cur(fuck_time):
    mysql = Mysql(config["mysql_release"])
    database = "z3dbus"
    table_name = "test"
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    ds.help_3_data(fuck_time)

def warp_history(args):
    try:
        # mysql = Mysql(config["mysql_test"])
        mysql = Mysql(config["mysql_release"])
    except Exception as e:
        print e,
        return
    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    # if args[2]:
    #     curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    # innercode_list = ds.get_INNER_CODE_list()
    # import ipdb; ipdb.set_trace()
    n = 30
    pool = mp.Pool(n)
    # print(pool)
    start_time = datetime.datetime(2015,01,01)
    end_time = datetime.datetime(2015,02,01)
    fuck_list = get_fuck_list(start_time,end_time)

    pool.map(fuck_cur,fuck_list)
    # fuck_cur(fuck_list[1])

def main_history(args):
    """
    equity history

    :param args:
    :return:
    """
    try:
        # mysql = Mysql(config["mysql_test"])
        mysql = Mysql(config["mysql_release"])
    except Exception as e:
        print e,
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    # if args[2]:
    #     curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    # innercode_list = ds.get_INNER_CODE_list()
    method = getattr(ds, m)
    method()


def main_fqian(args):
    """
    复权因子表处理
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    # if args[2]:
    #     curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    innercode_list = ds.get_INNER_CODE_list()
    # innercode_list = [
    # {"INNER_CODE": 101000001},
    # {"INNER_CODE": 101000005}, {"INNER_CODE": 101002348}]
    # start = int(args[1])
    # end = start + 100
    # print start, end
    # print innercode_list[start:end]
    # method = getattr(ds, m)
    method = getattr(ds, m)
    for i in innercode_list:
        # for i in innercode_list:
        data = method(i)
        # 格式化mysql数据
        format_data(data)
        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)

    if args[1]:
        # 如果传递了股票代码，说明是手动操作，不需要更新任务状态
        return
    # return
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    update_task(ds, curr_time, database, table_name)


def main_equity(args):
    """
    日级信号指标处理
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    if args[2]:
        curr_time = datetime.datetime.strptime(args[2], '%Y-%m-%d')
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    stock_list = ds.get_STOCKINFO_list()
    format_data(stock_list)
    # print stock_list\
    start = int(args[1])
    end = start + 10
    if hasattr(ds, m):
        method = getattr(ds, m)
        for i in stock_list:
            print i
            data = method([i, ])
            # 格式化mysql数据
            format_data(data)
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, 'Z3_EQUITY', data, table_info)

    if args[1]:
        # 如果传递了股票代码，说明是手动操作，不需要更新任务状态
        return

    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    # update_task(ds, curr_time, database, table_name)


def update_task(ds, curr_time, database, table_name):
    # 更新任务信息
    return
    update_dict = {

        "LASTRUNTIME": curr_time,
        "NEXTRUNTIME": get_last_update_time(curr_time, ds.task_info),
        "UPDATETIME": getnow().strftime("%Y-%m-%d %H:%M:%S"),
        "SDATABASE": ds.task_info.get("SDATABASE", ""),
        "STABLE": ds.task_info.get("STABLE", ""),
        "TDATABASE": ds.task_info.get("TDATABASE", database),
        "TTABLE": ds.task_info.get("TTABLE", table_name),
        "FREQUENCY": ds.task_info.get("FREQUENCY", "D"),
        "SPACE": ds.task_info.get("SPACE", 1),
    }
    print update_dict.values()
    sql = """
        INSERT INTO z3_update_task(%(keys)s) VALUES (%(values)s)
        ON DUPLICATE KEY UPDATE %(kwargs)s;
    """ % ({
        "keys": ",".join(update_dict.keys()),
        "values": ",".join([("'%s'" % v) if k != "NEXTRUNTIME" else ("%s" % v) for k, v in update_dict.items()]),
        "kwargs": " , ".join(
            [("%s='%s'" % (k, v)) if k != "NEXTRUNTIME" else("%s=%s" % (k, v)) for k, v in update_dict.items()])
    })
    print sql
    ds.update_taks(sql)


def main_day_inter(args):
    try:
        mysql = Mysql(config["mysql_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    n1 = datetime.datetime.now()
    innercode_list = ds.get_INNER_CODE_list()  # 可以考虑函数缓存
    # print "get innercode_list use:", datetime.datetime.now() - n1
    # innercode_list = [{"INNER_CODE": 101002348}]
    # innercode_list = [{"INNER_CODE": 101002348}, {"INNER_CODE": 101000001}, {"INNER_CODE": 101000005}]
    print len(innercode_list)
    start = int(args[1])
    end = start + 100
    print start, end
    print innercode_list[0]
    method = getattr(ds, m)
    #
    for c in innercode_list[start:end]:
        tradedate_list = ds.get_TRADEDATE_list(c["INNER_CODE"], 280)
        # print len(tradedate_list)
        for d in tradedate_list:
            print d
            n3 = datetime.datetime.now()
            do_method_old(method, d, c, table_name, args, database, '')
            # print "one code one day use:", datetime.datetime.now() - n3

            # print "one code 161 day use:", datetime.datetime.now() - n2
            # print c
            # curr = getnow()
            # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            # update_task(ds, curr_time, database, table_name)


def main_day_inter_timing(args):
    """
    定时执行，
    1.算当天的所有股票，4个复权状态的数据，（不算MA,SUM）
    2.如果当天的复权因子!=1，先重跑历史前复权基础数据，
    3.再重跑所有前复权（MA,SUM）
    4.如果DATE_MIN_60 或 DATE_MIN_160当日复权因子！=1，同上
    5.以上规则太复杂，
    6.所以改成如果某只股票
    6.所以改成如果某只股票
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    n1 = datetime.datetime.now()
    innercode_list = ds.get_INNER_CODE_list()  # 可以考虑函数缓存
    # print "get innercode_list use:", datetime.datetime.now() - n1
    # innercode_list = [{"INNER_CODE": 101002348}]
    # innercode_list = [{"INNER_CODE": 101002348}, {"INNER_CODE": 101000001}, {"INNER_CODE": 101000005}]
    print len(innercode_list)
    start = int(args[1])
    end = start + 100
    print start, end
    print innercode_list[0]
    m = "make_%s_data" % table_name
    no_factor = "make_%s_data_no_factor" % table_name
    pre_factor = "make_%s_data_pre_factor" % table_name
    after_60_factor = "make_%s_data_after_60_factor" % table_name
    after_160_factor = "make_%s_data_after_160_factor" % table_name
    # method = getattr(ds, m)
    no_factor = getattr(ds, no_factor)
    pre_factor = getattr(ds, pre_factor)
    after_60_factor = getattr(ds, after_60_factor)
    after_160_factor = getattr(ds, after_160_factor)
    #
    today = {"TRADEDATE": pre_date(98)}
    print today
    for c in innercode_list:
        c_info = ds.DAY_INTER_base(today["TRADEDATE"], c["INNER_CODE"])
        if not c_info: continue
        tradedate_list = ds.get_tradedate_day_list(c["INNER_CODE"])
        # 获取股票当日的交易数据
        # 获取今天，60，160的复权因子
        DATE_MAX = tradedate_list[0]["TRADEDATE"]
        DATE_MIN_60 = tradedate_list[:179][-1]["TRADEDATE"]
        DATE_MIN_160 = tradedate_list[:279][-1]["TRADEDATE"]

        factor_tody = ds.get_factor_day(c_info["symbol"], DATE_MAX)
        factor_60 = ds.get_factor_day(c_info["symbol"], DATE_MIN_60)
        factor_160 = ds.get_factor_day(c_info["symbol"], DATE_MIN_160)
        if factor_tody==1 and factor_60==1 and factor_160==1:
            continue
        print DATE_MAX, DATE_MIN_60, DATE_MIN_160
        print factor_tody, factor_60, factor_160
        # 添加今天不复权的数据
        do_method(no_factor, c_info, today, c, True, table_name, args, database, '')
        if factor_tody != 1:
            # 如果今天的复权因子变化，更新所有日期的前复权数据2次，
            trades = ds.get_TRADEDATE_list(c["INNER_CODE"])
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_method(no_factor, info, d, c, False, table_name, args, database, '')
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_method(no_factor, info, d, c, True, table_name, args, database, '')

        else:
            # 否则，更新今天的前复权
            do_method(pre_factor, c_info, today, c, True, table_name, args, database, '')

        if factor_60 != 1:
            trades = ds.get_TRADEDATE_list(c["INNER_CODE"], 0, DATE_MIN_60)
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_method(after_60_factor, info, d, c, False, table_name, args, database, '')
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_method(after_60_factor, info, d, c, True, table_name, args, database, '')

            else:
                # 否则，更新今天的前复权
                do_method(after_60_factor, c_info, today, c, True, table_name, args, database, '')
        # 如果60或160的复权因子变化，更新历史前复权数据2次，

        if factor_160 != 1:
            trades = ds.get_TRADEDATE_list(c["INNER_CODE"], 0, DATE_MIN_160)
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_method(after_160_factor, info, d, c, False, table_name, args, database, '')
            for d in trades:
                info = ds.DAY_INTER_base(d["TRADEDATE"], c["INNER_CODE"])
                # 不算ma
                do_method(after_160_factor, info, d, c, True, table_name, args, database, '')

            else:
                # 否则，更新今天的前复权
                do_method(after_160_factor, c_info, today, c, True, table_name, args, database, '')
                # 如果60或160的复权因子变化，更新历史前复权数据2次，


def do_method_old(method, d, c, table_name, args, database, mysql_table):
    try:
        #
        data = method(d["TRADEDATE"], c["INNER_CODE"], table_name, mysql_table)
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        result_size = len(data)
        # 格式化mysql数据
        format_data(data)
        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)
    except Exception, e:
        print c
        print d
        print e
        time.sleep(3)
        do_method_old(method, d, c, table_name, args, database, mysql_table)


def do_method(method, c_info, d, c, get_ma, table_name, args, database, mysql_table):
    # data = method(c_info, d["TRADEDATE"], c["INNER_CODE"], get_ma, table_name, mysql_table)
    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    # result_size = len(data)
    # # 格式化mysql数据
    # format_data(data)
    # # 添加，更新，删除数据到mongo
    # table_info = table_prkey_config[table_name]
    # upsert_mongo_data(args, database, table_name, data, table_info)
    try:

        c_info = copy.deepcopy(c_info)
        data = method(c_info, d["TRADEDATE"], c["INNER_CODE"], get_ma, table_name, mysql_table)
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        result_size = len(data)
        # 格式化mysql数据
        format_data(data)
        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)
    except Exception, e:
        print c
        print d
        print e.message
        time.sleep(5)
        do_method(method, c_info, d, c, get_ma, table_name, args, database, mysql_table)


def main_inter(args, mysql_table):
    try:
        mysql = Mysql(config["mysql_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    # m = "make_%s_data" % table_name
    m = "make_INTER_data"
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)

    innercode_list = ds.get_INNER_CODE_list2()

    # innercode_list = [{"INNER_CODE": 101002348}, {"INNER_CODE": 101000001}, {"INNER_CODE": 101000005}]
    start = int(args[1])
    end = start + 100
    print start, end
    # print innercode_list[::-1][start:end]

    method = getattr(ds, m)
    # for c in innercode_list:

    # for c in innercode_list:
    for c in innercode_list[start:end]:
        n2 = datetime.datetime.now()
        print c["INNER_CODE"]
        tradedate_list = ds.get_enddate_list(mysql_table, c)
        # continue
        for d in tradedate_list:
            n3 = datetime.datetime.now()
            do_method_old(method, d, c, table_name, args, database, mysql_table)
            # print "one code 161 day use:", datetime.datetime.now() - n3
            # print c

        # print "one code 161 day use:", datetime.datetime.now() - n2


def main_limit(args):
    """
    通过limit分段获取sql数据
    :param args:
    :return:
    """
    # print args
    try:
        mysql = Mysql(config["mysql_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time, None)
    if hasattr(ds, m):
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 100, 100
        while result_size == 100:
            data = method(offset, maxsize)
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 格式化mysql数据
            format_data(data)
            print(data)
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)
    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    update_task(ds, curr_time, database, table_name)


def main_news(args):
    """
    新闻公告数据处理
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    m2 = "make_%s_data2" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": args[1], "endtime": args[2]}, curr_time, None)
    if hasattr(ds, m):
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 500, 500
        while result_size == 500:
            data = method(offset, maxsize)
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 格式化mysql数据
            format_data(data)
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)

        method = getattr(ds, m2)
        offset = 0
        result_size, maxsize = 500, 500
        while result_size == 500:
            data = method(offset, maxsize)
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 格式化mysql数据
            format_data(data)
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)

    # curr = getnow()
    # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    update_task(ds, curr_time, database, table_name)


def getnow():
    '''
    获取当前时间
    :return:
    '''
    return datetime.datetime.now()


def get_last_update_time(curr_time, info={}):
    """
    生成 预测任务执行时间
    :param curr_time:   datetimestr 当前时间
    :param info:        dict 定时信息
    :return:
    """
    prequency = info.get("FREQUENCY", "H")
    space = info.get("SPACE", 1)
    if prequency == "H":
        interval_time = "HOUR"
    elif prequency == "D":
        interval_time = "DAY"
    elif prequency == "W":
        interval_time = "WEEK"
    elif prequency == "M":
        interval_time = "MONTH"
    elif prequency == "Q":
        interval_time = "QUARTER"
    elif prequency == "Y":
        interval_time = "YEAR"
    else:
        interval_time = "HOUR"

    # return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return "DATE_ADD('%s', INTERVAL %s %s)" % (curr_time, space, interval_time)


def upsert_mongo_data(args, database, table_name, data, table_info):
    """
    更新数据到mongo
    :param args:        list 来自sys.argv
    :param database:    str 目的表库名
    :param table_name:  str 目的表表名
    :param data:        list 需要更新同步的数据
    :param table_info:  dict 目的表配置信息，来自oonvert_config文件
    :return:
    """

    # conn = pymongo.MongoClient("127.0.0.1", 27017)
    # print conn.collection_names()
    # 更新或插入数据
    nor_list = []  # 用于删除，不满足条件的历史纪录
    equity_keys = ["innerCode", "symbol", "name"]

    for key, row in enumerate(data):
        tmp = row
        if table_info.get("equity", False):

            filter = {("equity.%s" % i): row[i] for i in table_info["pri_key"] if i in equity_keys}
            filter.update({i: row[i] for i in table_info["pri_key"] if i not in equity_keys})
            equity = {}
            for i in equity_keys:
                if i in tmp:
                    if args[2] != "insert":
                        tmp["equity.%s" % i] = tmp[i]

                    equity[i] = tmp[i]
                    del tmp[i]

            if args[2] == "insert" and equity:
                tmp["equity"] = equity

        else:
            filter = {i: row[i] for i in table_info["pri_key"]}
            # nor_list.append(filter)
        # print filter,tmp

        # except pymongo.errors.ServerSelectionTimeoutError, e:
        #     print e, '连接失败！'
        #     return

        # 判断是否需要删除历史不符合条件的数据
        # 如果配置不删除，或者传递了制定的股票代码，或者查不到数据，都不需要做删除操作
        # if table_info["delete_old"] and nor_list and not args[1]:
        #     print nor_list
        #     db[table_name].remove({"$nor": nor_list})

        if args[2] != "insert":

            conn = tools.mongo_cursor()
            db = conn[database]
            for i in table_info.get("nesteds", []):
                filtero = copy.deepcopy(filter)
                filtero.update({i: None})
                if db[table_name].find_one(filtero):
                    db[table_name].update(filter, {"$set": {i: {}}}, upsert=True)

            db[table_name].update(filter, {"$set": tmp}, upsert=True, multi=True)
        else:
            data[key] = tmp
    if args[2] == "insert" and data:
        conn = tools.mongo_cursor()
        db = conn[database]
        db[table_name].insert_many(data)


if __name__ == "__main__":
    import sys

    # try:
    # 补齐参数
    init_args = ["z3dbus.Z3_EQUITY_PROFILE", "", 0]
    for k, v in enumerate(sys.argv[1:]):
        # print(k,v)
        init_args[k] = v
    if init_args[0] in ["z3dbus.Z3_EQUITY_PROFILE", "z3dbus.Z3_TOPIC_SAMPLE", "z3dbus.Z3_RESEARCH_REPORT",
                        "z3dbus.Z3_MNG_HOLD_STK_INFO",
                        "z3dbus.Z3_INDEX_SAMPLE"]:
        # 批量复制 Z3_EQUITY_PROFILE 数据
        main_limit(init_args)
    elif init_args[0] in ["z3dbus.Z3_EX_FACTOR_ALL"]:
        main_fqian(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_NEWS"]:
        main_news(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY"]:
        main_equity(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY2"]:
        main_equity(init_args)
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_DAY_INTER"]:
        main_day_inter(init_args)
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_WEEK_INTER"]:
        main_inter(init_args, 'ANA_STK_MKT_WEEK')
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_MONTH_INTER"]:
        main_inter(init_args, 'ANA_STK_MKT_MONTH')
    elif init_args[0] in ["z3dbus.Z3_EXCHANGE_CALENDAR"]:
        main_limit(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY"]:
        main_history(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY2"]:
        main_history(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY3","z3dbus.Z3_EQUITY_HISTORY4"]:
        warp_history(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY5"]:
        copy_history_no_sql(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY6"]:
        copy_history_sql(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY7"]:
        copy_history_sql_2(init_args)
    elif init_args[0] in ["fin"]:
        copy_final(init_args)


        # except Exception, e:

        #     print e.args
        #     print e.message
        #     logger = None
        #     logger.debug(e.message)
