# coding:utf-8 # Created by qinlin.liu at 2017/3/14
import decimal
import numpy as np
import copy
import pymongo
from utils import tools
from common import format_data, pre_date
from functools import wraps
import datetime
from bson.objectid import ObjectId
import pathos.multiprocessing as mp

def cal_tcap(self,raw):
    print(raw['symbol'])
    try:
        return round(np.dot(raw['perf_idx']['close_px'],raw['totl_num']),4)
    except Exception as e:
        # print(e)
        return None


def cache(func):
    caches = {}

    @wraps(func)
    def wrap(*args):
        if args not in caches:
            caches[args] = func(*args)
        return caches[args]

    return wrap


class DataSourceCopy():
    def __init__(self, conn, database, table, args, curr_time, logger):
        """
        实例化方法
        :param conn: mysql链接
        :param args:  参数
        """
        self.conn = conn
        self.tdatabase = database  # 目的库
        self.ttable = table  # 目的表
        # self.seconds = args["seconds"]
        self.starttime = args["starttime"]
        self.curr_time = curr_time
        # stockcode = args["stockcode"]
        # 获取目的表任务信息
        self.task_info = self._get_task_info()
        self.logger = None
        # 获取股票信息
        # self.stock_info = self._get_stock_info(stockcode) if stockcode else {}

    def _get_task_info(self):
        """
        获取 任务 信息
        :return:
        """
        return {}
        sql = """
            SELECT * FROM z3_update_task a WHERE a.TDATABASE=%(tdatabase)s
            AND a.TTABLE = %(ttable)s
        """
        result = self.conn.fetchone(sql, {"tdatabase": self.tdatabase, 'ttable': self.ttable})
        return result if result else {}

    def _get_stock_info(self, stockcode):
        """
        获取股票信息
        :param stockcode: 股票代码 str
        :return:
        """
        # sql = """
        #     SELECT * FROM stk_code a WHERE a.STOCKCODE=%(stockcode)s
        # """
        #
        # results = self.conn.fetchone(sql, {"stockcode": stockcode})
        # if not results:
        #     raise Exception(u"股票代码错误", "")
        # return results
        pass

    def update_taks(self, sql):
        """
        执行 更新任务状态 的sql
        :param sql:
        :return:
        """
        print self.conn.execute(sql)

    def _make_where(self, key, alias_list, key_alias='a'):
        """
        生成sql where条件
        :param key:             str     股票相关代码 字段名
        :param alias_list:      list    过滤时间段表别名列表
        :param key_alias:       str     key参数对应的表(别)名
        :return:
        """
        where_str = ""
        # where_time_model = "%%s.MTIME>SUBDATE(now(),interval %s second)" % self.seconds
        less_curr = " %%(alias)s.MTIME<='%s'" % self.curr_time

        where_last_model = (
            "( %%(alias)s.MTIME>'%s' AND  %s )" % (self.task_info["LASTRUNTIME"], less_curr)) if self.task_info.get(
            "LASTRUNTIME",

            None) else less_curr
        where_last_model = (
            "( %%(alias)s.MTIME>'%s' AND  %s )" % (self.starttime, less_curr)) if self.starttime else where_last_model

        where_list = []
        # if key in self.stock_info:
        #     where_list.append(" AND %s.%s='%s'" % (key_alias, key, self.stock_info[key]))
        # 如果有秒数
        # if self.seconds:
        #     where_list.append(" AND (%s)" % " OR ".join([where_time_model % alias for alias in alias_list]))
        # # 如果有上次更新时间,而且没有传递股票代码
        # elif not self.stock_info:
        #     # where_list.append(where_last_model)

        where_list.append(" AND (%s)" % " OR ".join([where_last_model % {"alias": alias} for alias in alias_list]))

        if where_list:
            where_str = "".join(where_list)
        # print where_str,"stock_info"
        return where_str


    def make_Z3_EQUITY_HISTORY_data(self):
        self.__
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        c = 0
        # for i in db.Z3_EQUITY_HISTORY.find({},no_cursor_timeout=True).sort([( "trade_date",-1 )]):
        fuck_time = datetime.datetime(2015,01,01)
        for i in db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':fuck_time}},no_cursor_timeout=True):
            tcap = self.__cal_tcap(i)
            mktcap = self.__cal_mktcap(i)
            mktcap_a = self.__cal_mktcap_a(i)
            inner_code = self.__get_true_inner_code(i)
            rela_volume = self.__cal_rela_volume(i)

            pe_lyr = self.__cal_p(i,tcap,'mic_lyr')
            pe_ttm = self.__cal_p(i,tcap,'mic_ttm')
            pb = self.__cal_p(i,tcap,'net_asset')
            pc = self.__cal_p(i,tcap,'cash_ttm')
            ps = self.__cal_ps(i,tcap)
            volume,price = self.__cal_volume_price(i)

            expect_price_chng_pct = self.__expect_price_chng_pct(i)
            r = db.Z3_EQUITY_HISTORY.update_one(
                {'_id':ObjectId(i['_id'])},
                {
                    '$set':{
                        # mkt_idx
                        'mkt_idx.tcap':tcap,
                        'mkt_idx.mktcap':mktcap,
                        'mkt_idx.mktcap_a':mktcap_a,
                        'mkt_idx.rela_volume':rela_volume,
                        'mkt_idx.pe_lyr':pe_lyr,
                        'mkt_idx.pe_ttm':pe_ttm,
                        'mkt_idx.ps':ps,
                        'mkt_idx.pb':pb,
                        'mkt_idx.pc':pc,
                        # fcst_idx
                        'fcst_idx.expect_price_chng_pct':expect_price_chng_pct
                    }
                }
                )
            print(r.modified_count,r.acknowledged,i['_id'])
            # c += 1
            # print(c)
            print(i['trade_date'])

    def __cal_ps(self,raw,tcap):
        try:
            divisor = raw['fin_idx']['sale']
            if divisor < 0:
                return None
            else:
                return round(tcap/divisor,4)
        except Exception as e:
            # print(e)
            return None

    def get_some_trade_date(self,start_time,end_time):
        a = [i for i in range(1,13)]
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # start_time = datetime.datetime(2014,01,01)
        time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('trade_date')
        # print(time_list[:10])
        # print(len(time_list))
        return time_list


    def make_Z3_EQUITY_HISTORY4_data(self):
        # use multuprocessing update data more fast
        #  N = C/P    P means percentage of cal tasks , C means number of CPU
        n = 10
        pool = mp.ProcessingPool(n)
        # print(pool)
        start_time = datetime.datetime(2015,01,01)
        end_time = datetime.datetime(2015,02,01)
        time_list = self.get_some_trade_date(start_time,end_time)
        pool.map(self.help_1_data,time_list)
        # pool.close()
        # pool.join()

    def make_Z3_EQUITY_HISTORY3_data(self):
        # use multuprocessing update data more fast
        #  N = C/P    P means percentage of cal tasks , C means number of CPU
        n = 90
        pool = mp.ProcessingPool(n)
        # print(pool)
        start_time = datetime.datetime(2015,01,01)
        end_time = datetime.datetime(2015,02,01)
        time_list = self.get_some_trade_date(start_time,end_time)
        print(time_list)
        pool.map(self.help_2_data,time_list)

        # self.help_EQUITY_HISTORY_data(time_list[1])
    def help_muti(self):
        start_time = datetime.datetime(2015,01,01)
        end_time = datetime.datetime(2015,02,01)


    def help_3_data(self,fuck_info):
        print("version_3")
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        i = db.Z3_EQUITY_HISTORY.find_one({'trade_date':fuck_info[0],'innerCode':fuck_info[1]})
        # for i in db.Z3_EQUITY_HISTORY.find({'trade_date':fuck_info[0],'innerCode':fuck_info[1]},no_cursor_timeout=True):

        tcap = self.__cal_tcap(i)
        mktcap = self.__cal_mktcap(i)
        mktcap_a = self.__cal_mktcap_a(i)

        rela_volume = self.__cal_rela_volume(i)
        pe_lyr = self.__cal_p(i,tcap,'mic_lyr')
        pe_ttm = self.__cal_p(i,tcap,'mic_ttm')
        ps = self.__cal_ps(i,tcap)
        pb = self.__cal_p(i,tcap,'net_asset')
        pc = self.__cal_p(i,tcap,'cash_ttm')
        peg = self.__cal_peg(i,pe_ttm)
        volume,price = self.__cal_volume_price(i)
        div_rate = self.__cal_div_rate(i)
        print("half")
        rsi_14 = self.__cal_rsi_14(i)
        is_gap_down,is_gap_up = self.__cal_gap(i)
        cur_chng_pct = self.__cal_cur_chng_pct(i)
        # print(cur_chng_pct)
        chng_pct_week = self.__cal_chng_pct_week(i)
        is_limit_down,is_limit_up = self.__is_limit(i)
        chng_pct_from_open = self.__cal_chng_pct_from_open(i)
        # print(chng_pct_from_open)
        is_stop = self.__is_stop(i)
        signal_normal_1 = self.__cal_signal_normal_1(i)
        print("before 2")
        signal_normal_2 = self.__cal_signal_normal_2(i)
        signal_normal_3 = self.__cal_signal_normal_3(i)

        signal_normal_7 = self.__cal_signal_normal_7(i)

        signal_normal_8,signal_normal_9 = self.__cal_signal_normal_89(rsi_14)

        signal_normal_17 = self.__cal_signal_normal_17(cur_chng_pct)

        signal_normal_28,signal_normal_29 = self.__cal_signal_normal_28_29(pe_ttm)
        signal_normal_30,signal_normal_31 = self.__cal_signal_normal_30_31(pb)
        print("stop cal")
        r = db.Z3_EQUITY_HISTORY.update_one(
                {'_id':ObjectId(i['_id'])},
                {
                    '$set':{
                        # mkt_idx
                        'mkt_idx.tcap':tcap,
                        'mkt_idx.mktcap':mktcap,
                        'mkt_idx.mktcap_a':mktcap_a,
                        'mkt_idx.rela_volume':rela_volume,
                        'mkt_idx.pe_lyr':pe_lyr,
                        'mkt_idx.pe_ttm':pe_ttm,
                        'mkt_idx.ps':ps,
                        'mkt_idx.pb':pb,
                        'mkt_idx.pc':pc,
                        'mkt_idx.volume':volume,
                        'mkt_idx.price':price,
                        'mkt_idx.div_rate':div_rate,
                        'mkt_idx.rsi_14':rsi_14,
                        'mkt_idx.is_gap_down':is_gap_down,
                        'mkt_idx.is_gap_up':is_gap_up,
                        'mkt_idx.cur_chng_pct':cur_chng_pct,
                        'mkt_idx.chng_pct_week':chng_pct_week,
                        'mkt_idx.is_limit_down':is_limit_down,
                        'mkt_idx.is_limit_up':is_limit_up,
                        'mkt_idx.is_stop':is_stop,
                        'mkt_idx.chng_pct_from_open':chng_pct_from_open,

                        # signal normal
                        'signal_normal.signal_normal_1':signal_normal_1,
                        'signal_normal.signal_normal_2':signal_normal_2,

                        'signal_normal.signal_normal_7':signal_normal_7,
                        'signal_normal.signal_normal_8':signal_normal_8,
                        'signal_normal.signal_normal_9':signal_normal_9,

                        'signal_normal.signal_normal_17':signal_normal_17,
                        'signal_normal.signal_normal_30':signal_normal_30,
                        'signal_normal.signal_normal_31':signal_normal_31,
                        'signal_normal.signal_normal_28':signal_normal_28,
                        'signal_normal.signal_normal_29':signal_normal_29,
                        # fcst_idx
                        # 'fcst_idx.expect_price_chng_pct':expect_price_chng_pct
                    }
                }
                )
        print('dd',r)
        print(i['trade_date'],i['_id'])

    def help_1_data(self,fuck_time):
        print("part1")
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        c = 0
        # for i in db.Z3_EQUITY_HISTORY.find({},no_cursor_timeout=True).sort([( "trade_date",-1 )]):
        # fuck_time = datetime.datetime(2015,01,01)
        # for i in db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':fuck_time}},no_cursor_timeout=True):
        for i in db.Z3_EQUITY_HISTORY.find({'trade_date':fuck_time},no_cursor_timeout=True):
            tcap = self.__cal_tcap(i)
            mktcap = self.__cal_mktcap(i)
            mktcap_a = self.__cal_mktcap_a(i)
            pe_lyr = self.__cal_p(i,tcap,'mic_lyr')
            pe_ttm = self.__cal_p(i,tcap,'mic_ttm')
            ps = self.__cal_ps(i,tcap)
            pb = self.__cal_p(i,tcap,'net_asset')
            pc = self.__cal_p(i,tcap,'cash_ttm')

            # expect_price_chng_pct = self.__expect_price_chng_pct(i)
            # rela_volume = self.__cal_rela_volume(i)
            r = db.Z3_EQUITY_HISTORY.update_one(
                {'_id':ObjectId(i['_id'])},
                {
                    '$set':{
                        # mkt_idx
                        'mkt_idx.tcap':tcap,
                        'mkt_idx.mktcap':mktcap,
                        'mkt_idx.mktcap_a':mktcap_a,
                        # 'mkt_idx.rela_volume':rela_volume,
                        # 'mkt_idx.pe_lyr':pe_lyr,
                        # 'mkt_idx.pe_ttm':pe_ttm,
                        # 'mkt_idx.ps':ps,
                        # 'mkt_idx.pb':pb,
                        # 'mkt_idx.pc':pc,
                        # fcst_idx
                        # 'fcst_idx.expect_price_chng_pct':expect_price_chng_pct
                    }
                }
                )
            print(r.modified_count,r.acknowledged,i['_id'])
            # c += 1
            # print(c)
            print(i['trade_date'])


    def help_2_data(self,fuck_time):
        print('this is part2')
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        c = 0
        # for i in db.Z3_EQUITY_HISTORY.find(no_cursor_timeout=True).sort([( "trade_date",-1 )]):
        for i in db.Z3_EQUITY_HISTORY.find({'trade_date':fuck_time},no_cursor_timeout=True):
            # prepare data
            tcap = self.__cal_tcap(i)
            pe_ttm = self.__cal_p(i,tcap,'mic_ttm')
            pb = self.__cal_p(i,tcap,'net_asset')
            inner_code = self.__get_true_inner_code(i)

            print(inner_code)
            # product data
            peg = self.__cal_peg(i,pe_ttm)
            volume,price = self.__cal_volume_price(i)

            # print(volume,price)
            # print(volume,price)
            div_rate = self.__cal_div_rate(i)
            rsi_14 = self.__cal_rsi_14(i)
            is_gap_down,is_gap_up = self.__cal_gap(i)
            cur_chng_pct = self.__cal_cur_chng_pct(i)
            # print(cur_chng_pct)
            chng_pct_week = self.__cal_chng_pct_week(i)
            is_limit_down,is_limit_up = self.__is_limit(i)
            chng_pct_from_open = self.__cal_chng_pct_from_open(i)
            # print(chng_pct_from_open)
            is_stop = self.__is_stop(i)
            signal_normal_1 = self.__cal_signal_normal_1(i)
            signal_normal_2 = self.__cal_signal_normal_2(i)
            signal_normal_3 = self.__cal_signal_normal_3(i)

            signal_normal_7 = self.__cal_signal_normal_7(i)

            signal_normal_8,signal_normal_9 = self.__cal_signal_normal_89(rsi_14)

            signal_normal_17 = self.__cal_signal_normal_17(cur_chng_pct)

            signal_normal_28,signal_normal_29 = self.__cal_signal_normal_28_29(pe_ttm)
            signal_normal_30,signal_normal_31 = self.__cal_signal_normal_30_31(pb)

            # r = db.Z3_EQUITY_HISTORY.update_one(
            #     {'_id':ObjectId(i['_id'])},
            #     {
            #         '$set':{
            #             # mkt_idx
            #             # 'mkt_idx.volume':volume,
            #             # 'mkt_idx.price':price,
            #             'mkt_idx.div_rate':div_rate,
            #             'mkt_idx.rsi_14':rsi_14,
            #             'mkt_idx.is_gap_down':is_gap_down,
            #             'mkt_idx.is_gap_up':is_gap_up,
            #             'mkt_idx.cur_chng_pct':cur_chng_pct,
            #             'mkt_idx.chng_pct_week':chng_pct_week,
            #             'mkt_idx.is_limit_down':is_limit_down,
            #             'mkt_idx.is_limit_up':is_limit_up,
            #             'mkt_idx.is_stop':is_stop,
            #             'mkt_idx.chng_pct_from_open':chng_pct_from_open,

            #             # signal normal
            #             'signal_normal.signal_normal_1':signal_normal_1,
            #             'signal_normal.signal_normal_2':signal_normal_2,

            #             'signal_normal.signal_normal_7':signal_normal_7,
            #             'signal_normal.signal_normal_8':signal_normal_8,
            #             'signal_normal.signal_normal_9':signal_normal_9,

            #             'signal_normal.signal_normal_17':signal_normal_17,
            #             'signal_normal.signal_normal_30':signal_normal_30,
            #             'signal_normal.signal_normal_31':signal_normal_31,
            #             'signal_normal.signal_normal_28':signal_normal_28,
            #             'signal_normal.signal_normal_29':signal_normal_29

            #             # fcst_idx
            #             # 'fcst_idx.expect_price_chng_pct':expect_price_chng_pct
            #         }
            #     }
            #     )
            print(i['_id'],i['trade_date'])


    def make_Z3_EQUITY_HISTORY2_data(self):
        print('this is part2')
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        c = 0
        # for i in db.Z3_EQUITY_HISTORY.find(no_cursor_timeout=True).sort([( "trade_date",-1 )]):
        fuck_time = datetime.datetime(2015,01,01)
        for i in db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':fuck_time}},no_cursor_timeout=True):
            # prepare data
            tcap = self.__cal_tcap(i)
            pe_ttm = self.__cal_p(i,tcap,'mic_ttm')
            pb = self.__cal_p(i,tcap,'net_asset')

            # product data
            peg = self.__cal_peg(i,pe_ttm)
            volume,price = self.__cal_volume_price(i)
            div_rate = self.__cal_div_rate(i)
            rsi_14 = self.__cal_rsi_14(i)
            is_gap_down,is_gap_up = self.__cal_gap(i)
            cur_chng_pct = self.__cal_cur_chng_pct(i)
            # print(cur_chng_pct)
            chng_pct_week = self.__cal_chng_pct_week(i)
            is_limit_down,is_limit_up = self.__is_limit(i)
            chng_pct_from_open = self.__cal_chng_pct_from_open(i)
            # print(chng_pct_from_open)
            is_stop = self.__is_stop(i)
            signal_normal_1 = self.__cal_signal_normal_1(i)
            signal_normal_2 = self.__cal_signal_normal_2(i)
            signal_normal_3 = self.__cal_signal_normal_3(i)

            signal_normal_7 = self.__cal_signal_normal_7(i)

            signal_normal_8,signal_normal_9 = self.__cal_signal_normal_89(rsi_14)

            signal_normal_17 = self.__cal_signal_normal_17(cur_chng_pct)

            signal_normal_28,signal_normal_29 = self.__cal_signal_normal_28_29(pe_ttm)
            signal_normal_30,signal_normal_31 = self.__cal_signal_normal_30_31(pb)

            r = db.Z3_EQUITY_HISTORY.update_one(
                {'_id':ObjectId(i['_id'])},
                {
                    '$set':{
                        # mkt_idx
                        'mkt_idx.volume':volume,
                        'mkt_idx.price':price,
                        'mkt_idx.div_rate':div_rate,
                        'mkt_idx.rsi_14':rsi_14,
                        'mkt_idx.is_gap_down':is_gap_down,
                        'mkt_idx.is_gap_up':is_gap_up,
                        'mkt_idx.cur_chng_pct':cur_chng_pct,
                        'mkt_idx.chng_pct_week':chng_pct_week,
                        'mkt_idx.is_limit_down':is_limit_down,
                        'mkt_idx.is_limit_up':is_limit_up,
                        'mkt_idx.is_stop':is_stop,
                        'mkt_idx.chng_pct_from_open':chng_pct_from_open,

                        # signal normal
                        'signal_normal.signal_normal_1':signal_normal_1,
                        'signal_normal.signal_normal_2':signal_normal_2,

                        'signal_normal.signal_normal_7':signal_normal_7,
                        'signal_normal.signal_normal_8':signal_normal_8,
                        'signal_normal.signal_normal_9':signal_normal_9,

                        'signal_normal.signal_normal_17':signal_normal_17,
                        'signal_normal.signal_normal_30':signal_normal_30,
                        'signal_normal.signal_normal_31':signal_normal_31,
                        'signal_normal.signal_normal_28':signal_normal_28,
                        'signal_normal.signal_normal_29':signal_normal_29

                        # fcst_idx
                        # 'fcst_idx.expect_price_chng_pct':expect_price_chng_pct
                    }
                }
                )
            print(i['_id'],i['trade_date'])

    def __cal_signal_normal_30_31(self,pb):
        sig30 = True if pb < 1 else False
        sig31 = True if pb > 5 else False
        return sig30,sig31

    def __cal_signal_normal_28_29(self,pe_ttm):
        sig28 = True if pe_ttm < 20 and pe_ttm else False
        sig29 = True if pe_ttm > 50 else False
        return sig28,sig29


    def __cal_signal_normal_17(self,cur_chng_pct):
        try:
            # print(cur_chng_pct)
            return True if cur_chng_pct > 5 else False
        except Exception as e:
            return None

    def __cal_signal_normal_89(self,rsi):
        try:
            s8 = s9 = False
            if rsi > 80:
                s8 = True
            if rsi < 20:
                s9 = True
            return s8,s9
        except Exception as e:
            return None,None

    def __cal_signal_normal_7(self,raw):
        try:
            return True if raw['mkt_idx']['rela_volume'] > 3 else False
        except Exception as e:
            return None

    def __cal_signal_normal_3(self,raw):
        try:
            symbol = raw['symbol']
            # sql = "SELECT STOCKCODE FROM ANA_STK_MKT_DAY WHERE STOCKCODE = '{} 00:00:00' ORDER BY TRADEDATE ".format(symbol)
            sql = "SELECT STOCKCODE FROM ANA_STK_MKT_DAY WHERE STOCKCODE = '{}' ORDER BY TRADEDATE ".format(symbol)
            # print(sql)
            results = self.conn.fetchall(sql)
            flags = [i['STOCKCODE'] for i in results[:len(results)/10]]
            # print(flags)
            signal = False
            if symbol in flags:
                signal = True
            return signa

        except Exception as e:
            # print(e)
            return None

    def __cal_signal_normal_2(self,raw):
        try:
            symbol = raw['symbol']
            trade_date = raw['trade_date']
            # sql = "SELECT STOCKCODE FROM ANA_STK_MKT_DAY WHERE TRADEDATE = '{} 00:00:00' ORDER BY CHNG_PCT DESC".format(trade_date.strftime('%Y-%m-%d'))
            sql = "SELECT STOCKCODE FROM ANA_STK_MKT_DAY WHERE TRADEDATE = '{} 00:00:00' ORDER BY CHNG_PCT DESC".format('2017-04-17')
            # print(sql)
            results = self.conn.fetchall(sql)
            # print(len(results))
            signal = False
            symbol = "000518"
            flags = [i['STOCKCODE'] for i in results[:len(results)/10]]
            # print(flags)
            if symbol in flags and raw['perf_idx']['chng_pct'] < 0:
                signal = True
            # print(signal)
            return signal
        except Exception as e:
            # print('isstop error')
            # print(e)
            return None

    def __cal_signal_normal_1(self,raw):
        try:
            symbol = raw['symbol']
            trade_date = raw['trade_date']
            sql = "SELECT STOCKCODE FROM ANA_STK_MKT_DAY WHERE TRADEDATE = '{} 00:00:00' ORDER BY CHNG_PCT".format(trade_date.strftime('%Y-%m-%d'))
            # sql = "SELECT STOCKCODE FROM ANA_STK_MKT_DAY WHERE TRADEDATE = '{} 00:00:00' ORDER BY CHNG_PCT".format('2017-04-17')
            # print(sql)
            results = self.conn.fetchall(sql)
            # print(len(results))
            signal = False
            # symbol = "000040"
            flags = [i['STOCKCODE'] for i in results[:len(results)/10]]
            if symbol in flags and raw['perf_idx']['chng_pct'] > 0:
                signal = True
            return signal
        except Exception as e:
            # print('isstop error')
            # print(e)
            return None

    def __is_stop(self,raw):
        try:
            inner_code = self.__get_true_inner_code(raw)
            trade_date = raw['trade_date']
            sql = "select * from STK_STP_CALENDAR where STOPDATE = '{}' and INNER_CODE='{}'".format(trade_date.strftime('%Y-%m-%d'),inner_code)
            # print(sql)
            results = self.conn.fetchall(sql)
            if len(results) > 0:
                return True
            else:
                return False
        except Exception as e:
            # print('isstop error')
            # print(e)
            return False

    def __cal_chng_pct_from_open(self,raw):
        try:
            close_px = raw['perf_idx']['close_px']
            # close_px = 4.39
            symbol = raw['symbol']
            trade_date = raw['trade_date']
            sql = "SELECT TOPEN FROM ANA_STK_MKT_DAY WHERE STOCKCODE = '{}' AND TRADEDATE = '{} 00:00:00'".format(symbol,trade_date.strftime('%Y-%m-%d'))
            # print(sql)
            topen = self.conn.fetchall(sql)[0]['TOPEN']
            return round((decimal.Decimal(close_px)-topen)/topen,4)
        except Exception as e:
            # print('chng pct from open error')
            # print(e)
            return None


    def __is_limit(self,raw):
        # import ipdb; ipdb.set_trace()
        try:
            inner_code = self.__get_true_inner_code(raw)
            trade_date = raw['trade_date']
            sql = "SELECT CHNG_PCT FROM STK_MKT WHERE TRADEDATE = '{} 00:00:00' AND INNER_CODE ='{}'".format(trade_date.strftime('%Y-%m-%d'),inner_code)
            results = self.conn.fetchall(sql)
            up = down = False
            # print(results)
            chng_pct = results[0]['CHNG_PCT']
            if chng_pct == 10:
                up = True
            if chng_pct == -10:
                down = True
            return down,up
        except Exception as e:
            # print('limit error')
            # print(e)
            return False,False

    def __cal_chng_pct_week(self,raw):
        try:
            # import ipdb; ipdb.set_trace() 
            inner_code = self.__get_true_inner_code(raw)
            trade_date = raw['trade_date']
            sql = "SELECT CHNG_PCT_WEEK FROM ANA_STK_EXPR_IDX WHERE ENDDATE = '{} 00:00:00' AND INNER_CODE = '{}'".format(trade_date.strftime('%Y-%m-%d'),inner_code)
            results = self.conn.fetchall(sql)
            return round(float(results[0]['CHNG_PCT_WEEK']),4)
        except Exception as e:
            # print('chng error')
            # print(e)
            return None

    def __cal_cur_chng_pct(self,raw):
        try:
            # raw = db.Z3_EQUITY_HISTORY.find_one()
            # cur_chng_pct = db.Z3_STK_MKT_DAY.find_one({"equity.symbol":raw['symbol'],"trade_date":raw['trade_date']})['chg_pct']
            symbol = raw['symbol']
            trade_date = raw['trade_date']
            sql = "SELECT CHNG_PCT FROM ANA_STK_MKT_DAY WHERE STOCKCODE = '{}' AND TRADEDATE='{} 00:00:00'".format(symbol,trade_date.strftime('%Y-%m-%d'))
            results = self.conn.fetchall(sql)
            # print(sql)
            # print(results)
            cur_chng_pct = results[0]['CHNG_PCT']
            # print(cur_chng_pct)
            return round(float(cur_chng_pct),4)
        except Exception as e:
            # print('chng error')
            # print(e)
            return None


    def __cal_gap(self,raw):
        try:
            symbol = raw['symbol']
            trade_date = raw['trade_date']
            sql = "SELECT TOPEN,TLOW FROM ANA_STK_MKT_DAY WHERE TRADEDATE <= '{} 00:00:00' AND STOCKCODE ='{}' ORDER BY TRADEDATE DESC LIMIT 2".format(trade_date.strftime('%Y-%m-%d'),symbol)
            # sql = "SELECT TOPEN,TLOW,THIGH FROM ANA_STK_MKT_DAY WHERE TRADEDATE <= '{} 00:00:00' AND STOCKCODE ='{}' ORDER BY TRADEDATE DESC LIMIT 2".format(datetime.datetime.now().strftime('%Y-%m-%d'),symbol)
            # print(sql)
            results = self.conn.fetchall(sql)
            # print(results[1]['TOPEN'],results[0]['TLOW'] ,results[0]['THIGH'])
            if results[1]['TOPEN'] <= results[0]['TLOW']:
                down = True
            else:
                down = False
            if results[1]['TOPEN'] >= results[0]['THIGH']:
                up = True
            else:
                up = False
            return down,up
        except Exception as e:
            # print('gap error')
            # print(e)
            return False,False


    def __cal_rsi_14(self,raw):
        try:
            inner_code = self.__get_true_inner_code(raw)
            sql = "SELECT CHNG FROM STK_MKT WHERE INNER_CODE = '{}' AND TRADEDATE < '{}' ORDER BY TRADEDATE DESC LIMIT 14".\
                  format(inner_code,raw['trade_date'].strftime("%Y-%m-%d"))
            results = map(lambda x:x['CHNG'],self.conn.fetchall(sql))
            if len(results) == 14:
                x = sum(filter(lambda x:x>=0,results))
                y = sum(filter(lambda x:x<0,results))
                return round(x/(x+abs(y)),4)
            else:
                return None

        except Exception as e:
            # print(e)
            return None

    def __cal_div_rate(self,raw):
        try:
            inner_code = self.__get_true_inner_code(raw)
            # print(inner_code)
            sql = "SELECT DIV_RATE FROM ANA_STK_VAL_IDX WHERE isvalid =1 and INNER_CODE = '{}' and TRD_DATE = '{} 00:00:00'".\
                  format(inner_code,raw['trade_date'].strftime("%Y-%m-%d"))
            # print(sql)
            results = self.conn.fetchall(sql)
            return round(float(results[0]['DIV_RATE']),4)
        except Exception as e:
            # print(e)
            # print(sql)
            return None

    def __get_true_inner_code(self,raw):
        try:
            symbol = raw['symbol']
            sql1 = "SELECT INNER_CODE FROM STK_CODE WHERE isvalid=1 and STOCKCODE ='{}'".\
                   format(symbol)
            # print(sql1)
            results1 = self.conn.fetchall(sql1)
            # print(results1)
            return results1[0]['INNER_CODE']
        except Exception as e:
            # print(e)
            return None

    def __cal_volume_price2(self,raw,inner_code):
        try:
            print(inner_code)
            # symbol = raw['symbol']
            # inner_code = self.__get_true_inner_code(raw)
            sql2 = "SELECT TVOLUME,TCLOSE FROM STK_MKT WHERE isvalid =1 and INNER_CODE = '{}' and TRADEDATE like '{}%'".\
                   format(inner_code,raw['trade_date'].strftime("%Y-%m-%d"))
            # print(sql2)
            results2 = self.conn.fetchall(sql2)
            print(results2)
            return round(float(results2[0]['TVOLUME']),4),round(float(results2[0]['TCLOSE']),4)
        except Exception as e:
            # print(e)
            return None,None

    def __cal_volume_price(self,raw):
        try:
            symbol = raw['symbol']
            inner_code = self.__get_true_inner_code(raw)
            sql2 = "SELECT TVOLUME,TCLOSE FROM STK_MKT WHERE isvalid =1 and INNER_CODE = '{}' and TRADEDATE like '{}%'".\
                   format(inner_code,raw['trade_date'].strftime("%Y-%m-%d"))
            results2 = self.conn.fetchall(sql2)
            # print(results2)
            return round(float(results2[0]['TVOLUME']),4),round(float(results2[0]['TCLOSE']),4)
        except Exception as e:
            # print(e)
            return None,None



    def __cal_peg(self,raw,pe_ttm):
        try:
            es_3year = raw['mkt2_idx']['es_3year']
            # print(pe_ttm,es_3year)
            return round((pe_ttm/es_3year),2)
        except Exception as e:
            # print(e)
            return None



    def __expect_price_chng_pct(self,raw):
        try:
            return round( ( raw['fcst_idx']['expect_price_med'] -raw['perf_idx']['close_px'])/raw['perf_idx']['close_px'],4)
        except Exception as e:
            # expect_oprice_med sometimes equal None
            return None


    def __cal_p(self,raw,tcap,divisor_key):
        try:
            divisor = raw['mkt2_idx'][divisor_key]
            if divisor < 0:
                return None
            else:
                return round(tcap/divisor,4)

        except Exception as e:
            # print(divisor_key)
            # print(e)
            return None


    def __cal_rela_volume(self,raw):
        # import ipdb; ipdb.set_trace()
        trade_date = raw['trade_date']
        stock_code = raw['symbol']
        sql = "SELECT * from ANA_STK_MKT_DAY where STOCKCODE='{}' AND TRADEDATE like '{}%'".format(
            stock_code,trade_date.strftime("%Y-%m-%d")
        )
        # sql = "SELECT TVOLUME from ANA_STK_MKT_DAY where STOCKCODE='000018' AND TRADEDATE like '2017-04-21%'"
        # print(sql)
        results = self.conn.fetchall(sql)
        # print(results)
        try:
            # print(results[0]["TVOLUME"])
            # print(raw['perf_idx']['avg_vol_3month'])
            return round(np.divide(results[0]["TVOLUME"],decimal.Decimal(raw['perf_idx']['avg_vol_3month'])),4)
        except Exception as e:
            # print(e)
            return None

    def __cal_tcap(self,raw):
        try:
            return round(np.dot(raw['perf_idx']['close_px'],raw['totl_num']),4)
        except Exception as e:
            # print(e)
            return None

    def __cal_mktcap(self,raw):
        try:
            return round(np.dot(raw['perf_idx']['close_px'],raw['mkt_num']),4)
        except Exception as e:
            # print(e)
            return None


    def __cal_mktcap_a(self,raw):
        try:
            return round(np.dot(raw['perf_idx']['close_px'],raw['a_mkt_num']),4)
        except Exception as e:
            # print(e)
            return None


    def make_Z3_EQUITY_PROFILE_data(self, offset, limit):
        """
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c", "d", "e", "f"])
        sql = """
            SELECT
              b.SEC_UNI_ID    innerCode,
              a.STOCKCODE     symbol,
              a.STOCKSNAME    name,
              CASE when a.TRADE_MKT_REF=2 THEN 'SH' WHEN a.TRADE_MKT_REF=1 THEN 'SZ' END exchange,
              a.STK_TYPE_REF  sec_type,
              a.LIST_SEC_REF  list_sec,
              a.CHI_SPEL      chi_spel,
              d1.DIST_CODE     area_code,
              d1.PROV_NAME     area_name,
              e.SW_INDU_CODE_2014_1 sw_indu_code,
              f.INDU_NAME sw_indu_name,
              e.SW_INDU_CODE_2014_2 sw_indu_code_2,
              g.INDU_NAME sw_indu_name_2
            FROM STK_CODE a
              INNER JOIN pgznty.z3_sec_cons b ON a.INNER_CODE = b.INNER_CODE AND b.ISVALID=1
              LEFT JOIN
              (SELECT *
               FROM STK_COM_DIST_CHNG a
               WHERE ISVALID = 1 AND CHANGEDATE=(
                 SELECT max(CHANGEDATE)
                 FROM STK_COM_DIST_CHNG
                 WHERE ISVALID = 1 AND COMCODE = a.COMCODE) ) c ON a.COMCODE = c.COMCODE
              LEFT JOIN PUB_DIST_REF d ON c.DIST_CODE = d.DIST_CODE AND d.IS VALID=1
              LEFT JOIN PUB_DIST_REF d1 ON d.PROV_NAME = d1.PROV_NAME AND d1.CODE_LEVEL = 1 AND d1.ISVALID=1
              LEFT JOIN STK_COM_INDU_REL e ON a.COMCODE=e.COMCODE AND e.ISVALID =1
              LEFT JOIN PUB_INDU_REF f ON e.SW_INDU_CODE_2014_1 = f.INDU_CODE AND f.INDU_LEVEL=1 AND f.ISVALID=1 and f.INDU_SYS_MARK=15
              LEFT JOIN PUB_INDU_REF g ON e.SW_INDU_CODE_2014_2 = g.INDU_CODE AND g.INDU_LEVEL=2 AND g.ISVALID=1 and g.INDU_SYS_MARK=15
              WHERE a.ISVALID=1 %(where_str)s LIMIT %(offset)s,%(limit)s

        """ % {"where_str": where_str, "offset": offset, "limit": limit}
        print sql
        results = self.conn.fetchall(sql)
        return results

    def get_INNER_CODE_list(self):

        sql = """
        SELECT DISTINCT a.INNER_CODE,b.STOCKCODE SECCODE FROM STK_MKT a JOIN STK_CODE b ON a.INNER_CODE=b.INNER_CODE
        """

        innercode_list = self.conn.fetchall(sql)
        return innercode_list

    def get_INNER_CODE_list2(self):
        #
        # cursor = tools.mongo_cursor()
        # db=cursor["z3dbus"]
        # list(db.getCollection('Z3_STK_MKT_DAY_INTER').distinct("equity.symbol"))
        sql = """
        SELECT DISTINCT INNER_CODE FROM ANA_STK_MKT_WEEK WHERE ISVALID=1
        """

        innercode_list = self.conn.fetchall(sql)
        return innercode_list

    def get_STOCKINFO_listx(self):

        cursor = tools.mongo_cursor()
        db = cursor["z3dbus"]
        result = db["Z3_EQUITY"].find({"signal_normal.signal_normal_19": True}, {"symbol": 1})
        result = ["%s" % str(int(i["_id"].replace(".SZ", "").replace(".SH", ""))) for i in list(result)]
        print ",".join(result)
        return []
        sql = """
        SELECT DISTINCT
          b.SEC_UNI_ID innerCode,
          a.STOCKCODE  symbol,
          STOCKSNAME   name,
          COMCODE,
          a.INNER_CODE
        FROM STK_CODE a
          JOIN pgznty.z3_sec_cons b ON a.INNER_CODE = b.INNER_CODE
        WHERE STATUS_TYPE = '正常上市' AND a.ISVALID = 1 AND b.SEC_UNI_ID IN (%s)
        ORDER BY STOCKCODE;
        """ % ",".join("'%s'" % str(i) for i in result)

        seccode_list = self.conn.fetchall(sql)
        return seccode_list

    def get_STOCKINFO_list(self):

        sql = """
        SELECT DISTINCT
          b.SEC_UNI_ID innerCode,
          a.STOCKCODE  symbol,
          STOCKSNAME   name,
          COMCODE,
          a.INNER_CODE
        FROM STK_CODE a
          JOIN pgznty.z3_sec_cons b ON a.INNER_CODE = b.INNER_CODE
        WHERE STATUS_TYPE = '正常上市' AND a.ISVALID = 1
        ORDER BY STOCKCODE;
        """
        seccode_list = self.conn.fetchall(sql)
        return seccode_list

    def make_Z3_EX_FACTOR_ALL_data_timing(self, i):
        # 定时
        # 1.更新当前交易日的数据(收市，stk_mkt有今日数据，)
        # 2.更新历史数据的修改（根据MTIME）

        where_str_ab = self._make_where("SECCODE", ["a", "b"])
        where_str_ac = self._make_where("", ["a", "c"])

        i.update({
            "where_str_ab": where_str_ab,
            "where_str_ac": where_str_ac
        })
        sqlmodel = """
            SELECT *
            FROM   (
                SELECT
                      a.SECCODE  symbol,
                      a.TRADEDATE end_date,
                      b.EX_FACTOR ex_factor,
                      b.CUM_FACTOR cum_factor,
                 CASE WHEN a.TRADEDATE = b.ENDDATE
                   THEN EX_FACTOR
                 ELSE 1 END   ex_factor_today
                FROM STK_MKT a
                  JOIN pgznty.z3_sec_cons d ON a.INNER_CODE = d.INNER_CODE
                  JOIN (select * from STK_EX_FACTOR_MKT b where STOCKCODE='%(SECCODE)s')b   ON a.SECCODE = b.STOCKCODE
                  AND a.TRADEDATE>=b.ENDDATE
                  WHERE a.ISVALID=1 AND b.ISVALID=1 AND a.INNER_CODE='%(INNER_CODE)s'

                %(where_str_ab)s
                ORDER BY B.ENDDATE DESC
              ) A
                GROUP BY symbol,end_date
                UNION
                SELECT
                  c.STOCKCODE  symbol,
                  a.EX_DATE    end_date,
                  a.EX_FACTOR  ex_factor,
                  a.CUM_FACTOR cum_factor,
                  a.EX_FACTOR ex_factor_today
                FROM STK_EX_FACTOR a
                  JOIN pgznty.z3_sec_cons d ON a.INNER_CODE = d.INNER_CODE
                  JOIN
                  (SELECT a.INNER_CODE,
                     max(TRADEDATE) ENDDATE
                          FROM STK_MKT AS a
                            WHERE a.ISVALID=1 AND a.INNER_CODE='%(INNER_CODE)s'
            GROUP BY INNER_CODE  ) b ON a.INNER_CODE = b.INNER_CODE
                      AND a.EX_DATE > b.enddate
                      JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE
                    WHERE a.ISVALID = 1 AND c.ISVALID = 1
                %(where_str_ac)s
        """ % i
        result = self.conn.fetchall(sqlmodel)
        return result

    def make_Z3_EX_FACTOR_ALL_data(self, i):
        # 历史数据

        sqlmodel = """
            SELECT *
            FROM   (
                SELECT
                      a.SECCODE  symbol,
                      a.TRADEDATE end_date,
                      b.EX_FACTOR ex_factor,
                      b.CUM_FACTOR cum_factor,
                 CASE WHEN a.TRADEDATE = b.ENDDATE
                   THEN EX_FACTOR
                 ELSE 1 END   ex_factor_today
                FROM STK_MKT a
                  JOIN pgznty.z3_sec_cons d ON a.INNER_CODE = d.INNER_CODE
                  JOIN (select * from STK_EX_FACTOR_MKT b where STOCKCODE='%(SECCODE)s')b   ON a.SECCODE = b.STOCKCODE
                  AND a.TRADEDATE>=b.ENDDATE
                  WHERE a.ISVALID=1 AND b.ISVALID=1 AND a.INNER_CODE='%(INNER_CODE)s'
                ORDER BY B.ENDDATE DESC
              ) A
                GROUP BY symbol,end_date
                UNION
                SELECT
                  c.STOCKCODE  symbol,
                  a.EX_DATE    end_date,
                  a.EX_FACTOR  ex_factor,
                  a.CUM_FACTOR cum_factor,
                  a.EX_FACTOR ex_factor_today
                FROM STK_EX_FACTOR a
                  JOIN pgznty.z3_sec_cons d ON a.INNER_CODE = d.INNER_CODE
                  JOIN
                  (SELECT a.INNER_CODE,
                     max(TRADEDATE) ENDDATE
                          FROM STK_MKT AS a
                            WHERE a.ISVALID=1 AND a.INNER_CODE='%(INNER_CODE)s'
            GROUP BY INNER_CODE  ) b ON a.INNER_CODE = b.INNER_CODE
                      AND a.EX_DATE > b.enddate
                      JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE
                    WHERE a.ISVALID = 1 AND c.ISVALID = 1
        """ % i
        print sqlmodel
        result = self.conn.fetchall(sqlmodel)
        print len(result)
        return result

    def make_Z3_MNG_HOLD_STK_INFO_data(self, offset, limit):
        """
        生成 董监高持股变动最新记录表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c"], "c")
        sql = """
        SELECT
          c.SEC_UNI_ID                   AS innerCode,
          b.STOCKCODE                    AS symbol,
          b.STOCKSNAME                   AS name,
          a.INDI_ID                      AS mgt_id,
          a.MNG_NAME                     AS mgt_name,
          a.POST                         AS position,
          a.CHNG_RSN                     AS chg_reason,
          a.CHNG_VOL                     AS chg_vol,
          a.CHNG_PCT                     AS chg_pct,
          a.CHEG_EP                      AS chg_ep,
          a.CHNG_VOL * a.CHEG_EP / 10000 AS chg_mon,
          a.END_VOL                      AS end_vol,
          a.CHNG_DATE                    AS chg_date
        FROM (

               SELECT *
               FROM STK_MNG_TRADE_INFO AS a
               WHERE CHNG_DATE = (SELECT max(CHNG_DATE)
                                  FROM STK_MNG_TRADE_INFO
                                  WHERE RELATION = '本人' AND a.COMCODE = COMCODE AND a.INDI_ID = INDI_ID AND a.ISVALID=1)
             ) a
          JOIN STK_CODE b ON b.COMCODE = a.COMCODE
          JOIN pgznty.z3_sec_cons c ON c.INNER_CODE = b.INNER_CODE
        WHERE a.RELATION = '本人' AND a.ISVALID = 1 AND b.ISVALID = 1 AND c.ISVALID = 1 %(where_str)s LIMIT %(offset)s,%(limit)s
        """ % {"where_str": where_str, "offset": offset, "limit": limit}
        results = self.conn.fetchall(sql)
        # print len(results)
        return results

    def make_Z3_EQUITY_NEWS_data(self, offset, limit):
        """
        生成 个股新闻公告表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c", "d", "e", "f"], "c")
        sql = """
            SELECT
              d.SEC_UNI_ID    innerCode,
              a.guid       AS guid,
              '新闻'         AS info_type,
              b.ctime,
              a.declaredate AS declare_date,
              a.TITLE_MAIN AS title,
              a.autor,
              a.AUTOR_UNIT    autor_unit,
              e.SRC_NAME      src_name,
              c.STOCKCODE     symbol,
              c.STOCKSNAME    name,
              '否'         AS if_imp,
              f.TXT_CONTENT   info_content,
              ''           AS aace_route,
              ''           AS aace_type
            FROM news_main a
              JOIN news_stk b ON a.guid = b.guid
              JOIN STK_CODE c ON b.comcode = c.COMCODE
              JOIN pgznty.z3_sec_cons d ON c.INNER_CODE = d.INNER_CODE
              JOIN PUB_INFOR_SRC e ON a.src_code = e.SRC_CODE
              JOIN news_content f ON a.GUID = f.guid
            WHERE a.isvalid = 1 AND b.isvalid = 1 AND c.isvalid = 1 AND d.isvalid = 1 AND e.isvalid = 1  AND f.isvalid = 1 and ifnull(f.TXT_CONTENT,'') != ''  %(where_str)s  limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "offset": str(offset), "limit": str(limit)}
        # print sql
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["guid"]
            _t = copy.deepcopy(row)
            del _t["innerCode"]
            del _t["symbol"]
            del _t["name"]

            if key not in tmp:
                tmp.setdefault(
                    key, {
                        "stks": []
                    })
                tmp[key].update(_t)

            tmp[key]["stks"].append({
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
            })
        # print len(tmp)
        return tmp.values()

    def make_Z3_EQUITY_NEWS_data2(self, offset, limit):
        """
        生成 个股新闻公告表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c", "d", "e", "f"], "c")
        sql = """
            SELECT
              d.SEC_UNI_ID  innerCode,
              a.disc_id AS  guid,
              '公告'      AS  info_type,
              b.ctime,
              a.declaredate AS declare_date,
              a.TITLE   AS  title,
              NULL      AS  autor,
              NULL      AS  AUTOR_UNIT,
              a.SOURCE  AS  src_name,
              c.STOCKCODE AS symbol,
              c.STOCKSNAME AS name,
              '否'         AS if_imp,
              e.TXT_CONTENT info_content,
              f.ACCE_ROUTE  aace_route,
              f.ACCE_TYPE   aace_type
            FROM disc_main_com a
              JOIN DISC_COM b ON a.disc_id = b.disc_id
              JOIN STK_CODE c ON b.comcode = c.COMCODE
              JOIN pgznty.z3_sec_cons d ON c.INNER_CODE = d.INNER_CODE
              JOIN disc_content_com e ON a.DISC_ID = e.DISC_ID
              LEFT JOIN disc_acce_com f ON a.DISC_ID = f.DISC_ID AND f.isvalid = 1
            WHERE a.isvalid = 1 AND b.isvalid = 1 AND c.isvalid = 1  AND e.isvalid = 1 %(where_str)s limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "offset": str(offset), "limit": str(limit)}
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["guid"]
            _t = copy.deepcopy(row)
            del _t["innerCode"]
            del _t["symbol"]
            del _t["name"]

            if key not in tmp:
                tmp.setdefault(
                    key, {
                        "stks": []
                    })
                tmp[key].update(_t)

            tmp[key]["stks"].append({
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
            })
        return tmp.values()

    def make_Z3_RESEARCH_REPORT_data(self, offset, limit):
        """
        生成 个股研报表 数据
        :return:
        """
        where_str = self._make_where("STOCKCODE", ["a", "b", "c", "d", "e"], "c")
        sql = """
        SELECT
          a.RES_ID          res_id,
          d.SEC_UNI_ID      innerCode,
          a.RPT_TITLE       title,

          a.DECLAREDATE     declare_date,
          e.REF_NAME     AS res_type,
          a.ORGNAME as src_name,
          ifnull((select CSName from org_profile where ISVALID=1 and ORGCODE=a.ORGCODE),'') AS src_sname,
          c.STOCKCODE       symbol,
          c.STOCKSNAME      name,
          a.RPT_ABSTRACT AS summary,
          a.ACCE_ROUTE      aace_route
        FROM RES_REPORT_MAIN a
          JOIN RES_SEC_CODE b ON b.res_id = a.res_id
          JOIN STK_CODE c ON b.INNER_CODE = c.INNER_CODE
          JOIN pgznty.z3_sec_cons d ON c.INNER_CODE = d.INNER_CODE
          LEFT JOIN GEN_REF e ON e.CLS_CODE = 5041 AND e.REF_CODE = a.RPT_TYPE AND e.isvalid = 1
        WHERE a.isvalid = 1 AND b.isvalid = 1 AND c.isvalid = 1 AND ifnull(a.RPT_ABSTRACT,'') != ''  %(where_str)s
        LIMIT %(offset)s,%(limit)s
        """ % {"where_str": where_str, "offset": offset, "limit": limit}
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["res_id"]
            _t = copy.deepcopy(row)
            del _t["innerCode"]
            del _t["symbol"]
            del _t["name"]

            if key not in tmp:
                tmp.setdefault(
                    key, {
                        "stks": []
                    })
                tmp[key].update(_t)

            tmp[key]["stks"].append({
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
            })
        return tmp.values()

    def get_last5_enddate(self):
        """
        获取前5个交易日的日期
        :return:
        """
        sql = """
        SELECT MIN(ENDDATE) ENDDATE
        FROM (
          SELECT ENDDATE
          FROM Z3_EXCHANGE_CALENDAR
          WHERE MKT_TYPE = 1 AND OPEN_CLOSE = 1 AND ENDDATE < NOW()
          ORDER BY ENDDATE DESC
          LIMIT 5
        ) b;
        """
        raw = self.conn.fetchone(sql)
        return raw["ENDDATE"] if raw else None

    def get_TRADEDATE_list(self, c, limit=0, firt_day=None):
        '''
        获取股票前161个交易日日期
        :param c:
        :return:
        '''
        where_str = ' LIMIT %s' % str(limit) if limit else ''
        sql = """
            SELECT *
            FROM (
              SELECT DISTINCT TRADEDATE
              FROM STK_MKT
                        WHERE ISVALID = 1 AND INNER_CODE = '%(INNER_CODE)s'
              ORDER BY TRADEDATE DESC
              %(where_str)s
            ) b ORDER BY TRADEDATE
        """ % {"INNER_CODE": c, "where_str": where_str}
        result = self.conn.fetchall(sql)
        format_data(result)
        return result

    def get_enddate_list(self, mysql_table, c):
        c.update({"mysql_table": mysql_table})
        sql = """
            SELECT *
            FROM (

            SELECT DISTINCT ENDDATE TRADEDATE FROM %(mysql_table)s
             WHERE ISVALID=1 AND INNER_CODE = '%(INNER_CODE)s'

             ORDER BY TRADEDATE DESC
              LIMIT 279
            ) b ORDER BY TRADEDATE
        """ % c
        result = self.conn.fetchall(sql)
        format_data(result)
        return result

    def get_month_enddate_list(self):
        sql = """
        SELECT DISTINCT ENDDATE FROM ana_stk_mkt_month
         WHERE ISVALID=1
         ORDER BY enddate ;

        """
        result = self.conn.fetchall(sql)
        format_data(result)
        return result

    def make_Z3_EQUITY2_data(self, seccode_list):

        min_low = lambda infolist: min([r["low_px"] for r in infolist]) if len(infolist) else None
        max_high = lambda infolist: max([r["high_px"] for r in infolist]) if len(infolist) else None
        get_factor_info = lambda r: db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.symbol": r["a_stockcode"],
                "end_date": r["EX_DIVI_DATE"],
            }, {"ex_factor": 1, "cum_factor": 1}
        )
        data_list = []
        ps_cash_bt_1year_model = """
        SELECT *
        FROM (

          SELECT
            a_stockcode,
            PERIODDATE,
            EX_DIVI_DATE,
            ifnull((CASH_BT) / 10,0) CASH_BT10
          FROM STK_DIV_INFO a
          WHERE isvalid = 1 AND PRG_CODE IN (1, 3)
                AND DIV_TYPE_CODE IN (1, 3) AND year(PERIODDATE) = year(now()) - 1 AND stk_type_code = 1
                AND DIR_DCL_DATE = (
            SELECT max(DIR_DCL_DATE)
            FROM STK_DIV_INFO
            WHERE isvalid = 1 AND PRG_CODE IN (1, 3)
                  AND DIV_TYPE_CODE IN (1, 3) AND year(PERIODDATE) = year(now()) - 1
                  AND a.PERIODDATE = PERIODDATE AND a.COMCODE = COMCODE
          ) AND  COMCODE=%(COMCODE)s
          UNION
          SELECT
            a_stockcode,
            PERIODDATE,
            EX_DIVI_DATE,
            ifnull((CASH_BT) / 10,0) CASH_BT10
          FROM STK_DIV_INFO
          WHERE isvalid = 1 AND PRG_CODE IN (4, 6, 29)
                AND DIV_TYPE_CODE IN (1, 3) AND year(PERIODDATE) = year(now()) - 1 AND stk_type_code = 1 AND  COMCODE=%(COMCODE)s

        ) a ORDER BY PERIODDATE

        """
        # net_asset
        net_asset_mic_lyr_model = """
            SELECT
            ifnull(F110301,0) F110301 ,
            ifnull(F110101,0) F110101 ,COMCODE
            FROM STK_FIN_IDX a
            WHERE RPT_DATE = ENDDATE
                  AND DATE_FORMAT(RPT_DATE, '%%Y-%%m-%%d') LIKE '%%-12-31' AND ISVALID = 1
                  AND RPT_DATE = (
              SELECT max(RPT_DATE)
              FROM STK_FIN_IDX
              WHERE RPT_DATE = ENDDATE
                    AND DATE_FORMAT(RPT_DATE, '%%Y-%%m-%%d') LIKE '%%-12-31' AND ISVALID = 1 AND COMCODE = a.COMCODE
            ) AND COMCODE=%(COMCODE)s
        """
        cash_mic_ttm_model = """
        SELECT
          ifnull(INC_MI,0) INC_MI,
          ifnull(CAS_OPE,0) CAS_OPE
        FROM ANA_STK_TWE_IDX a
        WHERE isvalid = 1 AND ENDDATE = (
          SELECT max(ENDDATE)
          FROM ANA_STK_TWE_IDX
          WHERE isvalid = 1 AND a.COMCODE = COMCODE
        ) AND COMCODE=%(COMCODE)s
        """
        for i in seccode_list:
            conn = tools.mongo_cursor()
            db = conn["z3dbus"]
            # lclose_week
            tmp = {}
            results = list(db["Z3_STK_MKT_DAY_INTER"].find({
                "equity.innerCode": i["innerCode"],
                "ex_status": 1,
                "end_date": {"$gte": pre_date(7)}
            }, {"close_px": 1}).sort("end_date").limit(1))
            print pre_date(7)
            tmp["lclose_week"] = float(results[0]["close_px"]) if results else None
            results = list(db["Z3_STK_MKT_DAY_INTER"].find({
                "equity.innerCode": i["innerCode"],
                "ex_status": 1,
                "end_date": {"$lt": pre_date()}
            }, {"low_px": 1, "high_px": 1}).sort("end_date", pymongo.DESCENDING).limit(364))
            result_list = [results[:10], results[:20], results[:30], results[:60], results[:120], results]
            low_key_list = [
                "low_10day",
                "low_20day",
                "low_30day",
                "low_60day",
                "low_120day",
                "low_52week",
            ]
            low_key_list = ["%s" % k for k in [
                "low_10day",
                "low_20day",
                "low_30day",
                "low_60day",
                "low_120day",
                "low_52week",
            ]]
            high_key_list = ["%s" % k for k in [
                "high_10day",
                "high_20day",
                "high_30day",
                "high_60day",
                "high_120day",
                "high_52week",
            ]]
            tmp.update(dict(zip(low_key_list, map(min_low, result_list))))
            tmp.update(dict(zip(high_key_list, map(max_high, result_list))))
            # ps_cash_bt_1year
            results = self.conn.fetchall(ps_cash_bt_1year_model, i)
            print results
            print len(results)
            if not results:
                tmp["ps_cash_bt_1year"] = None
            elif len(results) == 1:

                tmp["ps_cash_bt_1year"] = float(results[0]["CASH_BT10"])
            else:
                if not results[0]["EX_DIVI_DATE"]:
                    base_ex_factor = 1
                    base_cum_factor = 1
                else:
                    base = get_factor_info(results[0])
                    base_ex_factor = float(base["ex_factor"]) if base else 1
                    base_cum_factor = float(base["cum_factor"]) if base else 1
                    ps_cash_bt_1year = float(results[0]["CASH_BT10"])
                    for r in results[0:]:
                        nobase = get_factor_info(r)
                        nobase_cum_factor = float(nobase["cum_factor"]) if nobase else 1
                        CASH_BT10 = float(r["CASH_BT10"]) * ((nobase_cum_factor / base_cum_factor) / base_ex_factor)
                        ps_cash_bt_1year += CASH_BT10
                    tmp["ps_cash_bt_1year"] = ps_cash_bt_1year

            # cash_ttm

            results = self.conn.fetchall(cash_mic_ttm_model, i)
            tmp["cash_ttm"] = float(results[0]["CAS_OPE"]) if results else None
            tmp["mic_ttm"] = float(results[0]["INC_MI"]) if results else None

            # net_asset,mic_lyr
            results = self.conn.fetchall(net_asset_mic_lyr_model, i)
            # tmp["net_asset"] = float(results[0]["F110301"]) if results else None
            tmp["mic_lyr"] = float(results[0]["F110101"]) if results else None
            #
            tmp = {("mkt2_idx.%s" % k): v for k, v in tmp.items()}
            tmp.update({"_id": i["innerCode"]})
            data_list.append(tmp)
            print tmp
        return data_list

        # get_max_high = lambda

    def make_Z3_EQUITY_data(self, seccode_list):
        """
        获取信号信息
        :param seccode_list:
        :return:
        """

        last5_enddate = self.get_last5_enddate()

        # 连续上涨,连续下跌
        sql_ups_and_downs_model = """
           SELECT
             sum(CASE WHEN TCLOSE > LCLOSE
               THEN 1
                 ELSE 0 END) ups,
             sum(CASE WHEN TCLOSE < LCLOSE
               THEN 1
                 ELSE 0 END) downs

           FROM
             (
               SELECT
                 TCLOSE,
                 LCLOSE
               FROM

                 STK_MKT a
               WHERE a.SECCODE = %(symbol)s AND a.ISVALID = 1

               ORDER BY TRADEDATE DESC
               LIMIT 5
             ) a;
       """
        # 业绩公告前
        sql_pa_defore = """
           SELECT 1
           FROM STK_PRE_DISCLOSURE
           WHERE ACT_DATE IS NULL AND ifnull(ifnull(CHNG_DATE3, ifnull(CHNG_DATE2, CHNG_DATE1)),PRE_DATE) <date_add(now(),INTERVAL 30 DAY)  AND ISVALID = 1 AND COMCODE=%(COMCODE)s
           LIMIT 1;
       """
        # 业绩公告后
        sql_pa_after = """
           SELECT 1
           FROM STK_PRE_DISCLOSURE
           WHERE ACT_DATE > date_sub(now(),INTERVAL 30 DAY)  AND ISVALID = 1 AND COMCODE=%(COMCODE)s
           LIMIT 1;
       """
        # 近期内部买入
        sql_inner_buy = """
       SELECT 1
       FROM STK_MNG_TRADE_INFO a
       WHERE a.ISVALID = 1
             AND COMCODE = %(COMCODE)s
             AND a.STK_CODE = %(symbol)s
             AND RELATION = '本人'
             AND CHNG_DATE >= date_sub(now(),INTERVAL 30 DAY)
             AND CHNG_VOL > 0 LIMIT 1

       """
        # 近期内部卖出
        sql_inner_sell = """
       SELECT 1
       FROM STK_MNG_TRADE_INFO a
       WHERE a.ISVALID = 1
             AND COMCODE = %(COMCODE)s
             AND a.STK_CODE = %(symbol)s
             AND RELATION = '本人'
             AND CHNG_DATE >= date_sub(now(),INTERVAL 30 DAY)
             AND CHNG_VOL < 0 LIMIT 1
       """
        # 重大事项
        sql_majorissue = """
    SELECT 1
    FROM STK_GREATE_EVENT
    WHERE isvalid = 1 AND DECLAREDATE >= %(last5_enddate)s AND EVENT_CODE IN (1, 2, 3, 4, 5, 8, 10) AND
          (ORG_CODE = %(COMCODE)s OR stockcode = %(symbol)s)
    UNION
    SELECT 1
    FROM STK_REPURCHASE
    WHERE isvalid = 1 AND comcode = %(COMCODE)s AND DECLAREDATE >= %(last5_enddate)s
    UNION
    SELECT 1
    FROM STK_TENDER_OFFER_INFO
    WHERE
      isvalid = 1 AND comcode = %(COMCODE)s AND FIRST_DATE >= %(last5_enddate)s
    UNION
    SELECT 1
    FROM STK_MERG_INFO
    WHERE isvalid = 1 AND comcode = %(COMCODE)s AND DECLAREDATE >= %(last5_enddate)s LIMIT 1;
       """
        # 近期机构买入
        sql_ins_buy = """
       SELECT 1
       FROM STK_ADD_HOLD a
         JOIN ORG_PROFILE b ON a.ADD_CODE = b.ORGCODE AND b.ORG_TYPE NOT IN (700, 800)
       WHERE
         a.ISVALID = 1 AND b.ISVALID = 1
         AND a.comcode = %(COMCODE)s
         AND ADD_SUB_TYPE = 1 AND ACTU_DATE > date_sub(now(),INTERVAL 30 DAY)
       UNION
       SELECT 1
       FROM STK_EXCRA_INFO_MAIN a
         JOIN STK_EXCRA_BRANCH_LIST b ON a.seq = b.p_seq
       WHERE a.ISVALID = 1 AND b.ISVALID = 1
             AND a.INNER_CODE = %(INNER_CODE)s
             AND a.RANK_CLS = 1 AND b.BRANCH_CODE = 200513872 AND ENDDATE > date_sub(now(),INTERVAL 30 DAY)
       LIMIT 1;

       """
        # 近期机构卖出
        sql_ins_sell = """
       SELECT 1
       FROM STK_ADD_HOLD a
         JOIN ORG_PROFILE b ON a.ADD_CODE = b.ORGCODE AND b.ORG_TYPE NOT IN (700, 800)
       WHERE
         a.ISVALID = 1 AND b.ISVALID = 1
         AND a.comcode = %(COMCODE)s
         AND ADD_SUB_TYPE = 2 AND ACTU_DATE > date_sub(now(),INTERVAL 30 DAY)
       UNION
       SELECT 1
       FROM STK_EXCRA_INFO_MAIN a
         JOIN STK_EXCRA_BRANCH_LIST b ON a.seq = b.p_seq
       WHERE a.ISVALID = 1 AND b.ISVALID = 1
             AND a.INNER_CODE = %(INNER_CODE)s
             AND a.RANK_CLS = 2 AND b.BRANCH_CODE = 200513872 AND ENDDATE > date_sub(now(),INTERVAL 30 DAY)
       LIMIT 1;
       """
        # 波动最大 获取Z3_EQUITY 5% 的 stockcode
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        count = db["Z3_EQUITY"].count() * 5 / 100
        wave_list = db["Z3_EQUITY"].find(
            {}, {"symbol": 1}
        ).sort("volat_mon", pymongo.DESCENDING).limit(count)
        wave_list = [k["symbol"] for k in wave_list if "symbol" in k]
        wave_list = list(set(wave_list))
        result = []
        for i in seccode_list:
            baseinfo = db["Z3_EQUITY"].find_one({"symbol": i["symbol"]})
            baseinfo = baseinfo if baseinfo else {}
            tmp = {}
            i.update({"last5_enddate": last5_enddate})
            raw = self.conn.fetchone(sql_ups_and_downs_model, i)
            tmp["signal_normal_10"] = True if raw["ups"] == 5 else False
            tmp["signal_normal_11"] = True if raw["downs"] == 5 else False
            raw = self.conn.fetchone(sql_pa_defore, i)
            tmp["signal_normal_12"] = True if raw else False

            print"uuu"
            raw = self.conn.fetchone(sql_pa_after, i)
            print"ooo"
            tmp["signal_normal_13"] = True if raw else False
            raw = self.conn.fetchone(sql_inner_buy, i)
            tmp["signal_normal_14"] = True if raw else False
            raw = self.conn.fetchone(sql_inner_sell, i)
            tmp["signal_normal_15"] = True if raw else False
            raw = self.conn.fetchone(sql_majorissue, i)
            tmp["signal_normal_16"] = True if raw else False
            raw = self.conn.fetchone(sql_ins_buy, i)
            tmp["signal_normal_18"] = True if raw else False
            raw = self.conn.fetchone(sql_ins_sell, i)
            tmp["signal_normal_19"] = True if raw else False
            tmp["signal_normal_5"] = True if i["symbol"] in wave_list else False
            # 市场同步
            # print baseinfo
            tmp["signal_normal_32"] = True if 0.95 < baseinfo.get("perf_idx", {}).get("beta", 0) < 1.05 else False
            # 买入或增持
            tmp["signal_normal_34"] = True if baseinfo.get("fcst_idx", {}).get("rating_syn", 0) in [1, 2] else False
            # 卖出或减持
            tmp["signal_normal_35"] = True if baseinfo.get("fcst_idx", {}).get("rating_syn", 0) in [4, 5] else False

            tmp = {("signal_normal.%s" % i): tmp[i] for i in tmp}
            tmp["_id"] = i["innerCode"]
            result.append(tmp)

        return result

    def make_Z3_EXCHANGE_CALENDAR_data(self, offset, limit):
        where_str = self._make_where("", ["a", ])
        sql = """
        SELECT
          CONVERT(date_format(ENDDATE, '%%Y%%m%%d'),SIGNED) AS trade_date,
          CASE WHEN MKT_TYPE = 1
            THEN 'SZ'
          WHEN MKT_TYPE = 2
            THEN 'SH' END AS exchange,
          OPEN_CLOSE      AS open_close
        FROM PUB_EXCHANGE_CALENDAR a
        WHERE isvalid = 1 AND MKT_TYPE IN (1, 2)
        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        results = self.conn.fetchall(sql)
        return results

    def make_Z3_INDEX_SAMPLE_data(self, offset, limit):
        """
        生成 指数样本表 表数据
        :return:
        """
        where_str = self._make_where("INNER_CODE", ["a", "b", "c", "d"])
        sql = """
        SELECT
          b.INDX_CODE  AS symbol,
          b.INDX_SNAME AS name,
          d.sec_uni_id AS samples_innerCode,
          c.STOCKCODE  AS samples_symbol,
          c.STOCKSNAME AS samples_name

        FROM INDX_SAMP_INFO a
          JOIN INDX_GEN_INFO b ON a.INNER_CODE = b.INNER_CODE
          JOIN STK_CODE c ON a.SEC_INNER_CODE = c.INNER_CODE
          JOIN pgznty.z3_sec_cons d ON c.INNER_CODE = d.INNER_CODE
        WHERE a.isvalid = 1 AND b.isvalid = 1 AND c.isvalid = 1 AND d.isvalid = 1 AND b.INDX_CODE IN (
          '000300', '000001', '399001', '399006', '399005', '000016', '000852', '000906', '000852', '000905')
              AND ifnull(a.STARTDATE, '1900-01-01') <= now()
              AND ifnull(a.ENDDATE, '2999-12-31') > now()
              %(where_str)s
              Limit %(offset)s,%(limit)s

        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["symbol"]
            tmp.setdefault(
                key, {
                    "symbol": row["symbol"],
                    "name": row["name"],
                    "samples": []
                })
            tmp[key]["samples"].append({
                "innerCode": row["samples_innerCode"],
                "symbol": row["samples_symbol"],
                "name": row["samples_name"],
            })
        return tmp.values()

    @cache
    def DAY_INTER_base(self, tradedate, inner_code):
        """
        获取某支股票的日级基础信息
        :return:
        """
        sql = """
        SELECT
        b.SEC_UNI_ID innerCode,
        a.TRADEDATE  end_date,
        0            ex_status,
        c.STOCKCODE  symbol,
        c.STOCKSNAME name,
        1            cum_factor_inter,
        round(a.TOPEN,2)      open_px,
        round(a.THIGH,2)      high_px,
        round(a.TLOW,2)       low_px,
        round(a.TCLOSE,2)     close_px,
        round(a.LCLOSE,2)     prev_close_px,
        round(a.CHNG,2)       chg,
        round(a.CHNG_PCT,4)   chg_pct,
        round(a.TVOLUME,0)    volume,
        round(a.TVALUE,4)     amount
        FROM STK_MKT a
          JOIN pgznty.z3_sec_cons b ON a.INNER_CODE = b.INNER_CODE
          JOIN STK_CODE c ON b.INNER_CODE = c.INNER_CODE AND c.STATUS_TYPE_REF=1
        WHERE a.ISVALID = 1 AND b.isvalid = 1 AND c.ISVALID = 1
        AND TRADEDATE=%(tradedate)s AND a.INNER_CODE=%(inner_code)s
        ORDER BY a.TRADEDATE DESC;
           """
        results = self.conn.fetchone(sql, {"tradedate": tradedate, "inner_code": inner_code})
        # print results
        return results

    def WEEK_INTER_base(self, tradedate, inner_code, mysql_table):
        """
        周行情表基础数据
        :return:
        """
        sql = """
        SELECT
        b.SEC_UNI_ID innerCode,
        a.ENDDATE  end_date,
        0            ex_status,
        c.STOCKCODE  symbol,
        c.STOCKSNAME name,
        a.FIRST_TRADE_DATE first_trade_date,
        a.LAST_TRADE_DATE last_trade_date,
        a.FAC_THIGH_DATE thigh_date,
        a.FAC_TLOW_DATE tlow_date,
        round(a.TOPEN,2) open_px,
        round(a.THIGH,2)      high_px,
        round(a.TLOW,2)       low_px,
        round(a.TCLOSE,2)     close_px,
        round(a.CHNG_PCT,4)   chg_pct,
        a.TVOLUME    volume,
        a.TVALUE     amount

        FROM %(mysql_table)s a
          JOIN pgznty.z3_sec_cons b ON a.INNER_CODE = b.INNER_CODE
          JOIN STK_CODE c ON b.INNER_CODE = c.INNER_CODE and c.STATUS_TYPE_REF=1
        WHERE a.ISVALID = 1 AND b.isvalid = 1 AND c.ISVALID = 1
        AND ENDDATE='%(tradedate)s' AND a.INNER_CODE='%(inner_code)s'
        AND ifnull(TVOLUME,0)!=0
        ORDER BY a.ENDDATE DESC;
           """ % {"tradedate": tradedate,
                  "inner_code": inner_code,
                  "mysql_table": mysql_table}
        results = self.conn.fetchall(sql)
        # print results, "------------"
        return results

    def make_Z3_TOPIC_SAMPLE_data(self, offset, limit):
        """
        生成 概念板块样本表 表数据
        :return:
        """

        where_str = self._make_where("INNER_CODE", ["a", "b", "c", "d"])
        sql = """
         SELECT
          b.SECTION_CODE AS topic_code,
          b.SECTION_NAME AS topic_name,
          d.SEC_UNI_ID AS innerCode,
          c.STOCKCODE AS symbol,
          c.STOCKSNAME AS name
         FROM PUB_SECTION_CODE b
          LEFT JOIN  PUB_SECTION_REL a ON a.isvalid = 1 AND a.SECTION_CODE = b.SECTION_CODE  AND ifnull(a.EN_TIME, '1900-01-01') <= now() AND ifnull(a.REJE_TIME, '2999-12-31') > now()
          LEFT JOIN STK_CODE c ON a.INNER_CODE = c.INNER_CODE AND c.isvalid = 1
          LEFT JOIN pgznty.z3_sec_cons d ON a.INNER_CODE = d.INNER_CODE AND d.isvalid = 1

        WHERE  b.isvalid = 1 AND b.sys_code = 5

        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        print sql
        results = self.conn.fetchall(sql)
        # 转换成嵌套结构
        tmp = {}
        for row in results:
            key = row["topic_code"]
            tmp.setdefault(
                key, {
                    "topic_code": row["topic_code"],
                    "topic_name": row["topic_name"],
                    "samples": []
                })
            tmp[key]["samples"].append({
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
            })
        for pid in tmp.keys():
            # 获取 该主题的所有子主题
            child_topics = self.get_topic_childs(pid)
            for cid in child_topics:
                tmp[pid]["samples"].extend([i for i in tmp[cid]["samples"] if i not in tmp[pid]["samples"]])
        return tmp.values()

    def get_topic_childs(self, pid):
        tmp = []
        sql = """
          SELECT SECTION_CODE
          FROM PUB_SECTION_CODE
          WHERE PARENT_CODE = %s AND ISVALID = 1
        """ % pid
        result = self.conn.fetchall(sql)
        # tmp = [i["SECTION_CODE"] for i in result]
        for i in result:
            cid = i["SECTION_CODE"]
            tmp.append(cid)
            # 递归获取子主题
            tmp.extend(self.get_topic_childs(cid))
        return tmp

    def update_sum_bak(self, row, data120):
        data119 = data120[:119]
        data59 = data120[:59]
        data29 = data120[:29]
        data19 = data120[:19]
        data9 = data120[:9]
        data4 = data120[:4]
        # if len(data119) == 119:
        #     print len(data119)
        row["SUM119"] = None if len(data119) < 119 else round(sum([i["close_px"] for i in data119]), 2)
        row["SUM59"] = None if len(data59) < 59 else round(sum([i["close_px"] for i in data59]), 2)
        row["SUM29"] = None if len(data29) < 29 else round(sum([i["close_px"] for i in data29]), 2)
        row["SUM19"] = None if len(data19) < 19 else round(sum([i["close_px"] for i in data19]), 2)
        row["SUM9"] = None if len(data9) < 9 else round(sum([i["close_px"] for i in data9]), 2)
        row["SUM4"] = None if len(data4) < 4 else round(sum([i["close_px"] for i in data4]), 2)

    def update_sum(self, row, data250):
        data249 = data250[:249]
        data119 = data249[:119]
        data59 = data119[:59]
        data29 = data59[:29]
        data19 = data29[:19]
        data9 = data19[:9]
        data4 = data9[:4]
        # if len(data119) == 119:
        #     print len(data119)
        row["SUM249"] = None if len(data249) < 249 else round(sum([i["close_px"] for i in data249]), 2)
        row["SUM119"] = None if len(data119) < 119 else round(sum([i["close_px"] for i in data119]), 2)
        row["SUM59"] = None if len(data59) < 59 else round(sum([i["close_px"] for i in data59]), 2)
        row["SUM29"] = None if len(data29) < 29 else round(sum([i["close_px"] for i in data29]), 2)
        row["SUM19"] = None if len(data19) < 19 else round(sum([i["close_px"] for i in data19]), 2)
        row["SUM9"] = None if len(data9) < 9 else round(sum([i["close_px"] for i in data9]), 2)
        row["SUM4"] = None if len(data4) < 4 else round(sum([i["close_px"] for i in data4]), 2)

    def update_ma_bak(self, row, data120):
        # print "len(data120)",len(data120)
        row["MA120"] = None if len(data120) < 120 else round(sum([i["close_px"] for i in data120]) / 120, 2)
        data60 = data120[:60]
        row["MA60"] = None if len(data60) < 60 else round(sum([i["close_px"] for i in data60]) / 60, 2)
        data30 = data120[:30]
        row["MA30"] = None if len(data30) < 30 else round(sum([i["close_px"] for i in data30]) / 30, 2)
        data20 = data120[:20]
        row["MA20"] = None if len(data20) < 20 else round(sum([i["close_px"] for i in data20]) / 20, 2)
        data10 = data120[:10]
        row["MA10"] = None if len(data10) < 10 else round(sum([i["close_px"] for i in data10]) / 10, 2)
        data5 = data120[:5]
        row["MA5"] = None if len(data5) < 5 else round(sum([i["close_px"] for i in data5]) / 5, 2)

    def update_ma(self, row, data250):
        # print "len(data120)",len(data120)
        data120 = data250[:120]
        data60 = data120[:60]
        data30 = data60[:30]
        data20 = data30[:20]
        data10 = data20[:10]
        data5 = data10[:5]
        row["MA250"] = None if len(data250) < 250 else round(sum([i["close_px"] for i in data250]) / 250, 2)
        row["MA120"] = None if len(data120) < 120 else round(sum([i["close_px"] for i in data120]) / 120, 2)
        row["MA60"] = None if len(data60) < 60 else round(sum([i["close_px"] for i in data60]) / 60, 2)
        row["MA30"] = None if len(data30) < 30 else round(sum([i["close_px"] for i in data30]) / 30, 2)
        row["MA20"] = None if len(data20) < 20 else round(sum([i["close_px"] for i in data20]) / 20, 2)
        row["MA10"] = None if len(data10) < 10 else round(sum([i["close_px"] for i in data10]) / 10, 2)
        row["MA5"] = None if len(data5) < 5 else round(sum([i["close_px"] for i in data5]) / 5, 2)

    def get_week_120(self, db, row, table):
        # return []
        data120 = db[table].find({
            "equity.innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lte": row["end_date"]}
        }, {"close_px": 1})
        data120.sort([
            ('end_date', pymongo.DESCENDING)]).limit(120)
        return list(data120)

    def get_day_120(self, db, row):
        datas = db["Z3_STK_MKT_DAY_INTER"].find({
            "equity.innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lte": row["end_date"]}
        }, {"close_px": 1})
        datas.sort([
            ('end_date', pymongo.DESCENDING)]).limit(120)
        return list(datas)

    def get_day_250(self, db, row):
        datas = db["Z3_STK_MKT_DAY_INTER"].find({
            "equity.innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lte": row["end_date"]}
        }, {"close_px": 1})
        datas.sort([
            ('end_date', pymongo.DESCENDING)]).limit(250)
        return list(datas)

    def get_factor_day(self, symbol, end_date):
        # 替换symbol
        cursor = tools.mongo_cursor()
        db = cursor["z3dbus"]
        try:
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.symbol": symbol,
                    "end_date": end_date
                })
            if info:

                return info["ex_factor_today"] if info["ex_factor_today"]  else 1
            else:
                return 1
        except Exception, e:
            print e
            return self.get_factor_day(symbol, end_date)

    def make_Z3_STK_MKT_DAY_INTER_data(self, tradedate, code, mongo_table='', mysql_table=''):
        # return []
        # 只获取单个交易日
        # 获取股票行情基础信息
        # 某天数据时需要取该交易日的前xxx天的数据
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        result = copy.deepcopy(self.DAY_INTER_base(tradedate, code))

        if not result:
            print code, "no results"
            return []
        sql_tradedate_list_model = """
                SELECT
                  TRADEDATE
                FROM STK_MKT a
                WHERE a.ISVALID = 1
                      AND a.INNER_CODE = %(INNER_CODE)s
                ORDER BY TRADEDATE DESC
                LIMIT 279;
            """
        tmp = {}
        result = [result, ]
        format_data(result)
        result_1 = []
        result_2 = []
        result_3 = []
        for row in result:
            # 获取历史279交易日列表 128ms
            tradedate_list = self.conn.fetchall(sql_tradedate_list_model, {"INNER_CODE": code})
            # 获取计算所需数据
            tmp = {}
            # print row["trade_date"]
            tmp["end_date"] = row["end_date"]
            tmp["DATE_MAX"] = tradedate_list[0]["TRADEDATE"]
            tmp["DATE_MIN_60"] = tradedate_list[:179][-1]["TRADEDATE"]
            tmp["DATE_MIN_160"] = tradedate_list[:279][-1]["TRADEDATE"]

            # 获取计算的交易日的复权因子信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["end_date"]
                })
            tmp["CUM_FAC"] = info["cum_factor"] if info else 1
            tmp["EX_FAC"] = info["ex_factor_today"] if info else 1
            # 获取最大交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MAX"]
                })
            tmp["CUM_FAC_MAX"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MAX"] = info["ex_factor"] if info else 1
            # 获取前60交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MIN_60"]
                })
            tmp["CUM_FAC_MIN_60"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MIN_60"] = info["ex_factor"] if info else 1
            # 获取前160交易日复权信息，替换symbol
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MIN_160"]
                })
            tmp["CUM_FAC_MIN_160"] = info["cum_factor"] if info else 1
            tmp["EX_FAC_MIN_160"] = info["ex_factor"] if info else 1
            # 计算前复权,后复权60，后复权160 数据
            row_1 = copy.deepcopy(row)
            row_2 = copy.deepcopy(row)
            row_3 = copy.deepcopy(row)
            rows = [row, row_1, row_2, row_3]
            for index, rr in enumerate(rows):
                rr["ex_status"] = index

            CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["end_date"] else tmp["CUM_FAC_MAX"] / tmp["CUM_FAC"]
            # CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["TRADEDATE"] else tmp["CUM_FAC_MAX"] / (
            #     tmp["CUM_FAC"] / tmp["EX_FAC"])
            # 24.043369(24.043369/)
            CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_60"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
                "CUM_FAC_MIN_60"]
            CUM_FACTOR_AFT_160 = 1 if tmp["DATE_MIN_160"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
                "CUM_FAC_MIN_160"]
            row_1["cum_factor_inter"] = CUM_FACTOR_BEF
            row_2["cum_factor_inter"] = CUM_FACTOR_AFT_60
            row_3["cum_factor_inter"] = CUM_FACTOR_AFT_160
            row_1["open_px"] = round(row_1["open_px"] / row_1["cum_factor_inter"], 2)
            row_2["open_px"] = round(row_2["open_px"] * row_2["cum_factor_inter"], 2)
            row_3["open_px"] = round(row_3["open_px"] * row_3["cum_factor_inter"], 2)
            row_1["high_px"] = round(row_1["high_px"] / row_1["cum_factor_inter"], 2)
            row_2["high_px"] = round(row_2["high_px"] * row_2["cum_factor_inter"], 2)
            row_3["high_px"] = round(row_3["high_px"] * row_3["cum_factor_inter"], 2)
            row_1["low_px"] = round(row_1["low_px"] / row_1["cum_factor_inter"], 2)
            row_2["low_px"] = round(row_2["low_px"] * row_2["cum_factor_inter"], 2)
            row_2["low_px"] = round(row_2["low_px"] * row_2["cum_factor_inter"], 2)
            row_3["low_px"] = round(row_3["low_px"] * row_3["cum_factor_inter"], 2)
            row_1["close_px"] = round(row_1["close_px"] / row_1["cum_factor_inter"], 2)
            # print row["close_px"]
            # print row_1["close_px"]
            row_2["close_px"] = round(row_2["close_px"] * row_2["cum_factor_inter"], 2)
            row_3["close_px"] = round(row_3["close_px"] * row_3["cum_factor_inter"], 2)
            row_1["prev_close_px"] = round(row_1["prev_close_px"] / row_1["cum_factor_inter"], 2)
            row_2["prev_close_px"] = round(row_2["prev_close_px"] * row_2["cum_factor_inter"], 2)
            row_3["prev_close_px"] = round(row_3["prev_close_px"] * row_3["cum_factor_inter"], 2)
            row_1["chg"] = round(row_1["chg"] / row_1["cum_factor_inter"], 4)
            row_2["chg"] = round(row_2["chg"] * row_2["cum_factor_inter"], 4)
            row_3["chg"] = round(row_3["chg"] * row_3["cum_factor_inter"], 4)
            # MA数据 从mongo获取历史数据

            for index, rr in enumerate(rows):
                data120 = self.get_day_120(db, rr)
                self.update_ma(rr, data120)
                self.update_sum(rr, data120)

            result_1.append(row_1)
            result_2.append(row_2)
            result_3.append(row_3)

        result.extend(result_1)
        result.extend(result_2)
        result.extend(result_3)
        # print result
        return result

    def make_Z3_STK_MKT_DAY_INTER_data_no_factor(self, result, tradedate, code, get_ma=False, mongo_table='',
                                                 mysql_table=''):
        """
        计算不复权数据
        :param result:
        :param tradedate:
        :param code:
        :param get_ma:
        :param mongo_table:
        :param mysql_table:
        :return:
        """

        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]
        format_data(results)
        row = results[0]

        row["ex_status"] = 0
        print "no_factor"
        if get_ma:
            data120 = self.get_day_120(db, row)
            self.update_ma(row, data120)
            self.update_sum(row, data120)
        return [row, ]

    def make_Z3_STK_MKT_DAY_INTER_data_after_60_factor(self, result, tradedate, code, get_ma=False, mongo_table='',
                                                       mysql_table=''):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]
        format_data(results)
        row = results[0]
        # 获取历史279交易日列表 128ms
        tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MIN_60"] = tradedate_list[:179][-1]["TRADEDATE"]

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            })
        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1

        # 获取前60交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MIN_60"]
            })
        tmp["CUM_FAC_MIN_60"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MIN_60"] = info["ex_factor"] if info else 1

        # 计算前复权数据
        row_2 = copy.deepcopy(row)
        row_2["ex_status"] = 2
        CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_60"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
            "CUM_FAC_MIN_60"]
        row_2["cum_factor_inter"] = CUM_FACTOR_AFT_60
        row_2["open_px"] = round(row_2["open_px"] * row_2["cum_factor_inter"], 2)
        row_2["high_px"] = round(row_2["high_px"] * row_2["cum_factor_inter"], 2)
        row_2["low_px"] = round(row_2["low_px"] * row_2["cum_factor_inter"], 2)
        # print row["close_px"]
        # print row_1["close_px"]
        row_2["close_px"] = round(row_2["close_px"] * row_2["cum_factor_inter"], 2)
        row_2["prev_close_px"] = round(row_2["prev_close_px"] * row_2["cum_factor_inter"], 2)
        row_2["chg"] = round(row_2["chg"] * row_2["cum_factor_inter"], 4)
        # MA数据 从mongo获取历史数据

        if get_ma:
            data120 = self.get_day_120(db, row_2)
            self.update_ma(row_2, data120)
            self.update_sum(row_2, data120)

        return [row_2, ]

    def make_Z3_STK_MKT_DAY_INTER_data_after_160_factor(self, result, tradedate, code, get_ma=False, mongo_table='',
                                                        mysql_table=''):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]
        format_data(results)
        row = results[0]
        # 获取历史279交易日列表 128ms
        tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MIN_160"] = tradedate_list[:279][-1]["TRADEDATE"]

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            })
        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1

        # 获取前160交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MIN_160"]
            })
        tmp["CUM_FAC_MIN_160"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MIN_160"] = info["ex_factor"] if info else 1

        # 计算前复权数据
        row_3 = copy.deepcopy(row)
        row_3["ex_status"] = 3
        CUM_FACTOR_AFT_60 = 1 if tmp["DATE_MIN_160"] == tmp["end_date"] else tmp["CUM_FAC"] / tmp[
            "CUM_FAC_MIN_160"]
        row_3["cum_factor_inter"] = CUM_FACTOR_AFT_60
        row_3["open_px"] = round(row_3["open_px"] * row_3["cum_factor_inter"], 2)
        row_3["high_px"] = round(row_3["high_px"] * row_3["cum_factor_inter"], 2)
        row_3["low_px"] = round(row_3["low_px"] * row_3["cum_factor_inter"], 2)
        # print row["close_px"]
        # print row_1["close_px"]
        row_3["close_px"] = round(row_3["close_px"] * row_3["cum_factor_inter"], 2)
        row_3["prev_close_px"] = round(row_3["prev_close_px"] * row_3["cum_factor_inter"], 2)
        row_3["chg"] = round(row_3["chg"] * row_3["cum_factor_inter"], 4)
        # MA数据 从mongo获取历史数据

        if get_ma:
            data120 = self.get_day_120(db, row_3)
            self.update_ma(row_3, data120)
            self.update_sum(row_3, data120)

        return [row_3, ]

    def make_Z3_STK_MKT_DAY_INTER_data_pre_factor(self, result, tradedate, code, get_ma=False, mongo_table='',
                                                  mysql_table=''):
        """
        计算前复权数据
        :param result:
        :param tradedate:
        :param code:
        :param get_ma:
        :param mongo_table:
        :param mysql_table:
        :return:
        """
        # return []
        # 只获取单个交易日
        # 获取股票行情基础信息
        # 某天数据时需要取该交易日的前xxx天的数据
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # 获取某只股票一个交易日基础数据 23ms
        # result = self.DAY_INTER_base(tradedate, code)
        if not result:
            print code, "no results"
            return []
        tmp = {}
        results = [result, ]
        format_data(results)
        row = results[0]
        # 获取历史279交易日列表 128ms
        tradedate_list = self.get_tradedate_day_list(code)
        # 获取计算所需数据
        tmp = {}
        # print row["trade_date"]
        tmp["end_date"] = row["end_date"]
        tmp["DATE_MAX"] = tradedate_list[0]["TRADEDATE"]

        # 获取计算的交易日的复权因子信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["end_date"]
            })
        tmp["CUM_FAC"] = info["cum_factor"] if info else 1
        tmp["EX_FAC"] = info["ex_factor_today"] if info else 1
        # 获取最大交易日复权信息
        info = db["Z3_EX_FACTOR_ALL"].find_one(
            {
                "equity.innerCode": row["innerCode"],
                "end_date": tmp["DATE_MAX"]
            })
        # print info
        tmp["CUM_FAC_MAX"] = info["cum_factor"] if info else 1
        tmp["EX_FAC_MAX"] = info["ex_factor"] if info else 1
        # 计算前复权数据
        row_1 = copy.deepcopy(row)
        row_1["ex_status"] = 1

        CUM_FACTOR_BEF = 1 if tmp["DATE_MAX"] == tmp["end_date"] else tmp["CUM_FAC_MAX"] / tmp["CUM_FAC"]
        row_1["cum_factor_inter"] = CUM_FACTOR_BEF
        row_1["open_px"] = round(row_1["open_px"] / row_1["cum_factor_inter"], 2)
        row_1["high_px"] = round(row_1["high_px"] / row_1["cum_factor_inter"], 2)
        row_1["low_px"] = round(row_1["low_px"] / row_1["cum_factor_inter"], 2)
        row_1["close_px"] = round(row_1["close_px"] / row_1["cum_factor_inter"], 2)
        row_1["prev_close_px"] = round(row_1["prev_close_px"] / row_1["cum_factor_inter"], 2)
        row_1["chg"] = round(row_1["chg"] / row_1["cum_factor_inter"], 4)

        if get_ma:
            # data120 = self.get_day_120(db, row_1)
            data250 = self.get_day_250(db, row_1)
            self.update_ma(row_1, data250)
            self.update_sum(row_1, data250)

        return [row_1, ]

    @cache
    def get_tradedate_list(self, code, mysql_table):
        sql_tradedate_list_model = """
                SELECT
                  ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
                FROM %(mysql_table)s a
                WHERE a.ISVALID = 1
                      AND a.INNER_CODE = '%(code)s'
                ORDER BY ENDDATE DESC
                LIMIT 279;
            """
        print sql_tradedate_list_model % {
            "code": code,
            "mysql_table": mysql_table
        }
        return self.conn.fetchall(sql_tradedate_list_model % {
            "code": code,
            "mysql_table": mysql_table
        })

    @cache
    def get_tradedate_day_list(self, code):
        sql_tradedate_list_model = """
                SELECT
                  TRADEDATE
                FROM STK_MKT a
                WHERE a.ISVALID = 1
                      AND a.INNER_CODE = %(code)s
                ORDER BY TRADEDATE DESC
                LIMIT 279;
            """
        return self.conn.fetchall(sql_tradedate_list_model % {
            "code": code
        })

    def make_INTER_data(self, tradedate, code, mongo_table, mysql_table):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        result = self.WEEK_INTER_base(tradedate, code, mysql_table)
        if not result:
            return []
        # sql_tradedate_list_model = """
        #     SELECT
        #       ENDDATE,LAST_TRADE_DATE,FIRST_TRADE_DATE
        #     FROM %(mysql_table)s a
        #     WHERE a.ISVALID = 1
        #           AND a.STOCKCODE = '%(symbol)s'
        #     ORDER BY ENDDATE DESC
        #     LIMIT 279;
        # """
        tmp = {}
        format_data(result)
        result_1 = []
        result_2 = []
        result_3 = []
        for row in result:
            # print "rrrrrrrrrrrrrrrrrrrrrr"
            # n5 = datetime.datetime.now()
            row.update({"mysql_table": mysql_table})
            tradedate_list = self.get_tradedate_list(code, mysql_table)  # 获取计算所需数据
            del row["mysql_table"]
            if not tradedate_list:
                # print "ssssssssssssssssssssssss"
                continue
            # print "yyyyyyyyyyyyyyyyyyyyyy"
            tmp = {}
            # print "get n5 use:", datetime.datetime.now() - n5
            n6 = datetime.datetime.now()
            # print row["trade_date"]
            tmp["END_DATE"] = row["end_date"]
            tmp["DATE_MAX"] = tradedate_list[0]["LAST_TRADE_DATE"]
            tmp["WEEK_MIN_60"] = tradedate_list[:179][-1]["FIRST_TRADE_DATE"]
            tmp["WEEK_MIN_160"] = tradedate_list[:279][-1]["FIRST_TRADE_DATE"]

            row_1 = copy.deepcopy(row)
            row_2 = copy.deepcopy(row)
            row_3 = copy.deepcopy(row)
            rows = [row, row_1, row_2, row_3]
            for index, rr in enumerate(rows):
                rr["ex_status"] = index

            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["DATE_MAX"]
                })
            # print "get n6 use:", datetime.datetime.now() - n5
            CUM_FAC_MAX = info.get("cum_factor", 1) if info else 1
            EX_FAC_MAX = info.get("ex_factor", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["WEEK_MIN_60"]
                })
            # print "get n7 use:", datetime.datetime.now() - n5
            CUM_FAC_MIN_60 = info.get("cum_factor", 1) if info else 1
            EX_FAC_MIN_60 = info.get("ex_factor", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": tmp["WEEK_MIN_160"]
                })
            CUM_FAC_MIN_160 = info.get("cum_factor", 1) if info else 1
            EX_FAC_MIN_160 = info.get("ex_factor", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["thigh_date"]
                })
            # print "get n8 use:", datetime.datetime.now() - n5
            CUM_FAC_THIGH = info.get("cum_factor", 1) if info else 1
            EX_FAC_THIGH = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["tlow_date"]
                })
            # print "get n9 use:", datetime.datetime.now() - n5
            CUM_FAC_TLOW = info.get("cum_factor", 1) if info else 1
            EX_FAC_TLOW = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["first_trade_date"]
                })
            # print "get n10 use:", datetime.datetime.now() - n5
            CUM_FAC_TOPEN = info.get("cum_factor", 1) if info else 1
            EX_FAC_TOPEN = info.get("ex_factor_today", 1) if info else 1
            info = db["Z3_EX_FACTOR_ALL"].find_one(
                {
                    "equity.innerCode": row["innerCode"],
                    "end_date": row["last_trade_date"]
                })
            # print "get n11 use:", datetime.datetime.now() - n5
            CUM_FAC_TCLOSE = info.get("cum_factor", 1) if info else 1
            EX_FAC_TCLOSE = info.get("ex_factor_today", 1) if info else 1

            # open_px
            CUM_FACTOR_BEF = 1 if row["first_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TOPEN
            # CUM_FACTOR_BEF = 1 if row["first_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TOPEN / EX_FAC_TOPEN)
            # print "equity.symbol", row["symbol"]
            # print "first_trade_date", row["first_trade_date"]
            # print "end_date", row["end_date"]
            # print "CUM_FAC_MAX", CUM_FAC_MAX
            # print "CUM_FAC_TOPEN", CUM_FAC_TOPEN
            # print "EX_FAC_TOPEN", EX_FAC_TOPEN
            # print "CUM_FAC_MIN_160", CUM_FAC_MIN_160
            # print "CUM_FAC_MIN_60", CUM_FAC_MIN_60
            # print "CUM_FACTOR_BEF", CUM_FACTOR_BEF

            CUM_FACTOR_AFT_60 = 1 if row["first_trade_date"] == tmp[
                "WEEK_MIN_60"] else CUM_FAC_TOPEN / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["first_trade_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TOPEN / CUM_FAC_MIN_160
            # print type(row_1["open_px"])
            # print type(CUM_FACTOR_BEF)
            row_1["open_px"] = round(row_1["open_px"] / CUM_FACTOR_BEF, 2) if row_1["open_px"]  else None
            row_2["open_px"] = round(row_2["open_px"] * CUM_FACTOR_AFT_60, 2) if row_2["open_px"]  else None
            row_3["open_px"] = round(row_3["open_px"] * CUM_FACTOR_AFT_160, 2) if row_3["open_px"]  else None

            # high_px
            CUM_FACTOR_BEF = 1 if row["thigh_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_THIGH
            # CUM_FACTOR_BEF = 1 if row["thigh_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_THIGH / EX_FAC_THIGH)

            CUM_FACTOR_AFT_60 = 1 if row["thigh_date"] == tmp["WEEK_MIN_60"] else CUM_FAC_THIGH / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["thigh_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_THIGH / CUM_FAC_MIN_160

            row_1["high_px"] = round(row_1["high_px"] / CUM_FACTOR_BEF, 2) if row_1["high_px"]  else None
            row_2["high_px"] = round(row_2["high_px"] * CUM_FACTOR_AFT_60, 2) if row_2["high_px"]  else None
            row_3["high_px"] = round(row_3["high_px"] * CUM_FACTOR_AFT_160, 2) if row_3["high_px"]  else None

            # low_px
            CUM_FACTOR_BEF = 1 if row["tlow_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TLOW
            # CUM_FACTOR_BEF = 1 if row["tlow_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TLOW / EX_FAC_TLOW)

            CUM_FACTOR_AFT_60 = 1 if row["tlow_date"] == tmp["WEEK_MIN_60"] else CUM_FAC_TLOW / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["tlow_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TLOW / CUM_FAC_MIN_160

            row_1["low_px"] = round(row_1["low_px"] / CUM_FACTOR_BEF, 2) if row_1["low_px"]  else None
            row_2["low_px"] = round(row_2["low_px"] * CUM_FACTOR_AFT_60, 2) if row_2["low_px"]  else None
            row_3["low_px"] = round(row_3["low_px"] * CUM_FACTOR_AFT_160, 2) if row_3["low_px"]  else None

            # close_px
            CUM_FACTOR_BEF = 1 if row["last_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / CUM_FAC_TCLOSE
            # CUM_FACTOR_BEF = 1 if row["last_trade_date"] == tmp["DATE_MAX"] else CUM_FAC_MAX / (
            #     CUM_FAC_TCLOSE / EX_FAC_TCLOSE)

            CUM_FACTOR_AFT_60 = 1 if row["last_trade_date"] == tmp[
                "WEEK_MIN_60"] else CUM_FAC_TCLOSE / CUM_FAC_MIN_60

            CUM_FACTOR_AFT_160 = 1 if row["last_trade_date"] == tmp[
                "WEEK_MIN_160"] else CUM_FAC_TCLOSE / CUM_FAC_MIN_160

            row_1["close_px"] = round(row_1["close_px"] / CUM_FACTOR_BEF, 2) if row_1["close_px"]  else None
            row_2["close_px"] = round(row_2["close_px"] * CUM_FACTOR_AFT_60, 2) if row_2["close_px"]  else None
            row_3["close_px"] = round(row_3["close_px"] * CUM_FACTOR_AFT_160, 2) if row_3["close_px"]  else None

            # prev_close_px
            # print "get n12 use:", datetime.datetime.now() - n5
            for index, rr in enumerate(rows):
                last_info = self.get_w_prev_close_px(rr, db, mongo_table)
                rr["prev_close_px"] = last_info.get("close_px", None)
                rr["chg"] = rr["close_px"] - rr["prev_close_px"] if rr["prev_close_px"] else None
                # print "get n13 use:", datetime.datetime.now() - n5
                # 更新ma,sum
                data120 = self.get_week_120(db, rr, mongo_table)
                # print "get n14 use:", datetime.datetime.now() - n5
                self.update_ma(rr, data120)
                self.update_sum(rr, data120)

            result_1.append(row_1)
            result_2.append(row_2)
            result_3.append(row_3)
            # print "get uuuu use:", datetime.datetime.now() - n5
        result.extend(result_1)
        result.extend(result_2)
        result.extend(result_3)
        # print "get UUUUU use:", datetime.datetime.now() - n5
        # print result
        return result

    def get_w_prev_close_px(self, row, db, mongo_table):
        last_info = db[mongo_table].find_one({
            "equity.innerCode": row["innerCode"],
            "ex_status": row["ex_status"],
            "end_date": {"$lt": row["first_trade_date"]}
        }, {"close_px": 1}, sort=[("end_date", pymongo.DESCENDING)]
        )
        return last_info if last_info else {}

if __name__ == "__main__":
    pass
