# -*- coding: utf-8 -*-
import pymongo
import datetime
import copy
from utils.mysqlutil import Mysql
from utils import tools
from config import config
from bson.objectid import ObjectId
import pathos.multiprocessing as mp
import numpy as np
import random
import pandas as pd


class CopyHistory():
    def __init__(self, conn, database, table, args, curr_time, logger):
        """
        实例化方法
        :param conn: mysql链接
        :param args:  参数
        """
        self.conn = conn
        self.tdatabase = database  # 目的库
        self.ttable = table  # 目的表
        # self.seconds = args["seconds"]
        self.starttime = args["starttime"]
        self.endtime = args["endtime"]
        self.curr_time = curr_time
        # stockcode = args["stockcode"]
        # 获取目的表任务信息
        self.logger = None
        # 获取股票信息
        # self.stock_info = self._get_stock_info(stockcode) if stockcode else {}

    def __get_true_inner_code(self,symbol):
        try:
            sql1 = "SELECT INNER_CODE FROM STK_CODE WHERE isvalid=1 and STOCKCODE ='{}'".\
                   format(symbol)
            # print(sql1)
            results1 = self.conn.fetchall(sql1)
            # print(results1)
            return results1[0]['INNER_CODE']
        except Exception as e:
            # print(e)
            return None


    def insertNosqlpart(self):
        info_list = self.getStocklist()
        pool = mp.ProcessingPool(40)
        pool.map(self.calNosqlpart,info_list)
        # map(self.calNosqlpart,info_list)

    def calNosqlpart(self,stockinfo):
        try:
            # print('start')
            # cal one stock no sql data on one day
            conn  = tools.mongo_cursor()
            db = conn["z3dbus"]
            # print('startconn')
            raw = db.Z3_EQUITY_HISTORY.find_one({'trade_date':stockinfo[0],'innerCode':stockinfo[1]})

          # business no sql caculate
            tcap  = round(np.dot(raw['perf_idx']['close_px'],raw['totl_num']),4)
            mktcap = round(np.dot(raw['perf_idx']['close_px'],raw['mkt_num']),4)
            mktcap_a = round(np.dot(raw['perf_idx']['close_px'],raw['a_mkt_num']),4)

            # pe_lyr = None if raw['mkt2_idx']['mic_lyr'] < 0 else round(tcap/raw['mkt2_idx']['mic_lyr'],4)
            mic_lyr = raw.get('mkt2_idx',{}).get('mic_lyr',None)

            pe_lyr = None if not mic_lyr  else round(tcap/raw['mkt2_idx']['mic_lyr'],4)

            pe_ttm = None if raw['mkt2_idx']['mic_ttm'] < 0 else round(tcap/raw['mkt2_idx']['mic_ttm'],4)

            peg = round((tcap/raw['mkt2_idx']['mic_ttm'])/raw['mkt2_idx']['es_3year'],4) if raw['mkt2_idx']['es_3year'] else 0

            ps = round(np.dot(raw['perf_idx']['close_px'],raw['totl_num'])/raw['fin_idx']['sale'],4) if raw['fin_idx']['sale'] != 0 else None

            pb = round(np.dot(raw['perf_idx']['close_px'],raw['totl_num'])/raw['mkt2_idx']['net_asset'],4)

            cash_ttm = raw.get('mkt2_idx',{}).get('cash_ttm',None)

            pc = round(np.dot(raw['perf_idx']['close_px'],raw['totl_num'])/raw['mkt2_idx']['cash_ttm'],4) if cash_ttm else None
            expect_price_chng_pct = round( ( raw['fcst_idx']['expect_price_med'] -raw['perf_idx']['close_px'])/raw['perf_idx']['close_px'],4) * 100 if raw['fcst_idx']['expect_price_med'] else 0

            ps_cash_bt_1year = raw.get('mkt2_idx',{}).get('ps_cash_bt_1year',None)

            div_rate = round((ps_cash_bt_1year*100)/raw['perf_idx']['close_px'],4) if ps_cash_bt_1year else 0

            fcps = raw.get('mkt2_idx',{}).get('fcps')

            price_cash = round(raw['perf_idx']['close_px']/fcps,4)

            sig_17 = True if raw['perf_idx']['chng_pct'] else False
            sig_28 =  True if pe_ttm < 20  and pe_ttm != None else False
            sig_29 = True if pe_ttm > 50 else False
            sig_30 = True if pb < 1 else False
            sig_31 = True if pb > 5 else False
            sig_33 = True if div_rate > 2 else False


            nosql_data = {
                # mkt_idx
                  'mkt_idx.tcap':tcap,
                'mkt_idx.mktcap':mktcap,
                  'mkt_idx.mktcap_a':mktcap_a,
                  'mkt_idx.pe_lyr':pe_lyr,
                  'mkt_idx.pe_ttm':pe_ttm,
                  'mkt_idx.ps':ps,
                'mkt_idx.peg':peg,
                  'mkt_idx.pb':pb,
                  'mkt_idx.pc':pc,
                'mkt_idx.div_rate':div_rate,
                'mkt_idx.price_cash':price_cash,

                'signal_normal.signal_normal_17':sig_17,
                'signal_normal.signal_normal_28':sig_28,
                'signal_normal.signal_normal_29':sig_29,
                'signal_normal.signal_normal_30':sig_30,
                'signal_normal.signal_normal_31':sig_31,
                'signal_normal.signal_normal_33':sig_33,
                  # fcst_idx
                  'fcst_idx.expect_price_chng_pct':expect_price_chng_pct

            }
            r = db.Z3_EQUITY_HISTORY.update_one(
                {'_id':ObjectId(raw['_id'])},
                {
                    '$set':nosql_data
                }
            )
            print(raw['_id'],raw['trade_date'])

        except Exception as e:
            print(e)

    def getStocklist(self):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        start_time = self.starttime
        end_time = self.endtime
        # start_time = datetime.datetime(2014,01,01)
        time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('trade_date')
        stock_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('innerCode')
        # print(stock_list[:10])
        # print(time_list[:10])
        # print(len(time_list))
        info_list = [(time,stock) for time in time_list for stock in stock_list]
        print(info_list[:10])
        return info_list

    def getSymbollist(self):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        start_time = self.starttime
        end_time = self.endtime
        # start_time = datetime.datetime(2014,01,01)
        time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('trade_date')
        stock_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}}).distinct('symbol')
        info_list = [(time,stock) for time in time_list for stock in stock_list]
        return info_list


    def makeDatewhere(self):
        return  "TRADEDATE BETWEEN '{}' AND '{}'".format(
            self.starttime.strftime('%Y-%m-%d'),
            self.endtime.strftime('%Y-%m-%d')
        )

    def insertRelavolume(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        # print(self.starttime,self.endtime)
        wheresql = self.makeDatewhere()
        sql = "SELECT TRADEDATE,TVOLUME,STOCKCODE FROM ANA_STK_MKT_DAY "+"WHERE " + wheresql
        results = self.conn.fetchall(sql)
        print(results[:10])
        for raw in results:
            try:
                primary = {
                        "symbol":raw['STOCKCODE'],
                        "trade_date":raw['TRADEDATE']
                }

                origin = db.Z3_EQUITY_HISTORY.find_one(
                    primary
                )
                rela_volume = round(float(raw['TVOLUME'])/origin['perf_idx']['avg_vol_3month'],4)
                db.Z3_EQUITY_HISTORY.update_one(
                        primary,
                    {
                        '$set':{
                            'mkt_idx.rela_volume':rela_volume,
                            'signal_normal.signal_normal_7': True if rela_volume > 3 else False
                        }
                    }
                )
                print(origin['_id'],origin['trade_date'])
            except Exception as e:
                print(e)

    def insertVolumeprice(self):

        sql = "SELECT TRADEDATE,STOCKCODE,TVOLUME,TCLOSE FROM STK_MKT INNER JOIN STK_CODE ON STK_MKT.INNER_CODE = STK_CODE.INNER_CODE AND " + self.makeDatewhere() + " AND STK_MKT.isvalid=1"
        print(sql)
        results = self.conn.fetchall(sql)
        # pool = mp.ProcessingPool(100)
        # pool.map(self.insertOnevolumeprice,results)
        map(self.insertOnevolumeprice,results)
        # self.insertOnevolumeprice(results[0])

    def insertOnevolumeprice(self,raw):
        try:
            conn  = tools.mongo_cursor()
            db = conn["z3dbus"]

            primary = {
                    "symbol":raw['STOCKCODE'],
                    "trade_date":raw['TRADEDATE']
            }

            origin = db.Z3_EQUITY_HISTORY.find_one(
                primary
            )
            db.Z3_EQUITY_HISTORY.update_one(
                    primary,
                {
                    '$set':{
                        'mkt2_idx.volume':round(float(raw['TVOLUME']),4),
                        'mkt2_idx.price':round(float(raw['TCLOSE']),4)
                    }
                }
            )
            print(origin['_id'],origin['trade_date'])
        except Exception as e:
            print(e)

    def calRsi14(self):
        # pool = mp.ProcessingPool(20)
        # pool.map(self.insertOnersi14,info_list)
        # self.insertOnersi14(info_list[0])
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]
        time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':self.starttime,'$lte':self.endtime}}).distinct('trade_date')
        info_list = self.getStocklist()
        # print(info_list[:10])
        # info_list = map(lambda x:(x,'000009.SZ'),time_list)
        map(self.insertOnersi14,info_list)

    def insertOnersi14(self,raw):
        try:
            conn  = tools.mongo_cursor()
            db = conn["z3dbus"]

            primary = {
                    "innerCode":raw[1],
                    "trade_date":raw[0]
            }

            origin = db.Z3_EQUITY_HISTORY.find_one(
                primary
            )
            rsi_14 = self.cal_rsi_14(origin)
            db.Z3_EQUITY_HISTORY.update_one(
                    primary,
                {
                    '$set':{
                        'mkt_idx.rsi_14':rsi_14,
                        'signal_normal.signal_normal_9':True if rsi_14 < 20 else False,
                        'signal_normal.signal_normal_8':True if rsi_14 > 80 else False
                    }
                }
            )
            print(rsi_14,origin['symbol'],origin['trade_date'],origin['_id'])
        except Exception as e:
            print(e)


    def cal_rsi_14(self,raw):
        try:
            inner_code = self.__get_true_inner_code(raw)
            sql = "SELECT CHNG FROM STK_MKT WHERE INNER_CODE = '{}' AND TRADEDATE <= '{}' ORDER BY TRADEDATE DESC LIMIT 14".\
                  format(inner_code,raw['trade_date'].strftime("%Y-%m-%d"))
            results = map(lambda x:x['CHNG'],self.conn.fetchall(sql))
            if len(results) == 14:
                x = sum(filter(lambda x:x>=0,results))
                y = sum(filter(lambda x:x<0,results))
                return round(x*100/(x+abs(y)),4)
            else:
                return None

        except Exception as e:
            # print(e)
            return None

    def __get_true_inner_code(self,raw):
        try:
            symbol = raw['symbol']
            sql1 = "SELECT INNER_CODE FROM STK_CODE WHERE isvalid=1 and STOCKCODE ='{}'".\
                   format(symbol)
            # print(sql1)
            results1 = self.conn.fetchall(sql1)
            # print(results1)
            return results1[0]['INNER_CODE']
        except Exception as e:
            # print(e)
            return None

    def cal_tendency(self):

        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        wheresql = self.makeDatewhere()
        sql = "SELECT FAC_THIGH,FAC_TLOW,FAC_TOPEN,STOCKCODE,TRADEDATE FROM ANA_STK_MKT_DAY WHERE " + wheresql +" ORDER BY TRADEDATE DESC"
        results = self.conn.fetchall(sql)
        print(len(results))
        print(results[:10])
        stock_codes = set(map(lambda x:x['STOCKCODE'],results))
        for stock in stock_codes:
            results1 = filter(lambda x:x['STOCKCODE']==stock,results)
            # results1 = filter(lambda x:x['STOCKCODE']=='600108',results)
            print(len(results1))
        # map(self.insertOneresult,results)
            for i in range(len(results1)-1):
             try:
                raw = results1[i]
                y_row = results1[i+1]
                primary = {
                        "symbol":raw['STOCKCODE'],
                        "trade_date":raw['TRADEDATE']
                }

                origin = db.Z3_EQUITY_HISTORY.find_one(
                    primary
                )
                topen = raw['FAC_TOPEN']
                thigh = raw['FAC_THIGH']
                tlow = raw['FAC_TLOW']
                y_tlow = y_row['FAC_TLOW']
                y_thigh = y_row['FAC_THIGH']
                sig22 = True if topen > y_thigh else False
                sig23 = True if topen < y_tlow else False
                sig24 = True if tlow > y_thigh else False
                sig25 = True if thigh < y_tlow else False

                db.Z3_EQUITY_HISTORY.update_one(
                        primary,
                    {
                        '$set':{
                            'signal_normal.signal_normal_22':sig22,
                            'signal_normal.signal_normal_23':sig23,
                            'mkt_idx.is_gap_down':sig23,
                            'mkt_idx.is_gap_up':sig22,
                            'signal_normal.signal_normal_24':sig24,
                            'signal_normal.signal_normal_25':sig25
                        }
                    }
                )
                print(origin['_id'],origin['trade_date'],raw['STOCKCODE'])

             except Exception as e:
                 print(e)

    def cal_tencyrank(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        wheresql = self.makeDatewhere()
        # sql1 = "SELECT DISTINCT TRADEDATE FROM ANA_STK_MKT_DAY WHERE " + wheresql
        date_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':self.starttime,'$lte':self.endtime}}).distinct('trade_date')
        # date_list= self.conn.fetchall(sql1)
        for date in date_list:
            toltl_num = int(len(db.Z3_EQUITY_HISTORY.find({ "trade_date":date }).distinct('symbol'))/10)
            sql3 = "SELECT STOCKCODE,CHNG_PCT FROM ANA_STK_MKT_DAY WHERE TRADEDATE = '{}' AND TRADE_STATUS = 1 and (STOCKCODE not like '20%' and STOCKCODE not like '90%') ORDER BY CHNG_PCT DESC LIMIT {}".format(
                date.strftime('%Y-%m-%d'),toltl_num
                # date['TRADEDATE'].strftime('%Y-%m-%d'),toltl_num
                # date['TRADEDATE'].strftime('%Y-%m-%d'),10
            )
            sql4 = "SELECT STOCKCODE,CHNG_PCT FROM ANA_STK_MKT_DAY WHERE TRADEDATE = '{}' AND TRADE_STATUS = 1 AND (STOCKCODE not like '20%' and STOCKCODE not like '90%') ORDER BY CHNG_PCT LIMIT {}".format(
                date.strftime('%Y-%m-%d'),toltl_num
                # date['TRADEDATE'].strftime('%Y-%m-%d'),toltl_num
                # date['TRADEDATE'].strftime('%Y-%m-%d'),10
            )

            head_results = self.conn.fetchall(sql3)
            tail_results = self.conn.fetchall(sql4)
            true_head = [stock['STOCKCODE'] for stock in filter(lambda x:x['CHNG_PCT'] > 0,head_results)]
            true_tail = [stock['STOCKCODE'] for stock in filter(lambda x:x['CHNG_PCT'] < 0,tail_results)]

            r2 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'trade_date':date
                },{
                    '$set':{
                        'signal_normal.signal_normal_2':False,
                        'signal_normal.signal_normal_1':False
                    }
                }
            )

            r1 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'symbol':{
                        '$in':true_head
                    },
                    'trade_date':date
                },{
                    '$set':{
                        'signal_normal.signal_normal_1':True
                    }
                }
            )
            r3 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'symbol':{
                        '$in':true_tail
                    },
                    'trade_date':date
                },{
                    '$set':{
                        'signal_normal.signal_normal_2':True
                    }
                }
            )

            print(r1.modified_count)
            print(r1.matched_count)
            print(r3.modified_count)
            print(r3.matched_count)

            print(date)


    def cal_limit(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        wheresql = self.makeDatewhere()
        sql1 = "SELECT DISTINCT TRADEDATE FROM STK_MKT WHERE " + wheresql
        date_list= self.conn.fetchall(sql1)
        for date in date_list:
            sql2 = "SELECT STOCKCODE FROM STK_MKT INNER JOIN STK_CODE ON STK_MKT.INNER_CODE = STK_CODE.INNER_CODE WHERE TRADEDATE = '{}' AND CHNG_PCT = 10".format(
                date['TRADEDATE'].strftime('%Y-%m-%d')
            )
            sql3 = "SELECT STOCKCODE FROM STK_MKT INNER JOIN STK_CODE ON STK_MKT.INNER_CODE = STK_CODE.INNER_CODE WHERE TRADEDATE = '{}' AND CHNG_PCT = -10".format(
                                date['TRADEDATE'].strftime('%Y-%m-%d')
                            )

            up_results = self.conn.fetchall(sql2)
            down_results = self.conn.fetchall(sql3)

            r1 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'trade_date':date['TRADEDATE']
                },{
                    '$set':{
                        'mkt_idx.is_limit_up':False,
                        'mkt_idx.is_limit_down':False
                    }
                }
                )

            r2 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'trade_date':date['TRADEDATE'],
                    'symbol':{
                        '$in':[stock['STOCKCODE'] for stock in up_results]
                    }
                },{
                    '$set':{
                        'mkt_idx.is_limit_up':True,
                    }
                }
                )

            r3 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'trade_date':date['TRADEDATE'],
                    'symbol':{
                        '$in':[stock['STOCKCODE'] for stock in down_results]
                    }
                },{
                    '$set':{
                        'mkt_idx.is_limit_down':True,
                    }
                }
                )
            print(r1.modified_count)
            print(r1.matched_count)
            print(r2.modified_count)
            print(r2.matched_count)
            print(r3.modified_count)
            print(r3.matched_count)

            print(date['TRADEDATE'])


    def cal_divrate(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        sql = "SELECT TRD_DATE,DIV_RATE,STOCKCODE FROM ANA_STK_VAL_IDX INNER JOIN STK_CODE ON ANA_STK_VAL_IDX.INNER_CODE = STK_CODE.INNER_CODE WHERE TRD_DATE BETWEEN '{}' AND '{}'".format(
            self.starttime.strftime('%Y-%m-%d'),
            self.endtime.strftime('%Y-%m-%d')
        )
        results = self.conn.fetchall(sql)
        # print(sql)
        # print(len(results))
        for raw in results:
            try:
                primary = {
                        "symbol":raw['STOCKCODE'],
                        "trade_date":raw['TRD_DATE']
                }

                db.Z3_EQUITY_HISTORY.update_one(
                        primary,
                    {
                        '$set':{
                            'mkt_idx.div_rate':float(raw['DIV_RATE']) if raw['DIV_RATE'] else None
                        }
                    }
                )

            except Exception as e:
                print(e)

    def cal_chng_pct_from_open(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        sql = "SELECT TOPEN,STOCKCODE,TRADEDATE FROM ANA_STK_MKT_DAY WHERE " + self.makeDatewhere()
        results = self.conn.fetchall(sql)
        for raw in results:
            try:
                primary = {
                        "symbol":raw['STOCKCODE'],
                        "trade_date":raw['TRADEDATE']
                }

                origin = db.Z3_EQUITY_HISTORY.find_one(
                    primary
                )

                db.Z3_EQUITY_HISTORY.update_one(
                        primary,
                    {
                        '$set':{
                            'mkt_idx.chng_pct_from_open':round(( origin['perf_idx']['close_px']-float(raw['TOPEN']) )/float(raw['TOPEN']),4) * 100
                        }
                    }
                )
                print(origin['_id'],origin['trade_date'])
            except Exception as e:
                print(e)

    def tmpUpdate(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]
        info_list = self.getStocklist()
        for stockinfo in info_list:
            try:
                raw = db.Z3_EQUITY_HISTORY.find_one({'trade_date':stockinfo[0],'innerCode':stockinfo[1]})
                sig_17 = True if raw['perf_idx']['chng_pct'] > 5 else False
                nosql_data = {
                    'signal_normal.signal_normal_17':sig_17
                }
                r = db.Z3_EQUITY_HISTORY.update_one(
                    {'trade_date':raw['trade_date'],
                    'innerCode':raw['innerCode']
                    },
                    {
                        '$set':nosql_data
                    }
                )
                print(raw['_id'],raw['trade_date'])
            except Exception as e:
                print(e)

    def cal_chng_pct_week(self):
        sql = "SELECT CHNG_PCT_WEEK,ENDDATE,STOCKCODE FROM ANA_STK_EXPR_IDX INNER JOIN STK_CODE ON ANA_STK_EXPR_IDX.INNER_CODE=STK_CODE.INNER_CODE WHERE ENDDATE BETWEEN '{}' and '{}'".format(
            self.starttime.strftime('%Y-%m-%d'),
            self.endtime.strftime('%Y-%m-%d')
        )
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        results = self.conn.fetchall(sql)
        print(len(results))
        for raw in results:
            try:
                primary = {
                        "symbol":raw['STOCKCODE'],
                        "trade_date":raw['ENDDATE']
                }

                origin = db.Z3_EQUITY_HISTORY.find_one(
                    primary
                )
                chng_pct_week = float(raw['CHNG_PCT_WEEK'])
                db.Z3_EQUITY_HISTORY.update_one(
                        primary,
                    {
                        '$set':{
                            'mkt_idx.chng_pct_week':chng_pct_week
                        }
                    }
                )
                print(origin['_id'],origin['trade_date'])
            except Exception as e:
                print(e)

    def cal_activate(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        # time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':self.starttime,'$lte':self.endtime}}).distinct('trade_date')
        time_list = [datetime.datetime(2015,1,19)]

        stock_list = self.getSymbollist()

        # for stock_info in stock_list:
        for time in time_list:
            sql = "SELECT TURNOVER_DAY,STOCKCODE FROM ANA_STK_EXPR_IDX INNER JOIN STK_CODE ON ANA_STK_EXPR_IDX.INNER_CODE=STK_CODE.INNER_CODE WHERE ENDDATE <= '{}' AND ANA_STK_EXPR_IDX.ISVALID=1 ORDER BY ENDDATE DESC LIMIT 2 ".format(
                # stock_info[0].strftime('%Y-%m-%d'),
                time.strftime('%Y-%m-%d'),
                # ( time+ datetime.timedelta(days=1)).strftime('%Y-%m-%d')
                # origin.get('symbol','error')
            )
            results = self.conn.fetchall(sql)
            code_lists = set(map(lambda x:x[1],stock_list))
            raw = {}
            for i in code_lists:
                raw[i]=[]

            for i in results:
                # if i['STOCKCODE'] in code_lists:
                raw[ i['STOCKCODE'] ].append(i['TURNOVER_DAY'])
                    # if i['STOCKCODE'] == '000498':
                    #     print('ss')
                    #     import ipdb; ipdb.set_trace()
                print(i['STOCKCODE'])

            turn_over = sorted([(k,sum(filter(lambda x:x!=None,v))) for k,v in raw.iteritems()],key=lambda x:-x[1])
            idx = int(round(0.05*len(turn_over)))

            turn_over_list = turn_over[:idx]
            activate_list = [i[0] for i in turn_over_list]

            import ipdb; ipdb.set_trace()
            r2 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'trade_date':time
                },{
                    '$set':{
                        'signal_normal.signal_normal_6':False,
                    }
                }
                )
            print(r2.modified_count)
            print(r2.matched_count)

            r1 = db.Z3_EQUITY_HISTORY.update_many(
                {
                    'symbol':{
                        '$in':activate_list
                    },
                    'trade_date':time
                },{
                    '$set':{
                        'signal_normal.signal_normal_6':True
                    }
                }
            )
            print(r1.modified_count)
            print(r1.matched_count)



    def cal_max_cross(self):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        gold_list = dead_list = []
        # time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':self.starttime,'$lte':self.endtime}}).distinct('trade_date')
        info_list = self.getStocklist()
        for info in info_list:
            try:
                all_ma = db.Z3_STK_MKT_DAY_INTER.find(
                    {
                        'equity.innerCode':info[1],
                        'end_date':{
                            '$lte':info[0],
                        }
                    },{
                        'MA20':1,
                        'MA60':1,
                        'equity':1,
                        'end_date':1

                    },
                    no_cursor_timeout=True
                ).sort([('end_date',pymongo.DESCENDING)]).limit(2)
                y_ma_20 = all_ma[1]['MA20']
                ma_20 = all_ma[0]['MA20']
                y_ma_60 = all_ma[1]['MA60']
                ma_60 = all_ma[0]['MA60']

                gold = dead = False

                if y_ma_20 < y_ma_60 and ma_20 > ma_60:
                    gold = True
                if y_ma_20 > y_ma_60 and ma_20 < ma_60:
                    dead = True

            except Exception as e:
                print(e)


            r = db.Z3_EQUITY_HISTORY.update_one(
                  {
                      'trade_date':info[0],
                      'innerCode':info[1]
                  },{
                      '$set':{
                          'signal_normal.signal_normal_20':gold,
                          'signal_normal.signal_normal_21':dead,
                      }
                  }
              )
            print(info[0],info[1],gold,dead)


    def cal_high_low(self):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        info_list = self.getStocklist()
        # info_list = [('000001',datetime.datetime(2015,1,5))]
        for stockinfo in info_list:
            try:
                raw = db.Z3_EQUITY_HISTORY.find_one({'trade_date':stockinfo[0],'innerCode':stockinfo[1]})
                sql = "SELECT FAC_TCLOSE FROM ANA_STK_MKT_DAY WHERE TRADEDATE <= '{}' AND STOCKCODE = '{}' ORDER BY TRADEDATE DESC LIMIT 60".format(
                    raw['trade_date'].strftime("%Y-%m-%d"),
                    raw['symbol']
                )
                results = self.conn.fetchall(sql)

                min_v = min(map(lambda x:x['FAC_TCLOSE'],results))
                max_v = max(map(lambda x:x['FAC_TCLOSE'],results))
                sig_3 = sig_4 = False
                if min_v > results[0]['FAC_TCLOSE']:
                    sig_4 = True
                if max_v < results[0]['FAC_TCLOSE']:
                    sig_3 = True
                r = db.Z3_EQUITY_HISTORY.update_one(
                    {'_id':raw['_id']},
                    {
                        '$set':{
                            'signal_normal.signal_normal_4':sig_4,
                            'signal_normal.signal_normal_3':sig_3

                        }
                    }
                )
                print(raw['symbol'],raw['trade_date'])
            except Exception as e:
                print(e)

    def cal_gap(self):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        start_time = self.starttime
        end_time = self.endtime
        stock_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':start_time,'$lte':end_time}})
        for stock in stock_list:
            try:
                gap_info = db.Z3_STK_MKT_DAY_INTER.find({
                'equity.innerCode':stock['innerCode'],
                    'end_date':{
                    '$lte':stock['trade_date'],
                }
            }).sort([('end_date',pymongo.DESCENDING)]).limit(2)
                tlow = gap_info[0]['low_px']
                thigh = gap_info[0]['high_px']
                y_tlow = gap_info[1]['low_px']
                y_thigh = gap_info[1]['high_px']
                if tlow > y_thigh:
                    gap = tlow - y_thigh
                elif thigh < y_tlow:
                    gap = thigh - y_tlow
                else:
                    gap = None
            except Exception as e:
                print(e)
                gap = None
            r = db.Z3_EQUITY_HISTORY.update_one(
                {
                    '_id':stock['_id']
                },
                {
                    '$set':{
                        'mkt_idx.gap':gap,
                        # 'mkt_idx.is_gap_down': True if gap < 0 else False,
                        # 'mkt_idx.is_gap_up':True if gap > 0 else False
                    }
                }
                )
            print(stock['_id'],stock['trade_date'])

    # def cal_price_cash(self,raw):
    #     mysql_conn = Mysql(config["mysql_test"])
    #     sql = "SELECT BAL_J,STOCKCODE,ENDDATE FROM ANA_STK_FIN_IDX INNER JOIN STK_CODE ON  ANA_STK_FIN_IDX.COMCODE = STK_CODE.COMCODE WHERE ENDDATE <= '{}' AND STOCKCODE = '{}' ORDER BY ENDDATE DESC LIMIT 1".format(
    #         raw.get('trade_date',datetime.datetime.now()),
    #         raw.get('symbol','000001')
    #     )
    #     tclose = raw.get('perf_idx',{}).get('close_px',10) if raw else None
    #     results = mysql_conn.fetchall(sql)
    #     bal_j = None

    #     if results:
    #         bal_j = results[0].get('BAL_J',None)
    #     ans = round(tclose/float(bal_j),4) if bal_j and tclose else 0
    #     return ans


    def del_the_b(self):
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        the_b_list =['^2','^9','^8','^4']
        for i in the_b_list:
            db.Z3_EQUITY_HISTORY.remove({
                'symbol':{
                    '$regex':i
                }
                }
            )


    def cal_activate1(self):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]

        # mysql_conn = Mysql(config["mysql_test"])
        time_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':self.starttime,'$lte':self.endtime}}).distinct('trade_date')
        # time_list = [datetime.datetime(2015,1,19)]
        # stock_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':self.starttime,'$lte':self.endtime}}).distinct('symbol')

        pool = mp.ProcessingPool(200)
        # pool.map(self.cal_one_day_turnover,time_list)
        map(self.cal_one_day_turnover,time_list)

        # for time in time_list:
        #     self.raw = {}
        #     # pool = mp.ProcessingPool(200)
        #     l_list = [(time,stock) for stock in stock_list]
        #     map(self.cal_one_day_turnover,l_list)
        #     pool.map(self.cal_one_day_turnover,l_list)

        #     # for stock in stock_list:
        #         # sql = "SELECT SUM(TURNOVER_DAY) FROM ANA_STK_EXPR_IDX INNER JOIN STK_CODE ON ANA_STK_EXPR_IDX.INNER_CODE=STK_CODE.INNER_CODE WHERE ENDDATE <= '{}' AND ANA_STK_EXPR_IDX.ISVALID=1 AND STOCKCODE = '{}' ORDER BY ENDDATE DESC LIMIT 3 ".format(
        #         #     time.strftime('%Y-%m-%d'),
        #         #     stock
        #         # )
        #         # results = self.conn.fetchall(sql)
        #         # raw[stock] = stock,results[0].get('SUM(TURNOVER_DAY)')
        #         # # import ipdb; ipdb.set_trace()
        #         # print(raw)

        #     turn_over = sorted([(k,v) for k,v in self.raw.iteritems()],key=lambda x:-x[1])
        #     idx = int(round(0.05*len(turn_over)))
        #     turn_over_list = turn_over[:idx]
        #     activate_list = [i[0] for i in turn_over_list]

        #     import ipdb; ipdb.set_trace()
        #     r2 = db.Z3_EQUITY_HISTORY.update_many(
        #         {
        #             'trade_date':time
        #         },{
        #             '$set':{
        #                 'signal_normal.signal_normal_6':False,
        #             }
        #         }
        #         )
        #     print(r2.modified_count)
        #     print(r2.matched_count)

        #     r1 = db.Z3_EQUITY_HISTORY.update_many(
        #         {
        #             'symbol':{
        #                 '$in':activate_list
        #             },
        #             'trade_date':time
        #         },{
        #             '$set':{
        #                 'signal_normal.signal_normal_6':True
        #             }
        #         }
        #     )
        #     print(r1.modified_count)
        #     print(r1.matched_count)

    def cal_one_day_turnover(self,time):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]
        raw = {}
        stock_list = db.Z3_EQUITY_HISTORY.find({'trade_date':{'$gte':self.starttime,'$lte':self.endtime}}).distinct('symbol')
        # stock_list = ['000001']
        mysql_conn = Mysql(config["mysql_test"])

        for stock in stock_list:
            innercode = self.__get_true_inner_code(stock)
            sql = """"
           SELECT COUNT(a.`ENDDATE`) AS c,sum(a.TURNOVER_DAY) AS pct  FROM\
                    (\
                        SELECT\
                        TURNOVER_DAY,ENDDATE\
                        FROM\
                    ANA_STK_EXPR_IDX\
                    WHERE  INNER_CODE = {inner_code} and ISVALID=1  and enddate <= '{tradedate}'  and TURNOVER_DAY IS NOT NULL\
                    ORDER BY ENDDATE DESC\
                    LIMIT 0,3\
                    ) AS a
            """.format(
                tradedate=time.strftime('%Y-%m-%d'),
                inner_code=innercode
            )
            results = mysql_conn.fetchall(sql)
            raw[stock] = results[0].get('pct')
            # print(raw)


        turn_over = sorted([(k,v) for k,v in raw.iteritems()],key=lambda x:-x[1])
        idx = int(round(0.05*len(turn_over)))
        turn_over_list = turn_over[:idx]
        activate_list = [i[0] for i in turn_over_list]

        r2 = db.Z3_EQUITY_HISTORY.update_many(
            {
                'trade_date':time
            },{
                '$set':{
                    'signal_normal.signal_normal_6':False,
                }
            }
            )
        print(r2.modified_count)
        print(r2.matched_count)

        r1 = db.Z3_EQUITY_HISTORY.update_many(
            {
                'symbol':{
                    '$in':activate_list
                },
                'trade_date':time
            },{
                '$set':{
                    'signal_normal.signal_normal_6':True
                }
            }
        )
        print(r1.modified_count)
        print(r1.matched_count)

    def unset_field(field):
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]
        db.Z3_EQUITY_HISTORY.update_many(
            {},
            {
                '$unset':{
                    field:1
                }
            }
        )


    def sig_6(self):
        # use pandas solve excel problem
        conn  = tools.mongo_cursor()
        db = conn["z3dbus"]
        file_list = ['data/2015.csv','data/2014.csv','data/20161.csv','data/20162.csv']
        for name in file_list:
            raw = pd.read_csv(name)
            time_list = map(lambda x:datetime.datetime.strptime(x, '%Y/%m/%d'),raw['enddate'].unique())
            for time in time_list:
                stock_list = raw[raw['enddate']==time.strftime('%-m/%-d/%Y')]
                stock_list = stock_list.sort_values(['TURNOVER_DAY_SUM'], ascending=[0])
                idx = int(round(len(stock_list)/20))
                a = stock_list[:idx]['STOCKCODE'].values.tolist()
                activate_list = map(lambda x:'{foo:06d}'.format(foo=x),stock_list[:idx]['STOCKCODE'].values.tolist())
                r2 = db.Z3_EQUITY_HISTORY.update_many(
                    {
                        'trade_date':time
                    },{
                        '$set':{
                            'signal_normal.signal_normal_6':False,
                        }
                    }
                    )
                print(r2.modified_count)
                print(r2.matched_count)

                r1 = db.Z3_EQUITY_HISTORY.update_many(
                    {
                        'symbol':{
                            '$in':activate_list
                        },
                        'trade_date':time
                    },{
                        '$set':{
                            'signal_normal.signal_normal_6':True
                        }
                    }
                )
                print(r1.modified_count)
                print(r1.matched_count)
                print(time)




