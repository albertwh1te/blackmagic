# coding:utf-8
import os
task_order = {
    "news_task":["Z3_NEWS","Z3_EQUITY_XREF_NEWS","Z3_TOPIC_XREF_NEWS","Z3_TOPIC_INFO"],
    "base_task":["Z3_EQUITY_PROFILE","Z3_RESEARCH_REPORT","Z3_INDEX_SAMPLE","Z3_MNG_HOLD_STK_INFO","Z3_EXCHANGE_CALENDAR"],
    "equity_task":["Z3_EQUITY2","Z3_EQUITY"],
    "factor_task_after":["Z3_STK_MKT_DAY_INTER","Z3_STK_MKT_WEEK_INTER","Z3_STK_MKT_MONTH_INTER","Z3_STK_MKT_DAY_INTER_NEW"],
    "factor_task_pre":["Z3_EX_FACTOR_ALL","Z3_STK_MKT_DAY_INTER_NEW"],
    "factor_task_7pre":["Z3_STK_MKT_DAY_INTER","Z3_EQUITY2","Z3_EQUITY"],
    "factor_task":["Z3_EX_FACTOR_ALL","Z3_STK_MKT_DAY_INTER","Z3_EQUITY2","Z3_EQUITY","Z3_STK_MKT_DAY_INTER_NEW"],
    "week_month_task":["Z3_STK_MKT_WEEK_INTER","Z3_STK_MKT_MONTH_INTER"],
    "topic_task":["Z3_TOPIC_INFO","Z3_TOPIC_XREF_EQUITY","Z3_TOPIC_REAL_WEEK","Z3_INDEX_HIS_QUOTE","Z3_TOPIC_HIS_QUOTE","Z3_SW_INDUSTRY","Z3_STK_MKT_DAY","Z3_STK_MKT_DAY02"],
    "once_a_day":["RES_DF_SCORES"]
        }
task_config = {
    "news_task": {
        # 新闻主表
        "Z3_NEWS": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_NEWS > /data/Logs/z3_transfer/z3_new.log 2>&1",
        # 个股新闻关系表
        "Z3_EQUITY_XREF_NEWS": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY_XREF_NEWS > /data/Logs/z3_transfer/z3_equity_xref_news.log 2>&1 &",
        # 主题新闻关系表
        "Z3_TOPIC_XREF_NEWS": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_TOPIC_XREF_NEWS '' 0 > /data/Logs/z3_transfer/z3_topic_xref_news.log 2>&1",
        # 主题基本信息表
        "Z3_TOPIC_INFO": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_TOPIC_INFO.EVENT_NUM '' 0 > /data/Logs/z3_transfer/topic_info_event_num.log 2>&1",
    },
    "base_task": {
        # 股票基础信息
        "Z3_EQUITY_PROFILE": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY_PROFILE > /data/Logs/z3_transfer/profile.log 2>&1 &",
        # 个股研报
        "Z3_RESEARCH_REPORT": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_RESEARCH_REPORT > /data/Logs/z3_transfer/z3_research_report.log 2>&1 &",
        # 指数样本表
        "Z3_INDEX_SAMPLE": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_INDEX_SAMPLE 0 > /data/Logs/z3_transfer/z3_index_sample.log 2>&1 &",
        # 董监高持股
        "Z3_MNG_HOLD_STK_INFO": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_MNG_HOLD_STK_INFO 0 > /data/Logs/z3_transfer/z3_mng_hold_stk_info.log 2>&1 &",
        # 交易所开市日历表
        "Z3_EXCHANGE_CALENDAR": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EXCHANGE_CALENDAR 0 > /data/Logs/z3_transfer/calendar.log 2>&1 &",

    },
    "equity_task": {

        # 大宽表 mkt2_idx
        "Z3_EQUITY2": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY2 0 > /data/Logs/z3_transfer/z3_equity2.log 2>&1 ",
        # 大宽表 信号
        "Z3_EQUITY": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY 0 > /data/Logs/z3_transfer/z3_equity.log 2>&1 & ",


    },

    "factor_task_after": {
        # 日行情
        "Z3_STK_MKT_DAY_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER 0 timing after > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing_after.log 2>&1",
        # 月行情
        "Z3_STK_MKT_WEEK_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_WEEK_INTER 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_week_inter_timing.log 2>&1",
        # 周行情
        "Z3_STK_MKT_MONTH_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_MONTH_INTER 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_month_inter_timing.log 2>&1",
        "Z3_STK_MKT_DAY_INTER_NEW": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER_NEW 0 timing after > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing_new_after.log 2>&1",
    },
    "week_month_task": {
         # 月行情
        "Z3_STK_MKT_WEEK_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_WEEK_INTER 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_week_inter_timing.log 2>&1",
        # 周行情
        "Z3_STK_MKT_MONTH_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_MONTH_INTER 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_month_inter_timing.log 2>&1",
    },

    "factor_task_7pre": {
        # 复权因子
        "Z3_EX_FACTOR_ALL": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EX_FACTOR_ALL 0 timing > /data/Logs/z3_transfer/z3_ex_factor_all_timing.log 2>&1",
        # 日行情
        "Z3_STK_MKT_DAY_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER 0 timing pre > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing_pre.log 2>&1",
        # 大宽表 mkt2_idx
        "Z3_EQUITY2": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY2 0 > /data/Logs/z3_transfer/z3_equity2.log 2>&1",
        # 大宽表 信号
        "Z3_EQUITY": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY 0 > /data/Logs/z3_transfer/z3_equity.log 2>&1",

        "Z3_STK_MKT_DAY_INTER_NEW": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER_NEW 0 timing pre > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing_new_pre.log 2>&1",
    },

    "factor_task_pre": {
        # 复权因子
        "Z3_EX_FACTOR_ALL": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EX_FACTOR_ALL 0 timing > /data/Logs/z3_transfer/z3_ex_factor_all_timing.log 2>&1",
        # 日行情
        "Z3_STK_MKT_DAY_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER 0 timing pre > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing_pre.log 2>&1",
        # 大宽表 mkt2_idx
        "Z3_EQUITY2": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY2 0 > /data/Logs/z3_transfer/z3_equity2.log 2>&1",
        # 大宽表 信号
        "Z3_EQUITY": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY 0 > /data/Logs/z3_transfer/z3_equity.log 2>&1",

        "Z3_STK_MKT_DAY_INTER_NEW": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER_NEW 0 timing pre > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing_new_pre.log 2>&1",
    },
    "factor_task": {
        # 复权因子
        "Z3_EX_FACTOR_ALL": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EX_FACTOR_ALL 0 timing > /data/Logs/z3_transfer/z3_ex_factor_all_timing.log 2>&1",
        # 日行情
        "Z3_STK_MKT_DAY_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing.log 2>&1",
        # 月行情
        "Z3_STK_MKT_WEEK_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_WEEK_INTER 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_week_inter_timing.log 2>&1",
        # 周行情
        "Z3_STK_MKT_MONTH_INTER": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_MONTH_INTER 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_month_inter_timing.log 2>&1",
        # 大宽表 mkt2_idx
        "Z3_EQUITY2": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY2 0 > /data/Logs/z3_transfer/z3_equity2.log 2>&1",
        # 大宽表 信号
        "Z3_EQUITY": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_EQUITY 0 > /data/Logs/z3_transfer/z3_equity.log 2>&1",

        "Z3_STK_MKT_DAY_INTER_NEW": "python /data/App/z3_transfer/shenzhen/other/main.py z3dbus.Z3_STK_MKT_DAY_INTER_NEW 0 timing > /data/Logs/z3_transfer/z3_stk_mkt_day_inter_timing_new.log 2>&1",


    },
    "topic_task": {
        # 主题基本信息表
        "Z3_TOPIC_INFO": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_TOPIC_INFO '' 0 > /data/Logs/z3_transfer/topic_info.log 2>&1 &",
        # 主题个股关系表
        "Z3_TOPIC_XREF_EQUITY": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_TOPIC_XREF_EQUITY '' 0 > /data/Logs/z3_transfer/topic_xref_equity.log 2>&1 &",
        # 主题周累计收益率表
        "Z3_TOPIC_REAL_WEEK": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_TOPIC_REAL_WEEK '' 0 > /data/Logs/z3_transfer/topic_real_week.log 2>&1 &",
        # 指数收益率历史明细表
        "Z3_INDEX_HIS_QUOTE": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_INDEX_HIS_QUOTE '' 0 > /data/Logs/z3_transfer/index_his_quote.log 2>&1 &",
        # 主题收益率历史明细表
        "Z3_TOPIC_HIS_QUOTE": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_TOPIC_HIS_QUOTE '' 0 > /data/Logs/z3_transfer/topic_his_quote.log 2>&1 &",
        # 申万行业代码表
        "Z3_SW_INDUSTRY": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_SW_INDUSTRY '' 0 > /data/Logs/z3_transfer/sw_industry.log 2>&1 &",
        # 主题新闻关系表
        # "Z3_TOPIC_XREF_NEWS": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_TOPIC_XREF_NEWS '' 0 > /data/Logs/z3_transfer/z3_topic_xref_news.log 2>&1 &",

        # 股票日行情（回测用）
        "Z3_STK_MKT_DAY": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_STK_MKT_DAY '' 0 > /data/Logs/z3_transfer/stk_mkt_day.log 2>&1 &",
        # 股票日行情（回测用）修改字段(等上一步跑完)
        #"Z3_STK_MKT_DAY02": "python /data/App/z3_transfer/shenzhen/topic/main.py z3dbus.Z3_STK_MKT_DAY.TRADE_NEXT_STATUS '' 0 > /data/Logs/z3_transfer/stk_mkt_day02.log 2>&1 &",

    },
    "once_a_day": {
        # 主题下个股推荐指数
        "RES_DF_SCORES": "python /data/App/z3_transfer/shenzhen/topic/stks_recommend_csv/main.py > /data/Logs/z3_transfer/res_df_scores.log 2>&1 &",
    },

}


def main(task_key, single_task=''):
    task_list = task_config.get(task_key, {})
    task_subs = task_order.get(task_key,[])
    single_task = task_list.get(single_task,None)
    if single_task:
        print "single"
        os.system(single_task)
        return
    for i in task_subs:
        os.system(task_list[i])


# 运行任务组
# python task.py news_task

# 运行单个任务
# * * * * * python /tmp/task.py topic_task
if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        task_key = sys.argv[1]
        single_task = sys.argv[2] if len(sys.argv) == 3 else ""
        main(task_key, single_task)

