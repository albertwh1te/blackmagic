# coding:utf-8
# Created by qinlin.liu at 2017/3/15
"""
mongo表对应的过滤字段
"""
config = {
    "Z3_STK_PROFILE": {
        "pri_key": ["innercode"],
        "delete_old": True,
        "equity": True
    },
    "Z3_INDX_SAMP": {
        "pri_key": ["innercode", "indx_inner_code"],
        "delete_old": True
    },
    "Z3_TOPIC_SAMP": {
        "pri_key": ["innercode", "topic_code"],
        "delete_old": True,
        "equity": True
    },
    "Z3_EQUITY_NEWS": {
        "pri_key": ["innercode", "guid"],
        "delete_old": False,
        "equity": True
    },
    "Z3_STK_EX_FACTOR_ALL": {
        "pri_key": ["symbol", "enddate"],
        "delete_old": False
    },
    "Z3_MNG_HOLD_STK_INFO": {
        "pri_key": ["innercode", "indi_id"],
        "delete_old": False,
        "equity": True
    },
    "Z3_RESEARCH_REPORT": {
        "pri_key": ["innercode", "res_id"],
        "delete_old": False,
        "equity": True
    },
    "Z3_STK_MKT_DAY_INTER": {
        "pri_key": ["innercode", "tradedate", "fac_satus"],
        "delete_old": False
    },
    "Z3_EQUITY": {
        "pri_key": ["innercode", ],
        "delete_old": False,
        "equity": True
    },
    "Z3_SIGNAL_INFO": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False
    },
    "Z3_FILTER_ENTRY": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False
    },
    "Z3_IDX_INFO": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False,
        "int2bool": ["view_status"]
    },
    "STK_LTTMP": {
        "pri_key": ["INNER_CODE", ],
        "delete_old": False,
        "equity": False
    },
    "Z3_TOPIC_SAMPLE": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False
    },
    "Z3_TOPIC_INFO": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False,
        "topinyin": ["topic_spell_init", ]
    },
    "Z3_TOPIC_XREF_NEWS": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False
    },
    "Z3_TOPIC_XREF_NEWS02": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False
    },
    "Z3_TOPIC_NEWS": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False
    },
    "Z3_TOPIC_XREF_EQUITY": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False,
        "stks": False
    },
    "Z3_TOPIC_REAL_WEEK": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False,
        "stks": False
    },
    "Z3_TOPIC_HIS_QUOTE": {
        "pri_key": ["topic_code", "trade_date", "period", ],
        "delete_old": False,
        "equity": False,
        "stks": False
    },
    "TEST_AAA": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False,
        "stks": False
    },
    "Z3_INDEX_HIS_QUOTE": {
        "pri_key": ["_id"],
        "delete_old": False,
        "equity": False,
        "stks": False
    },
    "Z3_STK_MKT_DAY": {
        "pri_key": ["_id",],
        "delete_old": False,
        "equity": False,
        "int2bool": ["limit_up_non_open", "limit_down_non_open", ]
    },
    "Z3_STK_MKT_WEEK": {
        "pri_key": ["symbol", "end_date", "innerCode", ],
        "delete_old": False,
        "equity": True,
    },
    "Z3_STK_MKT_WEEK02": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False,
    },
    "Z3_STK_MKT_MONTH": {
        "pri_key": ["symbol", "end_date", "innerCode", ],
        "delete_old": False,
        "equity": True,
    },
    "Z3_STK_MKT_MONTH02": {
        "pri_key": ["_id", ],
        "delete_old": False,
        "equity": False,
    },
    "Z3_SEARCH_SYMBOL": {
        "pri_key": ["_id", ],
        "delete_old": False,
    },
    "Z3_SEARCH_UNIT": {
        "pri_key": ["_id", ],
        "delete_old": False,
    },
    "Z3_SW_INDUSTRY": {
        "pri_key": ["_id", ],
        "delete_old": False,
    },
    "Z3_EQUITY_HISTORY": {
        "pri_key": ["innerCode", "trade_date"],
        "delete_old": False,
        "equity": False,
        "stks": False,
        "int2bool": ["price_cross_ma5_above", "price_cross_ma5_below", "ma5_cross_ma10_above",
                     "ma5_cross_ma10_below", "ma5_cross_ma20_above", "ma5_cross_ma20_below",
                     "price_cross_ma10_above", "price_cross_ma10_below", "ma10_cross_ma20_above",
                     "ma10_cross_ma20_below", "ma10_cross_ma30_above", "ma10_cross_ma30_below",
                     "price_cross_ma20_above", "price_cross_ma20_below", "ma20_cross_ma30_above",
                     "ma20_cross_ma30_below", "ma20_cross_ma60_above", "ma20_cross_ma60_below",
                     "price_cross_ma30_above", "price_cross_ma30_below", "ma30_cross_ma60_above",
                     "ma30_cross_ma60_below", "ma30_cross_ma120_above", "ma30_cross_ma120_below",
                     "price_cross_ma60_above", "price_cross_ma60_below", "ma60_cross_ma120_above",
                     "ma60_cross_ma120_below", "ma60_cross_ma250_above", "ma60_cross_ma250_below",
                     "price_cross_ma120_above", "price_cross_ma120_below", "ma120_cross_ma250_above",
                     "ma120_cross_ma250_below", "price_cross_ma250_above", "price_cross_ma250_below"
                     ]
    }

}
if __name__ == "__main__":
    pass
