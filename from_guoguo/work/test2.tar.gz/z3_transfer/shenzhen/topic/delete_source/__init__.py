# coding:utf-8
# Created by tao.liu at 2017/3/14
from data_source_copy import DataSourceCopy
from utils import tools
import datetime
from dateutil.relativedelta import relativedelta


class DeleteSource(DataSourceCopy):
    def delete_Z3_TOPIC_INFO_data(self, *args, **kwargs):
        """
        删除Z3_TOPIC_INFO中已经作废的数据
        :return:
        """
        where_str = self._make_where("_id", ["a"])

        sql = """
            select a.SECTION_CODE as _id
              from pgenius.PUB_SECTION_CODE a
             where a.SYS_CODE=5
               and a.ISVALID=0
           --    AND (( a.MTIME>'2017-05-11 14:48:57' AND   a.MTIME<='2017-05-16 14:50:20' ))
            %(where_str)s
        """ % {"where_str": where_str}

        results = self.conn.fetchall(sql)

        return results

    def delete_Z3_TOPIC_XREF_EQUITY_data(self, *args, **kwargs):
        """
        删除Z3_TOPIC_XREF_EQUITY中已经作废的数据
        :return:
        """
        where_str = self._make_where("_id", ["a", "b", "c"])

        # 获取主题
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        topics = db.Z3_TOPIC_XREF_EQUITY.distinct("topic_code")

        # 获取所有有效应该保留的 _id
        valid_id = []
        id_tmp = []
        for row in topics:
            child = self.get_child_section_code(row)
            sub_seccode = ",".join(str(i) for i in child)
            # sub_seccode = tuple(self.get_child_section_code(row))

            sql02 = """
                select distinct 
                          CONCAT(c.stockcode,
                                 case when c.TRADE_MKT like '上海%%' then '.SH'
                                       when c.TRADE_MKT like '深圳%%' then '.SZ'
                                        end,
                                 ",",
                                 %(topic_code)s) as _id
                     from pgenius.PUB_SECTION_CODE a
                     join pgenius.PUB_SECTION_REL b
                       on a.SECTION_CODE = b.SECTION_CODE and b.ISVALID = 1 
                     join pgenius.STK_CODE c
                       on c.inner_code = b.inner_code  and c.ISVALID = 1
                      and c.stk_type_ref = 1 and c.status_type_ref in (1,2)
                    where a.sys_code = 5
                      and a.ISVALID = 1  
                      and a.SECTION_CODE in (%(code)s)  
                   --   and a.section_code not in (400121942,400121950,400121951)
                      and ifnull(b.EN_TIME,'1900-01-01')<=cast(now() as date)
                      and ifnull(b.REJE_TIME  ,'2999-12-31')>cast(now() as date)
                 --     and (a.mtime >= '2017-05-11 00:00:00')
                 --     %(where_str)s
            """ % {"topic_code": row, "code": sub_seccode, "where_str": where_str}

            id_tmp.extend(self.conn.fetchall(sql02))
            # stocks.extend(self.conn.fetchall(sql02))

        # 获取所有有效_id
        valid_id.extend(row.get("_id") for row in id_tmp)

        # 获取mongo中所有的_id
        org_ids = db.Z3_TOPIC_XREF_EQUITY.distinct("_id")
        # 获取失效_id
        invalid_id = []
        for i in org_ids:
            if i not in valid_id:
                tmp = {"_id": i}
                invalid_id.append(tmp)
        return invalid_id

    def delete_Z3_TOPIC_REAL_WEEK_data(self, *args, **kwargs):
        """
        删除Z3_TOPIC_REAL_WEEK中已经作废的数据
        :return:
        """
        where_str = self._make_where("_id", ["a"])
        sql = """
                    select a.SECTION_CODE as _id
                      from pgenius.pub_section_code a
                     where a.SYS_CODE=5
                       and a.ISVALID=0
                --       %(where_str)s
                """ % {"where_str": where_str}

        results = self.conn.fetchall(sql)

        return results

    def delete_Z3_TOPIC_SAMPLE_data(self, *args, **kwargs):
        """
        删除Z3_TOPIC_REAL_WEEK中已经作废的数据
        :return:
        """
        where_str = self._make_where("_id", ["a"])
        sql = """
                    select a.SECTION_CODE as _id
                      from pgenius.pub_section_code a
                     where a.SYS_CODE=5
                       and a.ISVALID=0
                       %(where_str)s
                """ % {"where_str": where_str}

        results = self.conn.fetchall(sql)

        return results

    def delete_Z3_TOPIC_XREF_NEWS_data(self, *args, **kwargs):
        """
        删除Z3_TOPIC_REAL_WEEK中已经作废的数据
        :return:
        """
        # 获取主题
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        topics = db.Z3_TOPIC_XREF_NEWS.distinct("topic_code")
        print "topics", len(topics)
        # topics = self.conn.fetchall(sql01)
        results = []
        for code in topics:
            child = self.get_child_section_code(code)
            sub_seccode = ",".join(str(i) for i in child)

            sql = """
            select CONCAT(%(topic_code)s,",",c.GUID) as _id
              from pgenius.PUB_SECTION_CODE a
        	   	  ,pgenius.NEWS_SECTION b
                  ,pgenius.NEWS_MAIN c
                  ,pgenius.NEWS_CONTENT d
             where b.GUID=c.GUID
               and a.SECTION_CODE = b.SECTION_CODE
               and c.guid = d.guid
               and a.SECTION_CODE in (%(child_code)s)
               and (a.ISVALID = 0 or b.ISVALID = 0 or c.ISVALID = 0 or d.isvalid = 0)
                """ % {"topic_code": code, "child_code": sub_seccode}

            tmp = self.conn.fetchall(sql)
            results.extend(tmp)

        return results

    def delete_Z3_INDEX_HIS_QUOTE_data(self, *args, **kwargs):
        """
        删除Z3_INDEX_HIS_QUOTE中已经作废的数据
        :return:
        """
        where_str = self._make_where("_id", ["a", "b"])
        sql = """
            SELECT a.INDX_CODE as symbol
                  ,REPLACE(REPLACE(a.INDX_SNAME,'(深)',''),'(沪)','') as name
                  ,cast(DATE_FORMAT(b.tradedate,'%%Y-%%m-%%d 00:00:00') as datetime)  as trade_date
              from 	pgenius.INDX_GEN_INFO a
              join pgenius.INDX_MKT b
                on a.INNER_CODE = b.INNER_CODE
             where 1 = 1
               and a.INDX_CODE in ('000001','399001','399005','000016','399905','399006','000852','000300','000906')
               and (a.ISVALID = 0 or b.ISVALID = 0)
               %(where_str)s
        """ % {"where_str": where_str}

        results = self.conn.fetchall(sql)
        return results

    def delete_Z3_TOPIC_HIS_QUOTE_data(self, period, **kwargs):
        """
        删除Z3_TOPIC_REAL_WEEK中已经作废的数据
        :return:
        """
        print period, datetime.datetime.today()
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        # 删除无效主题数据
        sql01 = """
            SELECT  a.SECTION_CODE AS topic_code
                  --  ,a.SECTION_NAME AS topic_name
               FROM pgenius.PUB_SECTION_CODE a
              WHERE SYS_CODE = 5
                AND ISVALID = 0 
            --    and SECTION_CODE = 400130145
        """
        del_data01 = self.conn.fetchall(sql01)
        print "del_data01", len(del_data01)
        for row in del_data01:
            db["Z3_TOPIC_HIS_QUOTE"].remove({
                "topic_code": row["topic_code"],
                "period": period
                })

        # 获取有效主题的无效交易数据
        if period == "M01":
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -1 MONTH)+1 and CURDATE()"
        elif period == "M03":
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -3 MONTH)+1 and CURDATE()"
        elif period == "M06":
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -6 MONTH)+1 and CURDATE()"
        elif period == "M12":
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -12 MONTH)+1 and CURDATE()"
        elif period == "M36":
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -36 MONTH)+1 and CURDATE()"
        elif period == "ALL":
            date_condition = ""
        elif period == "WEEK":
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -1 WEEK)+1 and CURDATE()"

        where_str = self._make_where("_id", ["a", "b"])
        sql02 = """
            SELECT b.SECTION_CODE as topic_code
                  ,cast(date_format(a.TRD_DATE,'%%Y%%m%%d') as SIGNED) as trade_date
              from pgenius.ANA_SECTION_EXPR_IDX a
              join pgenius.PUB_SECTION_CODE b
                on a.INNER_CODE = b.SECTION_CODE
             where 1 = 1
                and b.sys_code=5 and b.ISVALID = 1
                and a.TRD_DATE >= date('2005-01-01')
                and a.ISVALID = 0 
                %(date_condition)s
          --     %(where_str)s
        """ % {"where_str": where_str, "date_condition": date_condition}

        del_data02 = self.conn.fetchall(sql02)
        print "del_data02:", len(del_data02)
        for row in del_data02:
            # print row
            db["Z3_TOPIC_HIS_QUOTE"].remove({
                "period": period,
                "topic_code": row.get("topic_code"),
                "trade_date": row.get("trade_date")
            })

        # 删除超过时间范围的数据
        if period <> "ALL":
            # 获取时间范围
            p_tmp = {
                "M01": relativedelta(months=1),
                "M03": relativedelta(months=3),
                "M06": relativedelta(months=6),
                "M12": relativedelta(months=12),
                # "M24": relativedelta(months=24),
                "M36": relativedelta(months=36)
            }
            today = datetime.date.today()
            dd = today - p_tmp.get(period)
            date_limit = int(dd.strftime('%Y%m%d'))
            print period, date_limit
            # 执行删除
            db["Z3_TOPIC_HIS_QUOTE"].remove({
                "period": period,
                "trade_date": {"$lte": date_limit}
            })

        return []

    def delete_Z3_EQUITY_XREF_NEWS_data(self, *args, **kwargs):
        """
        删除Z3_EQUITY_XREF_NEWS中已经作废的数据
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        # where_str = self._make_where("_id", ["a", "b", "c"])
        stk_list = list(db["Z3_EQUITY_XREF_NEWS"].distinct("symbol"))
        # stk_list = tmp.sort()
        print len(stk_list)
        # stk_list = ["000001"]

        for code in stk_list:
            print code
            sql = """
              select concat(c.stockcode,'.', case when c.trade_mkt_ref=1 then 'SZ'
                                                   when c.trade_mkt_ref=2 then 'SH'
                                                    end,',',a.guid) as _id
                     ,'新闻' as news_type
                from pgenius.NEWS_MAIN a 
                join pgenius.NEWS_STK b on a.guid=b.guid
                join pgenius.STK_CODE c on b.comcode=c.comcode 
                 and c.trade_mkt_ref in(1,2) and c.ISVALID = 1
                join pgenius.news_content d on a.GUID = d.GUID 
               where 1= 1
                 and c.stockcode = '%(code)s'
                 and (a.isvalid=0 or b.isvalid=0 or d.ISVALID = 0)
                 and a.mtime>='2014-01-01'
               union all
            select concat(c.stockcode,'.',case when c.trade_mkt_ref=1 then 'SZ'
                                        when c.trade_mkt_ref=2 then 'SH'
                                         end,',',a.disc_id) as _id
                   , '公告' as news_type
              from pgenius.DISC_MAIN_COM a 
              join pgenius.DISC_COM b on a.disc_id=b.disc_id  
              join pgenius.STK_CODE c on b.comcode=c.comcode 
               and c.trade_mkt_ref in(1,2) and c.isvalid = 1
              join pgenius.news_content d on a.disc_id = d.GUID 
             where 1 =1 
               and c.stockcode = '%(code)s'
               and (a.isvalid=0 or b.isvalid=0 or d.ISVALID = 0)
               and a.mtime>='2014-01-01'
            """ % {"code": str(code)}

            data = self.conn.fetchall(sql)
            print code, len(data)
            for row in data:
                db["Z3_EQUITY_XREF_NEWS"].remove(row)
            # results.extend(self.conn.fetchall(sql, {"code": i for i in stk_list}))

        # return results

    def delete_Z3_SW_INDUSTRY_data(self, *args, **kwargs):
        """
        生成 申万行业代码表表数据
        :return:
        """
        # where_str = self._make_where("SIGNAL_ID", ["a"])
        sql = """
        select a.INDU_CODE as _id
               ,a.INDU_NAME as industryname
               ,a.INDU_LEVEL as level
          from pgenius.PUB_INDU_REF a
         where a.INDU_SYS_MARK = 15
           and a.ISVALID = 0
        """
        # % {"where_str": where_str}
        bs_data = self.conn.fetchall(sql)
        return bs_data
        # results = bs_data
        # for row in bs_data:
        #     tmp =row
        #     tmp["parent_id"] = None if tmp["parent_id"] == '' else tmp["parent_id"]
        #     # tmp["parent_id"] = row.get("parent_id", None)
        #     results.append(tmp)
        # return results

    def delete_Z3_NEWS_data(self, *args, **kwargs):
        """
        删除 新闻主表无效数据
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        where_str = self._make_where("_id", ["a", "b"])
        sql = """
             select distinct a.guid as _id
               from pgenius.NEWS_MAIN a
               join pgenius.NEWS_CONTENT b on a.guid=b.guid
              where (a.isvalid=0 or b.isvalid=0 )
                and a.DECLAREDATE >= '2014-01-01'
           --     and a.guid = '0000000000000i5htc'
          --    %(where_str)s
        """
        # % {"where_str": where_str}
        bs_data = self.conn.fetchall(sql)

        print "bs_data", bs_data

        # 删除mongo的Z3_NEWS表中的无效数据
        for row in bs_data:
            db["Z3_NEWS"].remove(bs_data)

        # 删除mysql的z3_news_info_search表中的无效数据
        delete_sql = """
            delete from pgznty.z3_news_info_search where guid in (%s)
        """ % ",".join(["'%s'" % i["_id"] for i in bs_data])

        self.conn.execute(delete_sql)

        return []

    def delete_Z3_STK_MKT_DAY_data(self, *args, **kwargs):
        """
        删除 日行情表（回测用）无效数据
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        where_str = self._make_where("_id", ["a", "b"])
        sql = """
            select
                  CONCAT(case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                          when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                           end ,'-',date_format(b.TRADEDATE,'%Y%m%d')) as _id
            --     ,a.STOCKCODE as symbol
            --     ,case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
            --              when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
            --               end as innerCode
            --     ,cast(date_format(b.TRADEDATE,'%%Y%%m%%d') as SIGNED) as trade_date        
             from pgenius.STK_CODE a
             join pgenius.ANA_STK_MKT_DAY b
               on a.STOCKCODE = b.STOCKCODE -- and b.isvalid = 1
              and (b.TRADEDATE < ifnull(a.LIST_DATE,'1900-01-01')  
                or b.TRADEDATE >= ifnull(a.LIST_ENDDATE,'2099-12-31') )                     
            where a.isvalid = 1 
              and a.STK_TYPE_REF = 1 
              and a.STOCKCODE IS NOT NULL
              and a.TRADE_MKT_REF IS NOT NULL
              AND a.STOCKCODE not like 'N%'
               and year(b.TRADEDATE) > 2004

            """


        # print sql
        # % {"where_str": where_str}
        bs_data = self.conn.fetchall(sql)

        print "bs_data", bs_data

        # 执行删除
        for row in bs_data:
            db["Z3_STK_MKT_DAY"].remove(row)


        return []



    if __name__ == "__main__":
        pass
