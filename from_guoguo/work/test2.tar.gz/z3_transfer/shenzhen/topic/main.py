# coding:utf-8
# Created by qinlin.liu at 2017/3/14
import pymongo
import datetime
from utils.mysqlutil import Mysql
from config import config
from convert_config import config as table_prkey_config
from common import format_data
from data_source_copy import DataSourceCopy
import time
import threadpool
from delete_source import DeleteSource
# from datetime import datetime

def update_task(ds, curr_time, database, table_name):
    # 更新任务信息
    update_dict = {

        "LASTRUNTIME": curr_time,
        "NEXTRUNTIME": get_last_update_time(curr_time, ds.task_info),
        "UPDATETIME": getnow().strftime("%Y-%m-%d %H:%M:%S"),
        "SDATABASE": ds.task_info.get("SDATABASE", ""),
        "STABLE": ds.task_info.get("STABLE", ""),
        "TDATABASE": ds.task_info.get("TDATABASE", database),
        "TTABLE": ds.task_info.get("TTABLE", table_name),
        "FREQUENCY": ds.task_info.get("FREQUENCY", "D"),
        "SPACE": ds.task_info.get("SPACE", 1),
    }
    # print update_dict.values()
    sql = """
        INSERT INTO pgznty.z3_update_task(%(keys)s) VALUES (%(values)s)
        ON DUPLICATE KEY UPDATE %(kwargs)s;
    """ % ({
        "keys": ",".join(update_dict.keys()),
        "values": ",".join([("'%s'" % v) if k != "NEXTRUNTIME" else ("%s" % v) for k, v in update_dict.items()]),
        "kwargs": " , ".join(
            [("%s='%s'" % (k, v)) if k != "NEXTRUNTIME" else("%s=%s" % (k, v)) for k, v in update_dict.items()])
    })
    # print sql
    ds.update_taks(sql)

def main_limit(args):
    """
    通过limit分段获取sql数据
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_cloud_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")
    m = "make_%s_data" % table_name
    de = "delete_%s_data" % table_name
    # print m
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)
    # 删除数据
    delsrc = DeleteSource(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    if hasattr(delsrc, de):
        method = getattr(delsrc, de)
        data = method(0, 100)
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        result_size = len(data)
        print result_size
        # 删除mongo的无效数据
        table_info = table_prkey_config[table_name]

        delete_mongo_data(args, database, table_name, data, table_info)

    #更新数据
    if hasattr(ds, m):
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 1000, 1000
        while result_size == 1000:
            data = method(offset, maxsize)
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]

            upsert_mongo_data(args, database, table_name, data, table_info)

        update_task(ds, curr_time, database, table_name)

def stk_mkt_oncode(table_name,database,args,row,curr_time):
    # print row["stockcode"]

    mysql = Mysql(config["mysql_cloud_test"])
    m = "make_%s_data" % table_name
    m3 = "make_Z3_STK_MKT_DAY_TRADE_NEXT_STATUS_data"
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    method = getattr(ds, m)
    method3 = getattr(ds, m3)
    offset = 0
    result_size, maxsize = 10000, 10000
    # if str(row["stockcode"])[0:2] == "N1":
    data = method(offset, maxsize, row["stockcode"], "stk")
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    # print "%s--%s" % (str(offset), str(maxsize))
    result_size = len(data)
    print "result_size", result_size
    offset += maxsize
    # 添加，更新，删除数据到mongo
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, data, table_info)
    # 获取数据改变上一天的 “下一交易日”字段
    status_data = method3(offset, maxsize, data, "stk")
    table_info = table_prkey_config[table_name]
    upsert_mongo_data(args, database, table_name, status_data, table_info)


def main_topics(args):
    """
    按每个主题处理主题相关数据
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_cloud_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")

    m = "make_%s_data" % table_name
    de = "delete_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    # 删除数据
    delsrc = DeleteSource(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    if hasattr(delsrc, de):
        method = getattr(delsrc, de)
        data = method(0, 100)
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        result_size = len(data)
        print result_size
        # 删除数据到mongo
        table_info = table_prkey_config[table_name]
        delete_mongo_data(args, database, table_name, data, table_info)

    # 添加数据

    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    # 获取所有主题代码
    or_data = ds.get_topics()
    if hasattr(ds, m):
        method = getattr(ds, m)
        for row in or_data:
            offset = 0
            result_size, maxsize = 10000, 10000
            data = method(row["topic_code"], row["topic_name"])
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)

    update_task(ds, curr_time, database, table_name)

def main_stk_mtk(args):
    """
    通过传入日期参数，增量导入数据
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_cloud_test"])
    # except Exception, e:
    #     print e
    #     return
    except:
        time.sleep(5)
    database, table_name = args[0].split(".")

    m = "make_%s_data" % table_name
    m2 = "make_%s_ztss_data" % table_name
    m3 = "make_Z3_STK_MKT_DAY_TRADE_NEXT_STATUS_data"
    # print m
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    method = getattr(ds, m)

    # 插入指数数据
    for idx in ['000001', '399001', '399005','000016','399905','399006','000852','000300','000906']:
        offset = 0
        result_size, maxsize = 1000, 1000
        data = method(offset, maxsize, idx, "idx")
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        print "%s--%s" % (str(offset), str(maxsize))
        result_size = len(data)
        print result_size, "result_size"
        offset += maxsize
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)
    
    # 插入暂停上市股票数据
    method2 = getattr(ds, m2)
    method3 = getattr(ds, m3)
    ztss = ds.get_ztss_stkcode()
    for row in ztss:
	offset = 0
        result_size, maxsize = 1000, 1000
        data = method2(offset, maxsize, row["stockcode"], "stk")
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        print "%s--%s" % (str(offset), str(maxsize))
        result_size = len(data)
	offset += maxsize
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)
	#获取数据改变上一天的 “下一交易日”字段
        status_data = method3(offset, maxsize, data, "stk")
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, status_data, table_info)
    
    # 插入正常上市股票数据
    stklist = ds.get_all_stkcode()
    args_list = []
    for row in stklist:
        args_list.append((None,{
            "table_name":table_name,
            "database":database,
            "args":args,
            "row":row,
            "curr_time":curr_time
        }))
    pool = threadpool.ThreadPool(5)
    requests = threadpool.makeRequests(stk_mkt_oncode, args_list)
    [pool.putRequest(req) for req in requests]
    pool.wait()

    update_task(ds, curr_time, database, table_name)

def main_equity_his(args):
    """
    处理大宽表历史数据
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_cloud_test"])
    except Exception, e:
        print e
        return
    database, table_name = args[0].split(".")

    m = "make_%s_data" % table_name

    # print m
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    # 获取Z3_EQUITY_HISTORY表中所有股票代码
    or_data = ds.get_equity_history_symbol()
    if hasattr(ds, m):
        method = getattr(ds, m)
        for row in or_data:
            offset = 0
            result_size, maxsize = 10000, 10000
            data = method(row["innerCode"], row["symbol"])
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size, "result_size"
            offset += maxsize
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]
            upsert_mongo_data(args, database, table_name, data, table_info)
            # try:
            #     upsert_mongo_data(args, database, table_name, data, table_info)
            # except:
            #     with open("error_his_code", "a+") as f:
            #         f.write("%s" % row["symbol"])
            #     time.sleep(5)

                # curr = getnow()
                # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

        update_task(ds, curr_time, database, table_name)


def main_topic_his(args):
    """
    通过传入频度参数，增量导入数据
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_cloud_test"])
    # except Exception, e:
    #     print e
    #     return
    except:
        time.sleep(5)
    database, table_name = args[0].split(".")

    m = "make_%s_data" % table_name
    de = "delete_%s_data" % table_name
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")

    delsrc = DeleteSource(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)
    ds = DeleteSource(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    for period in ("M01", "M03", "M06", "M12", "M36", "ALL"):
    # for period in ("M03",):
        # 删除数据
        if hasattr(delsrc, de):
            method = getattr(delsrc, de)
            data = method(period)
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            result_size = len(data)
            print result_size
            # 删除数据到mongo
            table_info = table_prkey_config[table_name]
            delete_mongo_data(args, database, table_name, data, table_info)

        # 插入数据
	topiclist = ds.get_topics()
        args_list = []
	for row in topiclist:
            args_list.append((None, {
                "table_name": table_name,
                "database": database,
                "args": args,
                "period": period,
                "row": row,
                "curr_time": curr_time
            }))
	pool = threadpool.ThreadPool(5)
        requests = threadpool.makeRequests(topic_hisquote_oncode, args_list)
        [pool.putRequest(req) for req in requests]
        pool.wait()

    update_task(ds, curr_time, database, table_name)

def topic_hisquote_oncode(table_name,database,args,period,row,curr_time):
    """
     主题Z3_TOPIC_HIS_QUOTE 表获取数据
    """
    try:
        mysql = Mysql(config["mysql_cloud_test"])
    except Exception, e:
	print e
	return
    m = "make_%s_data" % table_name
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": None, "endtime": None}, curr_time)

    if hasattr(ds, m):
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 10000, 10000
        data = method(period, row["topic_code"])
        curr = getnow()
        curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
        print "%s--%s" % (str(offset), str(maxsize))
        result_size = len(data)
        print result_size
        offset += maxsize
        # 添加，更新，删除数据到mongo
        table_info = table_prkey_config[table_name]
        upsert_mongo_data(args, database, table_name, data, table_info)

def main_update_field(args):
    """
    更新某些表的字段
    :param args:
    :return:
    """
    try:
        mysql = Mysql(config["mysql_cloud_test"])
    except Exception, e:
        print e
        return
    database, table_name, field_name = args[0].split(".")
    # table_name = replace(table_name,"_update")
    m = "make_%s_%s_data" % (table_name, field_name)
    # print m
    curr = getnow()
    curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
    ds = DataSourceCopy(mysql, database, table_name, {"starttime": args[1], "endtime": args[2]}, curr_time)

    if hasattr(ds, m):
        method = getattr(ds, m)
        offset = 0
        result_size, maxsize = 500, 500
        while result_size == 500:
            data = method(offset, maxsize)
            curr = getnow()
            curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            print "%s--%s" % (str(offset), str(maxsize))
            result_size = len(data)
            print result_size
            offset += maxsize
            # 格式化mysql数据
            format_data(data)
            # 添加，更新，删除数据到mongo
            table_info = table_prkey_config[table_name]

            upsert_mongo_data(args, database, table_name, data, table_info)

            # curr = getnow()
            # curr_time = curr.strftime("%Y-%m-%d %H:%M:%S")
            # update_task(ds, curr_time, database, table_name)

def getnow():
    '''
    获取当前时间
    :return:
    '''
    return datetime.datetime.now()

def get_last_update_time(curr_time, info={}):
    """
    生成 预测任务执行时间
    :param curr_time:   datetimestr 当前时间
    :param info:        dict 定时信息
    :return:
    """
    prequency = info.get("FREQUENCY", "H")
    space = info.get("SPACE", 1)
    if prequency == "H":
        interval_time = "HOUR"
    elif prequency == "D":
        interval_time = "DAY"
    elif prequency == "W":
        interval_time = "WEEK"
    elif prequency == "M":
        interval_time = "MONTH"
    elif prequency == "Q":
        interval_time = "QUARTER"
    elif prequency == "Y":
        interval_time = "YEAR"
    else:
        interval_time = "HOUR"

    # return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return "DATE_ADD('%s', INTERVAL %s %s)" % (curr_time, space, interval_time)

def upsert_mongo_data(args, database, table_name, data, table_info):
    """
    更新数据到mongo
    :param args:        list 来自sys.argv
    :param database:    str 目的表库名
    :param table_name:  str 目的表表名
    :param data:        list 需要更新同步的数据
    :param table_info:  dict 目的表配置信息，来自oonvert_config文件
    :return:
    """

    # 格式化mysql数据
    format_data(data, table_info.get("int2bool", []))
    try:
        # conn = pymongo.MongoClient("127.0.0.1", 27017)
        conn = pymongo.MongoClient(config["mongodb_cloud_jq"]["uri"])
        # conn = pymongo.MongoClient(**config["mongodb_test"])
        # conn = pymongo.MongoClient(config["mongodb_4_11"]["uri"])
    except Exception, e:
        print e
        return
    db = conn[database]
    # print db.collection_names()
    # 更新或插入数据
    nor_list = []  # 用于删除，不满足条件的历史纪录
    if args[1] == "insert":
        # 首次导入数据，清空历史数据
        # db[table_name].drop()
        if table_info.get("equity", False):
            for key, row in enumerate(data):
                equity = {}
                for i in table_info["pri_key"]:
                    if i in ["symbol", "name", "innerCode"]:
                        equity[i] = row[i]
                        del row[i]
                if equity:
                    row["equity"] = equity
                    data[key] = row
        if data:
            db[table_name].insert_many(data)
        return
    # print "data", len(data)
    for row in data:
        tmp = row
        filter = {}
        if table_info.get("equity", False):

            filter.update({i: row[i] for i in table_info["pri_key"] if i not in ["innerCode", "symbol", "name"]})
            for i in table_info["pri_key"]:
                if i in ["innerCode", "symbol", "name"]:
                    filter["equity.%s" % i] = row[i]
                    tmp["equity.%s" % i] = row[i]
                    del tmp[i]

        else:
            filter = {i: row[i] for i in table_info["pri_key"]}
            # nor_list.append(filter)
        db[table_name].update(filter, {"$set": tmp}, upsert=True, multi=True)
        # except pymongo.errors.ServerSelectionTimeoutError, e:
        #     print e, '连接失败！'
        #     return

def delete_mongo_data(args, database, table_name, data, table_info):
    """
    删除mongo中的无效数据
    :param args:        list 来自sys.argv
    :param database:    str 目的表库名
    :param table_name:  str 目的表表名
    :param data:        list 需要更新同步的数据
    :param table_info:  dict 目的表配置信息，来自oonvert_config文件
    :return:
    """

    # 格式化mysql数据
    format_data(data, table_info.get("int2bool", []))
    # print "delete_data", format_data
    try:
        # conn = pymongo.MongoClient("127.0.0.1", 27017)
        conn = pymongo.MongoClient(config["mongodb_cloud_jq"]["uri"])
        # conn = pymongo.MongoClient(**config["mongodb_test"])
        # conn = pymongo.MongoClient(config["mongodb_4_11"]["uri"])
    except Exception, e:
        print e
        return
    db = conn[database]
    # print db.collection_names()
    # 删除数据
    for row in data:
        tmp = row
        filter = {}
        if table_info.get("equity", False):

            filter.update({i: row[i] for i in table_info["pri_key"] if i not in ["innerCode", "symbol", "name"]})
            for i in table_info["pri_key"]:
                if i in ["innerCode", "symbol", "name"]:
                    filter["equity.%s" % i] = row[i]
                    tmp["equity.%s" % i] = row[i]
                    del tmp[i]

        else:
            filter = {i: row[i] for i in table_info["pri_key"]}
        db[table_name].remove(filter)

if __name__ == "__main__":
    import sys

    # v_base = "test"
    # 补齐参数
    init_args = ["z3dbus.Z3_TOPIC_XREF_NEWS", "", 0]
    # 首次需要传送需要insert的传参
    # init_args = ["z3dbus.Z3_TOPIC_HIS_QUOTE", "insert", 0]

    for k, v in enumerate(sys.argv[1:]):
        init_args[k] = v
    if init_args[0] in ["z3dbus.Z3_SIGNAL_INFO", "z3dbus.Z3_FILTER_ENTRY",
                        "z3dbus.Z3_IDX_INFO",
                        "z3dbus.Z3_SEARCH_SYMBOL", "z3dbus.Z3_SEARCH_UNIT",
                        # "z3dbus.Z3_TOPIC_XREF_NEWS",
                        "z3dbus.Z3_TOPIC_INFO", "z3dbus.Z3_TOPIC_XREF_EQUITY",
                        "z3dbus.Z3_SW_INDUSTRY", "z3dbus.Z3_TOPIC_REAL_WEEK",
                        "z3dbus.Z3_INDEX_HIS_QUOTE", "z3dbus.Z3_INDEX_HIS_QUOTE2",
                        "z3dbus.Z3_STK_MKT_MONTH", "z3dbus.Z3_TOPIC_SAMPLE",
                        "z3dbus.Z3_EQUITY_XREF_NEWS"
                        ]:
        # 批量复制 Z3_STK_PROFILE 数据
        main_limit(init_args)
    elif init_args[0] in ["z3dbus.Z3_STK_MKT_DAY", "z3dbus.Z3_STK_MKT_DAY02",
                          "z3dbus.Z3_STK_MKT_DAY03",
                          "z3dbus.Z3_STK_MKT_WEEK",
                          "z3dbus.Z3_EQUITY_HISTORY_T"]:
        main_stk_mtk(init_args)
    elif init_args[0] in ["z3dbus.Z3_TOPIC_XREF_NEWS",
                          ]:
        main_topics(init_args)
    elif init_args[0] in ["z3dbus.Z3_TOPIC_HIS_QUOTE"
                          ]:
        main_topic_his(init_args)
    elif init_args[0] in ["z3dbus.Z3_TOPIC_INFO.EVENT_NUM",
                          "z3dbus.Z3_STK_MKT_DAY.TRADE_NEXT_STATUS" 
                          ]:
        # 更新字段用
        main_update_field(init_args)
    elif init_args[0] in ["z3dbus.Z3_EQUITY_HISTORY",
                          "z3dbus.Z3_EQUITY_HISTORY_TEST"]:
        main_equity_his(init_args)

