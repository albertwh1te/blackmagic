# coding:utf-8
# Created by qinlin.liu at 2017/3/14

import decimal, types
import datetime
import time



def _change_data(v, tobool=False, toutc=False):
    """
    转换mysql数据，用于插入mongo
    :param v:
    :return:
    """
    if type(v) == decimal.Decimal:
        return float(v)
    if type(v) == types.UnicodeType:
        return v
    if type(v) == types.IntType and tobool:
        return True if v == 1 else False
    # if type(v) == datetime and toutc:
    #     return time.mktime(v)
    return v


def format_data(data, int2bool=[], toutc=[]):
    """
    格式当行记录
    :param data:
    :return:
    """
    for i, row in enumerate(data):
        for k in row:
            row[k] = _change_data(row[k], (k in int2bool))
            # row[k] = _change_data(row[k], (k in toutc))
        data[i] = row



if __name__ == "__main__":
    pass
