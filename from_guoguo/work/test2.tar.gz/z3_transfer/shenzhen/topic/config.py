# coding:utf-8
# Created by qinlin.liu at 2017/3/14
import pymysql

config = {
    "mysql_release": {
        "host": "172.18.3.7",
        "user": "root",
        "password": "123456",
        "db": "pgenius",
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mysql_test": {
        "host": "172.18.3.7",
        "user": "root",
        "password": "123456",
        "db": "pgenius",
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mysql_bj": {
        "host": "10.88.3.178",
        "port": 3307,
        "user": "JRJ_JuLing",
        "password": "5um5HwHDn2vqnFwwGOis",
        "db": "pgznty",
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mysql_cloud_test": {
        "host": "10.77.4.8",
        "port": 3306,
        "user": "z3python",
        "password": "z3python",
        # "user": "ltpython",
        # "password": "bBK4MwwVCfzL",
        "charset": 'utf8mb4',
        "db": "pgznty",
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mysql_cloud_dev": {
        "host": "10.77.4.9",
        "port": 3306,
        # "user": "z3python",
        # "password": "z3python",
        "user": "ltpython",
        "password": "bBK4MwwVCfzL",
        "charset": 'utf8mb4',
        "db": "pgenius",
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mysql_123": {
        "host": "172.18.3.123",
        "user": "reader",
        "password": "reader",
        "db": "test",
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mysql_110": {
        "host": "172.18.28.110",
        "user": "reader",
        "password": "reader",
        "db": "test",
        "cursorclass": pymysql.cursors.DictCursor
    },
    "mongodb_test": {
        "host": "172.18.3.130",
        "replicaset": "athena",
        # "uri": "mongodb://z3dbusadmin:z3dbusadmin@117.121.98.91:27017/z3dbus?authMechanism=SCRAM-SHA-1"
    },
    "mongodb_bj": {
        # "host": "117.121.98.91",
        # "replicaset": "athena",
        "uri": "mongodb://z3dbusadmin:z3dbusadmin@117.121.98.91:27017/z3dbus?authMechanism=SCRAM-SHA-1"
    },
    "mongodb_cloud_test": {
        "host": "10.77.4.11",
        "replicaset": "zntytestdb",
        "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.11:27017,10.77.4.12:27017/z3dbus?authMechanism=SCRAM-SHA-1&replicaSet=zntytestdb"

    },
    "mongodb_cloud_dev": {
        "host": "10.77.4.33",
        "replicaset": "zntydevdb",
        "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.33:27017,10.77.4.34:27017/z3dbus?authMechanism=SCRAM-SHA-1&replicaSet=zntydevdb"
    },
    "mongodb_cloud_jq": {
        "host": "10.77.4.37",
        "replicaset": "zntytestdb",
        "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.37:27017,10.77.4.38:27017,10.77.4.39:27017/z3dbus?authMechanism=SCRAM-SHA-1"
        # "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.37:27017,10.77.4.38:27017,10.77.4.39:27017/z3dbus?authMechanism=SCRAM-SHA-1&replicaSet=zntytestdb"
    },
    "mongodb_4_11": {
        "host": "10.77.4.37",
        "replicaset": "zntytestdb",
        "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.11:27017/z3dbus?authMechanism=SCRAM-SHA-1"
        # "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.37:27017,10.77.4.38:27017,10.77.4.39:27017/z3dbus?authMechanism=SCRAM-SHA-1&replicaSet=zntytestdb"
    },
    "mongodb_local": {
        "host": "127.0.0.1"
    },
}
