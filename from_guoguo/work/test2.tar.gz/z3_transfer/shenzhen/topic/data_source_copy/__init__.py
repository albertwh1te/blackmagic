# coding:utf-8
# Created by tao.liu at 2017/3/14

from pypinyin import lazy_pinyin
from utils import tools
import pymongo
from datetime import datetime
import os

class DataSourceCopy():
    def __init__(self, conn, database, table, args, curr_time):
        """
        实例化方法
        :param conn: mysql链接
        :param args:  参数
        """
        # print "args", args
        self.conn = conn
        self.tdatabase = database  # 目的库
        self.ttable = table  # 目的表
        # self.seconds = args["seconds"]
        self.starttime = args["starttime"]
        self.curr_time = curr_time
        # stockcode = args["stockcode"]
        # 获取目的表任务信息
        self.task_info = self._get_task_info()
        # 获取股票信息
        # self.stock_info = self._get_stock_info(stockcode) if stockcode else {}
        print "*****self.tdatabase=" + self.tdatabase
        print "*****self.ttable=" + self.ttable
        # print self.task_info

    def _get_task_info(self):
        """
        获取 任务 信息
        :return:
        """
        sql = """
            SELECT * FROM pgznty.z3_update_task a WHERE a.TDATABASE=%(tdatabase)s
            AND a.TTABLE = %(ttable)s
        """
        result = self.conn.fetchone(sql, {"tdatabase": self.tdatabase, 'ttable': self.ttable})
        return result if result else {}
        # print result

    def update_taks(self, sql):
        """
        执行 更新任务状态 的sql
        :param sql:
        :return:
        """
        print self.conn.execute(sql)

    def _make_where(self, key, alias_list, key_alias='a'):
        """
        生成sql where条件
        :param key:             str     股票相关代码 字段名
        :param alias_list:      list    过滤时间段表别名列表
        :param key_alias:       str     key参数对应的表(别)名
        :return:
        """
        where_str = ""
        # where_time_model = "%%s.MTIME>SUBDATE(now(),interval %s second)" % self.seconds
        less_curr = " %%(alias)s.MTIME<='%s'" % self.curr_time
        where_last_model = (
            "( %%(alias)s.MTIME>'%s' AND  %s )" % (self.task_info["LASTRUNTIME"], less_curr)) if self.task_info.get(
            "LASTRUNTIME",

            None) else less_curr
        where_last_model = (
            "( %%(alias)s.MTIME>'%s' AND  %s )" % (self.starttime, less_curr)) if self.starttime else where_last_model

        where_list = []
        # if key in self.stock_info:
        #     where_list.append(" AND %s.%s='%s'" % (key_alias, key, self.stock_info[key]))
        # 如果有秒数
        # if self.seconds:
        #     where_list.append(" AND (%s)" % " OR ".join([where_time_model % alias for alias in alias_list]))
        # # 如果有上次更新时间,而且没有传递股票代码
        # elif not self.stock_info:
        #     # where_list.append(where_last_model)

        where_list.append(" AND (%s)" % " OR ".join([where_last_model % {"alias": alias} for alias in alias_list]))

        if where_list:
            where_str = "".join(where_list)
        # print where_str,"stock_info"
        return where_str

    def make_Z3_SIGNAL_INFO_data(self, *args, **kwargs):
        """
        生成 概念板块样本表 表数据
        :return:
        """

        # where_str = self._make_where("SIGNAL_ID", ["a"])
        sql = """
        SELECT
          a.signal_id AS _id,
          a.signal_cname AS signal_cname,
          a.signal_desc AS signal_desc,
          a.assoicate_word as assoicate_word,
          a.status as status
        FROM pgznty.z3_signal_info a
        """
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)
        return results
        # results

    def make_Z3_FILTER_ENTRY_data(self, *args, **kwargs):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        # where_str = self._make_where("item_id", ["a"])
        sql = """
        SELECT
          a.item_id AS _id,
          a.item_name AS item_name,
          a.idx_cname AS idx_cname,
          a.idx_id AS idx_id,
          a.rule_desc AS rule_desc,
          a.order_num AS order_num
        FROM pgznty.z3_filter_entry a

        """
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)
        return results

    def make_Z3_IDX_INFO_data(self, *args, **kwargs):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        # where_str = self._make_where("idx_id", ["a"])
        sql = """
        SELECT
          a.idx_id AS _id,
          a.idx_cname AS idx_cname,
          a.idx_column AS idx_column,
          a.category AS category,
          a.idx_desc AS idx_desc,
          a.order_num,
          a.assoicate_word,
          a.idx_type,
          a.idx_unit,
          case when a.view_status = 1 then True else False end as view_status
        FROM pgznty.z3_idx_info a
        """
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)
        return results

    def make_Z3_SEARCH_SYMBOL_data(self, *args, **kwargs):
        """
        生成 概念板块样本表 表数据
        :return:
        """

        # where_str = self._make_where("SIGNAL_ID", ["a"])
        sql = """
           SELECT
             a.symbol_name AS symbol_name,
             a.symbol_id AS _id,
             a.assoicate_word AS assoicate_word
           FROM pgznty.z3_search_symbol a
           """
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)
        return results

    def make_Z3_SEARCH_UNIT_data(self, *args, **kwargs):
        """
        生成 概念板块样本表 表数据
        :return:
        """

        # where_str = self._make_where("SIGNAL_ID", ["a"])
        sql = """
           SELECT
             a.unit_name AS unit_name,
             a.unit_id AS _id
           FROM pgznty.z3_search_unit a
           """
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)
        return results

    def make_Z3_SW_INDUSTRY_data(self, *args, **kwargs):
        """
        生成 申万行业代码表表数据
        :return:
        """
        # where_str = self._make_where("SIGNAL_ID", ["a"])
        sql = """
        select a.INDU_CODE as _id
               ,a.INDU_NAME as industryname
               ,a.INDU_LEVEL as level
               ,ifnull(b.INDU_CODE,'') as parent_id
          from pgenius.PUB_INDU_REF a
          left join pgenius.PUB_INDU_REF b
            on a.parent_code = b.INNER_CODE 
           and b.ISVALID = 1 and b.INDU_SYS_MARK = 15
         where a.INDU_SYS_MARK = 15
           and a.ISVALID = 1
        """
        # % {"where_str": where_str}
        bs_data = self.conn.fetchall(sql)
        # return bs_data
        results = []
        for row in bs_data:
            tmp =row
            tmp["parent_id"] = None if tmp["parent_id"] == '' else tmp["parent_id"]
            # tmp["parent_id"] = row.get("parent_id", None)
            results.append(tmp)
        return results

    def make_STK_LTTMP_data(self, *args, **kwargs):
        """
        生成 概念板块样本表 表数据
        :return:
        """

        # where_str = self._make_where("INNER_CODE", ["a"])
        sql = """
        select a.INNER_CODE,a.STOCKCODE,b.CHNG_PCT_DAY,b.MKTCAP,b.TCLOSE,c.PUB_FLO_SHARE
          from pgenius.stk_code a
          join pgenius.ANA_STK_EXPR_IDX b
            on a.INNER_CODE = b.INNER_CODE and b.ENDDATE = date('2017-03-20')
          join (select distinct STOCKCODE,PUB_FLO_SHARE from pgenius.QW_GLO_INFO where  CUR_TRD_DATE = '20170320') c
            on a.STOCKCODE = c.STOCKCODE
          limit 10

        """
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)
        return results

    def make_Z3_TOPIC_INFO_data(self, offset, limit):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        where_str = self._make_where("_id", ["a"])
        topic_sql = """
        select a.section_code as _id
               ,a.section_name as topic_name
               ,a.SECTION_MEANING as topic_desc
               ,a.ctime as declare_date
              --  ,date_add(a.ctime ,INTERVAL -8 HOUR) as declare_date
               ,0 as equityNum
               ,b.dri_event as driven_event
               ,b.event_id
               ,0 as event_num
          from pgenius.PUB_SECTION_CODE a
          left join -- 获取dri_event
              (select t.section_code
                      ,t.dri_event
                      ,t.event_id
                      ,if(@section_code=section_code  ,@rank := @rank+1,@rank:=1) as rank
                      ,@section_code := section_code
                 from (select aa.section_code,bb.summary as dri_event
                              ,aa.guid as event_id,bb.declaredate
                          from pgenius.NEWS_SECTION aa, pgenius.NEWS_MAIN bb
                              ,pgenius.NEWS_CONTENT cc
                              ,(select @section_code:=0, @declaredate:='',@ctime:='',@mtime:='',@rank := 1) t
                         where aa.guid = bb.guid and aa.isvalid=1 and bb.isvalid=1
                            and aa.guid = cc.guid and cc.isvalid = 1
                         order by aa.section_code,bb.declaredate,bb.ctime,bb.mtime
                       )t
              ) b
          on a.section_code = b.section_code and b.rank = 1
      where a.sys_code=5
        and a.ISVALID=1
        and a.section_code not in (select distinct parent_code 
                                      from pgenius.PUB_SECTION_CODE
                                     where isvalid = 1 and sys_code = 5)
     --   and a.section_code = 400129955
       -- %(where_str)s
       Limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        # % {"where_str": where_str}
        topic_info = self.conn.fetchall(topic_sql)
        chng_list = self.get_chng_pct_data()

        # 获取事件个数，成分股数，当日涨跌幅和周涨跌幅,首字母
        tmp = {}
        results = []
        for row in topic_info:
            tmp = row
            tmp["topic_code"] = row["_id"]
            # 获取事件个数event_num和成分股数equityNum
            tmp.update(self.get_topic_info_fields(row["_id"]))

            # 获取主题名称首字母
            s_spell = self.get_pinyin_init(row.get("topic_name"))
            tmp["topic_spell_cap"] = s_spell

            # 获取chng_pct 和 chng_pct_week
            chng_data = chng_list.get(row["_id"], [{"chng_pct": 0.0, "chng_pct_week": 0.0}])
            lens = len(chng_data) - 1
            tmp["chng_pct_week"] = chng_data[lens]["chng_pct_week"]
            #增加一个嵌套空字段，供实时数据填充
            # tmp["topic_market"] = {}

            results.append(tmp)

        return results

    def make_Z3_TOPIC_INFO_EVENT_NUM_data(self, *args, **kwargs):
        """
        更新Z3_TOPIC_INFO(主题基本信息表) 的event_num（事件个数）字段
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        topics = list(db["Z3_TOPIC_INFO"].find({}, {"_id": 1}))
        results = []
        for row in topics:
            tmp = row
            tmp2 = self.get_topic_info_fields(row["_id"])
            tmp["event_num"] = tmp2.get("event_num", None)
            results.append(tmp)
        return results

    def make_Z3_TOPIC_XREF_NEWS02_data(self, topic_code, topic_name):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        # 获取子主题
        child = self.get_child_section_code(topic_code)
        topic_child = ','.join(str(i) for i in child)
        # 获取前100条新闻
        where_str = self._make_where("GUID", ["a", "b", "c"])
        # print where_str
        sql02 = """
          select  t.SECTION_LEVEL as section_level
                  ,t.DECLAREDATE AS declare_date
                  ,date_add(t.ctime ,INTERVAL -8 HOUR) as ctime
                  ,CONCAT(t.SECTION_CODE,",",t.GUID) as _id
                  ,t.SECTION_CODE AS topic_code
                  ,e.SECTION_NAME as topic_name
                  ,t.GUID AS guid
                  ,t.TITLE AS title
                  ,t.src_name AS src_name
              from
                  (select SECTION_CODE
                          ,GUID
                          ,TITLE
                          ,src_name
                          ,DECLAREDATE
                          ,t.ctime
                          ,t.SECTION_LEVEL
                          ,@rank:=@rank+1 as rank
                          ,@section_code:=section_code
                    from
                      (select DISTINCT 
                             %(topic_code)s as SECTION_CODE
                            ,a.SECTION_LEVEL
                            ,c.TITLE_MAIN AS TITLE
                            ,(select SRC_NAME from pgenius.PUB_INFOR_SRC 
                               where isvalid=1 and c.src_code=SRC_CODE) AS src_name
                            ,c.GUID
                            ,c.DECLAREDATE
                            ,(case when c.SRC_CODE = 155 
                                   then c.DECLAREDATE else c.ctime end) as ctime
                         --   ,c.ctime
                        from pgenius.PUB_SECTION_CODE a
                            ,pgenius.NEWS_SECTION b
                            ,pgenius.NEWS_MAIN c
                            ,pgenius.NEWS_CONTENT d
                            ,(select @section_code:=0,@rank:=0) t
                        where b.GUID=c.GUID
                          and a.section_code=b.section_code
                          and b.guid = d.guid
                          and a.SYS_CODE=5
                          and a.isvalid = 1 and b.isvalid = 1 
                          and c.ISVALID = 1 and d.ISVALID = 1
                         and a.section_code in (%(child_code)s)
                     --    and c.DECLAREDATE >= date_add(curdate(), INTERVAL -3 year)
                   --    %(where_str)s
                        order by a.SECTION_LEVEL asc,c.ctime desc
                      ) t
                      )t ,pgenius.PUB_SECTION_CODE e 
                  where t.SECTION_CODE = e.SECTION_CODE and t.rank<=100
            """ % {"child_code": topic_child, "topic_code": topic_code, "where_str": where_str}

        # 获取驱动新闻
        sql03 = """
           select section_level,declare_date
                 ,date_add(t.ctime ,INTERVAL -8 HOUR) as ctime
                 ,_id,topic_code,topic_name,guid
                  ,title,src_name
             from (         
                select CONCAT(t.section_code,",",t.guid) as _id
                      ,t.section_level
                      ,t.section_code as topic_code,t.section_name as topic_name
                      ,t.declare_date,t.ctime ,t.guid,t.title,t.src_name
                      ,if(@section_code=section_code  ,@rank := @rank+1,@rank:=1) as rank
                      ,@section_code := section_code
                 from (select a.section_level,a.section_code,a.section_name,c.declaredate as declare_date
                              ,c.ctime,c.guid,c.TITLE_MAIN as title
                              ,(select SRC_NAME from pgenius.PUB_INFOR_SRC 
                                 where isvalid=1 and c.src_code=SRC_CODE) AS src_name
                          from pgenius.PUB_SECTION_CODE a
                          join pgenius.NEWS_SECTION b
                            on a.SECTION_CODE = b.SECTION_CODE and b.ISVALID = 1
                          join pgenius.NEWS_MAIN c
                            on b.GUID = c.GUID and c.ISVALID = 1
                          join pgenius.NEWS_CONTENT d 
                            on b.guid = d.guid and d.ISVALID = 1
                          join (select @section_code:=0, @declaredate:='',@ctime:='',@mtime:='',@rank := 1) tmp
                            on 1 =1
                         where a.sys_code=5
                           and a.ISVALID=1
                           and a.SECTION_CODE = %(topic_code)s
                         order by a.section_code,c.declaredate,c.ctime,c.mtime
                       )t
              ) t
          where t.rank =1
        """ % {"topic_code": topic_code}

        # topics = self.get_child_section_code(topic_code)

        news_base = []
        # print "topic_childs", topic_child

        tmp = self.conn.fetchall(sql02)
        news_base.extend(tmp)

        # 加上驱动事件新闻
        dri_id = []
        dri_news =self.conn.fetchall(sql03)
        news_base.extend(dri_news)

        dri_id.extend(i["_id"] for i in dri_news)

        # 去重和加上是否驱动事件标识
        _tmp = []
        bs_data = []
        for row in news_base:
            if row["_id"] not in _tmp:
                _tmp.append(row["_id"])
                # row["is_driven_event"] = True if row["_id"] in dri_id else False
                bs_data.append(row)

        # 封装
        results = []
        for rr in bs_data:
            _tmp = {
                "_id": rr["_id"],
                "topic_code": rr["topic_code"],
                "topic_name": rr["topic_name"],
                "declare_date": rr["declare_date"],
                "src_name": rr["src_name"],
                "title": rr["title"],
                "guid": rr["guid"],
                "ctime": rr["ctime"]
                # "is_driven_event": rr["is_driven_event"]
            }
            results.append(_tmp)

        return results

    def make_Z3_TOPIC_XREF_NEWS_data(self, topic_code, topic_name):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        print topic_code, topic_name.encode('utf-8'), datetime.now()
        # 获取子主题
        child = self.get_child_section_code(topic_code)
        topic_child = ','.join(str(i) for i in child)
        # 获取前100条新闻
        where_str = self._make_where("GUID", ["a", "b", "c"])
        # print where_str
        sql02 = """
          select DISTINCT
                 CONCAT(%(topic_code)s,",",c.GUID) as _id
                , %(topic_code)s as topic_code
                ,'%(topic_name)s' as topic_name
                 ,a.SECTION_LEVEL as section_level
                ,c.TITLE_MAIN AS title
                ,e.SRC_NAME as src_name
                ,c.GUID as guid
                ,c.DECLAREDATE AS declare_date
                ,c.ctime
              --  ,date_add((case when c.SRC_CODE = 155 then c.DECLAREDATE else c.ctime end)
              --            ,INTERVAL -8 HOUR) as ctime  -- 巨灵信息的新闻日期单独处理
            from pgenius.PUB_SECTION_CODE a
            join pgenius.NEWS_SECTION b on a.SECTION_CODE = b.SECTION_CODE and b.ISVALID =1
            join pgenius.NEWS_MAIN c on b.GUID=c.GUID and c.ISVALID = 1
            join pgenius.NEWS_CONTENT d on b.guid = d.guid and d.ISVALID = 1
            join pgenius.PUB_INFOR_SRC e on c.src_code=e.SRC_CODE and e.ISVALID = 1
            where  a.isvalid = 1 
             and a.section_code in (%(child_code)s)
           %(where_str)s
            """ % {"child_code": topic_child, "topic_code": topic_code,
                   "where_str": where_str, "topic_name": topic_name.encode("utf-8")}



        # topics = self.get_child_section_code(topic_code)

        news_base = []
        # print "topic_childs", topic_child

        tmp = self.conn.fetchall(sql02)
        news_base.extend(tmp)

        # 封装
        results = []
        for rr in news_base:
            _tmp = {
                "_id": rr["_id"],
                "topic_code": rr["topic_code"],
                "topic_name": rr["topic_name"],
                "declare_date": rr["declare_date"],
                "src_name": rr["src_name"],
                "title": rr["title"],
                "guid": rr["guid"],
                "ctime": rr["ctime"]
                # "is_driven_event": rr["is_driven_event"]
            }
            results.append(_tmp)

        return results

    def make_Z3_TOPIC_XREF_EQUITY_data(self, offset, limit):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        # 获取主题信息
        sql = """
            select distinct a.section_code as topic_code
                   ,a.section_name as topic_name
              from pgenius.PUB_SECTION_CODE a
             where a.isvalid = 1
               and a.sys_code = 5
               and a.section_code not in (select distinct parent_code 
                                             from pgenius.PUB_SECTION_CODE
                                            where isvalid = 1 and sys_code = 5)
                """
        topics = self.conn.fetchall(sql)
        recommend_list = self.get_csv_recommend_list()

        ori_data = []
        for row in topics:
            stks = []
            ss = []

            stks.extend(self.get_topic_base_stks(row["topic_code"]))
            # print "topic_code", row["topic_code"], len(stks)
            for rr in stks:
                tmp = rr
                tmp["topic_code"] = row["topic_code"]
                tmp["topic_name"] = row["topic_name"]
                ori_data.append(tmp)

        # 计算股票关联的主题数
        # for row in ori_data:
            # key = row["symbol"]
        stock_list = []
        # stock_list.extend(ori_data)
        for i in ori_data:
            stock_list.append(i["symbol"])
        # 封装数据
        results = []
        for row in ori_data:
            recommend_index = recommend_list.get("%s:%s" % (row["topic_code"], row["inner_code_org"]), '0')
            recommend_index = recommend_index if recommend_index else 0

            s_data = {
                "_id": row["innerCode"] + "," + str(row["topic_code"]),
                "topic_code": row["topic_code"],
                "topic_name": row["topic_name"],
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
                "topic_mark": row["topic_mark"],
                "rela_topic_num": stock_list.count(row["symbol"]),
                "sw_indu_code": row["sw_indu_code"],
                "sw_indu_name": row["sw_indu_name"],
                "recommend_index": float(recommend_index)
            }
            results.append(s_data)

        return results

    def make_Z3_TOPIC_SAMPLE_data(self, topic_code, topic_name):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        results = []
        stks = []
        ss = []
        stks.extend(self.get_topic_base_stks(topic_code))

        for index, items in enumerate(stks):
            stktmp = {
                "innerCode": items["innerCode"],
                "symbol": items["symbol"],
                "name": items["name"]
            }
            ss.append(stktmp)

        tmp = {"_id": topic_code,
               "topic_name": topic_name,
               "samples": ss
               }

        results.append(tmp)
        return results

    def make_Z3_TOPIC_REAL_WEEK_data(self, *args, **kwargs):
        """
        生成 所有主题累计涨跌幅 表数据
        :return:
        """
        tmp = self.get_anyfreq_pct_data("WEEK")


        results = []
        rank_list = []
        _tmp = {}
        for row in tmp:
            key = row["topic_code"]
            _tmp.setdefault(key, [])
            _tmp[key].append(row["rank"])

        for rr in tmp:
            if _tmp.get(rr["topic_code"]) and max(_tmp.get(rr["topic_code"])):
                mr = max(_tmp.get(rr["topic_code"]))
            else:
                mr = 0

            if rr["rank"] == mr:
                r_list = {"_id": rr.get("topic_code"),
                          "trade_date": rr.get("trade_date"),
                          "topic_name": rr.get("topic_name"),
                          # "chng_pct_day": rr.get("chng_pct_day"),
                          "chng_pct_all": rr.get("chng_pct_all")}
                results.append(r_list)
        return results

    def make_Z3_TOPIC_HIS_QUOTE_data(self, period, topic_code):
        """
        生成 Z3_TOPIC_HIS_QUOTE(主题历史明细，会实时同步当日最新数据) 表数据
        :return:
        """
        print period, datetime.now()

        # 获取基础数据
        bs_data = self.get_anyfreq_pct_data_bycode(period, topic_code)

        results = []
        for row in bs_data:
            # topic_data = bs_data.get(rr["topic_code"])
            # for row in topic_data:
            r_list = {"topic_code": row.get("topic_code"),
                      "trade_date": row.get("trade_date"),
                      "topic_name": row.get("topic_name"),
                      "period": row.get("time_point"),
                      "topic_return_rate": row.get("chng_pct_all"),
                      "hs300_return_rate": row.get("hs300_return_rate")}
            results.append(r_list)

        return results

    def make_Z3_INDEX_HIS_QUOTE3_data(self, offset, limit):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        where_str = self._make_where("symbol", ["a", "b"])
        sql = """
        SELECT a.INDX_CODE as symbol
                  ,REPLACE(REPLACE(trim(a.INDX_SNAME),'(深)',''),'(沪)','') as name
          --  ,b.tradedate as trade_date
                  ,cast(DATE_FORMAT(b.tradedate,'%%Y-%%m-%%d 00:00:00') as datetime)  as trade_date
                  ,IFNULL(b.TCLOSE,0.0) as indx_price
                  ,IFNULL(b.CHNG_PCT,0.0) as indx_chng
              from 	pgenius.INDX_GEN_INFO a
              join pgenius.INDX_MKT b
                on a.INNER_CODE = b.INNER_CODE and b.isvalid = 1
             where a.isvalid = 1
               and a.INDX_CODE in ('000001','399001','399005','000016','399905','399006','000852','000300','000906')
               %(where_str)s
              Limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)

        return results
        # print results

    def make_Z3_INDEX_HIS_QUOTE_data(self, offset, limit):
        """
        生成 概念板块样本表 表数据
        :return:
        """
        where_str = self._make_where("symbol", ["a", "b"])
        sql = """
        SELECT CONCAT(case when a.INDX_CODE in ('000001','000016','000852','000300','000906') 
                   then CONCAT(a.INDX_CODE,'.SH')
                   else CONCAT(a.INDX_CODE,'.SZ')
                    end,'-',date_format(b.tradedate,'%%Y%%m%%d')) as _id
               ,a.INDX_CODE as symbol
               ,case when a.INDX_CODE in ('000001','000016','000852','000300','000906') 
                   then CONCAT(a.INDX_CODE,'.SH')
                   else CONCAT(a.INDX_CODE,'.SZ')
                    end as innerCode 
               ,REPLACE(REPLACE(trim(a.INDX_SNAME),'(深)',''),'(沪)','') as name
          --  ,b.tradedate as trade_date
               ,cast(date_format(b.tradedate,'%%Y%%m%%d') as SIGNED) as trade_date
            --   ,cast(DATE_FORMAT(b.tradedate,'%%Y-%%m-%%d 00:00:00') as datetime) as trade_date
               ,IFNULL(b.TCLOSE,0.0) as indx_price
               ,IFNULL(b.CHNG_PCT,0.0) as indx_chng
              from 	pgenius.INDX_GEN_INFO a
              join pgenius.INDX_MKT b
                on a.INNER_CODE = b.INNER_CODE and b.isvalid = 1
             where a.isvalid = 1
               and a.INDX_CODE in ('000001','399001','399005','000016','399905','399006','000852','000300','000906')
               %(where_str)s
              Limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "limit": limit, "offset": offset}
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql)

        return results
        # print results

    def make_Z3_STK_MKT_DAY_data(self, offset, limit, code, type):
        """
        生成 股票日行情表（ANA_STK_MKT_DAY） 表数据
        :return:
        """
        print type, code, datetime.now()
        # 获取股票数据
        if type == "stk":
            where_str = self._make_where("symbol", ["a", "b", "c"])
            sql = """
            select
                  CONCAT(case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                          when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                           end ,'-',date_format(b.TRADEDATE,'%%Y%%m%%d')) as _id
                 ,a.STOCKCODE as symbol
                 ,case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                          when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                           end as innerCode
                 ,IFNULL(d.STOCKSNAME,a.STOCKSNAME) as name
                 ,cast(date_format(b.TRADEDATE,'%%Y%%m%%d') as SIGNED) as trade_date
                 ,b.LCLOSE       as    prev_close_px
                 ,b.TOPEN        as    open_px
                 ,b.THIGH        as    high_px
                 ,b.TLOW         as    low_px
                 ,b.TCLOSE       as    close_px
                 ,b.FAC_LCLOSE   as    ex_prev_close_px
                 ,b.FAC_TOPEN    as    ex_open_px
                 ,b.FAC_THIGH    as    ex_high_px
                 ,b.FAC_TLOW     as    ex_low_px
                 ,b.FAC_TCLOSE   as    ex_close_px
                 ,b.CHNG         as    chg
                 ,b.CHNG_PCT     as    chg_pct
                 ,b.AVG_PRC      as    price_avg
                 ,b.TVOLUME      as    volume
                 ,b.TVALUE       as    amount
                 ,if(b.TRADEDATE BETWEEN date_add(a.LIST_ENDDATE ,INTERVAL -7 day ) 
                                 and a.LIST_ENDDATE,0,TRADE_STATUS) as trade_status
                 ,b.TCLOSE * ifnull(c.FL_ASHR,c.FL_SHR) as mtkcap_a
                 ,case when b.TOPEN = b.THIGH and b.TOPEN = b.TLOW and b.TOPEN = b.TCLOSE
                       and IFNULL(b.TVOLUME,0) <> 0 and b.CHNG_PCT > 4
                       then true else false end  as limit_up_non_open
                  ,case when b.TOPEN = b.THIGH and b.TOPEN = b.TLOW and b.TOPEN = b.TCLOSE
                       and IFNULL(b.TVOLUME,0) <> 0 and b.CHNG_PCT < -4
                       then true else false end as limit_down_non_open
             from pgenius.STK_CODE a
             join pgenius.ANA_STK_MKT_DAY b
               on a.STOCKCODE = b.STOCKCODE and b.isvalid = 1
              and ifnull(a.LIST_DATE,'1900-01-01') <= b.TRADEDATE 
              and ifnull(a.LIST_ENDDATE,'2099-12-31') >= b.TRADEDATE
             join pgenius.STK_SHR_STRU c
               on a.COMCODE = c.COMCODE and c.isvalid = 1
              and c.CHANGEDATE = (select max(CHANGEDATE)
                                         from pgenius.STK_SHR_STRU
                                    where COMCODE = a.COMCODE and CHANGEDATE <= b.TRADEDATE
                                      and ISVALID = 1
                                    )
             left join pgenius.STK_SNAME_CHNG d
               on a.INNER_CODE = d.INNER_CODE and d.isvalid = 1
              and d.CHANGEDATE = (select max(CHANGEDATE)
                                    from pgenius.STK_SNAME_CHNG
                                   where INNER_CODE = a.INNER_CODE and CHANGEDATE <= b.TRADEDATE
                                     and ISVALID = 1)                       
            where a.isvalid = 1 
              and a.STK_TYPE_REF = 1 
              and a.STOCKCODE IS NOT NULL
              and a.TRADE_MKT_REF IS NOT NULL
               and year(b.TRADEDATE) > 2004
            --   and b.TRADEDATE < '2016-01-01'
               and a.stockcode = '%(code)s'
               %(where_str)s
              order by a.STOCKCODE, b.TRADEDATE
            """ % {"where_str": where_str,
                   "code": code}
            bs_data = self.conn.fetchall(sql)

            # 计算下一交易日交易标识
            max_idx = len(bs_data) - 1
            results = []
            for index, datas in enumerate(bs_data):
                tmp = datas
                tmp["trade_next_status"] = None if index == max_idx \
                else bs_data[index+1].get("trade_status")
                # print tmp
                results.append(tmp)

        # 获取指数数据
        elif type == "idx":
            where_str = self._make_where("symbol", ["a", "b"])
            sql = """
                SELECT a.INDX_CODE as symbol
                   ,case when a.INDX_CODE in ('000001','000016','000852','000300','000906') 
                       then CONCAT(a.INDX_CODE,'.SH')
                       else CONCAT(a.INDX_CODE,'.SZ')
                        end as innerCode 
                   ,CONCAT(case when a.INDX_CODE in ('000001','000016','000852','000300','000906') 
                       then CONCAT(a.INDX_CODE,'.SH')
                       else CONCAT(a.INDX_CODE,'.SZ')
                        end,'-',date_format(b.TRADEDATE,'%%Y%%m%%d')) as _id
                   ,REPLACE(REPLACE(trim(a.INDX_SNAME),'(深)',''),'(沪)','') as name
                   ,cast(date_format(b.TRADEDATE,'%%Y%%m%%d') as SIGNED) as trade_date
                   ,b.TOPEN as open_px
                   ,b.TCLOSE as close_px
                   ,b.THIGH as high_px
                   ,b.TLOW as low_px
                   ,b.TVOLUME as volume
                   ,b.TVALUE as amount
                   ,b.LCLOSE as prev_close_px
                   ,b.CHNG as chg
                   ,b.CHNG_PCT as chg_pct
                  from 	pgenius.INDX_GEN_INFO a
                  join pgenius.INDX_MKT b
                    on a.INNER_CODE = b.INNER_CODE and b.isvalid = 1
                 where a.isvalid = 1
                   and a.INDX_CODE  = '%(code)s'
                   and year(b.tradedate) > '2004'
                %(where_str)s         
                        """ % {"code": code, "where_str": where_str}

            results = self.conn.fetchall(sql)

        return results

    def make_Z3_STK_MKT_DAY_ztss_data(self, offset, limit, code, type):
	"""
        日行情表暂停上市的股票数据获取
        :return:
        """
	print "stk", code
	sql = """
	   select CONCAT(case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                                when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                                 end ,'-',date_format(a.ENDDATE,'%%Y%%m%%d')) as _id
                 ,IFNULL(e.STOCKSNAME,a.STOCKSNAME) as name
	         ,case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                        when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                        end as innerCode
                 ,a.STOCKCODE as symbol
                 , cast(date_format(a.ENDDATE,'%%Y%%m%%d') as SIGNED) as trade_date
                 ,c.TCLOSE       as    prev_close_px
                 ,c.TCLOSE        as    open_px
                 ,c.TCLOSE        as    high_px
                 ,c.TCLOSE         as    low_px
                 ,c.TCLOSE       as    close_px
                 ,c.FAC_TCLOSE   as    ex_prev_close_px
                 ,c.FAC_TCLOSE    as    ex_open_px
                 ,c.FAC_TCLOSE    as    ex_high_px
                 ,c.FAC_TCLOSE     as    ex_low_px
                 ,c.FAC_TCLOSE   as    ex_close_px
                 ,null        as    chg
                 ,null     as    chg_pct
                 ,null      as    price_avg
                 ,0      as    volume
                 ,0       as    amount
                 ,3 as trade_status
                 ,c.TCLOSE * ifnull(d.FL_ASHR,d.FL_SHR) as mtkcap_a
		,False as limit_up_non_open
                 ,False as limit_down_non_open
                 ,null as trade_next_status
          from (
                 select c.stockcode,c.stocksname,
                       a.ENDDATE,b.tradedate ,c.TRADE_MKT_REF,
                       c.INNER_CODE,c.COMCODE
                 from pgenius.PUB_EXCHANGE_CALENDAR a
                 join pgenius.stk_code c
                   on c.TRADE_MKT_REF = a.MKT_TYPE 
                  and a.ENDDATE >= IFNULL(c.LIST_DATE,'1900-01-01')
                  and a.ENDDATE < IFNULL(c.LIST_ENDDATE,'2099-12-31')
                 left join pgenius.ana_stk_mkt_day b 
                   on 1= 1 and b.stockcode = c.stockcode 
                  and a.ENDDATE = b.tradedate and b.isvalid = 1 
                where a.ISVALID = 1 and a.OPEN_CLOSE = 1
                  and a.ENDDATE = CURDATE()
                  and c.STATUS_TYPE_REF=2
                 and c.stockcode = '%(code)s'
               ) a 
          join pgenius.ana_stk_mkt_day c
            on a.STOCKCODE = c.STOCKCODE and c.isvalid = 1 
            and c.TRADEDATE = (select max(tradedate) from pgenius.ana_stk_mkt_day 
                                 where stockcode = a.stockcode and TRADEDATE <= a.ENDDATE and isvalid = 1)
          join pgenius.STK_SHR_STRU d
             on a.COMCODE = d.COMCODE and d.isvalid = 1
            and d.CHANGEDATE = (select max(CHANGEDATE)
                                  from pgenius.STK_SHR_STRU
                                 where COMCODE = a.COMCODE and CHANGEDATE <= a.ENDDATE
                                   and ISVALID = 1)
         left join pgenius.STK_SNAME_CHNG e
                        on a.INNER_CODE = e.INNER_CODE and e.isvalid = 1
                       and e.CHANGEDATE = (select max(CHANGEDATE)
                                             from pgenius.STK_SNAME_CHNG
                                            where INNER_CODE = a.INNER_CODE and CHANGEDATE <= a.ENDDATE
                                              and ISVALID = 1)  
          where a.tradedate is null
	""" % {"code": code}
        
	if type == 'stk':
            bs_data = self.conn.fetchall(sql)

            results = bs_data
	else:
            results = []
        return results
    
    def make_Z3_STK_MKT_DAY_TRADE_NEXT_STATUS_data(self, offset, limit, data, type):
        """
        处理 股票日行情表（ANA_STK_MKT_DAY）的TRADE_NEXT_STATUS 字段
        :return:
        """
        # 获取下一交易日交易字段为空的数据
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

	#curr_date = int(datetime.today().strftime("%Y%m%d"))	

        #bs_data = list(db.Z3_STK_MKT_DAY.find({
        #    "trade_next_status": None,
        #    "trade_status": {"$exists": True},
        #    "trade_date": {"$lt": curr_date}
        #},
        # {"_id": 1, "innerCode": 1, "trade_date": 1, "symbol": 1, "name": 1},
        #))

        # 修改下一交易日标识字段
        #results = []
        #for row in bs_data:
        #    tmp = {}
        #    next_data = list(db.Z3_STK_MKT_DAY.find(
        #        {"innerCode": row.get("innerCode"),
        #         "trade_date": {"$gt": row.get("trade_date")}},
        #        {"trade_status": 1},
        #        sort=[("trade_date", pymongo.ASCENDING)],
        #        limit=1
        #    ))
        #    tmp = {
        #        "_id": row.get("_id"),
        #        "innerCode": row.get("innerCode"),
        #        "symbol": row.get("symbol"),
        #        "name": row.get("name"),
        #        "trade_date": row.get("trade_date"),
        #        "trade_next_status": None if len(next_data) == 0 else next_data[0].get("trade_status")
        #    }
	results = []
        # 获取输入数据（data)的前一天数据
        for row in data:
            bs_data  = list(db.Z3_STK_MKT_DAY.find({
                # "trade_next_status": None,
                # "trade_status": {"$exists": True},
                "innerCode": row.get("innerCode"),
                "trade_date": {"$lt": row.get("trade_date")}
            },
	     {"_id": 1, "innerCode": 1, "trade_status": 1},
             sort=[("trade_date", pymongo.DESCENDING)],
             limit=1
            ))
	    
	    # 将data的 trade_status 赋值给前一天的数据 trade_next_status
            tmp = {
                "_id": bs_data[0]["_id"],
                "innerCode": bs_data[0]["innerCode"],
                "trade_next_status": row.get("trade_status", None)
            }
            results.append(tmp)
            #print tmp

        return results

    def make_Z3_STK_MKT_WEEK_data(self, offset, limit, stockcode):
        """
        生成 股票周行情表（Z3_STK_MKT_WEEK） 表数据
        :return:
        """
        # print "offset", offset, limit
        where_str = self._make_where("symbol", ["a", "b", "c"])
        # data_date = '2015-01-01'
        sql = """
         select case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                      when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                       end as innerCode
            ,CONCAT(case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                          when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                           end ,'-',date_format(b.ENDDATE,'%%Y%%m%%d')) as _id
           -- ,b.ENDDATE as end_date
            ,cast(date_format(b.ENDDATE,'%%Y%%m%%d') as SIGNED) as end_date
            ,a.STOCKCODE as symbol
            ,b.FIRST_TRADE_DATE as first_trade_date
            ,b.LAST_TRADE_DATE as last_trade_date
            ,b.THIGH_DATE as high_px_date
            ,b.TLOW_DATE as low_px_date
            ,b.FAC_THIGH_DATE as ex_high_px_date
            ,b.FAC_TLOW_DATE as ex_low_px_date
            ,b.TRADE_DAYS as trade_days
            ,b.LCLOSE as prev_close_px
            ,b.TOPEN as open_px
            ,b.THIGH as high_px
            ,b.TLOW as low_px
            ,b.TCLOSE as close_px
            ,b.FAC_LCLOSE as ex_prev_close_px
            ,b.FAC_TOPEN as ex_open_px
            ,b.FAC_THIGH as ex_high_px
            ,b.FAC_TLOW as ex_low_px
            ,b.FAC_TCLOSE as ex_close_px
            ,b.AVG_PRC as price_avg
            ,b.CHNG as ex_chg
            ,b.CHNG_PCT as chg_pct
            ,b.EXCHR as exchr
            ,b.TVOLUME as volume
            ,b.TVALUE as amount
        from pgenius.STK_CODE a
        join pgenius.ANA_STK_MKT_WEEK b
          on a.INNER_CODE = b.INNER_CODE and b.ISVALID = 1
       where a.ISVALID = 1
         and a.STOCKCODE not like '2%%' and a.STOCKCODE not like '9%%'
         and year(b.ENDDATE) > 2004
         and a.stockcode = '%(stockcode)s'
      --   and a.stockcode > 'N14542'
       --  Limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "limit": limit, "offset": offset, "stockcode": stockcode}

        results = self.conn.fetchall(sql)

        return results
        # print results

    def make_Z3_STK_MKT_WEEK02_data(self, offset, limit, stockcode, type):
        """
        生成 股票周行情表（Z3_STK_MKT_WEEK） 表数据
        :return:
        """
        if type == "stk":
            # print "offset", offset, limit
            where_str = self._make_where("symbol", ["a", "b", "c"])
            # data_date = '2015-01-01'
            sql = """
             select case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                          when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                           end as innerCode
                ,CONCAT(case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                              when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                               end ,'-',date_format(b.ENDDATE,'%%Y%%m%%d')) as _id
               -- ,b.ENDDATE as end_date
                ,cast(date_format(b.ENDDATE,'%%Y%%m%%d') as SIGNED) as end_date
                ,a.STOCKCODE as symbol
                ,cast(date_format(b.FIRST_TRADE_DATE,'%%Y%%m%%d') as SIGNED) as first_trade_date
                ,cast(date_format(b.LAST_TRADE_DATE,'%%Y%%m%%d') as SIGNED) as last_trade_date
                ,cast(date_format(b.THIGH_DATE,'%%Y%%m%%d') as SIGNED) as high_px_date
                ,cast(date_format(b.TLOW_DATE,'%%Y%%m%%d') as SIGNED) as low_px_date
                ,cast(date_format(b.FAC_THIGH_DATE,'%%Y%%m%%d') as SIGNED) as ex_high_px_date
                ,cast(date_format(b.FAC_TLOW_DATE,'%%Y%%m%%d') as SIGNED) as ex_low_px_date
                ,b.TRADE_DAYS as trade_days
                ,b.LCLOSE as prev_close_px
                ,b.TOPEN as open_px
                ,b.THIGH as high_px
                ,b.TLOW as low_px
                ,b.TCLOSE as close_px
                ,b.FAC_LCLOSE as ex_prev_close_px
                ,b.FAC_TOPEN as ex_open_px
                ,b.FAC_THIGH as ex_high_px
                ,b.FAC_TLOW as ex_low_px
                ,b.FAC_TCLOSE as ex_close_px
                ,b.AVG_PRC as price_avg
                ,b.CHNG as ex_chg
                ,b.CHNG_PCT as chg_pct
                ,b.EXCHR as exchr
                ,b.TVOLUME as volume
                ,b.TVALUE as amount
            from pgenius.STK_CODE a
            join pgenius.ANA_STK_MKT_WEEK b
              on a.INNER_CODE = b.INNER_CODE and b.ISVALID = 1
           where a.ISVALID = 1
             and year(b.ENDDATE) > 2004
             and a.stockcode = '%(stockcode)s'
          --   and a.stockcode > 'N14542'
           --  Limit %(offset)s,%(limit)s
            """ % {"where_str": where_str, "limit": limit, "offset": offset, "stockcode": stockcode}

            results = self.conn.fetchall(sql)

        return results
        # print results

    def make_Z3_STK_MKT_MONTH_data(self, offset, limit):
        """
        生成 股票月行情表（Z3_STK_MKT_MONTH） 表数据
        :return:
        """
        # print "offset", offset, limit
        where_str = self._make_where("symbol", ["a", "b", "c"])
        # data_date = '2015-01-01'
        stockcode = ""
        sql = """
         select case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                    when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                       end as innerCode
              ,b.ENDDATE as end_date
                ,b.STOCKCODE as symbol
                ,b.FIRST_TRADE_DATE as first_trade_date
                ,b.LAST_TRADE_DATE as last_trade_date
                ,b.THIGH_DATE as high_px_date
                ,b.TLOW_DATE as low_px_date
                ,b.FAC_THIGH_DATE as ex_high_px_date
                ,b.FAC_TLOW_DATE as ex_low_px_date
                ,b.TRADE_DAYS as trade_days
                ,b.LCLOSE as prev_close_px
                ,b.TOPEN as open_px
                ,b.THIGH as high_px
                ,b.TLOW as low_px
                ,b.TCLOSE as close_px
                ,b.FAC_LCLOSE as ex_prev_close_px
                ,b.FAC_TOPEN as ex_open_px
                ,b.FAC_THIGH as ex_high_px
                ,b.FAC_TLOW as ex_low_px
                ,b.FAC_TCLOSE as ex_close_px
                ,b.AVG_PRC as price_avg
                ,b.CHNG as ex_chg
                ,b.CHNG_PCT as chg_pct
                ,b.EXCHR as exchr
                ,b.TVOLUME as volume
                ,b.TVALUE as amount
            from pgenius.stk_code a
            join pgenius.ana_stk_mkt_month b
              on a.INNER_CODE = b.INNER_CODE and b.ISVALID = 1
           where a.ISVALID = 1
             and a.STOCKCODE not like '2%%' and a.STOCKCODE not like '9%%'
             and year(b.ENDDATE) > 2004
       --      and a.stockcode = '%(stockcode)s'
           Limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "limit": limit, "offset": offset, "stockcode": stockcode}

        results = self.conn.fetchall(sql)
        return results
        # print results

    def make_Z3_STK_MKT_MONTH02_data(self, offset, limit):
        """
        生成 股票月行情表（Z3_STK_MKT_MONTH） 表数据
        :return:
        """
        # print "offset", offset, limit
        where_str = self._make_where("symbol", ["a", "b", "c"])
        # data_date = '2015-01-01'
        stockcode = ""
        sql = """
         select case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                    when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                       end as innerCode
              ,CONCAT(case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                              when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                               end ,'-',date_format(b.ENDDATE,'%%Y%%m%%d')) as _id
               -- ,b.ENDDATE as end_date
                ,cast(date_format(b.ENDDATE,'%%Y%%m%%d') as SIGNED) as end_date
                ,b.STOCKCODE as symbol
                ,cast(date_format(b.FIRST_TRADE_DATE,'%%Y%%m%%d') as SIGNED) as first_trade_date
                ,cast(date_format(b.LAST_TRADE_DATE,'%%Y%%m%%d') as SIGNED) as last_trade_date
                ,cast(date_format(b.THIGH_DATE,'%%Y%%m%%d') as SIGNED) as high_px_date
                ,cast(date_format(b.TLOW_DATE,'%%Y%%m%%d') as SIGNED) as low_px_date
                ,cast(date_format(b.FAC_THIGH_DATE,'%%Y%%m%%d') as SIGNED) as ex_high_px_date
                ,cast(date_format(b.FAC_TLOW_DATE,'%%Y%%m%%d') as SIGNED) as ex_low_px_date
                ,b.TRADE_DAYS as trade_days
                ,b.LCLOSE as prev_close_px
                ,b.TOPEN as open_px
                ,b.THIGH as high_px
                ,b.TLOW as low_px
                ,b.TCLOSE as close_px
                ,b.FAC_LCLOSE as ex_prev_close_px
                ,b.FAC_TOPEN as ex_open_px
                ,b.FAC_THIGH as ex_high_px
                ,b.FAC_TLOW as ex_low_px
                ,b.FAC_TCLOSE as ex_close_px
                ,b.AVG_PRC as price_avg
                ,b.CHNG as ex_chg
                ,b.CHNG_PCT as chg_pct
                ,b.EXCHR as exchr
                ,b.TVOLUME as volume
                ,b.TVALUE as amount
            from pgenius.stk_code a
            join pgenius.ana_stk_mkt_month b
              on a.INNER_CODE = b.INNER_CODE and b.ISVALID = 1
           where a.ISVALID = 1
             and a.STOCKCODE not like '2%%' and a.STOCKCODE not like '9%%'
             and year(b.ENDDATE) > 2004
             and a.STOCKCODE in ('300050','002252','002024','000002','000001','000829','000009','600000','600019','600009')
       --      and a.stockcode = '%(stockcode)s'
           Limit %(offset)s,%(limit)s
        """ % {"where_str": where_str, "limit": limit, "offset": offset, "stockcode": stockcode}

        results = self.conn.fetchall(sql)
        return results
        # print results

    def get_child_section_code(self, pid, **kwargs):
        """
        获取一个主题的所有子节点主题（含自身）
        :return:
        """
        tmp = [pid, ]
        sql = """
        select section_code from pgenius.PUB_SECTION_CODE a
         where PARENT_CODE = %(pid)s
           and a.isvalid = 1 and a.sys_code = 5
        """ % {"pid": pid}
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql, {"pid": pid})

        for row in results:
            sub_id = row["section_code"]
            tmp.extend(self.get_child_section_code(sub_id))

        return tmp

    def get_topic_base_stks(self, topic_code, **kwargs):
        """
        获取一个主题的所有子节点主题（含自身）
        :return:
        """
        # 获取所有子主题以及股票信息
        child = self.get_child_section_code(topic_code)
        sub_seccode = ','.join(str(i) for i in child)

        # 获取股票信息
        where_str = self._make_where("symbol", ["a", "b", "c"])
        # print where_str
        sql02 = """
              select distinct a.SECTION_CODE as section_code
                     ,a.section_name as topic_name
                     ,CONCAT(c.stockcode,case when c.TRADE_MKT like '上海%%' then '.SH'
                                              when c.TRADE_MKT like '深圳%%' then '.SZ'
                                               end) as innerCode
                     ,c.stockcode as symbol
                     ,c.stocksname as name
                     ,if(b.COM_MENT='',null,b.COM_MENT) as topic_mark
                     ,0 as rela_topic_num
                     ,e.INDU_CODE as sw_indu_code
                     ,e.INDU_NAME as sw_indu_name
                     ,cast(0.0 as DECIMAL )as recommend_index
                     ,c.INNER_CODE as inner_code_org
                 from pgenius.PUB_SECTION_CODE a
                 join pgenius.PUB_SECTION_REL b
                   on a.SECTION_CODE = b.SECTION_CODE and b.ISVALID = 1
                 join pgenius.STK_CODE c
                   on c.inner_code = b.inner_code and c.ISVALID = 1
                  and c.stk_type_ref = 1 and c.status_type_ref in (1,2)
                  and c.TRADE_MKT_REF IS NOT NULL
                 left join  -- 获取行业代码和行业名称
                      (SELECT aa.COMCODE,bb.indu_code ,bb.INDU_NAME
                         from pgenius.STK_COM_PROFILE aa
                         join pgenius.PUB_INDU_REF bb
                           on aa.sw_indu_code_2014_1 = bb.INDU_CODE and bb.INDU_SYS_MARK = 15
                        where aa.ISVALID = 1 and bb.ISVALID = 1
                      ) e
                   on c.COMCODE = e.COMCODE
                where a.isvalid = 1
                  and a.sys_code = 5
                --  and c.stockcode in ('002774','002851')
                  and a.SECTION_CODE in (%(code)s)        
               --   and (case when a.section_name not like '%%解禁股%%' 
               --              then ifnull(b.EN_TIME,'1900-01-01')<=cast(now() as date) 
               --              else '1900-01-01'<=cast(now() as date) end)
                  and ifnull(b.REJE_TIME  ,'2999-12-31')>cast(now() as date)
            --    %(where_str)s
              """ % {"code": sub_seccode, "where_str": where_str}


        stocks = self.conn.fetchall(sql02)

        bs_data = []
        for row in stocks:
            tmp1 = {
                "innerCode": row["innerCode"],
                "symbol": row["symbol"],
                "name": row["name"],
                "topic_mark": row["topic_mark"],
                "rela_topic_num": row["rela_topic_num"],
                "sw_indu_code": row["sw_indu_code"],
                "sw_indu_name": row["sw_indu_name"],
                "recommend_index": row["recommend_index"],
                "inner_code_org": row["inner_code_org"],
            }
            bs_data.append(tmp1)

        # 按股票代码去重
        _tmp = []
        _tmp3 = []
        for row2 in bs_data:
            if row2["symbol"] not in _tmp:
                _tmp3.append(row2)
                _tmp.append(row2["symbol"])
        results = _tmp3
        return results

    def get_topic_info_fields(self, topic_code, **kwargs):
        """
        获取一个主题的所有子节点主题（含自身）
        :return:
        """
        child_list = self.get_child_section_code(topic_code)
        child_code = ",".join(str(i) for i in child_list)
        # print "topics", topics
        # 计算 event_num(近一年事件数)
        enum_sql = """
          select count(distinct c.GUID) as event_num
            from pgenius.PUB_SECTION_CODE a
                ,pgenius.NEWS_SECTION b
                ,pgenius.NEWS_MAIN c
                ,pgenius.NEWS_CONTENT d
            where b.GUID=c.GUID
              and a.section_code=b.section_code
              and b.guid = d.guid
              and a.SYS_CODE=5
              and a.isvalid = 1 and b.isvalid = 1 
              and c.ISVALID = 1 and d.ISVALID = 1
             and a.section_code in (%(child_code)s)
             and c.DECLAREDATE >= date_add(curdate(), INTERVAL -1 year)+1
        """ % {"child_code": child_code}
        results = self.conn.fetchone(enum_sql)

        # 计算equityNum 字段
        eqnum = len(self.get_topic_base_stks(topic_code))
        results["equityNum"] = eqnum
        # eqnum_sql = """
        #     select count(distinct a.INNER_CODE)  as equityNum
        #       from pgenius.PUB_SECTION_REL a
        #       join pgenius.STK_CODE c
        #         on c.inner_code = a.inner_code and c.ISVALID = 1
        #        and c.stk_type_ref = 1 and c.STOCKCODE IS NOT NULL
        #        and c.status_type_ref in (1,2)
        #         and c.TRADE_MKT_REF IS NOT NULL
        #      where a.ISVALID=1
        #        and ifnull(a.EN_TIME,'1900-01-01')<=cast(now() as date)
        #        and ifnull(a.REJE_TIME  ,'2999-12-31')>cast(now() as date)
        #        and a.section_code in (%(child_code)s)
        #        """% {"child_code": child_code}
        #
        # results.update(self.conn.fetchone(eqnum_sql))

        return results

    def get_csv_recommend_list(self, *args, **kwargs):
        """
        更新Z3_TOPIC_RELATED (主题股票关系表) 的股票推荐指数（recommend_index）字段
        数据源为csv文件
        :return:
        """
        date = datetime.today().strftime('%Y%m%d')
        # csv_file = r'E:\project2017\znty\res_df_scores_%s.csv' % date
        # csv_file = r'/tmp/topic/stks_recommend_csv/data/res_df_scores.csv'
        csv_file = r'/data/App/z3_transfer/shenzhen/topic/stks_recommend_csv/data/res_df_scores.csv'
        if os.path.exists(csv_file):
            with open(csv_file) as f:
                index = 0
                results = {}
                for row in f.readlines():
                    if index:
                        row = row.replace("\n", "")
                        row = row.split(",")
                        key = "%s:%s" % (row[0], row[1])
                        results[key] = row[2]
                    index += 1
        else:
            results = {}
        return results

    def get_pinyin_init(self, s_str, **kwargs):
        """
        更新Z3_TOPIC_RELATED (主题股票关系表) 的拼音首字母字段
        :return:
        """
	sstr = s_str.replace("长".decode("utf-8"), "C")
        ssstr = sstr.replace("重庆".decode("utf-8"), "C庆".decode("utf-8"))
	ssstr = ssstr.replace("重组".decode("utf-8"), "C组".decode("utf-8"))
        zm = []
        for i in ssstr:
            if u'\u4e00' <= i <= u'\u9fff':
                tmp = lazy_pinyin(i)[0]
            else:
                tmp = i
            zm.append(tmp[0].upper())

        result = "".join(a for a in zm)
        # ssstr = s_str.decode("utf-8")
        # ssstr = s_str
        # if ssstr[0] == "长".decode("utf-8"):
        #   result = "C"
        # elif ssstr[:2] == "重庆".decode("utf-8"):
        #     result = "C"
        # else:
        #     s_list = []
        #     s_list = lazy_pinyin(ssstr)
        #     r_str = ""
        #     r_str = s_list[0]
        #     result = r_str[0].upper()
        return result

    def get_anyfreq_pct_data(self, time_point, **kwargs):
        """
        生成 Z3_TOPIC_HIS_QUOTE(主题历史明细，会实时同步当日最新数据) 表数据
        :return:
        """
        where_str = self._make_where("topic_code", ["a", "b", "c"])
        date_condition = ""
        where_condition02 = ""
        if time_point == "M01":
            # days = 19
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -1 MONTH)+1 and CURDATE()"
            where_condition02 = ""
        elif time_point == "M03":
            # days = 59
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -3 MONTH)+1 and CURDATE()"
            where_condition02 = ""
        elif time_point == "M06":
            # days = 119
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -6 MONTH)+1 and CURDATE()"
            where_condition02 = ""
        elif time_point == "M12":
            # days = 249
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -12 MONTH)+1 and CURDATE()"

            where_condition02 = ""
        elif time_point == "M36":
            # days = 249
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -36 MONTH)+1 and CURDATE()"
            where_condition02 = ""
        elif time_point == "ALL":
            where_condition = ""
            date_condition = ""
            where_condition02 = ""
        elif time_point == "WEEK":
            date_condition = "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -1 WEEK)+1 and CURDATE()"
            where_condition02 = ""

        sql = """
        select sec_code as topic_code
              ,TRD_DATE as trade_date
              ,section_name as topic_name
              ,'%(time_point)s' as time_point
              ,pct as chng_pct_day
              ,indx_price
              ,ori_indx_pct
              ,round(if(rank=1,@pct_after:=0.0,@pct_after:=cast(100*((1+@pct_after/100)*(1+pct/100)-1) as decimal(18,6))),6) as chng_pct_all
              ,rank
       from (
          select sec_code, TRD_DATE, section_name,pct,indx_price,ori_indx_pct
                ,if(@sec_code=sec_code,@rank:=@rank+1,@rank:=1) as rank
                ,@sec_code := sec_code
                ,@pct_after:=0.0
             from (
                  select a.INNER_CODE as sec_code
                        ,cast(date_format(a.TRD_DATE,'%%Y%%m%%d') as SIGNED) as TRD_DATE
                        ,b.section_name
                        ,ifnull(a.CHNG_PCT_DAY,0.0) as pct
                        ,ifnull(c.TCLOSE,0.0) as indx_price
                        ,ifnull(c.CHNG_PCT,0.0) as ori_indx_pct
                    from pgenius.ANA_SECTION_EXPR_IDX a
                    join pgenius.PUB_SECTION_CODE b
                      on a.INNER_CODE = b.SECTION_CODE
                    left join pgenius.INDX_MKT c
                      on c.tradedate = a.TRD_DATE and c.isvalid = 1 
                     and c.INNER_CODE in ('106000232')  -- 沪深300 
                    join (select @pct_after:=0.0,@sec_code:='',@rank := 0) tmp
                      on 1=1
                   where b.sys_code=5
                  --   and b.SECTION_CODE not in (400121951,400121942,400121950)
                  and b.SECTION_CODE not in (select distinct parent_code 
                                             from pgenius.PUB_SECTION_CODE
                                            where isvalid = 1 and sys_code = 5)
                     and b.isvalid = 1 and a.isvalid = 1
                     and a.TRD_DATE >= date('2005-01-01')
                  --   and a.TRD_DATE >= date('2017-05-01')
                 --    and a.TRD_DATE <= date('2017-05-04')
                     %(date_condition)s
                   order by a.INNER_CODE,a.TRD_DATE) t
             ) t
        %(where_condition02)s
        """ % {"time_point": time_point, "date_condition": date_condition,
               "where_condition02": where_condition02}
        # % {"where_str": where_str}

        # 处理(400121951,400121942,400121950) 三个主题的数据（元数据缺失）
        sql02 = """
              select SECTION_CODE as topic_code
             ,TRD_DATE as trade_date
             ,section_name as topic_name
             ,'%(time_point)s' as time_point
             ,round(day_pct,6) as chng_pct_day
             ,indx_price
             ,ori_indx_pct
           --  ,round(cast(if(rank = 1,@pct_all := day_pct,@pct_all:= @pct_all+day_pct) as decimal(20,8)),6) as chng_pct_all
             ,round(if(rank=1,@pct_all:=day_pct,@pct_all:=cast(100*((1+@pct_all/100)*(1+day_pct/100)-1) as decimal(18,6))),6) as chng_pct_all
         ,rank
         from (
            select SECTION_CODE,section_name
                 ,cast(date_format(t.TRD_DATE,'%%Y%%m%%d') as SIGNED) as TRD_DATE
                 ,day_pct
                  ,ifnull(c.TCLOSE,0.0) as indx_price
                  ,ifnull(c.CHNG_PCT,0.0) as ori_indx_pct
                  , if(@sec_code=SECTION_CODE ,@rank := @rank+1,@rank:= 1) as rank
                  ,@sec_code := SECTION_CODE
                  ,@pct_all := 0.0
            from (
                select b.parent_code as section_code
                      ,c.section_name
                       ,a.TRD_DATE
                       ,a.CHNG_PCT_DAY 
                       ,ifnull(a.MKTCAP,0.0)
                       ,ifnull(sum(a.CHNG_PCT_DAY * a.MKTCAP)/sum(a.MKTCAP),0.0) as day_pct
                   from pgenius.PUB_SECTION_CODE b 
                   join pgenius.ANA_SECTION_EXPR_IDX a 
                     on b.section_code = a.inner_code and a.isvalid = 1
                   join pgenius.PUB_SECTION_CODE c
                     on b.parent_code = c.section_code and c.sys_code = 5 and c.isvalid = 1
                   join (select @sec_code := '',@rank = 0,@pct_all := 0.0) tmp
                     on 1 = 1
                  where b.isvalid = 1
                    and b.sys_code = 5
                    and b.parent_code in (400121951,400121942,400121950)
                    and a.TRD_DATE >= date('2005-01-01')
                    %(date_condition)s
                  group by b.parent_code ,a.TRD_DATE
                  order by b.parent_code ,a.TRD_DATE
                  ) t
              left join  pgenius.INDX_MKT c
                on t.trd_date = c.tradedate and c.isvalid = 1 
               and c.INNER_CODE in ('106000232')  -- 沪深300 
              ) t
        order by SECTION_CODE,TRD_DATE
        """ % {"time_point": time_point, "date_condition": date_condition}

        bs_data = []
        bs_data.extend(self.conn.fetchall(sql))
        # bs_data.extend(self.conn.fetchall(sql02))

        indx_tmp = {}
        indx_fir = {}
        s_data = []
        for row in bs_data:
            if row["rank"] == 1:
                key = row["topic_code"]
                indx_tmp.setdefault(key, {})
                indx_tmp[key].update({
                    "fir_indx_price": row["indx_price"],
                    "fir_indx_pct": row["ori_indx_pct"]
                })
                indx_fir.update(indx_tmp)
            row.update(indx_fir.get(row["topic_code"], {"fir_indx_price": None, "fir_indx_pct": None}))
            s_data.append(row)

        # 计算沪深300累计涨跌幅hs300_rate
        # print "s_data", len(s_data)
        data_tmp = {}
        results = []
        for rr in s_data:
            if rr["fir_indx_price"] <> 0.0 and rr["indx_price"] <> 0.0:
                hs300_rate = 100 * ((rr["indx_price"] - rr["fir_indx_price"]) / rr["fir_indx_price"])
            else:
                hs300_rate = 0.0
            tmp = {
                "topic_code": rr["topic_code"],
                "trade_date": rr["trade_date"],
                "topic_name": rr["topic_name"],
                "time_point": rr["time_point"],
                "chng_pct_day": rr["chng_pct_day"],
                "chng_pct_all": rr["chng_pct_all"],
                "rank": rr["rank"],
                "hs300_return_rate": 0.0
            }
            if rr["rank"] == 1:
                tmp["hs300_return_rate"] = 0.0
            else:
                tmp["hs300_return_rate"] = hs300_rate
            results.append(tmp)
        return results

            # 按 topic_code 封装成嵌套
            # kk = rr["topic_code"]
            # data_tmp.setdefault(kk, [])
            #
            # data_tmp[kk].append({
            #     "topic_code": rr["topic_code"],
            #     "trade_date": rr["trade_date"],
            #     "topic_name": rr["topic_name"],
            #     "time_point": rr["time_point"],
            #     "chng_pct_day": rr["chng_pct_day"],
            #     "chng_pct_all": rr["chng_pct_all"],
            #     "rank": rr["rank"],
            #     "hs300_return_rate": hs300_rate if rr["rank"] <> 1 else rr["fir_indx_pct"]
            # })

        # return data_tmp

    def get_anyfreq_pct_data_bycode(self, time_point, topic_code):
        """
        生成 Z3_TOPIC_HIS_QUOTE(主题历史明细，会实时同步当日最新数据) 表数据
        :return:
        """
	# where_str = self._make_where("topic_code", ["a", "b", "c"])

        time_condition = {
            "M01": "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -1 MONTH)+1 and CURDATE()",
            "M03": "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -3 MONTH)+1 and CURDATE()",
            "M06": "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -6 MONTH)+1 and CURDATE()",
            "M12": "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -12 MONTH)+1 and CURDATE()",
            "M36": "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -36 MONTH)+1 and CURDATE()",
            "ALL": "",
            "WEEK": "and a.TRD_DATE BETWEEN ADDDATE(CURDATE(),INTERVAL -1 WEEK)+1 and CURDATE()",
        }
	
	date_condition = time_condition.get(time_point)

	sql = """
        select sec_code as topic_code
              ,TRD_DATE as trade_date
              ,section_name as topic_name
              ,'%(time_point)s' as time_point
              ,pct as chng_pct_day
              ,indx_price
              ,ori_indx_pct
              ,round(if(rank=1,@pct_after:=0.0,@pct_after:=cast(100*((1+@pct_after/100)*(1+pct/100)-1) as decimal(18,6))),6) as chng_pct_all
              ,rank
       from (
          select sec_code, TRD_DATE, section_name,pct,indx_price,ori_indx_pct
                ,if(@sec_code=sec_code,@rank:=@rank+1,@rank:=1) as rank
                ,@sec_code := sec_code
                ,@pct_after:=0.0
             from (
                  select a.INNER_CODE as sec_code
                        ,cast(date_format(a.TRD_DATE,'%%Y%%m%%d') as SIGNED) as TRD_DATE
                        ,b.section_name
                        ,ifnull(a.CHNG_PCT_DAY,0.0) as pct
                        ,ifnull(c.TCLOSE,0.0) as indx_price
                        ,ifnull(c.CHNG_PCT,0.0) as ori_indx_pct
                    from pgenius.ANA_SECTION_EXPR_IDX a
                    join pgenius.PUB_SECTION_CODE b
                      on a.INNER_CODE = b.SECTION_CODE
                    left join pgenius.INDX_MKT c
                      on c.tradedate = a.TRD_DATE and c.isvalid = 1 
                     and c.INNER_CODE in ('106000232')  -- 沪深300 
                    join (select @pct_after:=0.0,@sec_code:='',@rank := 0) tmp
                      on 1=1
                   where b.sys_code=5
                     and b.SECTION_CODE  = %(topic_code)s
                  and b.SECTION_CODE not in (select distinct parent_code 
                                             from pgenius.PUB_SECTION_CODE
                                            where isvalid = 1 and sys_code = 5)
                     and b.isvalid = 1 and a.isvalid = 1
                     and a.TRD_DATE >= date('2005-01-01')
                  --   and a.TRD_DATE >= date('2017-05-01')
                 --    and a.TRD_DATE <= date('2017-05-04')
                     %(date_condition)s
                   order by a.INNER_CODE,a.TRD_DATE) t
             ) t
        """ % {"time_point": time_point, "date_condition": date_condition,
               "topic_code": topic_code}
	bs_data = []
        bs_data.extend(self.conn.fetchall(sql))

	indx_tmp = {}
        indx_fir = {}
        s_data = []
        for row in bs_data:
            if row["rank"] == 1:
                key = row["topic_code"]
                indx_tmp.setdefault(key, {})
                indx_tmp[key].update({
                    "fir_indx_price": row["indx_price"],
                    "fir_indx_pct": row["ori_indx_pct"]
                })
                indx_fir.update(indx_tmp)
            row.update(indx_fir.get(row["topic_code"], {"fir_indx_price": None, "fir_indx_pct": None}))
            s_data.append(row)
	
	# 计算沪深300累计涨跌幅hs300_rate
        # print "s_data", len(s_data)
        data_tmp = {}
        results = []
        for rr in s_data:
            if rr["fir_indx_price"] <> 0.0 and rr["indx_price"] <> 0.0:
                hs300_rate = 100 * ((rr["indx_price"] - rr["fir_indx_price"]) / rr["fir_indx_price"])
            else:
                hs300_rate = 0.0
            tmp = {
                "topic_code": rr["topic_code"],
                "trade_date": rr["trade_date"],
                "topic_name": rr["topic_name"],
                "time_point": rr["time_point"],
                "chng_pct_day": rr["chng_pct_day"],
                "chng_pct_all": rr["chng_pct_all"],
                "rank": rr["rank"],
                "hs300_return_rate": 0.0
            }
            if rr["rank"] == 1:
                tmp["hs300_return_rate"] = 0.0
                # tmp["hs300_return_rate"] = rr["fir_indx_pct"]
            else:
                tmp["hs300_return_rate"] = hs300_rate
            results.append(tmp)
        return results

    def get_indx_pct_data(self, time_point, **kwargs):
        """
        生成 Z3_TOPIC_HIS_QUOTE(沪深300指数累计收益率) 表数据
        :return:
        """
        # where_str = self._make_where("topic_code", ["a"])
        date_condition = ""
        where_condition02 = ""
        if time_point == "M01":
            # days = 19
            date_condition = "and c.TRADEDATE = DATE_ADD(b.TRADEDATE,INTERVAL -1 MONTH)"
            where_condition02 = ""
        elif time_point == "M03":
            # days = 59
            date_condition = "and c.TRADEDATE = DATE_ADD(b.TRADEDATE,INTERVAL -3 MONTH)"
            where_condition02 = ""
        elif time_point == "M06":
            # days = 119
            date_condition = "and c.TRADEDATE = DATE_ADD(b.TRADEDATE,INTERVAL -6 MONTH)"
            where_condition02 = ""
        elif time_point == "M12":
            # days = 249
            date_condition = "and c.TRADEDATE = DATE_ADD(b.TRADEDATE,INTERVAL -12 MONTH)"

            where_condition02 = ""
        elif time_point == "M36":
            # days = 249
            date_condition = "and c.TRADEDATE = DATE_ADD(b.TRADEDATE,INTERVAL -36 MONTH)"
            where_condition02 = ""
        elif time_point == "ALL":
            where_condition = ""
            date_condition = "and c.TRADEDATE = (select min(tradedate ) " \
                             " from pgenius.INDX_MKT where inner_code = c.inner_code " \
                             "and isvalid = 1)" \

            where_condition02 = ""
        elif time_point == "WEEK":
            days = 5
            date_condition = "and c.TRADEDATE = DATE_ADD(b.TRADEDATE,INTERVAL -5 DAY)"
            where_condition02 = "where rank = %(days)s" % {"days": int(days)}
        elif time_point == "4DAYS":
            days = 4
            date_condition = "and c.TRADEDATE = DATE_ADD(b.TRADEDATE,INTERVAL -4 DAY)"
            where_condition02 = "where rank = %(days)s" % {"days": int(days)}

        # where_condition = "where rank <= %s" % {int(days)}
        sql = """
       SELECT a.INDX_CODE
              ,a.INDX_SNAME
              ,'%(time_point)s' as time_point
              ,b.tradedate as trade_date
              ,IFNULL(b.TCLOSE,0.0) as indx_price
              ,IFNULL(c.TCLOSE,0.0) as start_price
              ,case when IFNULL(c.TCLOSE,0.0) = 0.0 then 0.0
                    else (IFNULL(b.TCLOSE,0.0) - IFNULL(c.TCLOSE,0.0)) / IFNULL(c.TCLOSE,0.0) * 100
                end as hs300_return_rate
          from pgenius.INDX_GEN_INFO a
          join pgenius.INDX_MKT b
            on a.INNER_CODE = b.INNER_CODE and b.ISVALID = 1
          left join pgenius.INDX_MKT c
            on b.INNER_CODE = c.INNER_CODE
           %(date_condition)s
           and c.ISVALID = 1
         where a.INNER_CODE = b.INNER_CODE
           and a.isvalid = 1
           and a.INDX_CODE in ('000300')
        %(where_condition02)s
        """ % {"time_point": time_point, "date_condition": date_condition, "where_condition02": where_condition02}
        # % {"where_str": where_str}
        tmp = self.conn.fetchall(sql)

        indx_data = {}
        results = []
        for row in tmp:
            key = row["time_point"] + str(row["trade_date"])
            indx_data.setdefault(key, [])
            indx_data[key].append({
                "hs300_return_rate": row["hs300_return_rate"]
            })
            # print "indx_data", type(indx_data)
        return indx_data

    def get_chng_pct_data(self, *args, **kwargs):
        """
        计算每个主题的周累计涨跌幅
        :return:
        """

        chng_list = self.get_anyfreq_pct_data("WEEK")
        results = []
        s_data = {}
        for row in chng_list:
            key = row["topic_code"]
            s_data.setdefault(key, [])
            s_data[key].append({
                "chng_pct": row["chng_pct_day"],
                "chng_pct_week": row["chng_pct_all"]
            })
        # print s_data

        # 计算三个源数据有问题的主题的周累计涨跌幅

        return s_data

    def make_Z3_EQUITY_HISTORY_data(self, innerCode, symbol):
        """
        计算Z3_EQUITY_HISTORY（大宽表历史表）
        :return:
        """
        print innerCode, " start:", datetime.now()
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        min_date = datetime.strptime('2017-06-30', "%Y-%m-%d")
        max_date = datetime.strptime('2017-07-04', "%Y-%m-%d")
        bs_data = list(db["Z3_EQUITY_HISTORY"].find(
            {
                "innerCode": innerCode,
                # "mkt_idx.ma5": {"$exists": False},
                # "trade_date": datetime.strptime('2017-05-24', "%Y-%m-%d")
                "trade_date": {"$gte": min_date, "$lte": max_date}
                # "mkt_idx.ma5_afac": None
                # "$or": [{"mkt_idx.chg": None}, {"mkt_idx.open_px": None},
                #         {"mkt_idx.prev_close_px": None}, {"mkt_idx.high_px": None},
                #         {"mkt_idx.amount": None}, {"mkt_idx.low_px": None},
                #         {"mkt_idx.prange": None}, {"mkt_idx.exchr": None}]
            },
            {"innerCode": 1, "symbol": 1, "trade_date": 1, "mkt_idx": 1},
            sort=[("trade_date", pymongo.ASCENDING)]
            # projection=[{'_id': False}]
            # limit=20
        ))
        print "bs_data", len(bs_data)

        if len(bs_data) == 0:
            results = []
        else:
            ma_base = self.get_equity_his_ma_data(symbol, min_date, max_date)
            pxs_base = self.get_equity_his_px_data(symbol, min_date, max_date)
            ma_cross_base = self.get_equity_his_ma_cross_data(innerCode, min_date, max_date)
            ma_be_rela_base = self.get_equity_his_mabf_rela_data(innerCode, min_date, max_date)

            results = []
            for row in bs_data:
                tmp = {}
                # print row["symbol"], row["trade_date"]
                tmp["innerCode"] = row.get("innerCode")
                tmp["symbol"] = row.get("symbol")
                tmp["trade_date"] = row.get("trade_date")
                tmp["mkt_idx"] = row.get("mkt_idx", {})
                # 获取maX,maX_afac
                _tmp1 = {
                    "ma5": None,
                    "ma5_afac": None,
                    "ma10": None,
                    "ma10_afac": None,
                    "ma20": None,
                    "ma20_afac": None,
                    "ma30": None,
                    "ma30_afac": None,
                    "ma60": None,
                    "ma60_afac": None,
                    "ma120": None,
                    "ma120_afac": None,
                    "ma250": None,
                    "ma250_afac": None
                }
                mas = ma_base.get(row["trade_date"], _tmp1)
                tmp["mkt_idx"].update(mas)

                # 获取maXbfac,rela_maX
                _tmp2 = {
                    "ma5_bfac": None,
                    "ma10_bfac": None,
                    "ma20_bfac": None,
                    "ma30_bfac": None,
                    "ma60_bfac": None,
                    "ma120_bfac": None,
                    "ma250_bfac": None,
                    "rela_ma5": None,
                    "rela_ma10": None,
                    "rela_ma20": None,
                    "rela_ma30": None,
                    "rela_ma60": None,
                    "rela_ma120": None,
                    "rela_ma250": None
                }
                ma_be_rela = ma_be_rela_base.get(row["trade_date"], _tmp2)
                tmp["mkt_idx"].update(ma_be_rela)
                # 获取金叉，死叉字段
                # 初始化
                _tmp3 = {
                    "price_cross_ma5_above": False,
                    "price_cross_ma5_below": False,
                    "ma5_cross_ma10_above": False,
                    "ma5_cross_ma10_below": False,
                    "ma5_cross_ma20_above": False,
                    "ma5_cross_ma20_below": False,
                    "price_cross_ma10_above": False,
                    "price_cross_ma10_below": False,
                    "ma10_cross_ma20_above": False,
                    "ma10_cross_ma20_below": False,
                    "ma10_cross_ma30_above": False,
                    "ma10_cross_ma30_below": False,
                    "ma10_dif_ma30": None,
                    "price_cross_ma20_above": False,
                    "price_cross_ma20_below": False,
                    "ma20_cross_ma30_above": False,
                    "ma20_cross_ma30_below": False,
                    "ma20_cross_ma60_above": False,
                    "ma20_cross_ma60_below": False,
                    "price_cross_ma30_above": False,
                    "price_cross_ma30_below": False,
                    "ma30_cross_ma60_above": False,
                    "ma30_cross_ma60_below": False,
                    "ma30_cross_ma120_above": False,
                    "ma30_cross_ma120_below": False,
                    "price_cross_ma60_above": False,
                    "price_cross_ma60_below": False,
                    "ma60_cross_ma120_above": False,
                    "ma60_cross_ma120_below": False,
                    "ma60_cross_ma250_above": False,
                    "ma60_cross_ma250_below": False,
                    "price_cross_ma120_above": False,
                    "price_cross_ma120_below": False,
                    "ma120_cross_ma250_above": False,
                    "ma120_cross_ma250_below": False,
                    "price_cross_ma250_above": False,
                    "price_cross_ma250_below": False
                }
                # 获取数据
                ma_cross = ma_cross_base.get(row["trade_date"], _tmp3)
                tmp["mkt_idx"].update(ma_cross)
                # 获取高开低收等字段
                _tmp4 = {
                    "chg": None,
                    "open_px": None,
                    "prev_close_px": None,
                    "high_px": None,
                    "low_px": None,
                    "amount": None,
                    "prange": None,
                    "exchr": None,
                    "limit_up": None,
                    "limit_down": None
                }
                pxs = pxs_base.get(row["trade_date"], _tmp4)
                tmp["mkt_idx"].update(pxs)
                results.append(tmp)

        return results

    def get_equity_his_ma_data(self, stockcode,  min_date, max_date):
        """
        计算Z3_EQUITY_HISTORY（大宽表历史表）的
        maX, maX_bfac字段
        :return:
        """
        print "min_date",min_date, max_date
        sql01 = """
           SELECT a.STOCKCODE as symbol
                  ,b.TRADEDATE as trade_date
                  ,ifnull(b.TCLOSE,0.0) as tclose
                  ,ifnull(b.FAC_TCLOSE,0.0) as fac_tclose
              from pgenius.STK_CODE a
              join pgenius.ANA_STK_MKT_DAY b
                on a.STOCKCODE = b.STOCKCODE and b.ISVALID = 1 and ifnull(b.TVOLUME,0) <> 0
             where a.ISVALID = 1
               and a.STK_TYPE_REF = 1
               and a.STOCKCODE IS NOT NULL
               and a.TRADE_MKT_REF IS NOT NULL
               and a.LIST_DATE <= b.TRADEDATE
               and ifnull(DATE(a.LIST_ENDDATE),'2099-12-31' )> b.TRADEDATE
               and a.STOCKCODE = '%(stockcode)s'
               and b.TRADEDATE <= '%(max_date)s'
            --   and b.TRADEDATE = '2014-01-02'
             order by a.STOCKCODE,b.TRADEDATE desc
                """ % {"stockcode": stockcode, "min_date": min_date, "max_date": max_date}

        bs_data = self.conn.fetchall(sql01)

        ll = list(i["trade_date"] for i in bs_data)

        get_index = {}
        get_nums = {}
        date_list = []
        for index, row in enumerate(bs_data):
            if row["trade_date"] >= min_date:
                date_list.append(row["trade_date"])

            # 以日期为主键，获取日期的index
            key1 = row["trade_date"]
            get_index.setdefault(key1, index)

            # 以index为主键，获取价格数据
            key2 = index
            get_nums.setdefault(key2, {})
            get_nums[key2] = {
                "tclose": row.get("tclose"),
                "fac_tclose": row.get("fac_tclose")
            }

        # print date_list

        bs_tmp = {}
        # 获取小于等于每个交易日的250条数据
        for dt in date_list:
            idx = get_index.get(dt)
            dlist = range(idx, idx + 250)
            bs_tmp.setdefault(dt, [])
            for i in dlist:
                if get_nums.get(i):
                    bs_tmp[dt].append(get_nums.get(i))

        tmp = {}
        # print "date_list", len(date_list)
        for rr in date_list:
            tmp.setdefault(rr, {})
            datas = bs_tmp.get(rr, [])
            # print rr, datas
            data250 = datas
            data120 = data250[:120]
            data60 = data120[:60]
            data30 = data60[:30]
            data20 = data30[:20]
            data10 = data20[:10]
            data5 = data10[:5]

            tmp[rr]["ma5"] = None if len(data5) < 5 else round(sum(i["tclose"] for i in data5) / 5, 2)
            tmp[rr]["ma5_afac"] = None if len(data5) < 5 else round(sum(i["fac_tclose"] for i in data5) / 5, 2)
            tmp[rr]["ma10"] = None if len(data10) < 10 else round(sum(i["tclose"] for i in data10) / 10, 2)
            tmp[rr]["ma10_afac"] = None if len(data10) < 10 else round(sum(i["fac_tclose"] for i in data10) / 10, 2)
            tmp[rr]["ma20"] = None if len(data20) < 20 else round(sum(i["tclose"] for i in data20) / 20, 2)
            tmp[rr]["ma20_afac"] = None if len(data20) < 20 else round(sum(i["fac_tclose"] for i in data20) / 20, 2)
            tmp[rr]["ma30"] = None if len(data30) < 30 else round(sum(i["tclose"] for i in data30) / 30, 2)
            tmp[rr]["ma30_afac"] = None if len(data30) < 30 else round(sum(i["fac_tclose"] for i in data30) / 30, 2)
            tmp[rr]["ma60"] = None if len(data60) < 60 else round(sum(i["tclose"] for i in data60) / 60, 2)
            tmp[rr]["ma60_afac"] = None if len(data60) < 60 else round(sum(i["fac_tclose"] for i in data60) / 60, 2)
            tmp[rr]["ma120"] = None if len(data120) < 120 else round(sum(i["tclose"] for i in data120) / 120, 2)
            tmp[rr]["ma120_afac"] = None if len(data120) < 120 else round(sum(i["fac_tclose"] for i in data120) / 120, 2)
            tmp[rr]["ma250"] = None if len(data250) < 250 else round(sum(i["tclose"] for i in data250) / 250, 2)
            tmp[rr]["ma250_afac"] = None if len(data250) < 250 else round(sum(i["fac_tclose"] for i in data250) / 250, 2)

        return tmp

    def get_equity_his_mabf_rela_data(self, code, min_date, max_date):
        """
        计算Z3_EQUITY_HISTORY（大宽表历史表）的maX_bfac,rela_maX字段
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        info = list(db["Z3_STK_MKT_DAY_INTER"].find({
            "equity.innerCode": code,
            # "trade_date": datetime.strptime('2017-05-04', "%Y-%m-%d")
            "end_date": {"$gte": min_date, "$lte": max_date},
            "ex_status": 1
            }))  # 前复权标志

        print "info", len(info)

        ma_bf_rela = {}
        for row in info:
            key = row["end_date"]
            ma_bf_rela.setdefault(key, {})

            ma_bf_rela[key] = {
                "ma5_bfac": None if row.get("MA5") is None else round(row["MA5"], 4),
                "ma10_bfac": None if row.get("MA10") is None else round(row["MA10"], 4),
                "ma20_bfac": None if row.get("MA20") is None else round(row["MA20"], 4),
                "ma30_bfac": None if row.get("MA30") is None else round(row["MA30"], 4),
                "ma60_bfac": None if row.get("MA60") is None else round(row["MA60"], 4),
                "ma120_bfac": None if row.get("MA120") is None else round(row["MA120"], 4),
                "ma250_bfac": None if row.get("MA250") is None else round(row["MA250"], 4),
                "rela_ma5":  None if not row.get("MA5") or row.get("close_px") is None else round(float(row["close_px"]) / float(row["MA5"]) - 1, 4),
                "rela_ma10":  None if not row.get("MA10") or row.get("close_px") is None else round(float(row["close_px"]) / float(row["MA10"]) - 1, 4),
                "rela_ma20":  None if not row.get("MA20") or row.get("close_px") is None else round(float(row["close_px"]) / float(row["MA20"]) - 1, 4),
                "rela_ma30":  None if not row.get("MA30") or row.get("close_px") is None else round(float(row["close_px"]) / float(row["MA30"]) - 1, 4),
                "rela_ma60":  None if not row.get("MA60") or row.get("close_px") is None else round(float(row["close_px"]) / float(row["MA60"]) - 1, 4),
                "rela_ma120":  None if not row.get("MA120") or row.get("close_px") is None else round(float(row["close_px"]) / float(row["MA120"]) - 1, 4),
                "rela_ma250":  None if not row.get("MA250") or row.get("close_px") is None else round(float(row["close_px"]) / float(row["MA250"]) - 1, 4)
            }

        return ma_bf_rela

    def get_equity_his_ma_cross_data(self, innerCode, min_date, max_date):
        """
        计算Z3_EQUITY_HISTORY（大宽表历史表）的金叉，死叉 字段
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        day_btw = max_date - min_date
        # 取交易日当日以及前一日数据
        info = list(db["Z3_STK_MKT_DAY_INTER"].find({
            "equity.innerCode": innerCode,
            "ex_status": 1,  # 前复权标志
            "end_date": {"$lte": max_date}},
            sort=[("end_date", pymongo.DESCENDING)],
            limit= day_btw.days + 5
        ))

        ma_cross = {}
        max_index = len(info) - 1
        for index, row in enumerate(info):
            if index <> max_index:
                tday = info[index]
                yday = info[index+1]
                key = info[index]["end_date"]
                # print "end_date", info[index]["end_date"]
                ma_cross.setdefault(key, {})
                tday["MA250"] = None if not info[index].get("MA250") else info[index].get("MA250")
                yday["MA250"] = None if not info[index + 1].get("MA250") else info[index + 1].get("MA250")

                # 股价与MA5金叉 ,股价与MA5死叉
                ma_cross[key]["price_cross_ma5_above"] = True \
                    if (tday.get("close_px") > tday.get("MA5") and yday.get("close_px") < yday.get("MA5")) else False
                ma_cross[key]["price_cross_ma5_below"] = True \
                    if (tday.get("close_px") < tday.get("MA5") and yday.get("close_px") > yday.get("MA5")) else False
                # MA5与MA10金叉 ,MA5与MA10死叉
                ma_cross[key]["ma5_cross_ma10_above"] = True \
                    if (tday.get("MA5") > tday.get("MA10") and yday.get("MA5") < yday.get("MA10")) else False
                ma_cross[key]["ma5_cross_ma10_below"] = True \
                    if (tday.get("MA5") < tday.get("MA10") and yday.get("MA5") > yday.get("MA10")) else False
                # MA5与MA20金叉 ,MA5与MA20死叉
                ma_cross[key]["ma5_cross_ma20_above"] = True \
                    if (tday.get("MA5") > tday.get("MA20") and yday.get("MA5") < yday.get("MA20")) else False
                ma_cross[key]["ma5_cross_ma20_below"] = True \
                    if (tday.get("MA5") < tday.get("MA20") and yday.get("MA5") > yday.get("MA20")) else False
                # 股价与MA10金叉 ,股价与MA10死叉
                ma_cross[key]["price_cross_ma10_above"] = True \
                    if (tday.get("close_px") > tday.get("MA10") and yday.get("close_px") < yday.get("MA10")) else False
                ma_cross[key]["price_cross_ma10_below"] = True \
                    if (tday.get("close_px") < tday.get("MA10") and yday.get("close_px") > yday.get("MA10")) else False
                # MA10与MA20金叉 ,MA10与MA20死叉
                ma_cross[key]["ma10_cross_ma20_above"] = True \
                    if (tday.get("MA10") > tday.get("MA20") and yday.get("MA10") < yday.get("MA20")) else False
                ma_cross[key]["ma10_cross_ma20_below"] = True \
                    if (tday.get("MA10") < tday.get("MA20") and yday.get("MA10") > yday.get("MA20")) else False
                # MA10与MA30金叉 ,MA10与MA30死叉,MA10减MA30差值
                ma_cross[key]["ma10_cross_ma30_above"] = True \
                    if (tday.get("MA10") > tday.get("MA30") and yday.get("MA10") < yday.get("MA30")) else False
                ma_cross[key]["ma10_cross_ma30_below"] = True \
                    if (tday.get("MA10") < tday.get("MA30") and yday.get("MA10") > yday.get("MA30")) else False
                ma_cross[key]["ma10_dif_ma30"] = round(tday.get("MA10") - tday.get("MA30"), 2) \
                        if tday.get("MA10") and tday.get("MA30") else None
                        # 股价与MA20金叉 ,股价与MA20死叉
                ma_cross[key]["price_cross_ma20_above"] = True \
                    if (tday.get("close_px") > tday.get("MA20") and yday.get("close_px") < yday.get("MA20")) else False
                ma_cross[key]["price_cross_ma20_below"] = True \
                    if (tday.get("close_px") < tday.get("MA20") and yday.get("close_px") > yday.get("MA20")) else False
                # MA20与MA30金叉 ,MA20与MA30死叉
                ma_cross[key]["ma20_cross_ma30_above"] = True \
                    if (tday.get("MA20") > tday.get("MA30") and yday.get("MA20") < yday.get("MA30")) else False
                ma_cross[key]["ma20_cross_ma30_below"] = True \
                    if (tday.get("MA20") < tday.get("MA30") and yday.get("MA20") > yday.get("MA30")) else False
                # MA20与MA60金叉 ,MA20与MA60死叉
                ma_cross[key]["ma20_cross_ma60_above"] = True \
                    if (tday.get("MA20") > tday.get("MA60") and yday.get("MA20") < yday.get("MA60")) else False
                ma_cross[key]["ma20_cross_ma60_below"] = True \
                    if (tday.get("MA20") < tday.get("MA60") and yday.get("MA20") > yday.get("MA60")) else False
                # 股价与MA30金叉 ,股价与MA30死叉
                ma_cross[key]["price_cross_ma30_above"] = True \
                    if (tday.get("close_px") > tday.get("MA30") and yday.get("close_px") < yday.get("MA30")) else False
                ma_cross[key]["price_cross_ma30_below"] = True \
                    if (tday.get("close_px") < tday.get("MA30") and yday.get("close_px") > yday.get("MA30")) else False
                # MA30与MA60金叉 ,MA30与MA60死叉
                ma_cross[key]["ma30_cross_ma60_above"] = True \
                    if (tday.get("MA30") > tday.get("MA60") and yday.get("MA30") < yday.get("MA60")) else False
                ma_cross[key]["ma30_cross_ma60_below"] = True \
                    if (tday.get("MA30") < tday.get("MA60") and yday.get("MA30") > yday.get("MA60")) else False
                # MA30与MA120金叉 ,MA30与MA120死叉
                ma_cross[key]["ma30_cross_ma120_above"] = True \
                    if (tday.get("MA30") > tday.get("MA120") and yday.get("MA30") < yday.get("MA120")) else False
                ma_cross[key]["ma30_cross_ma120_below"] = True \
                    if (tday.get("MA30") < tday.get("MA120") and yday.get("MA30") > yday.get("MA120")) else False
                # 股价与MA60金叉 ,股价与MA60死叉
                ma_cross[key]["price_cross_ma60_above"] = True \
                    if (tday.get("close_px") > tday.get("MA60") and yday.get("close_px") < yday.get("MA60")) else False
                ma_cross[key]["price_cross_ma60_below"] = True \
                    if (tday.get("close_px") < tday.get("MA60") and yday.get("close_px") > yday.get("MA60")) else False
                # MA60与MA120金叉 ,MA60与MA120死叉
                ma_cross[key]["ma60_cross_ma120_above"] = True \
                    if (tday.get("MA60") > tday.get("MA120") and yday.get("MA60") < yday.get("MA120")) else False
                ma_cross[key]["ma60_cross_ma120_below"] = True \
                    if (tday.get("MA60") < tday.get("MA120") and yday.get("MA60") > yday.get("MA120")) else False
                # MA60与MA250金叉 ,MA60与MA250死叉
                ma_cross[key]["ma60_cross_ma250_above"] = True \
                    if (tday.get("MA60") > tday.get("MA250") and yday.get("MA60") < yday.get("MA250")) else False
                ma_cross[key]["ma60_cross_ma250_below"] = True \
                    if (tday.get("MA60") < tday.get("MA250") and yday.get("MA60") > yday.get("MA250")) else False
                # 股价与MA120金叉 ,股价与MA120死叉
                ma_cross[key]["price_cross_ma120_above"] = True \
                    if (tday.get("close_px") > tday.get("MA120") and yday.get("close_px") < yday.get("MA120")) else False
                ma_cross[key]["price_cross_ma120_below"] = True \
                    if (tday.get("close_px") < tday.get("MA120") and yday.get("close_px") > yday.get("MA120")) else False
                # MA120与MA250金叉 ,MA120与MA250死叉
                ma_cross[key]["ma120_cross_ma250_above"] = True \
                    if (tday.get("MA120") > tday.get("MA250") and yday.get("MA120") < yday.get("MA250")) else False
                ma_cross[key]["ma120_cross_ma250_below"] = True \
                    if (tday.get("MA120") < tday.get("MA250") and yday.get("MA120") > yday.get("MA250")) else False
                # 股价与MA250金叉 ,股价与MA250死叉
                # print key
                ma_cross[key]["price_cross_ma250_above"] = True \
                    if (tday.get("close_px") > tday.get("MA250") and yday.get("close_px") < yday.get("MA250")) else False
                ma_cross[key]["price_cross_ma250_below"] = True \
                    if (tday.get("close_px") < tday.get("MA250") and yday.get("close_px") > yday.get("MA250")) else False

        return ma_cross

    def get_equity_his_px_data(self, symbol, min_date, max_date):
        """
        计算Z3_EQUITY_HISTORY（大宽表历史表）的高开低收等 字段
        :return:
        """
        # print "symbol:",symbol,min_date,max_date
        sql01 = """
             SELECT a.STOCKCODE as symbol
                   ,b.ENDDATE as trade_date
                   ,b.CHNG as chg
                   ,b.TOPEN as open_px
                   ,b.LCLOSE as prev_close_px
                   ,b.THIGH as high_px
                   ,b.TLOW as low_px
                   ,b.TVALUE as amount
                   ,b.SWING_DAY as prange
                   ,b.TURNOVER_DAY as exchr
                   ,case when b.ENDDATE <> a.LIST_DATE and a.SPECIAL_TYPE_REF in(2,3)
                          then b.LCLOSE * 1.05
                          when b.ENDDATE <> a.LIST_DATE and a.SPECIAL_TYPE_REF in(1,5,6) 
                          then b.LCLOSE * 1.1
                          when b.ENDDATE = a.LIST_DATE and b.ENDDATE >= date('2014-01-24')
                          then GREATEST(b.LCLOSE*1.44,b.THIGH)
                          when b.ENDDATE = a.LIST_DATE and b.ENDDATE >= date('2014-01-01') and b.ENDDATE <= date('2014-01-23')
                          then GREATEST(round(round(b.LCLOSE*1.2,2)*1.1,2)*1.1 , b.THIGH)
                          when b.ENDDATE = a.LIST_DATE and  b.ENDDATE < date('2014-01-01') 
                          then null end as limit_up
                   ,case when b.ENDDATE <> a.LIST_DATE and a.SPECIAL_TYPE_REF in(2,3)
                           then b.LCLOSE * 0.95
                           when b.ENDDATE <> a.LIST_DATE and a.SPECIAL_TYPE_REF in(1,5,6) 
                           then b.LCLOSE * 0.9
                           when b.ENDDATE = a.LIST_DATE and b.ENDDATE >= date('2014-01-24')
                           then LEAST(b.LCLOSE*0.64,b.TLOW)
                           when b.ENDDATE = a.LIST_DATE and b.ENDDATE >= date('2014-01-01') and b.ENDDATE <= date('2014-01-23')
                           then LEAST(round(round(b.LCLOSE*0.8,2)*0.9,2)*0.9,b.TLOW)
                           when b.ENDDATE = a.LIST_DATE and  b.ENDDATE < date('2014-01-01') 
                           then null end as limit_down
              from pgenius.STK_CODE a
              join pgenius.ANA_STK_EXPR_IDX b
                on a.INNER_CODE = b.INNER_CODE
             where a.ISVALID = 1 and b.ISVALID = 1
               and a.STK_TYPE_REF = 1
               and a.STOCKCODE IS NOT NULL
               and a.TRADE_MKT_REF IS NOT NULL
               and a.STOCKCODE = '%(symbol)s'
            --   and b.ENDDATE = '2017-05-24'
               and b.ENDDATE BETWEEN '%(min_date)s' and '%(max_date)s'
               and ifnull(b.TVOLUME,0) <> 0
            """ % {"symbol": symbol, "min_date": min_date, "max_date": max_date}

        datas = self.conn.fetchall(sql01)
        # print datas

        tmp = {}
        for row in datas:
            key = row["trade_date"]
            tmp.setdefault(key, {})

            tmp[key]["chg"] = None if row["chg"] is None else float(row["chg"])
            tmp[key]["open_px"] = None if row["open_px"] is None else float(row["open_px"])
            tmp[key]["prev_close_px"] = None if row["prev_close_px"] is None else float(row["prev_close_px"])
            tmp[key]["high_px"] = None if row["high_px"] is None else float(row["high_px"])
            tmp[key]["low_px"] = None if row["low_px"] is None else float(row["low_px"])
            tmp[key]["amount"] = None if row["amount"] is None else float(row["amount"])
            tmp[key]["prange"] = None if row["prange"] is None else float(row["prange"])
            tmp[key]["exchr"] = None if row["exchr"] is None else float(row["exchr"])
            tmp[key]["limit_up"] = None if row["limit_up"] is None else round(row["limit_up"], 2)
            tmp[key]["limit_down"] = None if row["limit_down"] is None else round(row["limit_down"], 2)
        return tmp

    def get_topic_all_childinfo(self, pid, **kwargs):
        """
        获取一个主题的所有子节点主题（含自身）
        :return:
        """
        # 获取主题下所有子主题
        tmp = [pid, ]
        sql_topic = """
                select section_code  
                  from pgenius.pub_section_code 
                 where PARENT_CODE = %(pid)s
                """ % {"pid": pid}
        # % {"where_str": where_str}
        results = self.conn.fetchall(sql_topic, {"pid": pid})
        # print results
        # print "dddddd"
        for row in results:
            sub_id = row["section_code"]
            tmp.extend(self.get_child_section_code(sub_id))

            # return tmp
            # 获取所有主题的股票

    def get_all_stkcode(self, *args, **kwargs):
        """
        获取股票日行情表所有stockcode
        :return:
        """
        # 获取主题下所有子主题
        sql = """
        select distinct stockcode  from pgenius.STK_CODE a
         where a.isvalid = 1 
           AND STK_TYPE_REF = 1 
           AND STOCKCODE IS NOT NULL
           AND TRADE_MKT_REF IS NOT NULL
           and a.STOCKCODE not like 'N%'
           and a.STATUS_TYPE_REF <> 2
       --    and a.STOCKCODE = '000001'
        --   and a.STOCKCODE in ("600209", "000403", "000755","000809")
        --   and a.STOCKCODE in ('300050','002252','002024','000002','000001','000829','000009','600000','600019','600009')
         order by stockcode
        """

        results = self.conn.fetchall(sql)
        # print "results", type(results)
        return results
 
    def get_ztss_stkcode(self, *args, **kwargs):
	"""
        获取暂停上市的所有stockcode
        :return:
        """
	sql = """
            select distinct stockcode  
              from pgenius.STK_CODE a
             where a.isvalid = 1 
               AND STK_TYPE_REF = 1 
               AND STOCKCODE IS NOT NULL
               AND TRADE_MKT_REF IS NOT NULL
               and a.STOCKCODE not like 'N%%'
               and a.LIST_DATE IS NOT NULL
               and a.STATUS_TYPE_REF = 2
	     order by stockcode
	"""
	results = self.conn.fetchall(sql)
	
	return results
		

    def get_equity_history_symbol(self, *args, **kwargs):
        """
        test
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]
        sql = """
            SELECT case when a.TRADE_MKT_REF= 1 then CONCAT(a.STOCKCODE,'.SZ')
                         when a.TRADE_MKT_REF= 2 then CONCAT(a.STOCKCODE,'.SH')
                          end as innerCode,
                    a.STOCKCODE as symbol      
              from pgenius.STK_CODE a
             where a.ISVALID = 1
               and a.STK_TYPE_REF = 1
               and a.STOCKCODE IS NOT NULL
               and a.TRADE_MKT_REF IS NOT NULL
               and a.STOCKCODE not like 'N%'
            --   and a.STOCKCODE not like '0%'
             --  and a.STOCKCODE = '000157'
             -- and a.STOCKCODE in ('300050','002252','002024','000002','000001','000829','000009','600000','600019','600009')
              order by a.STOCKCODE
        """
        # bs_data = list(db["Z3_EQUITY_HISTORY"].distinct("trade_date",{"trade_date": ""}))
        bs_data = self.conn.fetchall(sql)
        # print "bs_data", len(bs_data)

        return bs_data

    def get_topics(self, *args, **kwargs):
        """
        test
        :return:
        """
        sql = """
             SELECT  a.SECTION_CODE AS topic_code
                     ,a.SECTION_NAME AS topic_name
               FROM pgenius.PUB_SECTION_CODE a
              WHERE SYS_CODE = 5
                AND ISVALID = 1
                and a.SECTION_CODE not in (select distinct parent_code 
                                      from pgenius.PUB_SECTION_CODE
                                     where isvalid = 1 and sys_code = 5)
             --   and a.SECTION_CODE = 400130009
        """
        topics = self.conn.fetchall(sql)

        return topics

    def make_TEST_AAA_data(self, *args, **kwargs):
        """
        test
        :return:
        """
        conn = tools.mongo_cursor()
        db = conn["z3dbus"]

        db["Z3_STK_MKT_DAY02"].find({""})

        # return topics

    if __name__ == "__main__":
        pass

