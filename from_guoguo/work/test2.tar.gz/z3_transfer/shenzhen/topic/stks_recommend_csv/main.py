#!/usr/bin/env python
# -*- coding: utf-8 -*-

from datetime import datetime
import pandas as pd
from logger import logging
import os,sys
from compose_data import main as compose_data
from find_raising_period_by_sec import main as find_raising_period_by_sec
from find_flagships_by_sec import main as find_flagships_by_sec
# from stat_figure_by_sec import main as stat_figure_by_sec
from consts import df_sec_res_pk, df_stk_ind_by_day_pk, df_sec_stk_dt_raw_pk, \
    res_df_scores_csv, res_df_flags_csv

period = datetime.today().strftime('%Y%m%d')
logger = logging.getLogger(__name__)


def main():
    # 删除历史文件
    print os.getcwd(),sys.path[0]
    if os.path.exists(res_df_scores_csv):
        os.remove(res_df_scores_csv)
        logger.info("Remove csv file done.")
    else:
	logger.info("No csv file exists.")

    compose_data()

    logger.info('Reading data...')
    df_sec_res = pd.read_pickle(df_sec_res_pk)
    df_stk_by_day = pd.read_pickle(df_stk_ind_by_day_pk)
    df_sec_stk_dt = pd.read_pickle(df_sec_stk_dt_raw_pk)
    logger.info('Reading data done.')
    lst_scores, lst_flags = [], []
    # print "df_sec_res",len(df_sec_res), len(df_sec_res.groupby(['sec_code']))
    for name, group in df_sec_res.groupby(['sec_code']):
        logger.info('Searching the flagships of section: {sec}'.format(sec=name))
        df_sec_raising_period = find_raising_period_by_sec(group)
        df_scores, df_flags = find_flagships_by_sec(df_sec_raising_period,
                                                    df_stk_by_day,
                                                    df_sec_stk_dt,
                                                    name)
        if not df_scores.empty:
            lst_scores.append(df_scores)
            # lst_flags.append(df_flags)
    # print "lst_scores", len(lst_scores), len(lst_flags)
    res_df_scores = pd.concat(lst_scores, ignore_index=True)
    # res_df_flags = pd.concat(lst_flags, ignore_index=True)
    res_df_scores.to_csv(res_df_scores_csv.format(period=period), index=False)
    # res_df_flags.to_csv(res_df_flags_csv.format(period=period), index=False)


if __name__ == '__main__':
    main()
