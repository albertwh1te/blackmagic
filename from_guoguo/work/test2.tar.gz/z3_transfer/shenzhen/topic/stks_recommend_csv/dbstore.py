# -*- coding: utf-8 -*-

# import pymssql
import pymysql
import pymysql.err

# jrj_pg_conf = {
#     'server': '172.16.198.11',
#     'user': 'JRJ_PG',
#     'password': '47sTXSLIQiXPG9pY2SYh',
#     'database': 'PGenius',
# }

jrj_pg_conf = {
    "host": "10.77.4.9",
    "port": 3306,
    # "user": "z3python",
    # "password": "z3python",
    "user": "ltpython",
    "password": "bBK4MwwVCfzL",
    "charset": 'utf8mb4',
    "db": "pgenius",
    "cursorclass": pymysql.cursors.DictCursor
}

class MsSQLStore:
    def __init__(self, db_conf):
        self.conn = pymysql.connect(**db_conf)

    @staticmethod
    def _parse_sql(sql_str):
        sql_type = sql_str.strip().lower().split()[0]
        return sql_type

    def execute(self, sql_str, *args):
        sql_type = self._parse_sql(sql_str=sql_str)
        with self.conn.cursor() as cur:
            cur.execute(sql_str, *args)
            if sql_type == 'select':
                return cur.fetchall()
            else:
                self.conn.commit()

    def commit(self):
        self.conn.commit()

    def executemany(self, operation, params_seq):
        sql_type = self._parse_sql(sql_str=operation)
        with self.conn.cursor() as cur:
            cur.executemany(operation, params_seq)
        if sql_type != "select":
            self.conn.commit()

if __name__ == "__main__":
    pass

# print jrj_pg_conf
# jrj_pg_db = Mysql(config=jrj_pg_conf)
jrj_pg_db = MsSQLStore(db_conf=jrj_pg_conf)