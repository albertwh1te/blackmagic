#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from logger import logging

logger = logging.getLogger(__name__)


def main(df_sec_raising_period, df_stk_by_day, df_sec_stk_dt, target_sec):
    """
    function to find flagships of particular section. this function accepts section-raising-period
    and stock-by-day data, returns two result:
    1. all belongs stocks and the normalized flagship score, sum ranking score of each raising period
        and normalize it.
    2. each raising period and flagship(top 30% and top 10) for analysis and check out.
    :param df_sec_raising_period:
    :param df_stk_by_day:
    :param df_sec_stk_dt:
    :return: two data-frames holds flagships of each raising period and score result of all belongs stocks.
    """
    df_lst = []
    for idx, item in df_sec_raising_period.iterrows():
        start, end, cum_inc = item
        df_stk_incs = df_sec_stk_dt \
            .loc[(df_sec_stk_dt.sec_code == target_sec) &
                 (df_sec_stk_dt.period >= start) &
                 (df_sec_stk_dt.period <= end)] \
            .merge(df_stk_by_day, how='inner', on=['stk_code', 'period']) \
            .loc[:, ['sec_code', 'stk_code', 'chg_stk_net']] \
            .groupby(['sec_code', 'stk_code']) \
            .sum() \
            .reset_index() \
            .sort_values(by='chg_stk_net', ascending=False) \
            .assign(stk_cnt=lambda df: df.shape[0]) \
            .assign(ranks=lambda df: range(df.stk_cnt[0])) \
            .assign(rank_pct=lambda df: df.ranks * 1.0 / df.stk_cnt) \
            .assign(score=lambda df: np.linspace(1, 0, df.stk_cnt[0])) \
            .assign(flags=lambda df: (df.rank_pct <= 0.3) & (df.ranks <= 9)) \
            .assign(start_period=start) \
            .assign(end_period=end) \
            .assign(cum_inc=cum_inc)
        df_lst.append(df_stk_incs)
    try:
        df_concated = pd.concat(df_lst, ignore_index=True)
    except ValueError:
        logger.warn('THIS SECTION HAS NO RAISING PERIOD.')
        return pd.DataFrame(), pd.DataFrame()
    df_flags = df_concated.loc[df_concated.flags] \
        .loc[:, ['sec_code', 'start_period', 'end_period', 'cum_inc', 'stk_code', 'ranks', 'rank_pct', 'stk_cnt']]
    """
    df_scores = df_concated.loc[:, ['sec_code', 'stk_code', 'score']] \
        .groupby(['sec_code', 'stk_code']) \
        .sum() \
        .reset_index() \
        .assign(score_base=lambda df: np.min(df.score)) \
        .assign(score_range=lambda df: (np.max(df.score) - np.min(df.score))) \
        .assign(score_norm=lambda df: (df.score - df.score_base) / df.score_range) \
        .loc[:, ['sec_code', 'stk_code', 'score_norm']] \
        .sort_values(by='score_norm', ascending=False)
    """
    df_scores = df_concated.loc[:, ['sec_code', 'stk_code', 'score']] \
        .groupby(['sec_code', 'stk_code']) \
        .mean() \
        .reset_index() \
        .sort_values(by='score', ascending=False)
    return df_scores, df_flags
