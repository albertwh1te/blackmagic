#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
from logger import logging
from consts import SEC_INC_PCT, SEC_INC_VAR, SEC_CONT_PCT, SEC_DESC_VAR, \
    SEC_INC_ESTABLISH_STD

logger = logging.getLogger(__name__)


def label_period_by_sec(df_sec):
    """
    function to label the period as increase, continue, decrease,
    this function accept data-frame of particular section and output the labeled data-frame.
    :param df_sec: data-frame-by-section that composed from compose_data.py
    :return: labeled data-frame of section infos by day.
    """
    df_sec_labeled = df_sec \
        .sort_values(by='period', axis=0, ascending=True) \
        .assign(idx=lambda df: (df.chg_sec + 1).cumprod()) \
        .assign(is_inc=lambda df: (df.stk_inc_mean > SEC_INC_PCT)
                & (df.chg_sec_ln > (df.chg_sec_mean + df.chg_sec_std * SEC_INC_VAR))) \
        .assign(is_desc=lambda df:
                df.chg_sec_ln < (df.chg_sec_mean - df.chg_sec_std * SEC_DESC_VAR)) \
        .assign(is_cont=lambda df: df.stk_inc_mean > SEC_CONT_PCT) \
        .set_index('period')
    return df_sec_labeled


def find_raising_period_by_sec(df_sec_labeled):
    """
    CORE FUNCTION to find active period by section, this function accept the output
    labeled data-frame of particular section and return all appreciate raising periods.
    :param df_sec_labeled: labeled-data-frame-by-section that produced by LABEL_PERIOD_BY_SEC().
    :return: data-frame that records all appreciate raising periods.
    """
    res_periods, temp_periods = [], []
    last_period, last_item = None, pd.Series()
    for period, item in df_sec_labeled.iterrows():
        # deal with raise period
        if item.get('is_inc', False):
            if temp_periods:
                temp_periods.append(period)
            # if start raise, check whether last period is continue
            elif last_item.get('is_cont', False):
                temp_periods.extend([last_period, period])
            else:
                temp_periods.append(period)
        # deal with continuous raise period
        elif item.get('is_cont', False):
            if temp_periods:
                temp_periods.append(period)
        # deal with decrease period OR last period
        # TAKE ATTENTION: the follow if-condition is not else alternative of before conditions,
        # particular line could qualify double conditions and do the twice manipulations.
        if item.get('is_desc', False) or item.get('is_last', False):
            # if temp periods hold data, check whether its raising percent is appreciate
            if temp_periods:
                if len(temp_periods) == 1 and last_item.get('chg_sec', -99) > \
                                item.get('chg_sec_std', -99) * SEC_INC_ESTABLISH_STD:
                    res_periods.append([last_period, last_period, last_item['chg_sec']])
                else:
                    start_dt, end_dt = temp_periods[0], temp_periods[-1]
                    # start index store in the day before
                    start_dt_before = df_sec_labeled.at[start_dt, 'last_period']
                    try:
                        start_idx = df_sec_labeled.at[start_dt_before, 'idx']
                    except KeyError:
                        logger.warn('start: {start}, end: {end}, before: {before}'
                                    .format(start=start_dt, end=end_dt, before=start_dt_before))
                    end_idx = df_sec_labeled.at[end_dt, 'idx']
                    raise_pct = (end_idx * 1.0 / start_idx - 1)
                    # if the raise percent bigger than half index standard error,
                    # then accept this period as raising part.
                    if raise_pct > item.get('chg_sec_std', -99) * SEC_INC_ESTABLISH_STD:
                        res_periods.append([start_dt, end_dt, raise_pct])
                # clear temp periods
                temp_periods = []
        # assign current period and item to last at the end
        last_period, last_item = period, item
    df_res = pd.DataFrame(res_periods, columns=['start', 'end', 'cum_inc'])
    return df_res


def main(df_sec):
    df_sec_labeled = label_period_by_sec(df_sec)
    df_sec_raising_period = find_raising_period_by_sec(df_sec_labeled)
    return df_sec_raising_period
