#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
)
