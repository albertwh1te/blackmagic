#!/usr/bin/env python
# -*- coding: utf-8 -*-

from time import time
from datetime import timedelta, datetime
import numpy as np
import pandas as pd
from dbstore import jrj_pg_db as db
from logger import logging
import os
from consts import get_idx_perf_sql, get_seq_perf_sql, get_stk_perf_sql, get_sec_stk_rel_sql, \
    init_seq_perf_sql, get_valid_period_sql, init_stk_perf_sql, df_idx_raw_pk, df_sec_raw_pk, \
    df_stk_raw_pk, df_sec_stk_dt_raw_pk, df_sec_ind_by_day_pk, df_sec_ind_stat_pk, \
    df_stk_ind_by_day_pk, df_stk_ind_stat_pk, df_sec_ind_roll_stks_pk, df_sec_res_pk

time_delta_730 = timedelta(days=730)
logger = logging.getLogger(__name__)


def init_stk_sec_perf_data():
    t0 = time()
    df_stk = pd.read_sql(init_stk_perf_sql, db.conn).set_index('period')
    logger.info('Init stock data({sp}) done in {sec} seconds.'.format(sp=df_stk.shape, sec=(time() - t0)))
    df_stk.to_pickle(df_stk_raw_pk)
    logger.info('Dump init stock data done.')
    t0 = time()
    df_sec = pd.read_sql(init_seq_perf_sql, db.conn).set_index('period')
    logger.info('Query section data({sp}) done in {sec} seconds.'.format(sp=df_sec.shape, sec=(time() - t0)))
    df_sec.to_pickle(df_sec_raw_pk)
    logger.info('Dump init section data({sp}) done.')

def query_data():
    """
    function to query all target from database.
    query stock data and section-stock-period is the most time consuming part.
    :return:
    """
    t0 = time()
    df_idx = pd.read_sql(get_idx_perf_sql, db.conn).set_index('period')
    logger.info('Query index data({sp}) done in {sec} seconds.'.format(sp=df_idx.shape, sec=(time() - t0)))
    df_idx.to_pickle(df_idx_raw_pk)
    t0 = time()
    df_sec_add = pd.read_sql(get_seq_perf_sql, db.conn).set_index('period')
    logger.info('Query section data({sp}) done in {sec} seconds.'.format(sp=df_sec_add.shape, sec=(time() - t0)))
    df_sec_his = pd.read_pickle(df_sec_raw_pk)
    df_sec = pd.concat([df_sec_his, df_sec_add]) \
        .reset_index() \
        .drop_duplicates() \
        .assign(is_keep=lambda df: (datetime.now() - df.period) <= time_delta_730) \
        .set_index('period')
    df_sec = df_sec[df_sec.is_keep].drop('is_keep', axis=1)
    logger.info('Compute section data({sp}) done.'.format(sp=df_sec.shape))
    df_sec.to_pickle(df_sec_raw_pk)
    t0 = time()
    df_stk_add = pd.read_sql(get_stk_perf_sql, db.conn).set_index('period')
    logger.info('Query stock data({sp}) done in {sec} seconds.'.format(sp=df_stk_add.shape, sec=(time() - t0)))
    df_stk_his = pd.read_pickle(df_stk_raw_pk)
    df_stk = pd.concat([df_stk_his, df_stk_add]) \
        .reset_index() \
        .drop_duplicates() \
        .assign(is_keep=lambda df: (datetime.now() - df.period) <= time_delta_730) \
        .set_index('period')
    df_stk = df_stk[df_stk.is_keep].drop('is_keep', axis=1)
    logger.info('Compute stock data({sp}) done.'.format(sp=df_stk.shape))
    df_stk.to_pickle(df_stk_raw_pk)
    t0 = time()
    df_sec_stk_rel = pd.read_sql(get_sec_stk_rel_sql, db.conn)
    logger.info('Query section-stock-relation data({sp}) done in {sec} seconds.'
                .format(sp=df_sec_stk_rel.shape, sec=(time() - t0)))
    t0 = time()
    df_valid_period = pd.read_sql(get_valid_period_sql, db.conn)
    logger.info('Query valid-transaction-period data({sp}) done in {sec} seconds.'
                .format(sp=df_valid_period.shape, sec=(time() - t0)))
    df_tmp = pd.merge(df_sec_stk_rel.assign(_tmpkey=0),
                      df_valid_period.assign(_tmpkey=0),
                      on='_tmpkey').drop('_tmpkey', axis=1)
    df_sec_stk_dt = df_tmp[(df_tmp.en_time <= df_tmp.period) & (df_tmp.period <= df_tmp.reje_time)] \
                        .loc[:, ['sec_code', 'stk_code', 'period']]
    logger.info('Compute section-stock-period data({sp}) done.'.format(sp=df_sec_stk_dt.shape))
    df_sec_stk_dt.to_pickle(df_sec_stk_dt_raw_pk)



def compute_sec_ind_by_day():
    """
    function to compute section indicators by period, those that
    doesn't need to group by section to stat.
    TAKE CARE: CAN'T COMPUTE SEC_IDX HERE.
    :return:
    """
    df_idx = pd.read_pickle(df_idx_raw_pk)
    df_sec = pd.read_pickle(df_sec_raw_pk)
    df_res = df_sec.join(df_idx, how='inner') \
        .assign(chg_sec_net=lambda df: (df['chg_sec'] - df['chg_idx']) / 100.0) \
        .assign(chg_sec_net_ln=lambda df: df.chg_sec_net.apply(np.log1p)) \
        .reset_index()
    df_res.to_pickle(df_sec_ind_by_day_pk)


def compute_sec_ind_stat():
    """
    function to compute section indicators that needs to stat group by section,
    this function depends on the output of COMPUTE_SEC_IND_BY_DAY().
    :return:
    """
    df_sec = pd.read_pickle(df_sec_ind_by_day_pk)
    df_sec_std = df_sec \
                     .loc[:, ['sec_code', 'chg_sec_net_ln', 'period']] \
        .groupby('sec_code') \
        .agg({'chg_sec_net_ln': [np.mean, np.std],
              'period': [np.max]}) \
        .reset_index()
    df_sec_std.columns = ['_'.join(col).strip('_') for col in df_sec_std.columns]
    df_sec_std.to_pickle(df_sec_ind_stat_pk)


def compute_stk_ind_by_day():
    """
    function to compute stock indicators by period, those that
    doesn't need to group by stock to stat.
    :return:
    """
    df_idx = pd.read_pickle(df_idx_raw_pk)
    df_stk = pd.read_pickle(df_stk_raw_pk)
    df_res = df_stk.join(df_idx, how='inner') \
        .assign(chg_stk_net=lambda df: (df['chg_stk'] - df['chg_idx']) / 100.0) \
        .assign(chg_stk_net_ln=lambda df: df.chg_stk_net.apply(np.log1p)) \
        .reset_index()
    df_res.to_pickle(df_stk_ind_by_day_pk)


def compute_stk_ind_stat():
    """
    function to compute stock indicators that needs to stat group by stocks,
    this function depends on the output of COMPUTE_STK_IND_BY_DAY().
    :return:
    """
    df_stk = pd.read_pickle(df_stk_ind_by_day_pk)
    df_stk_std = df_stk \
                     .loc[:, ['stk_code', 'chg_stk_net_ln']] \
        .groupby('stk_code') \
        .agg({'chg_stk_net_ln': [np.mean, np.std]}) \
        .reset_index()
    df_stk_std.columns = ['_'.join(col).strip('_') for col in df_stk_std.columns]
    df_stk_std.to_pickle(df_stk_ind_stat_pk)


def compute_sec_ind_roll_stks_by_day():
    """
    function to merge section with stock performance to compute the average raising percent.
    this function depends on the outputs of COMPUTE_SEC_IND_BY_DAY() & COMPUTE_STK_IND_BY_DAY().
    :return:
    """
    df_sec_stk_dt = pd.read_pickle(df_sec_stk_dt_raw_pk)
    df_stk = pd.read_pickle(df_stk_ind_by_day_pk)
    df_res = pd.merge(df_sec_stk_dt,
                      df_stk.loc[:, ['stk_code', 'period', 'chg_stk_net']],
                      on=['stk_code', 'period']) \
        .assign(stk_inc=lambda df: (df.chg_stk_net > 0).astype(np.float)) \
        .groupby(['sec_code', 'period']) \
        .agg({'stk_inc': np.mean}) \
        .reset_index() \
        .rename(columns={'stk_inc': 'stk_inc_mean'})
    df_res.to_pickle(df_sec_ind_roll_stks_pk)


def compose_sec_inds():
    """
    function to compose the outputs of COMPUTE_SEC_IND_BY_DAY(), COMPUTE_SEC_IND_ROLL_STKS_BY_DAY()
    & COMPUTE_SEC_IND_STAT(), the output of this function is used to label section-period groups.
    :return:
    """
    df_sec_ind_by_day = pd.read_pickle(df_sec_ind_by_day_pk)
    df_sec_ind_stat = pd.read_pickle(df_sec_ind_stat_pk)
    df_sec_ind_roll_stks = pd.read_pickle(df_sec_ind_roll_stks_pk)
    df_res = pd.merge(
        pd.merge(
            df_sec_ind_by_day.loc[:, ['period', 'sec_code', 'chg_sec_net', 'chg_sec_net_ln']] \
                .rename(columns={'chg_sec_net': 'chg_sec', 'chg_sec_net_ln': 'chg_sec_ln'}),
            df_sec_ind_roll_stks,
            on=['sec_code', 'period']),
        df_sec_ind_stat \
            .rename(columns={'chg_sec_net_ln_mean': 'chg_sec_mean',
                             'chg_sec_net_ln_std': 'chg_sec_std',
                             'period_amax': 'period_max'})
            .loc[:, ['sec_code', 'chg_sec_mean', 'chg_sec_std', 'period_max']],
        on='sec_code') \
        .assign(last_period=lambda df: df.period.shift(1).fillna(method='bfill')) \
        .assign(is_last=lambda df: df.period == df.period_max) \
        .dropna()
    # print "df_res", len(df_res)
    df_res.to_pickle(df_sec_res_pk)


def main():
    if not os.path.exists(df_sec_raw_pk) or not os.path.exists(df_stk_raw_pk):
        init_stk_sec_perf_data()
    logger.info('Start compose data...')
    query_data()
    logger.info('Querying raw data done.')
    compute_sec_ind_by_day()
    logger.info('Compute sec-ind-by-day done.')
    compute_stk_ind_by_day()
    logger.info('Compute stk-ind-by-day done.')
    compute_sec_ind_stat()
    logger.info('Compute sec-ind-stat done.')
    compute_stk_ind_stat()
    logger.info('Compute stk-ind-stat done.')
    compute_sec_ind_roll_stks_by_day()
    logger.info('Compute sec-info-roll-stks-by-day done.')
    compose_sec_inds()
    logger.info('Compose sec-inds done.')
    logger.info('Compose data done.')


if __name__ == "__main__":
    main()
    # compose_sec_inds()
    # init_stk_sec_perf_data()
