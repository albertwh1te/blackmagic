#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
变量说明：
上涨：50%个股上涨（sec_inc_pct），且累计涨幅达到股价波动率取对数的均值加上0.5标准差（sec_inc_var）
下降：累计涨幅达到股价波动率取对数的均值减去0.5个标准差（sec_desc_var）
维持：50%的个股上涨（sec_cont_pct），
上涨区间成立：指数累计涨幅超过0.5个标准差（sec_inc_establish_var）
"""

SEC_INC_PCT = 0.5
SEC_INC_VAR = 0.5
SEC_DESC_VAR = 0.5
SEC_CONT_PCT = 0.5
SEC_INC_ESTABLISH_STD = 3

#abspath = '/tmp/topic/stks_recommend_csv'
abspath = '/data/App/z3_transfer/shenzhen/topic/stks_recommend_csv'

df_idx_raw_pk = '%s/data/df_idx_raw.pickle' % abspath
df_sec_raw_pk = '%s/data/df_sec_raw.pickle' % abspath
df_stk_raw_pk = '%s/data/df_stk_raw.pickle' % abspath
df_sec_stk_dt_raw_pk = '%s/data/df_sec_stk_dt_raw.pickle' % abspath

df_sec_ind_by_day_pk = '%s/data/df_sec_ind_by_day.pickle' % abspath
df_sec_ind_stat_pk = '%s/data/df_sec_ind_stat.pickle' % abspath

df_stk_ind_by_day_pk = '%s/data/df_stk_ind_by_day.pickle' % abspath
df_stk_ind_stat_pk = '%s/data/df_stk_ind_stat.pickle' % abspath
df_sec_ind_roll_stks_pk = '%s/data/df_sec_ind_roll_stks.pickle' % abspath

df_sec_res_pk = '%s/data/df_sec_res.pickle' % abspath

res_df_scores_csv = '%s/data/res_df_scores.csv' % abspath
res_df_flags_csv = '%s/data/res_df_flags.csv' % abspath

get_sec_stk_rel_sql = """
select r.SECTION_CODE as sec_code, r.INNER_CODE as stk_code
  , r.en_time, ifnull(r.REJE_TIME, CURDATE()) as reje_time
from pgenius.PUB_SECTION_REL r
where r.SYS_CODE = 5  -- 概念板块
  and r.ISVALID = 1  -- 有效
  and (r.REJE_TIME >= ADDDATE(CURDATE(),INTERVAL -730 DAY) or r.REJE_TIME is null)
"""

get_valid_period_sql = """
select ENDDATE as period
from pgenius.PUB_EXCHANGE_CALENDAR c
where c.MKT_TYPE = 1  -- 沪深两市
  and c.OPEN_CLOSE = 1  -- 开市
  and c.enddate >= ADDDATE(CURDATE(),INTERVAL -730 DAY)
  and c.enddate <= CURDATE()
"""

# 数据库连接需要0秒
# 注意日期的写法，保证可以使用索引
init_seq_perf_sql = """
select e.inner_code as sec_code, e.TRD_DATE as period
  , CAST(CHNG_PCT_DAY AS DECIMAL(24,6)) as chg_sec
from pgenius.ANA_SECTION_EXPR_IDX e
join pgenius.PUB_SECTION_CODE s on s.SECTION_CODE = e.INNER_CODE
where s.SYS_CODE = 5 and e.ISVALID = 1 and s.ISVALID = 1
  and e.trd_date >= ADDDATE(CURDATE(),INTERVAL -730 DAY)
  and e.CHNG_PCT_DAY is not null
"""

get_seq_perf_sql = """
select e.inner_code as sec_code, e.TRD_DATE as period
  , CAST(CHNG_PCT_DAY AS DECIMAL(24,6)) as chg_sec
from pgenius.ANA_SECTION_EXPR_IDX e
join pgenius.PUB_SECTION_CODE s on s.SECTION_CODE = e.INNER_CODE
where s.SYS_CODE = 5 and e.ISVALID = 1 and s.ISVALID = 1
  and e.trd_date >= ADDDATE(CURDATE(),INTERVAL -1 DAY)
  and e.CHNG_PCT_DAY is not null
"""

# 数据库连接需要0秒
# 注意日期的写法，保证可以使用索引
get_idx_perf_sql = """
select TRD_DATE as period, CAST(CHNG_PCT_DAY AS DECIMAL(24,6)) as chg_idx
from pgenius.ANA_INDX_EXPR_IDX
where INNER_CODE = '106000232'  -- 沪深300
  and trd_date >= ADDDATE(CURDATE(),INTERVAL -730 DAY)
  and CHNG_PCT_DAY is not null
"""

# 数据库查询连接3秒左右130w+条数据
# 注意日期的写法，保证可以使用索引
init_stk_perf_sql = """
select e.inner_code as stk_code, e.enddate as period
  , CAST(e.CHNG_PCT_DAY AS DECIMAL(24,6)) as chg_stk
from pgenius.ANA_STK_EXPR_IDX e
join pgenius.STK_CODE s on s.INNER_CODE = e.INNER_CODE
where e.chng_pct_day < 11 -- 剔除560个超过10%的涨幅
  and e.chng_pct_day is not null
  and e.enddate >= ADDDATE(CURDATE(),INTERVAL -730 DAY)
  and s.STATUS_TYPE_REF = 1
  and s.TRADE_MKT_REF in (1, 2)
"""

get_stk_perf_sql = """
select e.inner_code as stk_code, e.enddate as period
  , CAST(e.CHNG_PCT_DAY AS DECIMAL(24,6)) as chg_stk
from pgenius.ANA_STK_EXPR_IDX e
join pgenius.STK_CODE s on s.INNER_CODE = e.INNER_CODE
where e.chng_pct_day < 11 -- 剔除560个超过10%的涨幅
  and e.chng_pct_day is not null
  and e.enddate >= ADDDATE(CURDATE(),INTERVAL -1 DAY)
  and s.STATUS_TYPE_REF = 1
  and s.TRADE_MKT_REF in (1, 2)
"""
