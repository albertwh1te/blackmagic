# coding:utf-8
# Created by tao.liu at 2017/4/24
import pymongo
from config import config

def mongo_cursor():
    try:
        # conn = pymongo.MongoClient("127.0.0.1", 27017)
        conn = pymongo.MongoClient(config["mongodb_cloud_jq"]["uri"])
        # conn = pymongo.MongoClient(**config["mongodb_test"])
        # conn = pymongo.MongoClient(config["mongodb_4_11"]["uri"])

        return conn
    except Exception, e:
        print e
        return

def mongo_cursor2():
    try:
        # conn = pymongo.MongoClient("127.0.0.1", 27017)
        # conn = pymongo.MongoClient(config["mongodb_cloud_jq"]["uri"])
        # conn = pymongo.MongoClient(**config["mongodb_test"])
        conn = pymongo.MongoClient(config["mongodb_4_11"]["uri"])

        return conn
    except Exception, e:
        print e
        return



if __name__ == "__main__":
    pass
