# -*- coding:utf-8 -*-
# __author__=qiang.fu

from datetime import time, datetime
from pandas import date_range, DataFrame, DatetimeIndex
import pytz
import pymongo
from zipline.utils.calendars import TradingCalendar
from zipline.utils.calendars.trading_calendar import days_at_time
import pandas as pd
import numpy as np
from quant_dao import get_mongodb

# from lru import LRU
# # lunch break for shanghai and shenzhen exchange
# lunch_break_start = time(11, 30)
# lunch_break_end = time(13, 1)

start_default = pd.Timestamp('2005-01-01', tz='UTC')
end_base = pd.Timestamp('today', tz='UTC')
end_default = end_base + pd.Timedelta(days=365)

class ChinaCalendar(TradingCalendar):
    """
    China Exchange Calendar
    """
    def __init__(self, start=start_default, end=end_default):
        # Midnight in UTC for each trading day.
        db = get_mongodb()
        cursor = db['Z3_EXCHANGE_CALENDAR'].find(
            {'open_close': {'$in': [1, 3]},
             'trade_date': {'$gte': 20050101},
             'exchange': 'SZ'},
            projection={
                'trade_date': 1,
                '_id': 0
            }).sort([('trade_date', pymongo.ASCENDING)])
        df = pd.DataFrame(list(cursor))['trade_date']
        array = df.values
        days = []
        import datetime
        for i in array:
            s = str(i)
            d = datetime.datetime(int(s[:4]), int(s[4:6]), int(s[6:]))
            days.append(d)
        _all_days = DatetimeIndex(data=days, freq='D', tz='utc')
        #print _all_days

        # `DatetimeIndex`s of standard opens/closes for each day.
        self._opens = days_at_time(_all_days, self.open_time, self.tz,
                                   self.open_offset)
        self._closes = days_at_time(
            _all_days, self.close_time, self.tz, self.close_offset
        )
        #print "_opens",self._opens
        # # `DatetimeIndex`s of nonstandard opens/closes
        # _special_opens = self._calculate_special_opens(start, end)
        # _special_closes = self._calculate_special_closes(start, end)
        #
        # # Overwrite the special opens and closes on top of the standard ones.
        # _overwrite_special_dates(_all_days, self._opens, _special_opens)
        # _overwrite_special_dates(_all_days, self._closes, _special_closes)

        # In pandas 0.16.1 _opens and _closes will lose their timezone
        # information. This looks like it has been resolved in 0.17.1.
        # http://pandas.pydata.org/pandas-docs/stable/whatsnew.html#datetime-with-tz  # noqa
        self.schedule = DataFrame(
            index=_all_days,
            columns=['market_open', 'market_close'],
            data={
                'market_open': self._opens,
                'market_close': self._closes,
            },
            dtype='datetime64[ns]',
        )

        self.market_opens_nanos = self.schedule.market_open.values. \
            astype(np.int64)

        self.market_closes_nanos = self.schedule.market_close.values. \
            astype(np.int64)

        self._trading_minutes_nanos = self.all_minutes.values. \
            astype(np.int64)

        self.first_trading_session = _all_days[0]
        self.last_trading_session = _all_days[-1]

        # self._early_closes = pd.DatetimeIndex(
        #     _special_closes.map(self.minute_to_session_label)
        # )
        # self._minute_to_session_label_cache = LRU(1)

    @property
    def name(self):
        return "China"

    @property
    def tz(self):
        return pytz.timezone("Asia/Shanghai")

    @property
    def open_time(self):
        return time(17, 31)

    @property
    def close_time(self):
        return time(23, 00)

    @property
    def trading_day(self):
        today = datetime.today()
        return datetime(today.year, today.month, today.day, 0, 0, 0)
    # @property
    # def adhoc_holidays(self):
    #     return [Timestamp(t,tz=pytz.UTC) for t in get_cached()]
    #
    #
    # @property
    # @remember_last
    # def all_minutes(self):
    #     """
    #         Returns a DatetimeIndex representing all the minutes in this calendar.
    #     """
    #     opens_in_ns = \
    #         self._opens.values.astype('datetime64[ns]')
    #
    #     closes_in_ns = \
    #         self._closes.values.astype('datetime64[ns]')
    #
    #     lunch_break_start_in_ns = \
    #         self._lunch_break_starts.values.astype('datetime64[ns]')
    #     lunch_break_ends_in_ns = \
    #         self._lunch_break_ends.values.astype('datetime64[ns]')
    #
    #     deltas_before_lunch = lunch_break_start_in_ns - opens_in_ns
    #     deltas_after_lunch = closes_in_ns - lunch_break_ends_in_ns
    #
    #     daily_before_lunch_sizes = (deltas_before_lunch / NANOS_IN_MINUTE) + 1
    #     daily_after_lunch_sizes = (deltas_after_lunch / NANOS_IN_MINUTE) + 1
    #
    #     daily_sizes = daily_before_lunch_sizes + daily_after_lunch_sizes
    #
    #     num_minutes = np.sum(daily_sizes).astype(np.int64)
    #
    #     # One allocation for the entire thing. This assumes that each day
    #     # represents a contiguous block of minutes.
    #     all_minutes = np.empty(num_minutes, dtype='datetime64[ns]')
    #
    #     idx = 0
    #     for day_idx, size in enumerate(daily_sizes):
    #         # lots of small allocations, but it's fast enough for now.
    #
    #         # size is a np.timedelta64, so we need to int it
    #         size_int = int(size)
    #
    #         before_lunch_size_int = int(daily_after_lunch_sizes[day_idx])
    #         after_lunch_size_int = int(daily_after_lunch_sizes[day_idx])
    #
    #         all_minutes[idx:(idx + before_lunch_size_int)] = \
    #             np.arange(
    #                 opens_in_ns[day_idx],
    #                 lunch_break_start_in_ns[day_idx] + NANOS_IN_MINUTE,
    #                 NANOS_IN_MINUTE
    #             )
    #
    #         all_minutes[(idx + before_lunch_size_int):(idx + size_int)] = \
    #             np.arange(
    #                 lunch_break_ends_in_ns[day_idx],
    #                 closes_in_ns[day_idx] + NANOS_IN_MINUTE,
    #                 NANOS_IN_MINUTE
    #             )
    #
    #         idx += size_int
    #     return DatetimeIndex(all_minutes).tz_localize("UTC")