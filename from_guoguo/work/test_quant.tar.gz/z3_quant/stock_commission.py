# -*- coding: utf-8 -*-
from zipline.finance.commission import CommissionModel
from collections import defaultdict


#
# class StockCommission(CommissionModel):
#     def __init__(self, rate, tax_rate=0.001, min_commission=5):
#         self.commission_map = defaultdict(lambda: min_commission)
#         self.min_commission = min_commission
#         self.tax_rate = tax_rate
#         self.rate = rate
#
#     def calculate(self, order, transaction):
#         """
#         计算手续费这个逻辑比较复杂，按照如下算法来计算：
#         1.  定义一个剩余手续费的概念，根据order_id存储在commission_map中，默认为min_commission
#         2.  当trade来时计算该trade产生的手续费cost_money
#         3.  如果cost_money > left_commission
#             3.1 如果commission 等于 min_commission，说明这是第一笔trade，此时，直接commission置0，返回cost_money即可
#             3.2 如果commission 不等于 min_commission, 则说明这不是第一笔trade,此时，直接cost_money - commission即可
#         4.  如果cost_money <= left_commission
#             4.1 如果commission 等于 min_commission, 说明是第一笔trade, 此时，返回min_commission(提前把最小手续费收了)
#             4.2 如果commission 不等于 min_commission， 说明不是第一笔trade, 之前的trade中min_commission已经收过了，所以返回0.
#         """
#         order_id = transaction.order_id
#         left_commission = self.commission_map[order_id]
#         # 总成交额
#         turnover = transaction.price * abs(transaction.amount)
#         cost_money = transaction.price * abs(transaction.amount) * self.rate
#         total_commission = 0
#         if cost_money > left_commission:
#             if left_commission == self.min_commission:
#                 #如果第一次，第一次就超5块 直接添剩余
#                 self.commission_map[order_id] = 0
#                 total_commission = cost_money
#             else:
#                 #如果不是第一次 因为之前直接扣过五块 所以 left_commission给加回来
#                 self.commission_map[order_id] = 0
#                 total_commission = cost_money - left_commission
#         else:#如果比剩的少
#             if left_commission == self.min_commission:
#                 #如果第一次 直接扣五块
#                 self.commission_map[order_id] -= cost_money
#                 total_commission = left_commission
#             else:
#                 #不是第一次 跟之前的往下减 不再扣手续费
#                 self.commission_map[order_id] -= cost_money
#                 total_commission = 0
#
#         if transaction.amount < 0:
#             tax = turnover * self.tax_rate
#             total_commission += tax
#         return total_commission


class StockCommission(CommissionModel):
    def __init__(self, rate, tax_rate=0.001, min_commission=5):
        self.min_commission = min_commission
        self.tax_rate = tax_rate
        self.rate = rate

    def calculate(self, order, transaction):
        """
        如果
        """
        turnover = transaction.price * abs(transaction.amount)
        cost_money = turnover * self.rate
        commission = max(cost_money, self.min_commission)
        if transaction.amount < 0:
            tax = turnover * self.tax_rate
            commission += tax
        return commission

    def calculate_by_amount_price(self, amount, price):
        # 总成交额
        turnover = price * abs(amount)
        cost_money = turnover * self.rate
        commission = max(cost_money, self.min_commission)
        if amount < 0:
            tax = turnover * self.tax_rate
            commission += tax
        return commission

    def calculate_by_amount_price_no_tax(self, amount, price):
        # 总成交额
        turnover = price * abs(amount)
        cost_money = turnover * self.rate
        commission = max(cost_money, self.min_commission)
        return commission

if __name__ == "__main__":
    from zipline.finance.order import *
    from datetime import datetime
    from zipline.finance.transaction import *


    class tr(object):
        def __init__(self, price, amount):
            pass
            self.price = price
            self.amount = amount


    transaction = tr(2, -10000)
    com = StockCommission(0.0002)
    print com.calculate(None, transaction)
