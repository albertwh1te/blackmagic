# -*- coding:utf-8 -*-

import pymongo
import time
import pandas as pd
from quant_dao import get_mongodb
from datetime import datetime,timedelta
from utils.utils import *
def check_day():
    db = get_mongodb()
    _today = time.strftime('%Y%m%d', time.localtime(time.time()))
    int_today_date = int(_today)
    count = db['Z3_EXCHANGE_CALENDAR'].find(
        {'open_close': 1,
         'trade_date': int_today_date,
         'exchange': 'SZ'},
        projection={
            'trade_date': 1,
            '_id': 0
        }).sort([('trade_date', pymongo.ASCENDING)]).count()
    if count:
        return True
    else:
        return False


if __name__== "__main__":
    print check_day()