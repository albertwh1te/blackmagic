# -*- coding:utf-8 -*-
# __author__=qiang.fu
import time

from backtest_thread import BacktestThread
from quant_dao import get_kafka_consumer,get_kafka_producer
from utils.z3logging import info

thread_dict = dict()
_running_thread_dict = {}


class DemoTask(object):
    """demo task used for test"""

    def __init__(self, stra):
        self.stop = False
        self.name = stra

    def set_stop(self):
        self.stop = True

    def start(self):
        while True:
            if self.stop:
                info("stopped by user ...")
                break

            print("running {}".format(self.name))
            time.sleep(3)

        self.stop = True


def start_back_test2(backtest_id,strategy_id,strategy_type,data_portal,asset_finder):
    global thread_dict
    # just 4 test
    # new_thread = DemoTask(strategy_id)
    if thread_dict.has_key(backtest_id):
        thread = thread_dict[backtest_id]
        thread.set_stop(False)
        del thread_dict[backtest_id]

    new_thread = BacktestThread(backtest_id,strategy_id,data_portal,asset_finder, remove_thread)
    new_thread.setStrategyType(strategy_type)
    thread_dict[backtest_id] = new_thread
    new_thread.start()


def start_back_test(backtest_id,strategy_id,data_portal,asset_finder):
    global thread_dict
    new_thread = BacktestThread(backtest_id,strategy_id,data_portal, asset_finder,remove_thread)
    thread_dict[backtest_id] = new_thread
    new_thread.start()

def notify_stop_back_test(backtest_id):
    try:
        producer = get_kafka_producer()
        # print "run time",send_dict["running_time"]
        send_dict = {}
        import json
        send_dict["backtest_id"] = backtest_id
        print "send stop ",backtest_id
        send_json = json.dumps(send_dict)
        producer.send("quant_backtest_stop", send_json)
        producer.flush()
    except Exception,e:
        print e
def stop_back_test(backtest_id):
    global thread_dict
    if thread_dict.has_key(backtest_id):
        running_thread = thread_dict.get(backtest_id)
        running_thread.set_stop()
        del thread_dict[backtest_id]
        # del thread_dict[strategy_id]
        # stop_thread(running_thread)
        # del thread_dict[strategy_id]
        # db = get_mongodb()
        # result_overview_detail = db['Z3_BACKTEST'].find_one({'strategy_id': strategy_id}).get(
        #     'backtest_result_overview_detail')
        # result_overview_detail[-1]['status'] = 3
        # db['Z3_BACKTEST'].update_one({'strategy_id': strategy_id},
        #                              {"$set": {'backtest_result_overview_detail': result_overview_detail,
        #                                        'backtest_status': 3}})


def remove_thread(backtest_id):
    global thread_dict
    try:
        if thread_dict.has_key(backtest_id):
            del thread_dict[backtest_id]
    except:
        pass
        # def _async_raise(tid, exctype):
        #     """raises the exception, performs cleanup if needed"""
        #     tid = ctypes.c_long(tid)
        #     if not inspect.isclass(exctype):
        #         exctype = type(exctype)
        #     res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))
        #     if res == 0:
        #         raise ValueError("invalid thread id")
        #     elif res != 1:
        #         # """if it returns a number greater than one, you're in trouble,
        #         # and you should call it again with exc=NULL to revert the effect"""
        #         ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)
        #         raise SystemError("PyThreadState_SetAsyncExc failed")
        #
        # def stop_thread(thread):
        #     _async_raise(thread.ident, SystemExit)


def handle_stop_message():
    """
        获取停止回测消息
        主题：topic_stop_backtest
        消息体：strategy_id
    :return: 
    """
    print("init stop_backtest kafka consumer ... ")
    topic = "quant_backtest_stop"
    consumer = get_kafka_consumer(topic)
    # while True:
    #     try:
    #         data = consumer.poll(timeout_ms=2000, max_records=100)
    #         for topic in data.keys():
    #             message_list = data[topic]
    #             for record in message_list:
    #                 print("stop stratety {}".format(record.value))
    #                 stop_back_test(record.value)
    #     except Exception as e:
    #         print(e)
    #     # fetch data every 3 second
    #     time.sleep(3)
    #     # print("poll data from kafka ...")
    import json
    for message in consume_data(consumer):
        try:
            # print message
            message_value = json.loads(message.value)
            # if "strategy_id" in strategy_id:
            #
            #     strategy_id = strategy_id.get("strategy_id")
            backtest_id = message_value.get("backtest_id")
            print "stop", backtest_id
            stop_back_test(backtest_id)
        except Exception, e:
            print e


def consume_data(consumer):
    try:
        for message in consumer:
            yield message
    except KeyboardInterrupt, e:
        print e


def handle_task_tracker():
    """
        更新任务队列表
        1）定期维护的任务列表，防止其他意外情况造成的任务列表不一致。
        2）统计打印当前的任务数
    """
    global thread_dict
    while True:
        try:
            for stra in thread_dict.keys():
                task = thread_dict[stra]
                if task and task.stop:
                    del thread_dict[stra]
                    info("strategy with id {} finished.".format(stra))
        except:
            pass
        # info("current running task {}".format(len(thread_dict)))
        # update rate: every 30s
        time.sleep(30)




from indicator_service import get_true_days
def get_buy_sell_points(inner_code,buy_param,buy_exp,sell_param,sell_exp,start_date,end_date,z3_data_portal,z3_asset_finder,calendar):


    ret =  get_true_days(inner_code,buy_param,buy_exp,sell_param,sell_exp,start_date,end_date,z3_data_portal,z3_asset_finder,calendar)
    return ret

#
#
# z3_data_portal = None
# z3_asset_finder = None
# z3_trading_calendar = None
# z3_benchmark_returns = None
# z3_env = None
# current_day=None
# z3_data_portal_dir=None
# z3_ex_data = {}
# ex_columns = ('open','high','low','close','volume',
#               'ex_open', 'ex_high', 'ex_low', 'ex_close','avg','mtkcap_a',
#               'trade_next_status','trade_status',
#               'limit_down_non_open','limit_up_non_open')
#
# from z3_quant.data.ex_data_cache import *
#
#
#
# def get_data_portal():
#     if z3_data_portal is not None:
#         return z3_data_portal
#     global z3_data_portal
#     global z3_asset_finder
#     global z3_trading_calendar
#     global z3_benchmark_returns
#     global current_day
#     global z3_env
#     today = datetime.today().date()
#     if z3_data_portal is None or current_day != today:
#         bundle = 'genius_bundle'
#         bundle_data = load(
#             bundle,
#             os.environ,
#             None,
#         )
#         prefix, connstr = re.split(
#             r'sqlite:///',
#             str(bundle_data.asset_finder.engine.url),
#             maxsplit=1,
#         )
#         z3_env = env = Z3TradingEnvironment(
#             bm_symbol="000001",
#             load=load_benchmark_data,
#             trading_calendar=get_calendar("China"),
#             asset_db_path=connstr
#         )
#         z3_asset_finder = env.asset_finder
#         z3_benchmark_returns = env.benchmark_returns
#         calendar_start_date = pd.to_datetime(str("2005-01-04") + " 17:30:00").tz_localize("Asia/Shanghai").astimezone(
#             tz=pytz.UTC)
#         first_trading_day = \
#             bundle_data.equity_minute_bar_reader.first_trading_day
#
#         z3_trading_calendar = get_calendar("China")
#
#         z3_data_portal = Z3DataPortal(
#             env.asset_finder,
#             get_calendar("China"),
#             first_trading_day=first_trading_day,
#             equity_minute_reader=bundle_data.equity_minute_bar_reader,
#             equity_daily_reader=bundle_data.equity_daily_bar_reader,
#             adjustment_reader=bundle_data.adjustment_reader,
#         )
#         current_day = today
#     return z3_data_portal
#
#
# def get_env():
#     get_data_portal()
#     global z3_env
#     return z3_env
#
# def get_asset_finder():
#     get_data_portal()
#     global z3_asset_finder
#     return z3_asset_finder
#
#
#
# @data_lru_cache(3500)
# def get_history_date(symbol,asset_finder, frequency="1d"):
#     get_data_portal()
#     global z3_asset_finder
#     global z3_data_portal
#     now = datetime.now()-timedelta(days=1)
#     end_dt = pd.Timestamp(now) #z3_benchmark_returns.index[-1]
#     end_session = get_session(end_dt)
#     # start_loc = get_date_loc(calendar_start_date)
#     end_loc = get_date_loc(end_dt)
#     count = end_loc + 1  # 所有数据
#     sym = asset_finder.lookup_symbol(symbol, as_of_date=end_session)
#     df_dict = {
#         field: z3_data_portal.get_history_window([sym], end_session, count, frequency, field)[sym] for field in ex_columns
#     }
#     df = pd.DataFrame(df_dict)
#     return df
#
#
# def get_calendar_session(dt):
#     get_data_portal()
#     global z3_trading_calendar
#     return z3_trading_calendar.minute_to_session_label(dt,direction='previous')
#
#
# def get_date_loc(dt):
#     get_data_portal()
#     global z3_trading_calendar
#     tds = z3_trading_calendar.all_sessions
#     dt_session = get_calendar_session(dt)
#     return tds.get_loc(dt_session)
#
#
# def get_session(dt):
#     get_data_portal()
#     global z3_trading_calendar
#     tds = z3_trading_calendar.all_sessions
#     dt_session = get_calendar_session(dt)
#     return dt_session
#
# def get_curret_data(symbols,dt,column):
#     get_data_portal()
#     global z3_asset_finder
#     session = get_session(dt)
#     ret_dict = {
#         symbol: get_history_date(symbol,z3_asset_finder).loc[session][column] for symbol in symbols
#     }
#     return ret_dict
#
# def ex_data_history_all(symbols, end_session):
#     get_data_portal()
#     global z3_asset_finder
#     ret_dict = {
#         symbol: get_history_date(symbol,z3_asset_finder).loc[:end_session] for symbol in symbols
#     }
#     return ret_dict
#     # return pa
#
# def ex_assets_finder(symbols,lookup_date):
#     get_data_portal()
#     syms =  [ex_asset_finder(identifier,lookup_date) for identifier in symbols]
#     return syms
#
#
# @data_lru_cache(3500)
# def ex_asset_finder(symbol_str,lookup_date):
#     get_data_portal()
#     global z3_asset_finder
#     sym = z3_asset_finder.lookup_symbol(
#         symbol_str,
#         as_of_date=lookup_date,
#     )
#     return sym