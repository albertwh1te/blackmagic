# -*- coding:utf-8 -*-
import ctypes
import inspect
import multiprocessing
import os
import sys
import threading

import time
import traceback

from flask import Flask, request

from backtest_thread import BacktestThread
from quant_dao import setup_run_env
from utils.z3logging import info, debug

app = Flask(__name__)
_pool = None
_running_tasks_dic = {}

class DemoTask(object):
    """demo task used for test"""

    def __init__(self):
        self.stop = False
        self.name = threading.currentThread().name

    def set_stop(self):
        self.stop = True

    def start(self):
        while True:
            if self.stop:
                info("stopped by user ...")
                return
            print("forever {}".format(self.name))
            time.sleep(3)


def start_task_wrapper(strategy_id, task_dict):
    def wrapper_task(demo):
        demo.start()

    try:
        demo = DemoTask()
        threading.Thread(target=wrapper_task, args=(demo, )).start()
        task_dict[strategy_id] = demo
    except Exception as e:
        traceback.print_exc(file=sys.stdout)


def stop_task_wrapper(strategy_id, task_dict):
    if strategy_id in task_dict:
        task = task_dict[strategy_id]
        task.set_stop()
        if task.stop:
            del task_dict[strategy_id]


# 首页控制器
@app.route('/')
def index():
    return "量化回测服务"


# 开始回测
@app.route('/start_back_test')
def start_back_test():
    try:
        strategy_id = request.args.get("strategy_id")
        future = _pool.apply_async(start_task_wrapper, args=(strategy_id, _running_tasks_dic))
    except Exception as e:
        traceback.print_exc(file=sys.stdout)
    return 'started'


# 停止回测
@app.route('/stop_back_test')
def stop_back_test():
    strategy_id = request.args.get("strategy_id")
    stop_task_wrapper(strategy_id, _running_tasks_dic)
    return "stopped"


if __name__ == '__main__':
    if sys.platform == 'win32':
        multiprocessing.freeze_support()

    _pool = multiprocessing.Pool(4, maxtasksperchild=2)
    _running_tasks_dic = multiprocessing.Manager().dict()
    run_env = None
    if len(sys.argv) > 1:
        run_env = sys.argv[1]
    setup_run_env(run_env)

    info("quant web started.")
    # app.run(host="0.0.0.0", port=5050, processes=4)
    app.run(host="0.0.0.0", port=5050)
