### 1. 主要功能
提供量化回测调用接口

### 2. 安装依赖库
su
./Anaconda2-4.3.0-Linux-x86_64.sh
conda install -c Quantopian zipline=1.0.2
pip install flask
pip install ply
pip install pymongo
pip install kafka-python
pip install empyrical
pip install APScheduler
conda install -c https://conda.anaconda.org/quantopian ta-lib

### 服务启动服务脚本
python quant_web [pro]

### 数据输出结果数据结构
{
    "strategy_id": "", #策略id
    "backtest_start_date": "", #开始回测时间
    "backtest_end_date": "", #回测结束时间
    "init_fund": 0, #初始金额
    "trade_status": 0, #回测结果
    "backtest_result_overview_detail": [
        {
            "strategy_id": "", #策略id
            "backtest_date": "", #回测日期
            "progess": 0, #回测进度
            "status": 0, #回测状态
            "running_time": 0, #运行时间
            "algorithm_period_return": 0, # 总收益
            "benchmark_period_return": 0, #基准收益
            "annual_return": 0, #年化收益
            "excess_return": 0, #超额收益
            "algo_volatility": 0, #波动率
            "sharpe": 0, #夏普比率
            "max_drawdown": 0, #最大回撤
            "alpha": 0, #alpha
            "beta": 0, #beta
            "win_ratio": 0, #胜率
            "turnover": 0, #换手率
            "alpha_20": 0, #20日alpha
            "alpha_60": 0, #60日alpha
            "alpha_120": 0, #120日alpha
            "alpha_250": 0, #250日alpha
            "beta_20": 0, #20日beta
            "beta_60": 0, #60日beta
            "beta_120": 0, #120日beta
            "beta_250": 0, #250日beta
            "information_20": 0, #20日信息比率
            "information_60": 0, #60日信息比率
            "information_120": 0, #120日信息比率
            "information_250": 0, #250日信息比率
            "sharpe_20": 0, #20日夏普比率
            "sharpe_60": 0, #60日夏普比率
            "sharpe_120": 0, #120日夏普比率
            "sharpe_250": 0, #250日夏普比率
            "algo_volatility_20": 0, #20日波动率
            "algo_volatility_60": 0, #60日波动率
            "algo_volatility_120": 0, #120日波动率
            "algo_volatility_250": 0, #250日波动率
            "max_drawdown_20": 0, #20日最大回撤
            "max_drawdown_60": 0, #60日最大回撤
            "max_drawdown_120": 0, #120日最大回撤
            "max_drawdown_250": 0, #250日最大回撤
            "buy_value": 0, #买入金额
            "sell_value": 0, #卖出金额
            "profit": 0, #当日盈亏
            "portfolio": 0 #当日资产
        }
    ], 
    "backtest_trade_detail": [
        {
            "backtest_date": "", #回测日期
            "inner_code": "", #股票代码
            "name": "", #股票名称
            "buy_sell_type": 1, #买卖类型
            "price": 0, #成交价格
            "amount": 0, #成交量
            "quantity": 0, #成交额
            "commission": 0, #佣金
            "status": 0, #交易状态
            "log": "" #日志
        }
    ], 
    "backtest_daily_position_detail": [
        {                    
            "backtest_date": "", #回测日期
            "portfolio_value": 0, #总资产
            "cash": 0, #可用余额
            "inner_code": "", #股票代码
            "name": "", #股票名称
            "cost_price": 0, #参考成本
            "market_price": 0, #参考市价
            "hold_volume": 0, #持股数量
            "market_value": 0, #参考市值
            "profit_loss_amount": 0, #参考盈亏
            "profit_loss_ratio": 0 #盈亏比例
        }
    ]
}

### 修訂記錄
    20170706 侯月明 将原回测线程改完普通对象，在quant_web中通过线程池启动回测线程，停止回测通过监听kafka消息，消息主题：quant_backtest_stop，内容：策略id

