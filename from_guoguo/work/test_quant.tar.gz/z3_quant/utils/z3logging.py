# encoding=utf8

from logbook import Logger, FileHandler, StreamHandler
import sys

_default_logger = Logger("Z3_QUANT")

_default_logger.suppress_dispatcher = True
debug = _default_logger.debug
info = _default_logger.info
warn = _default_logger.warn
error = _default_logger.error
exception = _default_logger.exception
catch_exceptions = _default_logger.catch_exceptions
critical = _default_logger.critical
del _default_logger

handler = StreamHandler(sys.stdout)
handler.push_application()

__ALL__ = [debug, info, warn, error, exception, critical, catch_exceptions]

