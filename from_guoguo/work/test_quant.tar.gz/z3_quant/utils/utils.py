# -*- coding:utf-8 -*-
from datetime import datetime
import time
import pytz
import pandas as pd
def str_to_if(str):
    try:
        if '.' in str:
            return float(str)
        return int(str)
    except:
        return str


def date_to_n8(date):
    if date is None:
        return 0
    return date.year * 10000 + date.month * 100 + date.day


def date_to_n6(date):
    if date is None:
        return 0
    return date.year * 100 + date.month


def n8_to_date(n8):
    day = n8 % 100
    value = int(n8 / 100)
    month = int(value % 100)
    year = int(value / 100)
    return datetime(year, month, day)


def n8_to_utc_date(n8):
    day = n8 % 100
    value = n8 / 100
    month = value % 100
    year = value / 100
    return datetime(year, month, day,tzinfo = pytz.UTC)

def local2utc(local_st):
    a=  local_st.timetuple()
    time_struct = time.mktime(local_st.timetuple())
    utc_st = datetime.utcfromtimestamp(time_struct)
    return utc_st

def date_to_ts(dt):
    return int(time.mktime(dt.timetuple()))


def n8_to_ts(n8):
    return date_to_ts(n8_to_date(n8))

def utc2local(utc_st):
    now_stamp = time.time()
    local_time = datetime.datetime.fromtimestamp(now_stamp)
    utc_time = datetime.datetime.utcfromtimestamp(now_stamp)
    offset = local_time - utc_time
    local_st = utc_st + offset
    return local_st

def n8_to_utc_ts(n8):
    strn8 = str(n8)
    import pandas as pd
    t = pd.Timestamp(n8_to_date(n8),unit='s',tz='UTC')
    return t.value/int(1e9)

def ts_to_date(ts):
    dt = datetime.fromtimestamp(ts)
    return datetime(dt.year, dt.month, dt.day)


def diff_day(end, start):
    delta = end - start
    return delta.days


def is_same_week(date1, date2):
    iso1 = date1.isocalendar()
    iso2 = date2.isocalendar()
    if iso1[0] == iso2[0] and iso1[1] == iso2[1]:
        return True
    else:
        return False


def is_same_month(date1, date2):
    if date1.year == date2.year and date1.month == date2.month:
        return True
    else:
        return False


def str_to_date_(sdt):
    return datetime.strptime(sdt, '%Y-%m-%d')


def date_to_month_day_str(dt):
    return "%02d%02d" % (dt.month,dt.day)


if __name__ == "__main__":
    date = (datetime(2017,9,5))
    print pd.Timestamp(date)
    # print ts_to_date(n8_to_utc_ts(20170101))
    # print (datetime(2017, 1, 3).isocalendar()[0])
# start_i = date_to_ts(datetime(2017,6,6))
# end_i = date_to_ts(datetime.now())
# start_amount = 1
# end_amount=10
# mid_i = (start_i*start_amount +end_i * end_amount)/(start_amount+end_amount)
# start_date = ts_to_date(mid_i)
# print start_date
