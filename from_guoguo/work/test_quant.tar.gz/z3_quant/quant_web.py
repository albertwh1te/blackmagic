# -*- coding:utf-8 -*-
import os
import sys
import threading
import traceback
import warnings
from multiprocessing.pool import ThreadPool

from flask import Flask, request,jsonify
from zipline.utils.run_algo import load_extensions

import quant_service
from backtest_thread import get_mongodb, datetime, numpy
from china_calendar import ChinaCalendar
from genius_bundle import genius_equities
from quant_dao import setup_run_env
from quant_service import notify_stop_back_test, handle_task_tracker,handle_stop_message,get_buy_sell_points
from utils.z3logging import info
import logging
from apscheduler.scheduler import Scheduler

logging.basicConfig()
app = Flask(__name__)
_pool = None
_running_thread_dic = {}

z3_data_portal = None
z3_asset_finder = None
z3_trading_calendar = None
g_bars = None
daily_bar = None
g_sp = False
schedudler = Scheduler()


# 首页控制器
@app.route('/')
def index():
    return "量化回测服务"


def update_callback(name, ud_df):
    global g_bars
    items = g_bars
    innerCode = name[2:8] + "." + name[0:2]
    items[innerCode] = ud_df


@schedudler.cron_schedule(second='0', day_of_week='1-5', hour='23',minute='10')
# @schedudler.cron_schedule(second='0', day_of_week='1-5', hour='18',minute='10')
def update_memory_data():
    if g_sp:
        return
    global g_bars
    from datetime import datetime
    print "update data",datetime.now()
    from hdf_data_update import get_data
    get_data(update_callback)
    # get_data_portal(g_bars)
    #

@schedudler.cron_schedule(second='0', day_of_week='1-5', hour='23',minute='40')
# @schedudler.cron_schedule(second='0', day_of_week='1-5', hour='18',minute='5')
def update_memory_data_process():
    if not g_sp:
        return
    global g_bars
    from datetime import datetime
    print "update data",datetime.now()
    from hdf_data_update import get_data
    # get_data(update_callback)
    get_data_portal(g_bars)

def start_task_wrapper(backtest_id,strategy_id,strategy_type, z3_data_portal,asset_finder):
    try:
        quant_service.start_back_test2(backtest_id,strategy_id,strategy_type, z3_data_portal,asset_finder)
    except Exception as e:
        traceback.print_exc(file=sys.stdout)


def stop_task_wrapper(backtest_id):
    try:
        quant_service.stop_back_test(backtest_id)
    except Exception as e:
        traceback.print_exc(file=sys.stdout)


# 开始回测
@app.route('/start_back_test')
def start_back_test():
    global z3_data_portal
    global z3_asset_finder
    try:
        info("current running task : {}".format(len(_running_thread_dic)))
        strategy_id = request.args.get("strategy_id")
        backtest_id = request.args.get("backtest_id")
        strategy_type = request.args.get("type")
        if strategy_type is None:
            strategy_type = '1'
        _pool.apply_async(start_task_wrapper, args=(backtest_id,strategy_id,strategy_type, z3_data_portal,z3_asset_finder))
    except Exception as e:
        traceback.print_exc(file=sys.stdout)
    return 'started'


# 停止回测
@app.route('/stop_back_test')
def stop_back_test():
    backtest_id = request.args.get("backtest_id")
    notify_stop_back_test(backtest_id)
    return 'stopped'


@app.route('/buy_sell_points')
def buy_sell_points():

    try:
        global z3_data_portal
        global z3_asset_finder
        global z3_trading_calendar
        inner_code = request.args.get("inner_code")
        buy_param = request.args.get("buy_param")
        buy_exp = request.args.get("buy_exp")
        sell_param = request.args.get("sell_param")
        sell_exp = request.args.get("sell_exp")
        start_date = request.args.get("start_date")
        end_date = request.args.get("end_date")
        now  = datetime.now()
        import json
        from utils.utils import n8_to_date
        if buy_param is not None:
            buy_param = json.loads(buy_param)
        if sell_param is not None:
            sell_param = json.loads(sell_param)

        print "buy_sell_points", inner_code,start_date,end_date
        # print "start_date",start_date
        # print "end_date",end_date
        if start_date is None:
            start_date = datetime(now.year-1,now.month,now.day)
        else:
            start_date = n8_to_date(int(start_date))
        if end_date is None:
            end_date = datetime(now.year,now.month,now.day)
        else:
            end_date = n8_to_date(int(end_date))

        # print "inner_code",inner_code
        # print "buy_param",buy_param
        # print "buy_exp",buy_exp
        # print "sell_param",sell_param
        # print "sell_exp",sell_exp
        # print "start_date",start_date
        # print "end_date",end_date
        ret = get_buy_sell_points(inner_code,buy_param,buy_exp,sell_param,sell_exp,start_date,end_date,z3_data_portal,z3_asset_finder,z3_trading_calendar)

        return jsonify(data=ret)

    except Exception,e:
        return jsonify(error_code=1)

def _init_task_tracker():
    task = threading.Thread(target=handle_task_tracker, args=())
    task.daemon = True
    task.start()


def _init_stop_message_receiver():
    task = threading.Thread(target=handle_stop_message, args=())
    task.daemon = True
    task.start()


import os
import re
from qunt_trading_environment import Z3TradingEnvironment
from benchmark_loader import load_benchmark_data
from zipline.utils.calendars import get_calendar
from data.Z3DataPortal import Z3DataPortal
import pytz
import pandas as pd
from datetime import datetime


# z3_data_portal = None


def get_data_portal(bars):
    global z3_data_portal
    global z3_asset_finder
    global z3_trading_calendar
    # if z3_data_portal is not None:
    #     return z3_data_portal
    # global z3_data_portal
    # global z3_asset_finder
    # global z3_trading_calendar
    # global z3_benchmark_returns
    # global current_day
    # global z3_env
    today = datetime.today().date()
    # if z3_data_portal is None or current_day != today:
    bundle = 'genius_bundle'
    from quant_core import load
    bundle_data = load(
        bundle,
        os.environ,
        None,
    )
    prefix, connstr = re.split(
        r'sqlite:///',
        str(bundle_data.asset_finder.engine.url),
        maxsplit=1,
    )
    z3_trading_calendar = get_calendar("China")
    z3_env = env = Z3TradingEnvironment(
        bm_symbol="000001",
        load=load_benchmark_data,
        trading_calendar=z3_trading_calendar,
        asset_db_path=connstr
    )
    z3_asset_finder = env.asset_finder
    z3_benchmark_returns = env.benchmark_returns
    calendar_start_date = pd.to_datetime(str("2005-01-04") + " 17:30:00").tz_localize("Asia/Shanghai").astimezone(
        tz=pytz.UTC)
    first_trading_day = \
        bundle_data.equity_minute_bar_reader.first_trading_day


    z3_data_portal = Z3DataPortal(
        env.asset_finder,
        get_calendar("China"),
        first_trading_day=first_trading_day,
        equity_minute_reader=bundle_data.equity_minute_bar_reader,
        equity_daily_reader=bundle_data.equity_daily_bar_reader,
        adjustment_reader=bundle_data.adjustment_reader,
        memory_bars=bars
    )
    current_day = today


def run_progress(bars, run_env, port):
    global g_sp
    g_sp = True
    setup_run_env(run_env)
    global _pool
    get_data_portal(bars)
    warnings.filterwarnings("ignore")
    numpy.seterr(invalid='ignore')

    import pandas as pd
    # 1)create thread pool
    _pool = ThreadPool(100)
    # 2)任务监控
    _init_task_tracker()
    # 3)启动停止回测任务监听
    _init_stop_message_receiver()


    def ingest_data():
        from quant_core import register
        from zipline.utils.calendars import register_calendar
        register_calendar("China", ChinaCalendar(), force=True)
        db = get_mongodb()
        symbols = db['Z3_STK_MKT_DAY'].distinct("innerCode")
        start_session_str = '2005-01-04'
        end_session_str = datetime.today()
        register(
            'genius_bundle',
            genius_equities(symbols),
            "China",
            pd.Timestamp(start_session_str, tz='utc'),
            pd.Timestamp(end_session_str, tz='utc'),
            # 中国股市每日交易时间为4个小时 美国是6个半小时
            minutes_per_day=240
        )

        load_extensions(
            default=True,
            extensions=[],
            strict=True,
            environ=os.environ,
        )
        info("ingest data complete.")

    schedudler.start()
    ingest_data()
    info("quant web started.")
    app.run(host="0.0.0.0", port=port)


from multiprocessing import Process, Manager
import time

from hdf_data_update import load_data
def run_server(bars,daily_bar):
    start_time = time.clock()
    db = get_mongodb()
    symbols = db['Z3_STK_MKT_DAY'].distinct("innerCode")
    store = pd.HDFStore("stocks.h5")
    length = len(symbols)
    index = 1
    for innerCode in symbols:
        try:
            name = innerCode[7:9] + innerCode[0:6]
            df = store.select(name)
            if name=='SH603960':
                print 'SH603960:',df.iloc[-1:]
            bars[innerCode] = df
        except Exception,e:
            pass
            df = load_data(innerCode,store,db)
            bars[innerCode] = df
        index += 1
        # print innerCode, index, length
        sys.stdout.write("\r %s %d %d " % (innerCode,index,length))
        sys.stdout.flush()

    print "load ok : ", time.clock() - start_time


def terminate(pool, event, manager, sig_num, addtion):
    print 'terminate process %d' % os.getpid()
    if not event.is_set():
        event.set()

    pool.close()
    pool.join()
    manager.shutdown()
    print 'exit ...'
    os._exit(0)
import signal
import functools
from multiprocessing import Pool
def main_fun():
    global g_bars
    global daily_bar
    run_env = None
    num = 5
    if len(sys.argv) > 1:
        run_env = sys.argv[1]
    if len(sys.argv) > 2:
        num = int(sys.argv[2])
    setup_run_env(run_env)




    # while True:
    #     time.sleep(60)

    manager = Manager()
    bars = manager.dict()
    daily_bar = manager.dict()
    g_bars = bars

    run_server(bars,daily_bar)
    from quant_dao import clear_mongodb
    clear_mongodb()
    ps = [Process(target=run_progress, args=(bars, run_env, 5000 + i)) for i in range(num)]
    for p in ps:
        p.daemon=True
        p.start()
    schedudler.start()
    for p in ps:
        p.join()


    # event = manager.Event()
    # mul_pool = Pool()
    # handler = functools.partial(terminate, mul_pool, event, manager)
    # signal.signal(signal.SIGTERM, handler)
    #
    # for i in range(num):
    #     mul_pool.apply_async(func=run_progress, args=(bars, run_env, 5000 + i, event))
    #


if __name__ == "__main__":
    main_fun()
