# -*- coding:utf-8 -*-
import os
import sys
import threading
import traceback
import warnings
from multiprocessing.pool import ThreadPool

from flask import Flask, request
from zipline.utils.calendars import register_calendar
from zipline.utils.run_algo import load_extensions

import quant_service
from backtest_thread import get_mongodb, datetime, numpy
from china_calendar import ChinaCalendar
from genius_bundle import genius_equities
from quant_core import register
from quant_dao import setup_run_env
from quant_service import handle_stop_message, handle_task_tracker
from utils.z3logging import info

app = Flask(__name__)
_pool = None
_running_thread_dic = {}
z3_data_portal = None

from quant_core import load
import os
import re
from qunt_trading_environment import Z3TradingEnvironment
from benchmark_loader import load_benchmark_data
from zipline.utils.calendars import get_calendar
from data.Z3DataPortal import Z3DataPortal
import pytz
import pandas as pd
from datetime import datetime


def get_data_portal(bars=None):
    global z3_data_portal
    # if z3_data_portal is not None:
    #     return z3_data_portal
    # global z3_data_portal
    # global z3_asset_finder
    # global z3_trading_calendar
    # global z3_benchmark_returns
    # global current_day
    # global z3_env
    today = datetime.today().date()
    # if z3_data_portal is None or current_day != today:
    bundle = 'genius_bundle'
    bundle_data = load(
        bundle,
        os.environ,
        None,
    )
    prefix, connstr = re.split(
        r'sqlite:///',
        str(bundle_data.asset_finder.engine.url),
        maxsplit=1,
    )
    z3_env = env = Z3TradingEnvironment(
        bm_symbol="000001",
        load=load_benchmark_data,
        trading_calendar=get_calendar("China"),
        asset_db_path=connstr
    )
    z3_asset_finder = env.asset_finder
    z3_benchmark_returns = env.benchmark_returns
    calendar_start_date = pd.to_datetime(str("2005-01-04") + " 17:30:00").tz_localize("Asia/Shanghai").astimezone(
        tz=pytz.UTC)
    first_trading_day = \
        bundle_data.equity_minute_bar_reader.first_trading_day

    z3_trading_calendar = get_calendar("China")

    z3_data_portal = Z3DataPortal(
        env.asset_finder,
        get_calendar("China"),
        first_trading_day=first_trading_day,
        equity_minute_reader=bundle_data.equity_minute_bar_reader,
        equity_daily_reader=bundle_data.equity_daily_bar_reader,
        adjustment_reader=bundle_data.adjustment_reader,
        memory_bars=bars
    )
    current_day = today

# 首页控制器
@app.route('/')
def index():
    return "量化回测服务"


def start_task_wrapper(backtest_id,strategy_id,z3_data_portal):
    try:
        quant_service.start_back_test2(backtest_id,strategy_id,z3_data_portal)
    except Exception as e:
        traceback.print_exc(file=sys.stdout)


def stop_task_wrapper(backtest_id):
    try:
        quant_service.stop_back_test(backtest_id)
    except Exception as e:
        traceback.print_exc(file=sys.stdout)


# 开始回测
@app.route('/start_back_test')
def start_back_test():
    global z3_data_portal
    try:
        info("current running task : {}".format(len(_running_thread_dic)))
        strategy_id = request.args.get("strategy_id")
        backtest_id = request.args.get("backtest_id")
        _pool.apply_async(start_task_wrapper, args=(backtest_id,strategy_id,z3_data_portal))
    except Exception as e:
        traceback.print_exc(file=sys.stdout)
    return 'started'


# 停止回测
@app.route('/stop_back_test')
def stop_back_test():
    strategy_id = request.args.get("strategy_id")
    stop_task_wrapper(strategy_id)
    return 'stopped'


def _init_task_tracker():
    task = threading.Thread(target=handle_task_tracker, args=())
    task.daemon = True
    task.start()


def _init_stop_message_receiver():
    task = threading.Thread(target=handle_stop_message, args=())
    task.daemon = True
    task.start()




if __name__ == '__main__':

    get_data_portal()
    warnings.filterwarnings("ignore")
    numpy.seterr(invalid='ignore')

    import pandas as pd
    # 1)create thread pool
    _pool = ThreadPool(100)
    # 2)任务监控
    _init_task_tracker()
    # 3)启动停止回测任务监听
    _init_stop_message_receiver()

    run_env = None
    port = 5000
    if len(sys.argv) > 1:
        run_env = sys.argv[1]
    if len(sys.argv)>2:
        port = int(sys.argv[2])

    setup_run_env(run_env)

    def ingest_data():
        register_calendar("China", ChinaCalendar(), force=True)
        db = get_mongodb()
        symbols = db['Z3_STK_MKT_DAY'].distinct("innerCode")
        start_session_str = '2005-01-04'
        end_session_str = datetime.today()
        register(
            'genius_bundle',
            genius_equities(symbols),
            "China",
            pd.Timestamp(start_session_str, tz='utc'),
            pd.Timestamp(end_session_str, tz='utc'),
            # 中国股市每日交易时间为4个小时 美国是6个半小时
            minutes_per_day=240
        )

        load_extensions(
            default=True,
            extensions=[],
            strict=True,
            environ=os.environ,
        )
        info("ingest data complete.")


    ingest_data()
    info("quant web started.")
    app.run(host="0.0.0.0", port=port)
