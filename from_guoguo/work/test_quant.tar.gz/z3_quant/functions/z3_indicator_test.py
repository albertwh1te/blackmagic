# -*- coding:utf-8 -*-
# h
from __future__ import division
from z3_indeicator_call import *
import z3_indicator
import logbook
import pandas as pd
from pymongo import MongoClient, ReadPreference, ASCENDING
from datetime import datetime, timedelta
import numpy as np
from barDS import *


def n8_to_date(n8):
    day = n8 % 100
    value = int(n8 / 100)
    month = int(value % 100)
    year = int(value / 100)
    return datetime(year, month, day)

import time

class Tester(object):
    def __init__(self):
        self.db = self.get_mongoDB()
        self.stocks = self.get_stocks()
        # funcs = dir(z3_indicator)
        # funcs.remove("Z3_func_call")
        # funcs.remove("Z3_func_count")
        # funcs.remove("Z3_func_columns")
        # funcs.remove("Z3_func_to_list_date")
        # funcs = filter(lambda x: x.startswith("Z3"), funcs)
        # funcs = filter(lambda x: not x.endswith("_COUNT"), funcs)
        # funcs = map(lambda x:x[3:], funcs)
        # self.funcs= funcs

    def get_mongoDB(self):
        client = MongoClient([u'10.77.4.37:27017'])
        db = client["z3dbus"]
        db.authenticate("z3dbusadmin", "z3dbusadmin")
        return db

    def get_stocks(self):
        symbols = self.db['Z3_STK_MKT_DAY'].distinct("innerCode")
        return symbols

    def get_data(self,inner_code,start,end):
        cursor = self.db['Z3_STK_MKT_DAY'].find(
            {'innerCode': inner_code,
             'trade_date': {'$lte': end,
                              '$gte': start}},
            projection={
                'trade_date': 1,
                'ex_open_px': 1,
                'ex_high_px': 1,
                'ex_low_px': 1,
                'ex_close_px': 1,
                "volume": 1,
                '_id': 0
            }).sort([('trade_date', ASCENDING)])
        df = pd.DataFrame(list(cursor))
        list_date = []
        for i in df['trade_date']:
            list_date.append(n8_to_date(i))
        df['trade_date'] = pd.Series(list_date)
        # 时间设置为索引
        df.set_index('trade_date', inplace=True)
        df.rename(columns={'ex_open_px': 'ex_open', 'ex_high_px': 'ex_high', 'ex_low_px': 'ex_low',
                           'ex_close_px': 'ex_close'}, inplace=True)
        # 去停牌 暂停
        df = df[df["volume"] > 0]
        return df

    def call_time(self, inner_code,func_name ,start, end, **param):
        df = self.get_data(inner_code,start,end)
        bards = barDS(df)
        count = len(df)
        try:
            start = time.time()
            for i in range(3300):
                value = Z3_func_call(func_name+"_0", bards,count, param)
            print func_name,time.time()-start
        except Exception,e:
            print e


    def call_all(self, inner_code, start, end, **param):
        '''跟据指标名 取指标结果
            input:
                inner_code 股票代码.证券市场 如 002800.SZ
                start 开始日期
                end 结束日期
                func_name 函数名
                param 函数参数  可写到 N=12,M=20
                输入实例  call("002800.SZ",20150101,20160101,"MA_0",N1=5,N2=10,N3=30)
            output:
                list
        '''
        # 计算窗口长度
        df = self.get_data(inner_code,start,end)

        bards = barDS(df)
        count = len(df)
        names=[]
        values = []
        for func_name in self.funcs:
            try:
                start = time.time()
                for i in range(3300):
                    value = Z3_func_call(func_name+"_0", bards,count, param)
                names.append(func_name)
                values.append(time.time()-start)
            except Exception,e:
                pass
        for name in names:
            print name
        for value in values:
            print value
                    # if value is not None:
            #
            # ret_date.append(index_date)
            # ret_list.append(value)
            # index_date += timedelta(days=1)
        #
        # ret_df = pd.DataFrame({"trade_date": ret_date, "value": ret_list})
        # return value

    def call(self, inner_code,func_name, start, end, **param):
        '''跟据指标名 取指标结果
            input:
                inner_code 股票代码.证券市场 如 002800.SZ
                start 开始日期
                end 结束日期
                func_name 函数名
                param 函数参数  可写到 N=12,M=20
                输入实例  call("002800.SZ",20150101,20160101,"MA_0",N1=5,N2=10,N3=30)
            output:
                list
        '''
        # 计算窗口长度
        df = self.get_data(inner_code,start,end)

        bards = barDS(df)
        count = len(df)
        names=[]
        values = []
        value = None
        try:
            value = Z3_func_call(func_name+"_0", bards,count, param)
        except Exception,e:
            import traceback
            print traceback.print_exc()
        return value
                    # if value is not None:
            #
            # ret_date.append(index_date)
            # ret_list.append(value)
            # index_date += timedelta(days=1)
        #
        # ret_df = pd.DataFrame({"trade_date": ret_date, "value": ret_list})
        # return value


if __name__ == "__main__":

    tester = Tester()
    tester.call_time("002800.SZ","SKDJ",20160101,20170101)
    # # print tester.stocks
    # # df0= tester.call("002800.SZ",20160530,20170505,"MTM_0",N1=6,N2=6)
    # # df1= tester.call("002800.SZ",20160530,20170505,"MTM_1",N1=6,N2=6)
    # # df2= tester.call("002800.SZ",20160530,20170505,"MTM_2",N1=6,N2=6)
    # # df3= tester.call("002800.SZ",20160530,20170505,"MTM_3",N1=6,N2=6)
    # # df4= tester.call("002800.SZ",20160530,20170505,"MTM_4",N1=6,N2=6)
    # df = tester.call("000001.SZ",20050101,20170501,"MICD_0",N1=2,N2=3,N3=4)
    # print df