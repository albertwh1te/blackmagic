# -*- coding: utf-8 -*-
"""
Created on Fri Apr 07 13:29:35 2017

@author: ZhouHuaxi
"""

class barDS:
    def __init__(self,df):
        # self.__dateTime = df.index
        self.__open = df.get('ex_open')
        self.__close = df.get('ex_close')
        self.__high = df.get('ex_high')
        self.__low = df.get('ex_low')
        self.__volume = df.get('volume')


        if self.__open is not None:
            self.__open = self.__open.values
        if self.__close is not None:
            self.__close = self.__close.values
        if self.__high is not None:
            self.__high = self.__high.values
        if self.__low is not None:
            self.__low = self.__low.values
        if self.__volume is not None:
            self.__volume = self.__volume.values


#        self.__amount = df['amount']

    def getTradeDate(self):
        return self.__dateTime
    def getOpenDataSeries(self):
        """return the open prices."""
        return self.__open
    
    def getHighDataSeries(self):
        """return the high prices."""
        return self.__high
    
    def getLowDataSeries(self):
        """return the low prices."""
        return self.__low
        
    def getCloseDataSeries(self):
        """return the close prices."""
        return self.__close
    
    def getVolumeDataSeries(self):
        """return the volume."""
        return self.__volume

    def add_data(self,data):
        pass


    def __len__(self):
        if self.__open is not None:
            return len(self.__open)
        elif self.__high is not None:
            return len(self.__high)
        elif self.__low is not None:
            return len(self.__low)
        elif self.__close is not None:
            return len(self.__close)
        elif self.__volume is not None:
            return len(self.__volume)
        else:
            return 0
    
#    def getAmountDataSeries(self):
#        """return the amount."""
#        return self.__amount.values       
        

