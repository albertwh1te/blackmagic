# -*- coding: utf-8 -*-
from __future__ import division

from indicator import *




########################### z3dubs wrappers,by fangxin.he ##############################################################################

def Z3_MI_COUNT(index=0, N=12):
    if index > 0:
        return N*2+1
    return N * 2

def Z3_MI(barDs, count, N=12):
    '''MI 动量指标
        A:CLOSE-REF(CLOSE,N);//收盘价与N周期前收盘价做差
        MI:SMA_CN(A,N,1);//A的移动平均
       input:
        timeperiod：（1，300，12）
       output:
        MI, cross_const(MI,0)
    '''
    assert count >= N * 2
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    ref_close_n = ref(closes, N)
    A = closes - ref_close_n
    MI = SMA_CN(A, count, N)
    crsu_mi_0, crsd_mi_0 = cross_const(MI, 0)
    return MI, crsu_mi_0, crsd_mi_0

def Z3_MICD_COUNT(index=0, N=3, N1=10, N2=20):
    ret =  max(N2 + N, N1 + N,10+2)
    if index in [2,3]:
        return ret+1
    return ret

def Z3_MICD(barDs, count, N=3, N1=10, N2=20):
    '''
        MICD 异同离差动力指数
        MI:=CLOSE-REF(CLOSE,1);//收盘价与前一周期收盘价之差
        AMI:=SMA_CN(MI,N,1);//MI的移动平均值
        DIF:MA(REF(AMI,1),N1)-MA(REF(AMI,1),N2);//前一周期AMI的N1周期均值与前一周期AMI的N2周期均值之间做差。
        MICD:SMA_CN(DIF,10,1);//DIF的移动平均值
        input:
        timeperiod：（1，100，3）
        timeperiod1：（1，100，10）
        timeperiod2：（1，100，20）
       output:
        DIF, MICD, cross(DIF,MICD),compare(DIF,MICD)
    '''
    max_count = max(N2 + N, N1 + N)
    assert count >= max_count and count > 10
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    MI = closes - ref(closes, 1)
    AMI = SMA_CN(MI, count, N)
    ref_AMI = ref(AMI, 1)
    DIF1 = MA(ref_AMI, count, N1)
    DIF2=MA(ref_AMI, count, N2)

    DIF = DIF1 - DIF2
    MICD = SMA_CN(DIF, count, 10)
    crsu_dif_micd, crsd_dif_micd = cross(DIF, MICD)
    cmpg_dif_micd, cmpl_dif_micd = compare(DIF, MICD)
    return DIF, MICD, crsu_dif_micd, crsd_dif_micd, cmpg_dif_micd, cmpl_dif_micd


def Z3_RC_COUNT(index=0, N=50):
    if index >0:
        return N+2
    return N+1


def Z3_RC(barDs, count, N=50):
    '''1.3.RC变化率指数
    RC:CLOSE/REF(CLOSE,N);//收盘价与N周期前的收盘价做比。
    input:
    barDs:data
    count:
    timeperiod：（1，100，50）
    output:
    RC, cross_const(RC,1

    '''
    assert count >= N
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    RC = closes / ref(closes, N)
    crsu_rc_1, crsd_rc_1 = cross_const(RC, 1)
    return RC, crsu_rc_1, crsd_rc_1


def Z3_RCCD_COUNT(index=0, N=59, N1=21, N2=28):
    ret =  max(N2 + N+2, N1 + N+2)
    if index in [2,3]:
        return ret+1
    return ret

def Z3_RCCD(barDs, count, N=59, N1=21, N2=28):
    '''RCCD 异同离差变化率指数
    RC:=CLOSE/REF(CLOSE,N);//当前价格除以N周期前的收盘价；
    ARC:=SMA_CN(REF(RC,1),N,1);//一周期前的RC的以1为权重的移动平均；
    DIF:MA(REF(ARC,1),N1)-MA(REF(ARC,1),N2);//N1个周期的一周期前的ARC的简单移动平均与N2周期内前一周期的ARC的简单移动平均的差值；
    RCCD:SMA_CN(DIF,N,1);//DIF的N周期的以1为权重的移动平均；
    input:
    barDs, count, timeperiod=59, timeperiod1=21, timeperiod2=28
    output:

    '''
    max_count = max(N2 + N, N1 + N)
    assert count >= max_count
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    RC = closes / ref(closes, N)
    ARC = SMA_CN(ref(RC, 1), count, N)
    ref_ARC_1 = ref(ARC, 1)
    DIF = MA(ref_ARC_1, count, N1) - MA(ref_ARC_1, count, N2)
    RCCD = SMA_CN(DIF, count, N)
    crsu_dif_rccd, crsd_dif_rccd = cross(DIF, RCCD)
    cmpg_dif_rccd, cmpl_dif_rccd = compare(DIF, RCCD)
    return DIF, RCCD, crsu_dif_rccd, crsd_dif_rccd, cmpg_dif_rccd, cmpl_dif_rccd


def Z3_SRMI_COUNT(index=0, N=9):
    return N+1


def Z3_SRMI(barDs, count, N=9):
    '''1.5.SRMI(MI修正指标)
    A:IFELSE(CLOSE<REF(CLOSE,N),(CLOSE-REF(CLOSE,N))/REF(CLOSE,N),IFELSE(CLOSE=REF(CLOSE,N),0,(CLOSE-REF(CLOSE,N))/CLOSE));
    //如果当前价格小于N周期前的收盘价，则返回(CLOSE-REF(CLOSE,N))/REF(CLOSE,N)的值，
    如果当前价格大于等于N周期前的收盘价，则当等于的时候返回0，大于的时候返回(CLOSE-REF(CLOSE,N))/CLOSE);
    SRMI:SMA_CN(A,N,1);//A的N周期的以1为权重的移动平均；
    input:
    barDs, count, timeperiod=9
    output:
    SRMI, cross_const(SRMI,0)
    '''
    assert count >= N
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    ref_c_n = ref(closes, N)
    A = numpy.ones(count) * numpy.nan

    for i in range(N, count):
        close = closes[i]
        ref_close = closes[i - N]
        if close < ref_close:
            A[i] = (close - ref_close) / ref_close if ref_close else numpy.nan
        elif close > ref_close:
            A[i] = (close - ref_close) / close if close else numpy.nan
        else:
            A[i] = 0
    SRMI = SMA_CN(A, count, N)
    cmpg_srmi_0, cmpl_srmi_0 = cross_const(SRMI, 0)
    return SRMI, cmpg_srmi_0, cmpl_srmi_0


def Z3_ATR_COUNT(index=0, N=14):
    return N+1


def Z3_ATR(barDs, count, N=14):
    '''ATR真实波幅
    TR:MAX(MAX((HIGH-LOW),ABS(REF(CLOSE,1)-HIGH)),ABS(REF(CLOSE,1)-LOW));//求最高价减去最低价，
    一个周期前的收盘价减去最高价的绝对值，一个周期前的收盘价减去最低价的绝对值，这三个值中的最大值
    ATR : MA(TR,N);//求N个周期内的TR的简单移动平均
    input:
    barDs, count, timeperiod=14
    output:
    ATR, compare(TR,ATR*3), compare(TR,ATR*6), compare(TR,ATR*9)
    '''
    assert count >= N
    closes = bar_ds_close_to_numpy(barDs, count)
    highs = bar_ds_high_to_numpy(barDs, count)
    lows = bar_ds_low_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    assert highs is not None and len(highs) == count
    assert lows is not None and len(lows) == count

    # atr_=ATR(barDs,count,timeperiod)
    ATR = numpy.ones(count) * numpy.nan
    TR = numpy.ones(count) * numpy.nan
    for i in range(1, count):
        high = highs[i]
        low = lows[i]
        lclose = closes[i - 1]
        TR[i] = max(high - low, abs(lclose - high), abs(lclose - low))
    ATR = MA(TR, count, N)
    cmpg_tr_3atr, cmpl3 = compare(TR, ATR * 3)
    cmpg_tr_6atr, cmpl6 = compare(TR, ATR * 6)
    cmpg_tr_9atr, cmpl9 = compare(TR, ATR * 9)
    return cmpg_tr_3atr, cmpg_tr_6atr, cmpg_tr_9atr


def Z3_MASS_COUNT(index=0, N1=9, N2=25):
    return max(N2, N1)+1


def Z3_MASS(barDs, count, N1=9, N2=25):
    '''2.2.MASS梅丝线
    MASS:SUM(EMA((HIGH-LOW),N1)/EMA(EMA((HIGH-LOW),N1),N1),N2);//N1个周期最高值与最低值之差做指数平滑移动平均，
    该平均值与N1个周期该均值的指数平滑移动平均值做比，计算该比值的N2个周期的累加求和。
    input:
    barDs, count, timeperiod1=9, timeperiod2=25
    output:
    MASS

    '''
    assert count >= max(N2, N1)
    highs = bar_ds_high_to_numpy(barDs, count)
    lows = bar_ds_low_to_numpy(barDs, count)
    assert highs is not None and len(highs) == count
    assert lows is not None and len(lows) == count

    MASS = numpy.ones(count) * numpy.nan
    ema_hl = EMA(highs - lows, count, N1)
    ema_ema_hl = EMA(ema_hl, count, N1)
    ema_ema_hl[ema_ema_hl==0]=numpy.nan
    MASS = SUM(ema_hl / ema_ema_hl,count, N2)
    # print "MASS",MASS
    return MASS


def Z3_CSTD_COUNT(index=0, N=26):
    return N


def Z3_CSTD(barDs, count, N=26):
    '''2.3.STD标准差（没有固定用法）
    input:
    barDs, count, timeperiod=26
    output:
    STD
    '''
    assert count >= N
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    CSTD = STD(closes, count, N)
    return CSTD


def Z3_VHF_COUNT(index=0, N=28):
    return N+1


def Z3_VHF(barDs, count, N=28):
    '''2.4.VHF纵横指标
    VHF:=(HHV(CLOSE,N)-LLV(CLOSE,N))/SUM(ABS(CLOSE-REF(CLOSE,1)),N);
    先计算N日来最高收盘价与最低收盘价的差，统计N日内今收与昨收的差的累加和，二者的比值即为VHF.
    input:
    barDs, count, timeperiod=28
    output:
    VHF
    '''
    assert count >= N
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    ref_closes = ref(closes, 1)
    VHF = (MAX(closes, count, N) - MIN(closes, count, N)) / SUM(numpy.abs(closes - ref_closes), count,
                                                                N)
    return VHF


def Z3_ADTM_COUNT(index=0, N=23, M=8):
    return M + N


# '''动态买卖人气指标'''


def Z3_ADTM(barDs, count, N=23, M=8):
    '''3.1.ADTM动态买卖人气指标
    DTM:=IFELSE(OPEN<=REF(OPEN,1),0,MAX((HIGH-OPEN),(OPEN-REF(OPEN,1))));
    如果开盘价小于等于一个周期前的开盘价，DTM取值为0，否则取最高价减去开盘价和开盘价减去前一个周期开盘价这两个差值中的最大值
    DBM:=IFELSE(OPEN>=REF(OPEN,1),0,MAX((OPEN-LOW),(OPEN-REF(OPEN,1))));
    如果开盘价大于等于一个周期前的开盘价，DBM取值为0，否则取开盘价减去最低价和开盘价减去前一个周期开盘价这两个差值中的最大值
    STM:=SUM(DTM,N);//求N个周期内的DTM的总和
    SBM:=SUM(DBM,N);//求N个周期内的DBM的总和
    ADTM:IFELSE(STM>SBM,(STM-SBM)/STM,IFELSE(STM=SBM,0,(STM-SBM)/SBM));
    如果STM大于SBM，ADTM取值为(STM-SBM)/STM，如果STM等于SBM，ADTM取值为0,如果STM小于SBM，ADTM取值为(STM-SBM)/SBM
    ADTMMA:MA(ADTM,M);//求M个周期内的ADTM的简单移动平均
    input:
    barDs, count, timeperiod_n=23, timeperiod_m=8
    output:
    ADTM
    '''
    assert count >= M + N
    highs = bar_ds_high_to_numpy(barDs, count)
    lows = bar_ds_low_to_numpy(barDs, count)
    opens = bar_ds_open_to_numpy(barDs, count)
    assert highs is not None and len(highs) == count
    assert lows is not None and len(lows) == count
    assert opens is not None and len(opens) == count
    ADTM = numpy.ones(count) * numpy.nan
    DTM = numpy.ones(count) * numpy.nan
    DBM = numpy.ones(count) * numpy.nan
    ADTMMA = numpy.ones(count) * numpy.nan
    for i in range(1, count):
        if opens[i] <= opens[i - 1]:
            DTM[i] = 0
        else:
            DTM[i] = max(highs[i] - opens[i], opens[i] - opens[i - 1])
        if opens[i] >= opens[i - 1]:
            DBM[i] = 0
        else:
            DBM[i] = max(opens[i] - lows[i], abs(opens[i - 1] - opens[i]))
    STM = SUM(DTM, count, N)
    SBM = SUM(DBM, count, N)
    for i in range(N - 1, count):
        if STM[i] > SBM[i]:
            ADTM[i] = (STM[i] - SBM[i]) / STM[i]
        elif STM[i] == SBM[i]:
            ADTM[i] = 0
        else:
            ADTM[i] = (STM[i] - SBM[i]) / SBM[i]
        pass
    ADTMMA = MA(ADTM, count, M)
    return ADTM, ADTMMA


def Z3_SKDJ_COUNT(index=0, N=9, M1=3, M2=3, M3=3):
    ret =  max(N, M1, M2, M3)+1
    if index in [2,3]:
        return ret+1
    return ret

def Z3_SKDJ(barDs, count, N=9, M1=3, M2=3, M3=3):
    '''SKDJ慢速随机指标
        RSV:= (CLOSE-LLV(LOW,N))/(HHV(HIGH,N)-LLV(LOW,N))*100;//收盘价与N周期最高值做差，N周期最高值与N周期最低值做差，两差之间做比值。
        FASTK:=SMA_CN(RSV,M1,1);//RSV的移动平均值
        K:SMA_CN(FASTK,M2,1);//FASTK的移动平均值
        D:SMA_CN(K,M3,1);//K的移动平均值
        input:
        barDs, count, timeperiod_n=9, timeperiod_m1=3, timeperiod_m2=3, timeperiod_m3=3
        output:
         K, D, cross(K, D), compare(K, D)
    '''
    timeperiod = max(N, M1, M2, M3)
    assert count >= timeperiod
    lows = bar_ds_low_to_numpy(barDs, count)
    highs = bar_ds_high_to_numpy(barDs, count)
    closes = bar_ds_close_to_numpy(barDs, count)
    assert closes is not None and len(closes) == count
    assert lows is not None and len(lows) == count
    assert highs is not None and len(highs) == count

    # RSV = (closes - MIN(lows, count, N)) / (MAX(highs, count, N) - MIN(lows, count, N)) * 100
    # FASTK = SMA_CN(RSV, count, M1)
    # K = SMA_CN(FASTK, count, M2)
    # D = SMA_CN(K, count, M3)
    #
    # crsu_k_d, crsd_k_d = cross(K, D)
    # cmpg_k_d, cmpl_k_d = compare(K, D)
    # return K, D, crsu_k_d, crsd_k_d, cmpg_k_d, cmpl_k_d

    RSV = (closes - MIN(lows, count, N)) / (MAX(highs, count, N) - MIN(lows, count, N)) * 100
    FASTK = SMA_CN(RSV, count, M1)
    # print FASTK
    K = SMA_CN(FASTK, count, M2)
    D = SMA_CN(K, count, M3)

    crsu_k_d, crsd_k_d = cross(K, D)
    cmpg_k_d, cmpl_k_d = compare(K, D)
    return K, D, crsu_k_d, crsd_k_d, cmpg_k_d, cmpl_k_d

def Z3_VMA_COUNT(index=0, N=10):
    if index in [1,3]:
        return N+1
    return N


def Z3_VMA(barDs, count, N=10):
    '''VMA量简单移动平均
        VMA:MA(VOL,N);//成交量均线
        input:
        barDs, count, timeperiod_n=10
        output:
        VMA, compare(VOL, VMA), compare(VOL, VMA * 2)
    '''
    assert count >= N
    VOL = bar_ds_volume_to_numpy(barDs, count)
    assert VOL is not None and len(VOL) == count
    VMA = MA(VOL, count, N)

    cmpg_vol_vma, cmpl_vol_vma = compare(VOL, VMA)
    cmpg_vol_2vma, cmpl_vol_2vma = compare(VOL, VMA * 2)
    return cmpg_vol_vma, cmpl_vol_vma, cmpg_vol_2vma, cmpl_vol_2vma


def Z3_VMACD_COUNT(index=0, N1=12, N2=26, M=9):
    ret =  max(N1, N2, M)
    if index in [3,4]:
        return ret+1
    return ret

def Z3_VMACD(barDs, count, N1=12, N2=26, M=9):
    '''VMACD量指数平滑异同平均
        成交量的MACD形式
        DIFF=EMA(VOL,N1)-EMA(VOL,N2);
        DEA=EMA(DIFF,M);
        VMACD=DIFF-DEA;
        input:
        barDs, count, timeperoid_n1=12, timeperoid_n2=26, timeperoid_m=9
        output:
        DIFF, DEA, VMACD, cross(DIFF, DEA), compare(DIFF, DEA)
    '''
    timeperiod = max(N1, N2, M)
    assert count >= timeperiod
    VOL = bar_ds_volume_to_numpy(barDs, count)
    assert VOL is not None and len(VOL) == count
    DIFF = EMA(VOL, count, N1) - EMA(VOL, count, N2)
    DEA = EMA(DIFF, count, M)
    VMACD = DIFF - DEA
    crsu_diff_dea, crsd_diff_dea = cross(DIFF, DEA)
    cmpg_diff_dea, cmpl_diff_dea = compare(DIFF, DEA)
    return DIFF, DEA, VMACD, crsu_diff_dea, crsd_diff_dea, cmpg_diff_dea, cmpl_diff_dea


def Z3_VOSC_COUNT(index=0, SHORT=12, LONG=26):
    assert LONG > SHORT
    if index >0:
        return LONG+1
    return LONG


def Z3_VOSC(barDs, count, SHORT=12, LONG=26):
    '''VOSC成交量震荡
        先分别计算短期移动平均线(SHORT)和长期移动平均线(LONG)，然后算两者的差值，
        再求差值与短期移动平均线(SHORT)的比，最后将比值放大100倍。
        VOSC:=(MA(VOL,SHORT)-MA(VOL,LONG))/MA(VOL,SHORT)*100;
        input:
        barDs, count, timeperoid_s=12, timeperoid_l=26
        output:
        VOSC, cross_const(VOSC, 0)
    '''
    assert SHORT < LONG <= count
    VOL = bar_ds_volume_to_numpy(barDs, count)
    assert VOL is not None and len(VOL) == count
    SHORT = MA(VOL, count, SHORT)
    LONG = MA(VOL, count, LONG)
    VOSC = (SHORT - LONG) / SHORT * 100
    crsu_vosc_0, crsd_vosc_0 = cross_const(VOSC, 0)
    return VOSC, crsu_vosc_0, crsd_vosc_0


def Z3_VSTD_COUNT(index=0, N=10):
    return N


def Z3_VSTD(barDs, count, N=10):
    '''VSTD成交量标准差
        成交量标准差（VSTD）就是求N周期成交量的估算标准差，该指标可很好追踪成交量放大和缩小的趋势
        input:
        barDs, count, timeperoid_n=10
        output:
        VSTD
    '''
    assert N <= count
    VOL = bar_ds_volume_to_numpy(barDs, count)
    assert VOL is not None and len(VOL) == count
    VSTD = STD(VOL, count, N)
    return VSTD


########################### z3dubs wrappers,by bo.li ##############################################################################

# 反趋势指标

def Z3_BIAS_COUNT(index=0, N=12):
    return N


def Z3_BIAS(barDs, count=1, N=12):
    """
    BIASS 乖离率
    BIAS:(CLOSE-MA(CLOSE,N))/MA(CLOSE,N)*100;
    input:
        timeperiod(12)
    output:
        bias
    """
    assert N <= count

    close = bar_ds_close_to_numpy(barDs, count)
    MAC = MA(close, count, N)
    bias = (close - MAC) / MAC * 100
    return bias


def Z3_CCI_COUNT(index=0, N=14):
    if index >0:
        return N+1
    return N


def Z3_CCI(barDs, count=1, N=14):
    """
    Commodity Channel Index 顺势指标
    TYP:=(CLOSE+HIGH+LOW)/3 求最新价，最高价和最低价三者的简单平均
    CCI:(TYP-MA(TYP,N))/(0.015*AVEDEV(TYP,N))
    TYP与TYP的N周期平均值做差，该差值与TYP在N个周期内的0.015倍的平均绝对偏差值做比值

    input:
        timeperiod（1，100，14）
    output:
        CCI
    """
    assert N <= count

    cci = call_talib_with_hlc(barDs, count, talib.CCI, N)

    crsu_cci_100, crsd_cci_100 = cross_const(cci, 100)
    return cci, crsu_cci_100, crsd_cci_100


def Z3_DBCD_COUNT(index=0, N=5, M=16, T=76):
    ret = max(N + M, T+1)
    if index in [2,3]:
        return ret+1
    return ret

def Z3_DBCD(barDs, count=1, N=5, M=16, T=76):
    """
    DBCD异同离差乖离率
    BIAS:=(CLOSE-MA(CLOSE,N))/MA(CLOSE,N) 收盘价减收盘价在N个周期内的简单移动平均比收盘价在N个周期内的简单移动平均；
    DIF:=(BIAS-REF(BIAS,M)) BIAS减M个周期前的BIAS;
    DBCD:SMA_CN(DIF,T,1) DIF在T个周期内的移动平均
    MM:MA(DBCD,5) DBCD在5个周期内的简单移动平均
    input:
        timeperiod1（1，100，5）
        timeperiod2（1，100，16）
        timeperiod3（1，100，76）
    output:
        dbcd,mm,compare(dbcd,mm),cross(dbcd,mm)
    """
    assert N + M <= count and T <= count

    bias = Z3_BIAS(barDs, count, N) / 100
    timeperiod2_bias = ref(bias, M)
    dif = bias - timeperiod2_bias

    dbcd = SMA_CN(dif, len(dif), T)
    mm = MA(dbcd, len(dbcd), 5)

    crsu_dbcd_mm, crsd_dbcd_mm = cross(dbcd, mm)
    cmpg_dbcd_mm, cmpl_dbcd_mm = compare(dbcd, mm)
    return dbcd, mm, crsu_dbcd_mm, crsd_dbcd_mm, cmpg_dbcd_mm, cmpl_dbcd_mm


def Z3_DPO_COUNT(index=0, N1=20, N2=11, N3=6):
    ret =  max(N1 + N2, N3+1)
    if index in [2,3]:
        return ret+1
    return ret

def Z3_DPO(barDs, count=1, N1=20, N2=11, N3=6):
    """
    DPO区间震荡线
    DPO:C - REF(MA(CLOSE,n1),n2);收盘价减去前n2日的n1日简单移动平均价
    MDPO:MA(DPO,n3);DPO的n3日简单移动平均
    input:
        timeperiod1(1，999，20);
        timeperiod2(1，999，11);
        timeperiod3(1,999,6)
    output:
        dpo,mdpo,compare(dpo,mdpo),cross(dpo,mdpo)
    """
    assert N1 + N2 <= count and N3 <= count
    assert N2 <= N1

    close = bar_ds_close_to_numpy(barDs, count)
    dpo = close - ref(MA(close, count, N1), N2)
    mdpo = MA(dpo, count, N3)
    crsu_dpo_mdpo, crsd_dpo_mdpo = cross(dpo, mdpo)
    cmpg_dpo_mdpo, cmpl_dpo_mdpo = compare(dpo, mdpo)

    return dpo, mdpo, crsu_dpo_mdpo, crsd_dpo_mdpo, cmpg_dpo_mdpo, cmpl_dpo_mdpo


def Z3_KDJ_COUNT(index = 0,N=9, M1=3, M2=3):
    ret =  max(N + M2, N + M1)
    if index in [3,4]:
        return ret+1
    return ret

def Z3_KDJ(barDs, count=1, N=9, M1=3, M2=3):
    """
    KDJ随机指标
    RSV:=(CLOSE-LLV(LOW,N))/(HHV(HIGH,N)-LLV(LOW,N))*100;//收盘价与N周期最低值做差，N周期最高值与N周期最低值做差，两差之间做比值。
    K:SMA_CN(RSV,M1,1);//RSV的移动平均值
    D:SMA_CN(K,M2,1);//K的移动平均值
    J:3*K-2*D;
    input:
        timeperiod1（1，100，9）
        timeperiod2（2，40，3）
        timeperiod3（2，40，3）
    output:
         k,d,j,compare(k,d),cross(k,d)
    """
    assert M1 <= M2 <= count
    assert N + M2 <= count

    close = bar_ds_close_to_numpy(barDs, count)
    low = bar_ds_low_to_numpy(barDs, count)
    high = bar_ds_high_to_numpy(barDs, count)
    rsv = (close - MIN(low, count, N)) / (MAX(high, count, N) - MIN(low, count, N)) * 100
    rsv[numpy.isnan(rsv)] = 0
    k = SMA_CN(rsv, count, M1)
    d = SMA_CN(k, count, M2)
    j = 3 * k - 2 * d

    crsu_k_d, crsd_k_d = cross(k, d)
    cmpg_k_d, cmpl_k_d = compare(k, d)
    return k, d, j, crsu_k_d, crsd_k_d, cmpg_k_d, cmpl_k_d


def Z3_LWR_COUNT(index=0, N=9, M1=3, M2=3):
    ret =  max(N, M1, M2)+1
    if index in [2,3]:
        return ret+1
    return ret

def Z3_LWR(barDs, count=1, N=9, M1=3, M2=3):
    """
    LWR威廉指标
    RSV:= (HHV(HIGH,N)- CLOSE)/(HHV(HIGH,N)-LLV(LOW,N))*100
    N周期最高值与收盘价做差，N周期最高值与N周期最低值做差，两差值间做比值
    LWR1:SMA_CN(RSV,M1,1);//RSV的移动平均
    LWR2:SMA_CN(LWR1,M2,1);//LWR1的移动平均
    input:
        timeperiod1（1，100，9）
        timeperiod2（2，40，3）
        timeperiod3（2，40，3）
    output:
        lwr1,lwr2compare(lwr1,lwr2),cross(lwr1,lwr2)
    """
    assert max(N, M1, M2) <= count

    high = bar_ds_high_to_numpy(barDs, count)
    low = bar_ds_low_to_numpy(barDs, count)
    close = bar_ds_close_to_numpy(barDs, count)
    rsv = ((MAX(high, len(high), N) - close) / (MAX(high, len(high), N) - MIN(low, len(low), N))) * 100
    rsv[numpy.isnan(rsv)] = 0
    lwr1 = SMA_CN(rsv, len(rsv), M1)
    lwr2 = SMA_CN(lwr1, len(lwr1), M2)

    crsu_lwr1_lwr2, crsd_lwr1_lwr2 = cross(lwr1, lwr2)
    cmpg_lwr1_lwr2, cmpl_lwr1_lwr2 = compare(lwr1, lwr2)
    return lwr1, lwr2, crsu_lwr1_lwr2, crsd_lwr1_lwr2, cmpg_lwr1_lwr2, cmpl_lwr1_lwr2


def Z3_ROC_COUNT(index=0, N=12, M=6):
    ret =  N + M
    if index >1:
        return ret+1
    return ret


def Z3_ROC(barDs, count=1, N=12, M=6):
    """
    Rate of change变动速率
    ROC:(CLOSE-REF(CLOSE,N))/REF(CLOSE,N)*100
    收盘价与N周期前收盘价做差，该差值与N周期前收盘价做比值，定义为ROC
    ROCMA:MA(ROC,M)
    input:
        timeperiod1（1，100，12）
        timeperiod2（1，100，6）
    output:
        roc,rocma,cross_const(roc,0),cross(roc,rocma)
    """
    assert N + M <= count

    close = bar_ds_close_to_numpy(barDs, count)
    close_t1 = numpy.append(numpy.ones(N) * numpy.nan, numpy.roll(close, N)[N:])
    roc = ((close - close_t1) / close_t1) * 100
    rocma = MA(roc, len(roc), M)

    crsu_roc_0, crsd_roc_0 = cross_const(roc, 0)
    crsu_roc_rocma, crsd_roc_rocma = cross(roc, rocma)

    return roc, rocma, crsu_roc_0, crsd_roc_0, crsu_roc_rocma, crsd_roc_rocma


def Z3_RSI_COUNT(index=0, N=7):
    return N+1


def Z3_RSI(barDs, count=1, N=7):
    """
    Relative Strength Index 相对强弱指标
    LC := REF(CLOSE,1) 前一周期收盘价
    RSI:SMA_CN(MAX(CLOSE-LC,0),N,1)/SMA_CN(ABS(CLOSE-LC),N,1)*100
    input:
        close
        timeperiod1：（1，100，7）
        timeperiod2：（1，100，14）
    output:
        rsifast
        cross(rsifast,rsislow)
        compare(rsifast,rsislow)
    """
    assert N <= count

    close = bar_ds_close_to_numpy(barDs, count)
    rsifast = RSI(close, len(close), N)
    # rsislow = RSI(close, len(close), N1)
    # crsu_rsifast_rsislow, crsd_rsifast_rsislow = cross(rsifast, rsislow)
    # cmpg_rsifast_rsislow, cmpl_rsifast_rsislow = compare(rsifast, rsislow)
    return rsifast  # , crsu_rsifast_rsislow, crsd_rsifast_rsislow, cmpg_rsifast_rsislow, cmpl_rsifast_rsislow


def Z3_SRDM_COUNT(index=0, N=30):
    ret = max(N+1,11)
    if index in [2,3]:
        return ret+1
    return ret


def Z3_SRDM(barDs, count=1, N=30):
    """
    SRDM
    DMZ:=IFELSE((HIGH+LOW)<=(REF(HIGH,1)+REF(LOW,1)),0,MAX(ABS(HIGH-REF(HIGH,1)),ABS(LOW-REF(LOW,1))))
    如果高点加低点的价格小于等于昨天的高点加低点的价格，则返回0，
    否则返回 当根K线的高点与上根K线的高点的差值的绝对值与当根K线的低点与上根K线的低点的绝对值中较大者；
    DMF:=IFELSE((HIGH+LOW)>=(REF(HIGH,1)+REF(LOW,1)),0,MAX(ABS(HIGH-REF(HIGH,1)),ABS(LOW-REF(LOW,1))))
    如果当根K线的高点加低点的价格大于等于昨天的高点加低点的价格，则返回0，
    否则返回 当根K线的高点与上根K线的高点的差值的绝对值与当根K线的低点与上根K线的低点的绝对值中较大者；
    ADMZ:=MA(DMZ,10);//DMZ值的10日简单移动平均；
    ADMF:=MA(DMF,10);//DMF值的10日简单移动平均；
    SRDM:IFELSE(ADMZ>ADMF,(ADMZ-ADMF)/ADMZ,IFELSE(ADMZ=ADMF,0,(ADMZ-ADMF)/ADMF));
    如果ADMZ>ADMF，则返回(ADMZ-ADMF)/ADMZ，否则当ADMZ=ADMF时返回0，小于时返回(ADMZ-ADMF)/ADMF;
    ASRDM:SMA_CN(SRDM,N,1);//SRDM值的N日以1为权重的移动平均；
    input:
        timeperiod1（1，100，30）
    output:
        srdm,asrdm,cross(srdm,asrdm),compare(srdm,asrdm)
    """
    assert N <= count

    close = bar_ds_close_to_numpy(barDs, count)
    high = bar_ds_high_to_numpy(barDs, count)
    low = bar_ds_low_to_numpy(barDs, count)
    dmz = numpy.ones(len(close)) * numpy.nan
    dmf = numpy.ones(len(close)) * numpy.nan

    for i in range(1, len(close)):
        if high[i - 1] + low[i - 1] > high[i] + low[i]:
            dmz[i] = 0
            dmf[i] = max(abs(high[i] - high[i - 1]), abs(low[i] - low[i - 1]))
        elif high[i - 1] + low[i - 1] < high[i] + low[i]:
            dmz[i] = max(abs(high[i] - high[i - 1]), abs(low[i] - low[i - 1]))
            dmf[i] = 0
        elif high[i - 1] + low[i - 1] == high[i] + low[i]:
            dmz[i] = 0
            dmf[i] = 0

    admz = MA(dmz, len(dmz), 10)
    admf = MA(dmf, len(dmf), 10)
    srdm = numpy.ones(len(admz)) * numpy.nan

    for i in range(len(admz)):
        if admz[i] > admf[i]:
            srdm[i] = (admz[i] - admf[i]) / admz[i]
        elif admz[i] < admf[i]:
            srdm[i] = (admz[i] - admf[i]) / admf[i]
        elif admz[i] == admf[i]:
            srdm[i] = 0

    asrdm = SMA_CN(srdm, len(srdm), N)
    crsu_srdm_asrdm, crsd_srdm_asrdm = cross(srdm, asrdm)
    cmpg_srdm_asrdm, cmpl_srdm_asrdm = compare(srdm, asrdm)

    return srdm, asrdm, crsu_srdm_asrdm, crsd_srdm_asrdm, cmpg_srdm_asrdm, cmpl_srdm_asrdm


def Z3_VROC_COUNT(index=0, N=12):
    ret  = N+1
    if index > 0:
        return ret+1
    return ret


def Z3_VROC(barDs, count=1, N=12):
    """
    volume Rate of change量变动速率
    (VOL-REF(VOL,N))/REF(VOL,N)*100;
    量变动速率指标（VROC）是以今天的成交量和N天前的成交量比较，通过计算某一段时间内成交量变动的幅度，
    应用成交量的移动比较来测量成交量运动趋向，达到事先探测成交量供需的强弱，
    进而分析成交量的发展趋势及其将来是否有转势的意愿，属于成交量的反趋向指标。
    input:
        timeperiod1（1，100，12）
    output:
        vroc,cross_const(vroc,0)
    """
    assert N <= count

    volume = bar_ds_volume_to_numpy(barDs, count)
    volume_t1 = numpy.append(numpy.ones(N) * numpy.nan, numpy.roll(volume, N)[N:])
    vroc = ((volume - volume_t1) / volume_t1) * 100

    crsu_vroc_0, crsd_vroc_0 = cross_const(vroc, 0)
    return vroc, crsu_vroc_0, crsd_vroc_0


def Z3_VRSI_COUNT(index=0, N=6):
    return N+1


def Z3_VRSI(barDs, count=1, N=6):
    """
    volume Relative Strength Index量相对强弱
    SMA_CN(MAX(VOL-REF(VOL,1),0),N,1)/SMA_CN(ABS(VOL-REF(VOL,1)),N,1)*100
    RSI以成交价为计算基础,而VRSI指标以成交量为计算标准,由于量比价先行,故此本指标相对于RSI（相对强弱指标）要灵敏一些。
    input:
        timeperiod1（1，100，6）
    output:
        vrsi
    """
    assert N <= count

    volume = bar_ds_volume_to_numpy(barDs, count)
    vrsi = RSI(volume, len(volume), N)

    return vrsi


def Z3_MFI_COUNT(index=0, N=14):
    return N+1


def Z3_MFI(barDs, count=1, N=14):
    """
    Money Flow Index资金流向指标
    TYP := (HIGH + LOW + CLOSE)/3;//当根K线的最高值最低值收盘价3者之和取简单均值。
    MR:=SUM(IFELSE(TYP>REF(TYP,1),TYP*VOL,0),N)/SUM(IFELSE(TYP<REF(TYP,1),TYPMFI*VOL,0),N)
    如果TYP大于前一周期TYP时取TYP乘以成交量，否则取0，对该值做N周期累加求和。如果TYP小于前一周期TYP取TYP乘以成交量，
    否则取0，对该值做N周期累加求和。两求和值之间进行比值计算。
    MFI:100-(100/(1+MR));
    input:
        timeperiod1（2，100，14）
    output:
        MFI
    """
    assert N <= count

    mfi = call_talib_with_hlcv(barDs, count, talib.MFI, N)
    mfi[mfi == 100] = 0
    return mfi


def Z3_WVAD_COUNT(index=0, N=24):
    if index >0:
        return N+1
    return N


def Z3_WVAD(barDs, count=1, N=24):
    """
    WVAD威廉变异离散量
    M1:=(CLOSE-OPEN)/(HIGH-LOW)*VOL;(当日收盘价－当日开盘价)/(当日最高价－当日最低价)*成交量
    WVAD=SUM(M1,N)
    input:
        null
    output:
        wvad,cross_const(wvad,0)
    """
    assert N <= count

    close = bar_ds_close_to_numpy(barDs, count)
    high = bar_ds_high_to_numpy(barDs, count)
    low = bar_ds_low_to_numpy(barDs, count)
    open1 = bar_ds_open_to_numpy(barDs, count)
    volume = bar_ds_volume_to_numpy(barDs, count)
    M1 = ((close - open1) / (high - low)) * volume
    M1[numpy.isnan(M1)] = 0
    WVAD = SUM(M1, len(close), N)
    crsu_wvad_0, crsd_wvad_0 = cross_const(WVAD, 0)
    return WVAD, crsu_wvad_0, crsd_wvad_0


def Z3_ARBR_COUNT(index=0, N=26):
    return N+1


def Z3_ARBR(barDs, count=1, N=26):
    """
    ARBR人气意愿指标
    AR : SUM(HIGH-OPEN,N)/SUM(OPEN-LOW,N)*100
    N个周期内的最高价减去开盘价的和与N个周期内的开盘价减去最低价的和的百分比
    BR:SUM(MAX(0,HIGH-REF(CLOSE,1)),N)/SUM(MAX(0,REF(CLOSE,1)-LOW),N)*100
    取最高价减去一个周期前的收盘价的与0中的最大值，求和，取一个周期前的收盘价减去最低价与0中的最大值，求和，两个和的百分比
    input:
        timeperiod1（2，100，26）
    output:
        ar,br
    """
    assert N <= count

    close = bar_ds_close_to_numpy(barDs, count)
    high = bar_ds_high_to_numpy(barDs, count)
    low = bar_ds_low_to_numpy(barDs, count)
    open1 = bar_ds_open_to_numpy(barDs, count)

    ar = (SUM(high - open1, len(close), N) / SUM(open1 - low, len(close), N)) * 100

    close_1 = numpy.append(numpy.ones(1) * numpy.nan, numpy.roll(close, 1)[1:])
    brmid = high - close_1
    brmid[brmid < 0] = 0
    brmid1 = close_1 - low
    brmid1[brmid1 < 0] = 0

    br = (SUM(brmid, len(close), N) / SUM(brmid1, len(close), N)) * 100

    return ar, br


def Z3_CR_COUNT(index=0, N=26, M1=5, M2=10, M3=20):
    ret =  max(N + M1, N + M2, N + M3)+1
    if index in [3,4,5,6]:
        return ret+1
    return ret

def Z3_CR(barDs, count=1, N=26, M1=5, M2=10, M3=20):
    """
    CR能量指标
    MID := (HIGH+LOW+CLOSE)/3;//求最新价，最高价和最低价三者之和的简单平均
    CR:SUM(MAX(0,HIGH-REF(MID,1)),N)/SUM(MAX(0,REF(MID,1)-LOW),N)*100
    取最高价减去一个周期前的MID的与0中的最大值，求和，取一个周期前的MID减去最低价与0中的最大值，求和，两个和的百分比
    CRMA1:REF(MA(CR,M1),M1/2.5+1);//取(M1/2.5+1)个周期前的M1周期CR简单平均值
    CRMA2:REF(MA(CR,M2),M2/2.5+1);//取(M2/2.5+1)个周期前的M2周期CR简单平均值
    CRMA3:REF(MA(CR,M3),M3/2.5+1);//取(M3/2.5+1)个周期前的M3周期CR简单平均值
    input:
        timeperiod1（5，300，26）
        timeperiod2（1，100，5）
        timeperiod3（1，100，10）
        timeperiod4（1，100，20）
    output:
    return cr, long_ma, short_ma, crsu_cr, crsd_cr, crsu_1,
    crsd_1, cmpg_cr, cmpl_cr, cmpg_1, cmpl_1
    """
    assert M1 < M2 < M3
    assert N + M3 <= count

    close = bar_ds_close_to_numpy(barDs, count)
    high = bar_ds_high_to_numpy(barDs, count)
    low = bar_ds_low_to_numpy(barDs, count)

    mid = (high + close + low) / 3
    mid_1 = numpy.append(numpy.ones(1) * numpy.nan, numpy.roll(mid, 1)[1:])
    crmid = high - mid_1
    crmid[crmid < 0] = 0
    crmid1 = mid_1 - low
    crmid1[crmid1 < 0] = 0

    cr = (SUM(crmid, len(close), N) / SUM(crmid1, len(close), N)) * 100

    crma1 = MA(cr, len(cr), M1)
    ma1_day = int(1 + M1 / 2.5)
    crma1_day = numpy.append(numpy.ones(ma1_day) * numpy.nan, numpy.roll(crma1, ma1_day)[ma1_day:])

    crma2 = MA(cr, len(cr), M2)
    ma2_day = int(1 + M2 / 2.5)
    crma2_day = numpy.append(numpy.ones(ma2_day) * numpy.nan, numpy.roll(crma2, ma2_day)[ma2_day:])

    crma3 = MA(cr, len(cr), M3)
    ma3_day = int(1 + M3 / 2.5)
    crma3_day = numpy.append(numpy.ones(ma3_day) * numpy.nan, numpy.roll(crma3, ma3_day)[ma3_day:])

    long_ma = [False for _ in range(len(cr))]
    short_ma = [False for _ in range(len(cr))]
    for i in range(1, len(cr)):

        if crma1_day[i] > crma2_day[i] > crma3_day[i]:
            long_ma[i] = True
        elif crma1_day[i] < crma2_day[i] < crma3_day[i]:
            short_ma[i] = True

    crsu_cr_crmal, crsd_cr_crmal = cross(cr, crma1_day)
    crsu_crma1_cram2, crsd_crma1_crma2 = cross(crma1_day, crma2_day)
    cmpg_cr_crma1, cmpl_cr_crma1 = compare(cr, crma1_day)
    cmpg_crma1_crma2, cmpl_crma1_crma2 = compare(crma1_day, crma2_day)
    return cr, long_ma, short_ma, crsu_cr_crmal, crsd_cr_crmal, crsu_crma1_cram2, crsd_crma1_crma2, cmpg_cr_crma1, cmpl_cr_crma1, cmpg_crma1_crma2, cmpl_crma1_crma2


def Z3_PSY_COUNT(index=0, N=12, M=16):
    ret =  N + M
    if index in [2,3,4,5]:
        return ret+1
    return ret

def Z3_PSY(barDs, count=1, N=12, M=6):
    """
    PSY心理指标
    PSY:COUNT(CLOSE>REF(CLOSE,1),N)/N*100
    N个周期内满足收盘价大于一个周期前的收盘价的周期数，比N*100
    PSYMA:MA(PSY,M);//PSY在M个周期内的简单移动平均
    input:
        timeperiod1（2，100，12）
        timeperiod2（2，100，6）
    output:
        psy,psyma,cross_const(psy,50),cross(psy,psyma),compare(psy,psyma)
    """
    assert N + M <= count

    close = bar_ds_close_to_numpy(barDs, count)
    close_1 = numpy.append(numpy.ones(1) * numpy.nan, numpy.roll(close, 1)[1:])

    psymid = ref(numpy.zeros(len(close)), 1)
    psymid[close > close_1] = 1
    psy = 100 * SUM(psymid, len(psymid), N) / N
    psyma = MA(psy, len(psy), M)

    crsu_psyma_50, crsd_psyma_50 = cross_const(psyma, 50)
    crsu_psy_psyma, crsd_psy_psyma = cross(psy, psyma)
    cmpg_psy_psyma, cmpl_psy_psyma = compare(psy, psyma)

    return psy, psyma, crsu_psyma_50, crsd_psyma_50, crsu_psy_psyma, crsd_psy_psyma, cmpg_psy_psyma, cmpl_psy_psyma


def Z3_VR_COUNT(index=0, N=26):
    return N+1


def Z3_VR(barDs, count=1, N=26):
    """
    VR成交量比率
    LC:=REF(CLOSE,1)
    VR:=SUM(IFELSE(CLOSE>LC,VOL,0),N)/SUM(IFELSE(CLOSE<=LC,VOL,0),N)*100
    在N日内,若某日收阳(收盘价高于开盘价),则将该日成交量累加到强势和中
    收阴，累加到弱势和中。若平盘，则该日成交量一半累加到强势和，一半累加到弱势和。最后，计算强势和与弱势和的比，并放大100倍。
    input:
        timeperiod1（5，300，26）
    output:
        vr
    """
    assert N <= count

    close = bar_ds_close_to_numpy(barDs, count)
    close_1 = numpy.append(numpy.ones(1) * numpy.nan, numpy.roll(close, 1)[1:])
    volume = bar_ds_volume_to_numpy(barDs, count)

    powup = ref(numpy.zeros(len(close)), 1)
    powdown = ref(numpy.zeros(len(close)), 1)

    for i in range(len(close)):
        if close[i] < close_1[i]:
            powdown[i] = volume[i]
        elif close[i] > close_1[i]:
            powup[i] = volume[i]
        elif close[i] == close_1[i]:
            powup[i] = volume[i] / 2
            powdown[i] = volume[i] / 2

    vr = 100 * SUM(powup, len(powup), N) / SUM(powdown, len(powup), N)

    return vr


########################### z3dubs wrappers,by huaxi.zhou ##############################################################################

def Z3_BBI_COUNT(index=0, N1=3, N2=6, N3=12, N4=24):
    ret =  max(N1, N2, N3, N4)
    if index >1:
        return ret+1
    return ret

# 趋向指标
def Z3_BBI(barDs, count=1, N1=3, N2=6, N3=12, N4=24):
    '''BBI多空指数
    BBI:(MA(CLOSE,N1)+MA(CLOSE,N2)+MA(CLOSE,N3)+MA(CLOSE,N4))/4;//求N1周期，N2周期，N3周期，N4周期收盘价均线的简单平均
    Bull and Bear Index,At least 2 day barDs
    Output:above_below_closebbi,crosser_closebbi'''

    timeperiod = max(N1, N2, N3, N4)  # 时间窗口需要的最大值
    assert timeperiod <= count  # 传入的数据量少于参数要求量，抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    above_below_closebbi = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    crosser_closebbi = numpy.zeros(count)  # 0代表即不金叉也不死叉，100代表金叉，-100代表死叉

    MA1 = MA(close, count, N1)
    MA2 = MA(close, count, N2)
    MA3 = MA(close, count, N3)
    MA4 = MA(close, count, N4)

    bbi = (MA1 + MA2 + MA3 + MA4) / 4

    crsu_, crsd_ = cross(close, bbi)
    cmpg, cmpl = compare(close, bbi)

    return cmpg, cmpl, crsu_, crsd_


def Z3_DDI_COUNT(index=0, N=13):
    if index > 0:
        return N + 2
    return N + 1


def Z3_DDI(barDs, count=1, N=13):
    '''9.2.DDI多空指数
    TR:=MAX(ABS(HIGH-REF(HIGH,1)),ABS(LOW-REF(LOW,1)));
    //（最高价-前一周期最高价）的绝对值与（最低价-前一周期最低价）的绝对值两者之间较大者定义为TR
    DMZ:=IFELSE((HIGH+LOW)<=(REF(HIGH,1)+REF(LOW,1)),0,MAX(ABS(HIGH-REF(HIGH,1)),ABS(LOW-REF(LOW,1))));/
    /如果（最高价+最低价）<=（前一周期最高价+前一周期最低价），DMZ返回0，否则返回TR
    DMF:=IFELSE((HIGH+LOW)>=(REF(HIGH,1)+REF(LOW,1)),0,MAX(ABS(HIGH-REF(HIGH,1)),ABS(LOW-REF(LOW,1))));
    //如果（最高价+最低价）>=（前一周期最高价+前一周期最低价），DMF返回0，否则返回TR
    DIZ:=SUM(DMZ,N)/(SUM(DMZ,N)+SUM(DMF,N));//N个周期DMZ之和与（N个周期DMZ的和+N个周期DMF的和）作比值
    DIF:=SUM(DMF,N)/(SUM(DMF,N)+SUM(DMZ,N));//N个周期DMF的和与（N个周期DMF的和+N个周期DMZ的和）作比值
    DDI:=DIZ-DIF;//DIZ与DIF的差值定义为DDI
    Depth Deviation Index,At least 2 day barDs
       Output:DDI,crosser_ddi0'''

    assert N <= count  # 传入的数据量少于参数要求量，抛异常

    high = bar_ds_high_to_numpy(barDs, count)
    low = bar_ds_low_to_numpy(barDs, count)
    assert high is not None and low is not None and len(high) == count and len(
        low) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    DDI = numpy.ones(count) * numpy.nan  # nan数组
    DMZ = numpy.ones(count) * numpy.nan  # nan数组
    DMF = numpy.ones(count) * numpy.nan  # nan数组
    crosser_ddi0 = numpy.zeros(count)  # 0代表即不金叉也不死叉，100代表金叉，-100代表死叉

    # tr = MAX(numpy.abs(high-ref(high,1)),numpy.abs(low-ref(low,1)),count,N)

    for i in range(1, count):
        TR = max(abs(high[i] - high[i - 1]), abs(low[i] - low[i - 1]))

        if high[i] + low[i] <= high[i - 1] + low[i - 1]:
            DMZ[i] = 0
        else:
            DMZ[i] = TR

        if high[i] + low[i] >= high[i - 1] + low[i - 1]:
            DMF[i] = 0
        else:
            DMF[i] = TR
    DMZ_SUM = SUM(DMZ, count, N)
    DMF_SUM = SUM(DMF, count, N)
    DIZ = DMZ_SUM / (DMZ_SUM + DMF_SUM)
    DIF = DMF_SUM / (DMZ_SUM + DMF_SUM)
    DDI = DIZ - DIF
    crsu_ddi_0, crsd_ddi_0 = cross_const(DDI, 0)
    return DDI, crsu_ddi_0, crsd_ddi_0


def Z3_DMA_COUNT(index=0, N1=10, N2=50, M=10):
    ret =  max(N1, N2) + M
    if index in [2,3]:
        return ret+1
    return ret

def Z3_DMA(barDs, count=1, N1=10, N2=50, M=10):
    ''' DMA平均线差
    DMA : MA(CLOSE,N1)-MA(CLOSE,N2);//短周期收盘价均值与长周期收盘价均值差
    AMA : MA(DMA,M);//M个周期的DDD均值
    Displaced Moving Average
       Output:DMA,AMA,above_below_damama,crosser_damama'''

    timeperiod = max(N1, N2) + M
    assert timeperiod <= count  # 传入的数据量少于参数要求量，抛异常
    assert N1 < N2  # 如果短线天数大于长线天数，抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    # DMA = numpy.ones(count) * numpy.nan  # nan数组
    # AMA = numpy.ones(count) * numpy.nan  # nan数组
    # above_below_dmaama = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    # crosser_dmaama = numpy.zeros(count)  # 0代表即不金叉也不死叉，100代表金叉，-100代表死叉

    MA1 = MA(close, count, N1)
    MA2 = MA(close, count, N2)
    DMA = MA1 - MA2
    AMA = MA(DMA, len(DMA), M)
    crsu_dma_ama, crsd_dma_ama = cross(DMA, AMA)
    cmpg_dma_ama, cmpl_dma_ama = compare(DMA, AMA)
    return DMA, AMA, crsu_dma_ama, crsd_dma_ama, cmpg_dma_ama, cmpl_dma_ama


def Z3_MA_COUNT(index=0, N1=10, N2=20, N3=30):
    ret =  max(N1, N2)
    if index in [4,5]:
        ret = max(ret,N3)
    if index in [2,3,6,7]:
        return ret+1
    return ret

def Z3_MA(barDs, count=1, N1=10, N2=20, N3=30):
    ''' MA简单移动平均
    MA:MA(CLOSE,N);
    Moving Average
       Output:above_below_closema1,above_below_ma1ma2,crosser_closema1,crosser_ma1ma2,long_short_ma'''

    timeperiod = max(N1, N2)  # 时间窗口需要的最大值
    assert timeperiod <= count  # 传入的数据量少于参数要求量，抛异常
    assert N1 < N2 < N3  # N1<N2<N3，否则抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    above_below_closema1 = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    above_below_ma1ma2 = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    crosser_closema1 = numpy.zeros(count)  # 0代表即不金叉也不死叉，100代表金叉，-100代表死叉
    crosser_ma1ma2 = numpy.zeros(count)  # 0代表即不金叉也不死叉，100代表金叉，-100代表死叉
    long_short_ma = numpy.zeros(count)  # 0代表即不多头也不空头，100代表均线多头，-100代表均线空头

    MA1 = MA(close, count, N1)  # M1均线
    MA2 = MA(close, count, N2)  # M2均线
    MA3 = MA(close, count, N3)  # M3均线
    cmpg_c_1 = [False for _ in range(count)]
    cmpl_c_1 = [False for _ in range(count)]
    crsu_c_1 = [False for _ in range(count)]
    crsd_c_1 = [False for _ in range(count)]
    long_ma = [False for _ in range(count)]
    short_ma = [False for _ in range(count)]
    crsu_1_2 = [False for _ in range(count)]
    crsd_1_2 = [False for _ in range(count)]
    cmpg_1_2 = [False for _ in range(count)]
    cmpl_1_2 = [False for _ in range(count)]
    for i in range(N1 - 1, count):

        if close[i] > MA1[i]:
            cmpg_c_1[i] = True
        elif close[i] < MA1[i]:
            cmpl_c_1[i] = True

        if close[i - 1] < MA1[i - 1] and close[i] > MA1[i]:
            crsu_c_1[i] = True
        elif close[i - 1] > MA1[i - 1] and close[i] < MA1[i]:
            crsd_c_1[i] = True

        if MA1[i] > MA2[i] > MA3[i]:
            long_ma[i] = True
        elif MA1[i] < MA2[i] < MA3[i]:
            short_ma[i] = True

        if MA1[i - 1] < MA2[i - 1] and MA1[i] > MA2[i]:
            crsu_1_2[i] = True
        elif MA1[i - 1] > MA2[i - 1] and MA1[i] < MA2[i]:
            crsd_1_2[i] = True

        if MA1[i] > MA2[i]:
            cmpg_1_2[i] = True
        elif MA1[i] < MA2[i]:
            cmpl_1_2[i] = True

    return cmpg_c_1, cmpl_c_1, crsu_c_1, crsd_c_1, long_ma, short_ma, crsu_1_2, crsd_1_2, cmpg_1_2, cmpl_1_2


def Z3_EMA_COUNT(index=0, N1=10, N2=20, N3=30):
    ret =  max(N1, N2, N3)
    if index in [2,3,6,7]:
        return ret+1
    return ret

def Z3_EMA(barDs, count=1, N1=10, N2=20, N3=30):
    '''9.5.EMA指数平滑移动平均
    EMA(X,N)=2*X/(N+1)+(N-1)/(N+1)*昨天的指数收盘平均值
    Exponential Moving Average
       Output:above_below_closeema1,above_below_ema1ema2,crosser_closeema1,crosser_ema1ema2,long_short_ema'''

    N = max(N1, N2, N3)  # 时间窗口需要的最大值
    assert N1 <= count  # 传入的数据量少于参数要求量，抛异常
    assert N1 < N2 < N3# N1<N2<N3，否则抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    above_below_closeema1 = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    above_below_ema1ema2 = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    crosser_closeema1 = numpy.zeros(count)  # 0代表即不金叉也不死叉，100代表金叉，-100代表死叉
    crosser_ema1ema2 = numpy.zeros(count)  # 0代表即不金叉也不死叉，100代表金叉，-100代表死叉
    long_short_ema = numpy.zeros(count)  # 0代表即不多头也不空头，100代表均线多头，-100代表均线空头
    N = max(N1, N2, N3)  # 时间窗口需要的最大值

    EMA1 = EMA(close, count, N1)  # M1均线
    EMA2 = EMA(close, count, N2)  # M2均线
    EMA3 = EMA(close, count, N3)  # M3均线
    cmpg_c_1 = [False for _ in range(count)]
    cmpl_c_1 = [False for _ in range(count)]
    crsu_c_1 = [False for _ in range(count)]
    crsd_c_1 = [False for _ in range(count)]
    long_ma = [False for _ in range(count)]
    short_ma = [False for _ in range(count)]
    crsu_1_2 = [False for _ in range(count)]
    crsd_1_2 = [False for _ in range(count)]
    cmpg_1_2 = [False for _ in range(count)]
    cmpl_1_2 = [False for _ in range(count)]

    for i in range(1, count):

        if close[i] > EMA1[i]:
            cmpg_c_1[i] = True
        elif close[i] < EMA1[i]:
            cmpl_c_1[i] = True

        if close[i - 1] < EMA1[i - 1] and close[i] > EMA1[i]:
            crsu_c_1[i] = True
        elif close[i - 1] > EMA1[i - 1] and close[i] < EMA1[i]:
            crsd_c_1[i] = True

        if EMA1[i] > EMA2[i] > EMA3[i]:
            long_ma[i] = True
        elif EMA1[i] < EMA2[i] < EMA3[i]:
            short_ma[i] = True

        if EMA1[i - 1] < EMA2[i - 1] and EMA1[i] > EMA2[i]:
            crsu_1_2[i] = True
        elif EMA1[i - 1] > EMA2[i - 1] and EMA1[i] < EMA2[i]:
            crsd_1_2[i] = True

        if EMA1[i] > EMA2[i]:
            cmpg_1_2[i] = True
        elif EMA1[i] < EMA2[i]:
            cmpl_1_2[i] = True

    return cmpg_c_1, cmpl_c_1, crsu_c_1, crsd_c_1, long_ma, short_ma, crsu_1_2, crsd_1_2, cmpg_1_2, cmpl_1_2


def Z3_MACD_COUNT(index=0, N1=12, N2=26, M=9):
    ret =  max(N1, N2, M)
    if index in [4,5]:
        return ret+1
    return ret

def Z3_MACD(barDs, count=1, N1=12, N2=26, M=9):
    '''MACD指数平滑异同平均
    DIFF:EMA(CLOSE,N1) - EMA(CLOSE,N2);//短周期与长周期的收盘价的指数平滑移动平均值做差。
    DEA:EMA(DIFF,M);//DIFF的M个周期指数平滑移动平均
    MACD:2*(DIFF-DEA),COLORSTICK;//DIFF减DEA的2倍画柱状线
    Moving Average Convergence/Divergence
       DIFF,DEA,MACD,above_below_diffdea,crosser_diffdea'''

    N = max(N1, N2, M)  # 时间窗口需要的最大值
    assert N1 <= count  # 传入的数据量少于参数要求量，抛异常
    assert N1 < N2  # N1<N2，否则抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    above_below_diffdea = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    crosser_diffdea = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    DIFF = numpy.ones(count) * numpy.nan  # nan数组
    DEA = numpy.ones(count) * numpy.nan  # nan数组
    MACD = numpy.ones(count) * numpy.nan  # nan数组

    EMA1 = EMA(close, count, N1)  # M2均线
    EMA2 = EMA(close, count, N2)  # M2均线
    DIFF = EMA1 - EMA2
    DEA = EMA(DIFF, count, M)
    MACD = (DIFF - DEA) * 2
    crsu_diff_dea = [False for _ in range(count)]
    crsd_diff_dea = [False for _ in range(count)]
    cmpg_diff_dea = [False for _ in range(count)]
    cmpl_diff_dea = [False for _ in range(count)]
    for i in range(1, count):

        if DIFF[i] > DEA[i]:
            cmpg_diff_dea[i] = True
        elif DIFF[i] < DEA[i]:
            cmpl_diff_dea[i] = True

        if DIFF[i - 1] < DEA[i - 1] and DIFF[i] > DEA[i]:
            crsu_diff_dea[i] = True
        elif DIFF[i - 1] > DEA[i - 1] and DIFF[i] < DEA[i]:
            crsd_diff_dea[i] = True

    return DIFF, DEA, MACD, crsu_diff_dea, crsd_diff_dea, cmpg_diff_dea, cmpl_diff_dea


def Z3_MTM_COUNT(index=0, N1=6, N2=6):
    ret = max(N1, N2)+1
    if index in [1,2]:
        return ret+1
    return ret

def Z3_MTM(barDs, count=1, N1=6, N2=6):
    '''MTM动力指标
        MTM : CLOSE-REF(CLOSE,N);//收盘价与N周期前收盘价做差
        MTMMA : MA(MTM,N1);
        Momentum Index
       Output:MTM,above_below_mtmmtmma,crosser_mtmmtmma'''

    max_N = max(N1, N2)  # 时间窗口需要的最大值
    assert max_N <= count  # 传入的数据量少于参数要求量，抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    above_below_mtmmtmma = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    crosser_mtmmtmma = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    MTM = numpy.ones(count) * numpy.nan  # nan数组

    REFCLOSE = ref(close, N1)
    MTM = close - REFCLOSE
    MTMMA = MA(MTM, count, N2)
    crsu_mtm_mtmma = [False for _ in range(count)]
    crsd_mtm_mtmma = [False for _ in range(count)]
    cmpg_mtm_mtmma = [False for _ in range(count)]
    cmpl_mtm_mtmma = [False for _ in range(count)]
    for i in range(max_N - 1, count):

        if MTM[i] > MTMMA[i]:
            cmpg_mtm_mtmma[i] = True
        elif MTM[i] < MTMMA[i]:
            cmpl_mtm_mtmma[i] = True

        if MTM[i - 1] < MTMMA[i - 1] and MTM[i] > MTMMA[i]:
            crsu_mtm_mtmma[i] = True
        elif MTM[i - 1] > MTMMA[i - 1] and MTM[i] < MTMMA[i]:
            crsd_mtm_mtmma[i] = True

    return MTM, crsu_mtm_mtmma, crsd_mtm_mtmma, cmpg_mtm_mtmma, cmpl_mtm_mtmma


def Z3_PRICEOSC_COUNT(index=0, N1=12, N2=26):
    ret =  max(N1, N2)
    if index >0:
        return ret+1
    return ret

def Z3_PRICEOSC(barDs, count=1, N1=12, N2=26):
    '''PRICEOSC价格振荡指标
    PRICEOSC:(MA(CLOSE,N1)-MA(CLOSE,N2))/MA(CLOSE,N1)*100;//短周期与长周期均值做差，该差与短周期均值之间做比值。
    Price Oscillator
       Output:PRICEOSC,crosser_priceosc0'''

    N = max(N1, N2)  # 时间窗口需要的最大值
    assert N <= count  # 传入的数据量少于参数要求量，抛异常
    assert N1 < N2  # N1<N2，否则抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    crosser_priceosc0 = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量

    MA1 = MA(close, count, N1)  # M1均线
    MA2 = MA(close, count, N2)  # M2均线

    PRICEOSC = (MA1 - MA2) / MA1 * 100

    crsu_priceosc_0 = [False for _ in range(count)]
    crsd_priceosc_0 = [False for _ in range(count)]
    for i in range(N - 1, count):

        if PRICEOSC[i - 1] < 0 and PRICEOSC[i] > 0:
            crsu_priceosc_0[i] = True
        elif PRICEOSC[i - 1] > 0 and PRICEOSC[i] < 0:
            crsd_priceosc_0[i] = True

    return PRICEOSC, crsu_priceosc_0, crsd_priceosc_0


def Z3_TRIX_COUNT(index=0, N=12, M=20):
    assert N > 1
    if index == 0:
        return 2
    if index in [1,2]:
        return M+1
    return M


def Z3_TRIX(barDs, count=1, N=12, M=20):
    '''TRIX三重指数平滑平均
    TR:= EMA(EMA(EMA(CLOSE,N),N),N);
    TRIX:(TR-REF(TR,1))/REF(TR,1)*100;
    TRMA:MA(TRIX,M)。
        Triple Exponential Moving Average
       Output:TRIX,above_below_trixtrma,crosser_trixtrma'''

    assert N > 1  # EMA指标的窗口参数要大于1，否则抛异常
    assert 2 <= count  # 传入的数据量少于参数要求量，抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    TRIX = numpy.ones(count) * numpy.nan  # nan数组

    EMA1 = EMA(close, count, N)
    EEMA1 = EMA(EMA1, count, N)
    TR = EMA(EEMA1, count, N)
    REFTR = ref(TR, 1)
    TRIX = (TR - REFTR) / REFTR * 100
    TRMA = MA(TRIX, count, M)

    cmpg_trix_trma, cmpl_trix_trma = compare(TRIX, TRMA)
    crsu_trix_trma, crsd_trix_trma = cross(TRIX, TRMA)

    return TRIX, crsu_trix_trma, crsd_trix_trma, cmpg_trix_trma, cmpl_trix_trma


##压力支撑指标

def Z3_BBIBOLL_COUNT(index=0, N=10, M=3):
    assert N > 1
    return 24


def Z3_BBIBOLL(barDs, count=24, N=10, M=3):
    '''10.1.BBIBOLL多空布林线
        1.BBI=(MA(CLOSE,3)+MA(CLOSE,6)+MA(CLOSE,12)+MA(CLOSE,24))/4;
        2.UPR=BBI+M*BBI的N日估算标准差
        3.DWN=BBI-M*BBI的N日估算标准差
        Bull and Bear Index Bollinger Bands
       Output:above_below_closeupr,above_below_closebbi,above_below_closedwn
              crosser_closeupr,crosser_closebbi,crosser_closedwn'''

    assert N > 1  # 计算标准差的窗口数少于2，抛异常
    assert count >= 24  # 需要的数据量>=24,否则抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    MA1 = MA(close, count, 3)
    MA2 = MA(close, count, 6)
    MA3 = MA(close, count, 12)
    MA4 = MA(close, count, 24)
    BBI = (MA1 + MA2 + MA3 + MA4) / 4
    UPR = BBI + M * STD(BBI, count, N)
    DWN = BBI - M * STD(BBI, count, N)

    cmpg_c_u, cmpl_c_u = compare(close, UPR)
    cmpg_c_b, cmpl_c_b = compare(close, BBI)
    cmpg_c_d, cml_c_d = compare(close, DWN)

    crsu_c_u, crsd_c_u = cross(close, UPR)
    crsu_c_b, crsd_c_b = cross(close, BBI)
    crsu_c_d, crsd_c_d = cross(close, DWN)

    return crsu_c_u, crsu_c_b, crsu_c_d, crsd_c_u, crsd_c_b, crsd_c_d, cmpg_c_u, cmpg_c_b, cmpg_c_d, cmpl_c_u, cmpl_c_b, cml_c_d


def Z3_BOLL_COUNT(index=0, N=26, P=2):
    if index <6:
        return N+1
    return N


def Z3_BOLL(barDs, count=1, N=26, P=2):
    '''BOLL布林线
        MID:MA(CLOSE,N);//求N个周期的收盘价均线，称为布林通道中轨
        TMP2:=STD(CLOSE,M);//求M个周期内的收盘价的标准差
        TOP:MID+P*TMP2;//布林通道上轨
        BOTTOM:MID-P*TMP2;//布林通道下轨
        Bollinger Bands
        Output:above_below_closetop,above_below_closemid,above_below_closebottom
              crosser_closetop,crosser_closemid,crosser_closebottom'''

    assert N <= count  # 传入的数据量少于参数要求量，抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    MID = MA(close, count, N)
    TMP2 = STD(close, count, N)
    TOP = MID + P * TMP2
    BOTTOM = MID - P * TMP2

    cmpg_c_t, cmpl_c_t = compare(close, TOP)
    cmpg_c_m, cmpl_c_m = compare(close, MID)
    cmpg_c_b, cmpl_c_b = compare(close, BOTTOM)

    crsu_c_t, crsd_c_t = cross(close, TOP)
    crsu_c_m, crsd_c_m = cross(close, MID)
    crsu_c_b, crsd_c_b = cross(close, BOTTOM)

    return crsu_c_t, crsu_c_m, crsu_c_b, crsd_c_t, crsd_c_m, crsd_c_b, cmpg_c_t, cmpg_c_m, cmpg_c_b, cmpl_c_t, cmpl_c_m, cmpl_c_b


##强弱指标

def Z3_DPTB_COUNT(index=0, N=7):
    return N


def Z3_DPTB(barDs, barDs_index, count=1, N=7):
    ''' DPTB大盘同步指标
        COUNT((C>O AND INDEXC>INDEXO) OR (C<O AND INDEXC<INDEXO),N)/N;
        // N天中与大盘走势保持一致,同收阳线和阴线的天数/N天。
        Dan pan tong bu index
       Output:DPTB'''

    assert N <= count  # 传入的数据量少于参数要求量，抛异常

    close_stock = bar_ds_close_to_numpy(barDs, count)
    close_index = bar_ds_close_to_numpy(barDs_index, count)
    open_stock = bar_ds_open_to_numpy(barDs, count)
    open_index = bar_ds_open_to_numpy(barDs_index, count)

    assert close_stock is not None and len(close_stock) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert close_index is not None and len(close_index) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert open_stock is not None and len(close_stock) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert open_index is not None and len(close_index) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    count_tb = numpy.zeros(count)  # 0代表不同步，1代表同步，此处为初始化
    count_sum = numpy.zeros(count)  # 计算N日内，股票与指数同步的天数值

    for i in range(count):

        if close_stock[i] > open_stock[i] and close_index[i] > open_index[i]:
            count_tb[i] = 1
        elif close_stock[i] < open_stock[i] and close_index[i] < open_index[i]:
            count_tb[i] = 1

    count_sum = SUM(count_tb, count, N)
    DPTB = count_sum / N

    return DPTB


def Z3_JDQS_COUNT(index=0, N=20):
    return N


def Z3_JDQS(barDs, barDs_index, count=1, N=20):
    ''' JDQS阶段强势指标(没有固定用法)
        A:=COUNT(C>O AND INDEXC<INDEXO,N);//N天中大盘收阴线个股收阳线的天数
        B:=COUNT(INDEXC<INDEXO,N);//N天中大盘收阴线的天数
        JDSQ:A/B;
        Jie duan qiang shi index
        Output:JDQS'''

    assert N <= count  # 传入的数据量少于参数要求量，抛异常

    close_stock = bar_ds_close_to_numpy(barDs, count)
    close_index = bar_ds_close_to_numpy(barDs_index, count)
    open_stock = bar_ds_open_to_numpy(barDs, count)
    open_index = bar_ds_open_to_numpy(barDs_index, count)

    assert close_stock is not None and len(close_stock) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert close_index is not None and len(close_index) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert open_stock is not None and len(close_stock) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert open_index is not None and len(close_index) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    count_a = numpy.zeros(count)  # 0代表不同步，1代表同步，此处为初始化
    A = numpy.zeros(count)  # 计算N日内，股票与指数同步的天数值
    count_b = numpy.zeros(count)  # 0代表不同步，1代表同步，此处为初始化
    B = numpy.zeros(count)  # 计算N日内，股票与指数同步的天数值

    for i in range(count):

        if close_stock[i] > open_stock[i] and close_index[i] < open_index[i]:
            count_a[i] = 1

        if close_index[i] < open_index[i]:
            count_b[i] = 1

    A = SUM(count_a, count, N)
    B = SUM(count_b, count, N)
    JDQS = A / B

    return JDQS


def Z3_JDRS_COUNT(index=0, N=20):
    return N


def Z3_JDRS(barDs, barDs_index, count=1, N=20):
    '''JDRS阶段弱势指标（没有固定用法）
        A:=COUNT(C<O AND INDEXC>INDEXO,N);//N天中大盘收阳线个股收阴线的天数
        B:=COUNT(INDEXC>INDEXO,N);//N天中大盘收阳线的天数
        JDRS:A/B;
        Jie duan ruo shi index
        Output:JDRS'''

    assert N <= count  # 传入的数据量少于参数要求量，抛异常

    close_stock = bar_ds_close_to_numpy(barDs, count)
    close_index = bar_ds_close_to_numpy(barDs_index, count)
    open_stock = bar_ds_open_to_numpy(barDs, count)
    open_index = bar_ds_open_to_numpy(barDs_index, count)

    assert close_stock is not None and len(close_stock) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert close_index is not None and len(close_index) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert open_stock is not None and len(close_stock) == count  # 如果barDS为空或者数据长度少于count数，抛异常
    assert open_index is not None and len(close_index) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    count_a = numpy.zeros(count)  # 0代表不同步，1代表同步，此处为初始化
    A = numpy.zeros(count)  # 计算N日内，股票与指数同步的天数值
    count_b = numpy.zeros(count)  # 0代表不同步，1代表同步，此处为初始化
    B = numpy.zeros(count)  # 计算N日内，股票与指数同步的天数值

    for i in range(count):

        if close_stock[i] < open_stock[i] and close_index[i] > open_index[i]:
            count_a[i] = 1

        if close_index[i] > open_index[i]:
            count_b[i] = 1

    A = SUM(count_a, count, N)
    B = SUM(count_b, count, N)
    JDRS = A / B

    return JDRS


def Z3_ZDZB_COUNT(index=0, N1=25, N2=5, N3=20):
    ret =  max(N2, N3) + N3
    if index in [2,3]:
        return ret+1
    return ret

def Z3_ZDZB(barDs, count=1, N1=25, N2=5, N3=20):
    ''' ZDZB 筑底指标
        A:=COUNT(CLOSE>=REF(CLOSE,1),N1)/COUNT(CLOSE<REF(CLOSE,1),N1);//N1周期内CLOSE>=REF(CLOSE,1)的次数与N1周期内CLOSE<REF(CLOSE,1)的次数的比值；
        B:MA(A,N2);//N2周期内的A的简单移动平均；
        D: MA(A,N3);//N3周期内的A的简单移动平均；
        Zhu di index
       Output:B,D,above_below_bd,crosser_bd'''

    N = max(N2, N3) + N3
    assert N <= count  # 传入的数据量少于参数要求量，抛异常
    assert N2 < N3  # N2<N3，否则抛异常

    close = bar_ds_close_to_numpy(barDs, count)
    assert close is not None and len(close) == count  # 如果barDS为空或者数据长度少于count数，抛异常

    count_a = numpy.zeros(count)  # 0代表不同步，1代表同步，此处为初始化
    count_b = numpy.zeros(count)  # 0代表不同步，1代表同步，此处为初始化

    for i in range(1, count):

        if close[i] > close[i - 1]:
            count_a[i] = 1
        elif close[i] < close[i - 1]:
            count_b[i] = 1

    Aa = SUM(count_a, count, N1)
    Ab = SUM(count_b, count, N1)
    A = Aa / Ab

    B = MA(A, count, N2)
    D = MA(A, count, N3)

    above_below_bd = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量
    crosser_bd = numpy.zeros(count)  # 0代表前变量=后变量，100代表前变量>后变量，-100代表前变量<后变量

    cmpg_b_d, cmpl_b_d = compare(B, D)
    crsu_b_d, crsd_b_d = cross(B, D)

    return B, D, crsu_b_d, crsd_b_d, cmpg_b_d, cmpl_b_d

#
# ##持有指标
# # (市值-持仓成本)/持仓成本
# def Z3_GDZY(returns, zhiyingwei=0.1):
#     '''Sell by Zhi ying wei
#        Output:GDZY'''
#
#     assert returns is not None  # 如果传入个股票收益率为空，抛异常
#     assert zhiyingwei > 0  # 如果止盈点为负数，抛异常
#
#     if returns >= zhiyingwei:
#         GDZY = 100  # 100表示TURE,达到卖出条件
#     else:
#         GDZY = 0  # 0表示FALSE，没有达到卖出条件
#
#     return GDZY
#
#
# # (市值-持仓成本)/持仓成本
# def Z3_GDZS(returns, zhisunwei=-0.1):
#     '''Sell by Zhi sun wei
#        Output:GDZS'''
#
#     assert returns is not None  # 如果传入个股票收益率为空，抛异常
#     assert zhisunwei < 0  # 如果止损点为正数，抛异常
#
#     if returns <= zhisunwei:
#         GDZS = 100  # 100表示TURE,达到卖出条件
#     else:
#         GDZS = 0  # 0表示FALSE，没有达到卖出条件
#
#     return GDZS
#
#
# def Z3_GDTS(holddays, count, N):
#     '''Sell by Holding Days
#        Output:GDTS'''
#
#     assert holddays is not None  # 如果传入个股票持有天数为空，抛异常
#     assert N > 0  # 如果设定的卖出持有天数为负数，抛异常
#
#     if holddays >= N:
#         GDTS = 100  # 100表示TURE,达到卖出条件
#     else:
#         GDTS = 0  # 0表示FALSE，没有达到卖出条件
#
#     return GDTS
#
#
# # 参考成本
# def Z3_DRAWDOWN(barDs, buy_price, N, drawdown=0.2):
#     '''Sell by Max Drawdown
#         (MAX(CLOSE,N)-buy_price)/buy_price * (1.0-drawdown)
#        Input:barDs, buy_price, N, drawdown=0.2
#        Output:current_profit <= dd'''
#
#     assert barDs is not None  # 如果传入个股票最大回撤为空，抛异常
#
#     closes = bar_ds_close_to_numpy(barDs, N)
#     assert closes is not None and len(closes) == N
#     assert 1 >= drawdown >= 0  # 断言 回撤止盈比利 在0 1 之间
#     assert buy_price > 0
#     current_close = closes[-1]
#     # 改成成本价
#     dd = (max(closes) - buy_price) / buy_price * (1.0 - drawdown)
#     current_profit = (current_close - buy_price) / buy_price
#
#     return current_profit <= dd



#
# Z3_MI.columns={"ex_close"}
# Z3_MICD.columns={"ex_close"}
# Z3_RC.columns={"ex_close"}
# Z3_RCCD.columns={"ex_close"}
# Z3_SRMI.columns={"ex_close"}
# Z3_ATR.columns={"ex_close","ex_high","ex_low"}
# Z3_MASS.columns={"ex_high","ex_low"}
# Z3_CSTD.columns={"ex_close"}
# Z3_VHF.columns={"ex_close"}
# Z3_ADTM.columns={"ex_high","ex_low","ex_open"}
# Z3_SKDJ.columns={"ex_close","ex_high","ex_low"}
# Z3_VMA.columns={"volume"}
# Z3_VMACD.columns={"volume"}
# Z3_VOSC.columns={"volume"}
# Z3_VSTD.columns={"volume"}
# Z3_BIAS.columns={"ex_close"}
# Z3_CCI.columns={"ex_close","ex_high","ex_low"}
# Z3_DBCD.columns={"ex_close"}
# Z3_DPO.columns={"ex_close"}
# Z3_KDJ.columns={"ex_close","ex_high","ex_low"}
# Z3_LWR.columns={"ex_close","ex_high","ex_low"}
# Z3_ROC.columns={"ex_close"}
# Z3_RSI.columns={"ex_close"}
# Z3_SRDM.columns={"ex_close","ex_high","ex_low"}
# Z3_VROC.columns={"volume"}
# Z3_VRSI.columns={"volume"}
# Z3_MFI.columns={"ex_close","ex_high","ex_low","volume"}
# Z3_WVAD.columns={"ex_close","ex_high","ex_low","ex_open","volume"}
# Z3_ARBR.columns={"ex_close","ex_high","ex_low","ex_open"}
# Z3_CR.columns={"ex_close","ex_high","ex_low"}
# Z3_PSY.columns={"ex_close"}
# Z3_VR.columns={"ex_close","volume"}
# Z3_BBI.columns={"ex_close"}
# Z3_DDI.columns={"ex_high","ex_low"}
# Z3_DMA.columns={"ex_close"}
# Z3_MA.columns={"ex_close"}
# Z3_EMA.columns={"ex_close"}
# Z3_MACD.columns={"ex_close"}
# Z3_MTM.columns={"ex_close"}
# Z3_PRICEOSC.columns={"ex_close"}
# Z3_TRIX.columns={"ex_close"}
# Z3_BBIBOLL.columns={"ex_close"}
# Z3_BOLL.columns={"ex_close"}
# Z3_DPTB.columns={"ex_close","ex_open","idx_open","idx_close"}
# Z3_JDQS.columns={"ex_close","ex_open","idx_open","idx_close"}
# Z3_JDRS.columns={"ex_close","ex_open","idx_open","idx_close"}
# Z3_ZDZB.columns={"ex_close"}
#
#
# Z3_MI.to_list_date=True
# Z3_MICD.to_list_date=True
# Z3_RC.to_list_date=False
# Z3_RCCD.to_list_date=True
# Z3_SRMI.to_list_date=True
# Z3_ATR.to_list_date=False
# Z3_MASS.to_list_date=True
# Z3_CSTD.to_list_date=False
# Z3_VHF.to_list_date=False
# Z3_ADTM.to_list_date=False
# Z3_SKDJ.to_list_date=True
# Z3_VMA.to_list_date=False
# Z3_VMACD.to_list_date=True
# Z3_VOSC.to_list_date=False
# Z3_VSTD.to_list_date=False
# Z3_BIAS.to_list_date=False
# Z3_CCI.to_list_date=False
# Z3_DBCD.to_list_date=True
# Z3_DPO.to_list_date=False
# Z3_KDJ.to_list_date=True
# Z3_LWR.to_list_date=True
# Z3_ROC.to_list_date=False
# Z3_RSI.to_list_date=True
# Z3_SRDM.to_list_date=True
# Z3_VROC.to_list_date=False
# Z3_VRSI.to_list_date=True
# Z3_MFI.to_list_date=False
# Z3_WVAD.to_list_date=False
# Z3_ARBR.to_list_date=False
# Z3_CR.to_list_date=False
# Z3_PSY.to_list_date=False
# Z3_VR.to_list_date=False
# Z3_BBI.to_list_date=False
# Z3_DDI.to_list_date=False
# Z3_DMA.to_list_date=False
# Z3_MA.to_list_date=False
# Z3_EMA.to_list_date=True
# Z3_MACD.to_list_date=True
# Z3_MTM.to_list_date=False
# Z3_PRICEOSC.to_list_date=False
# Z3_TRIX.to_list_date=True
# Z3_BBIBOLL.to_list_date=False
# Z3_BOLL.to_list_date=False
# Z3_DPTB.to_list_date=False
# Z3_JDQS.to_list_date=False
# Z3_JDRS.to_list_date=False
# Z3_ZDZB.to_list_date=False
#
#
#
#
# #
# # arg_name_list = (
# #     "N", "N1", "N2", "N3", "N4", "M", "M1", "M2", "M3", "M4", "SHORT", "LONG", "P", "barDs_index")
#
#
# def get_valid_params(params, valid_params):
#     params_dict = params.copy()
#     for key, value in params_dict.items():
#         if key not in valid_params:
#             params_dict.pop(key)
#     return params_dict
#
#
# import inspect
#
#
# def Z3_func_call(func_name, bards, count, params={},barDs_index=None):
#     try:
#         assert func_name and bards is not None and count
#         if params == None:
#             params = {}
#         numpy.seterr(invalid='ignore')
#         funcs = func_name.split("_")
#         assert len(funcs) == 2
#         fname = "Z3_" + funcs[0]
#         index = int(funcs[1])
#         func = eval(fname)
#         # valid_params = inspect.getargspec(func)[0]
#         # params_dict = get_valid_params(params, valid_params)
#         # params_dict ={}
#         # params_dict["barDs"] = bards
#         # params_dict["count"] = count
#         # if barDs_index is not None:
#         #     params_dict["barDs_index"]=barDs_index
#         # ret = apply(func, (), params_dict)
#         ret = func(bards,count,**params)
#         ret_array = None
#         if type(ret) == tuple:
#             ret_array = ret[index]
#         else:
#             ret_array = ret
#         if ret_array is not None:
#             ret_array[ret_array == numpy.inf] = 0
#         return ret_array
#     except Exception,e:
#         # print "Z3_func_call",func_name,e
#         raise e
#
#
# def Z3_func_count(func_name, params={}):
#     assert func_name
#     if params == None:
#         params = {}
#     funcs = func_name.split("_")
#     assert len(funcs) == 2
#     fname = "Z3_{func_name}_COUNT".format(func_name=funcs[0])
#     index = int(funcs[1])
#     func = eval(fname)
#     # valid_params = inspect.getargspec(func)[0]
#     # params_dict = get_valid_params(params, valid_params)
#     # params_dict['index'] = index
#     # if params_dict.has_key("barDs_index"):
#     #     params_dict.pop("barDs_index")
#     # return apply(eval(fname), (), params_dict)
#
#     params['index'] = index
#     ret = func(**params)
#     return ret
#
#
# def Z3_func_columns(func_name):
#     assert func_name
#     funcs = func_name.split("_")
#     assert len(funcs) == 2
#     fname = "Z3_{func_name}".format(func_name=funcs[0])
#     func = eval(fname)
#     return func.columns
#
#
# def Z3_func_to_list_date(func_name):
#     assert func_name
#     funcs = func_name.split("_")
#     assert len(funcs) == 2
#     fname = "Z3_{func_name}".format(func_name=funcs[0])
#     func = eval(fname)
#     return func.to_list_date

# example
'''
ds = barDS(df)
param={"N":2}
print Z3_func_call("MI_0",ds,50,param)
print Z3_func_count("MI_0",param)
'''
