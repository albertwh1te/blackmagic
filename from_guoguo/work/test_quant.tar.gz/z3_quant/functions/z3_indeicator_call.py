# -*- coding:utf-8 -*-
# h
# 2017-09-22 17:37
from z3_indicator import *
import traceback
import numpy

func_dict={
    "Z3_MI":{"columns":{"ex_close"},"to_list_date":True},
"Z3_MICD":{"columns":{"ex_close"},"to_list_date":True},
"Z3_RC":{"columns":{"ex_close"},"to_list_date":False},
"Z3_RCCD":{"columns":{"ex_close"},"to_list_date":True},
"Z3_SRMI":{"columns":{"ex_close"},"to_list_date":True},
"Z3_ATR":{"columns":{"ex_close","ex_high","ex_low"},"to_list_date":False},
"Z3_MASS":{"columns":{"ex_high","ex_low"},"to_list_date":True},
"Z3_CSTD":{"columns":{"ex_close"},"to_list_date":False},
"Z3_VHF":{"columns":{"ex_close"},"to_list_date":False},
"Z3_ADTM":{"columns":{"ex_high","ex_low","ex_open"},"to_list_date":False},
"Z3_SKDJ":{"columns":{"ex_close","ex_high","ex_low"},"to_list_date":True},
"Z3_VMA":{"columns":{"volume"},"to_list_date":False},
"Z3_VMACD":{"columns":{"volume"},"to_list_date":True},
"Z3_VOSC":{"columns":{"volume"},"to_list_date":False},
"Z3_VSTD":{"columns":{"volume"},"to_list_date":False},
"Z3_BIAS":{"columns":{"ex_close"},"to_list_date":False},
"Z3_CCI":{"columns":{"ex_close","ex_high","ex_low"},"to_list_date":False},
"Z3_DBCD":{"columns":{"ex_close"},"to_list_date":True},
"Z3_DPO":{"columns":{"ex_close"},"to_list_date":False},
"Z3_KDJ":{"columns":{"ex_close","ex_high","ex_low"},"to_list_date":True},
"Z3_LWR":{"columns":{"ex_close","ex_high","ex_low"},"to_list_date":True},
"Z3_ROC":{"columns":{"ex_close"},"to_list_date":False},
"Z3_RSI":{"columns":{"ex_close"},"to_list_date":True},
"Z3_SRDM":{"columns":{"ex_close","ex_high","ex_low"},"to_list_date":True},
"Z3_VROC":{"columns":{"volume"},"to_list_date":False},
"Z3_VRSI":{"columns":{"volume"},"to_list_date":True},
"Z3_MFI":{"columns":{"ex_close","ex_high","ex_low","volume"},"to_list_date":False},
"Z3_WVAD":{"columns":{"ex_close","ex_high","ex_low","ex_open","volume"},"to_list_date":False},
"Z3_ARBR":{"columns":{"ex_close","ex_high","ex_low","ex_open"},"to_list_date":False},
"Z3_CR":{"columns":{"ex_close","ex_high","ex_low"},"to_list_date":False},
"Z3_PSY":{"columns":{"ex_close"},"to_list_date":False},
"Z3_VR":{"columns":{"ex_close","volume"},"to_list_date":False},
"Z3_BBI":{"columns":{"ex_close"},"to_list_date":False},
"Z3_DDI":{"columns":{"ex_high","ex_low"},"to_list_date":False},
"Z3_DMA":{"columns":{"ex_close"},"to_list_date":False},
"Z3_MA":{"columns":{"ex_close"},"to_list_date":False},
"Z3_EMA":{"columns":{"ex_close"},"to_list_date":True},
"Z3_MACD":{"columns":{"ex_close"},"to_list_date":True},
"Z3_MTM":{"columns":{"ex_close"},"to_list_date":False},
"Z3_PRICEOSC":{"columns":{"ex_close"},"to_list_date":False},
"Z3_TRIX":{"columns":{"ex_close"},"to_list_date":True},
"Z3_BBIBOLL":{"columns":{"ex_close"},"to_list_date":False},
"Z3_BOLL":{"columns":{"ex_close"},"to_list_date":False},
"Z3_DPTB":{"columns":{"ex_close","ex_open","idx_open","idx_close"},"to_list_date":False},
"Z3_JDQS":{"columns":{"ex_close","ex_open","idx_open","idx_close"},"to_list_date":False},
"Z3_JDRS":{"columns":{"ex_close","ex_open","idx_open","idx_close"},"to_list_date":False},
"Z3_ZDZB":{"columns":{"ex_close"},"to_list_date":False}
}






#
# arg_name_list = (
#     "N", "N1", "N2", "N3", "N4", "M", "M1", "M2", "M3", "M4", "SHORT", "LONG", "P", "barDs_index")


def get_valid_params(params, valid_params):
    params_dict = params.copy()
    for key, value in params_dict.items():
        if key not in valid_params:
            params_dict.pop(key)
    return params_dict


import inspect


def Z3_func_call(func_name, bards, count, params={},barDs_index=None):
    try:
        assert func_name and bards is not None and count
        if params == None:
            params = {}
        numpy.seterr(invalid='ignore')
        funcs = func_name.split("_")
        assert len(funcs) == 2
        fname = "Z3_" + funcs[0]
        index = int(funcs[1])
        func = eval(fname)
        valid_params = inspect.getargspec(func)[0]
        params_dict = get_valid_params(params, valid_params)
        # params_dict ={}
        # params_dict["barDs"] = bards
        # params_dict["count"] = count
        # if barDs_index is not None:
        #     params_dict["barDs_index"]=barDs_index
        # ret = apply(func, (), params_dict)
        ret = func(bards,count,**params_dict)
        ret_array = None
        if type(ret) == tuple:
            ret_array = ret[index]
        else:
            ret_array = ret
        if ret_array is not None:
            ret_array[ret_array == numpy.inf] = 0
        return ret_array
    except Exception,e:
        # print "Z3_func_call",func_name,e
        traceback.print_exc()
        raise e


def Z3_func_count(func_name, params={}):
    assert func_name
    if params == None:
        params = {}
    funcs = func_name.split("_")
    assert len(funcs) == 2
    fname = "Z3_{func_name}_COUNT".format(func_name=funcs[0])
    index = int(funcs[1])
    func = eval(fname)
    valid_params = inspect.getargspec(func)[0]
    params_dict = get_valid_params(params, valid_params)
    # params_dict['index'] = index
    # if params_dict.has_key("barDs_index"):
    #     params_dict.pop("barDs_index")
    # return apply(eval(fname), (), params_dict)

    params_dict['index'] = index
    ret = func(**params_dict)
    return ret


def Z3_func_columns(func_name):
    assert func_name
    funcs = func_name.split("_")
    assert len(funcs) == 2
    fname = "Z3_{func_name}".format(func_name=funcs[0])
    # func = eval(fname)
    # return func.columns
    return func_dict[fname]["columns"]


def Z3_func_to_list_date(func_name):
    assert func_name
    funcs = func_name.split("_")
    assert len(funcs) == 2
    fname = "Z3_{func_name}".format(func_name=funcs[0])
    # func = eval(fname)
    # return func.to_list_date
    return func_dict[fname]["to_list_date"]