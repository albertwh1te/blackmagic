# -*- coding:utf-8 -*-
# h
from __future__ import division

from z3_indicator import *

import logbook
import pandas as pd
from pymongo import MongoClient, ReadPreference, ASCENDING
from datetime import datetime, timedelta
import numpy as np
from barDS import *


def n8_to_date(n8):
    day = n8 % 100
    value = int(n8 / 100)
    month = int(value % 100)
    year = int(value / 100)
    return datetime(year, month, day)


class Tester(object):
    def __init__(self):
        self.db = self.get_mongoDB()
        self.stocks = self.get_stocks()

    def get_mongoDB(self):
        client = MongoClient([u'10.77.4.37:27017'])
        db = client["z3dbus"]
        db.authenticate("z3dbusadmin", "z3dbusadmin")
        return db

    def get_stocks(self):
        symbols = self.db['Z3_STK_MKT_DAY'].distinct("innerCode")
        return symbols

    def call(self, inner_code, start, end, func_name, **param):
        '''跟据指标名 取指标结果
            input:
                inner_code 股票代码.证券市场 如 002800.SZ
                start 开始日期
                end 结束日期
                func_name 函数名
                param 函数参数  可写到 N=12,M=20
                输入实例  call("002800.SZ",20150101,20160101,"MA_0",N1=5,N2=10,N3=30)
            output:
                list
        '''
        # 计算窗口长度
        window_size = Z3_func_count(func_name, param)
        cursor = self.db['Z3_STK_MKT_DAY'].find(
            {'innerCode': inner_code,
             'trade_date': {'$lte': end}},
            projection={
                'trade_date': 1,
                'ex_open_px': 1,
                'ex_high_px': 1,
                'ex_low_px': 1,
                'ex_close_px': 1,
                "volume": 1,
                '_id': 0
            }).sort([('trade_date', ASCENDING)])
        df = pd.DataFrame(list(cursor))
        list_date = []
        for i in df['trade_date']:
            list_date.append(n8_to_date(i))
        df['trade_date'] = pd.Series(list_date)
        # 时间设置为索引
        df.set_index('trade_date', inplace=True)
        df.rename(columns={'ex_open_px': 'ex_open', 'ex_high_px': 'ex_high', 'ex_low_px': 'ex_low',
                           'ex_close_px': 'ex_close'}, inplace=True)
        # 去停牌 暂停
        df = df[df["volume"] > 0]
        start_date = n8_to_date(start)
        index_date = n8_to_date(start)
        end_date = n8_to_date(end)

        ret_date = []
        ret_list = []
        while index_date < end_date:
            value = None
            if index_date in df.index:
                df_window = df.loc[:index_date][-window_size:]
                if len(df_window) >= window_size:

                    try:
                        bards = barDS(df_window)
                        value = Z3_func_call(func_name, bards, window_size, param)[-1]
                    except Exception,e:
                        print e
                    # if value is not None:

            ret_date.append(index_date)
            ret_list.append(value)
            index_date += timedelta(days=1)

        ret_df = pd.DataFrame({"trade_date": ret_date, "value": ret_list})
        return ret_df


if __name__ == "__main__":
    tester = Tester()
    # print tester.call("002800.SZ",20160530,20170101,"MA_0",N1=5,N2=10,N3=30)
    # print tester.stocks
    # df0= tester.call("002800.SZ",20160530,20170505,"MTM_0",N1=6,N2=6)
    # df1= tester.call("002800.SZ",20160530,20170505,"MTM_1",N1=6,N2=6)
    # df2= tester.call("002800.SZ",20160530,20170505,"MTM_2",N1=6,N2=6)
    # df3= tester.call("002800.SZ",20160530,20170505,"MTM_3",N1=6,N2=6)
    # df4= tester.call("002800.SZ",20160530,20170505,"MTM_4",N1=6,N2=6)
    df = tester.call("002800.SZ",20160530,20170101,"MICD_0",N1=2,N2=3,N3=4)
    print df