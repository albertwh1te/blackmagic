# -*- coding:utf-8 -*-

from flask import Flask, request
import datetime
import quant_service
from check_trade_day import CheckDay
from zipline.utils.calendars import get_calendar, register_calendar
from china_calendar import ChinaCalendar
from quant_core import bundles, register, ingest
from zipline.utils.run_algo import load_extensions
import pandas as pd
import os
from genius_bundle import genius_equities
import sys
from quant_dao import setup_run_env,get_mongodb
from zipline.data.data_portal import DataPortal

app = Flask(__name__)

#首页控制器
@app.route('/')
def index():
    return "量化回测服务"

#开始回测
@app.route('/start_back_test')
def start_back_test():
    strategy_id = request.args.get("strategy_id")
    print(strategy_id)
    quant_service.start_back_test(strategy_id)
    return 'started'

#停止回测
@app.route('/stop_back_test')
def stop_back_test():
    strategy_id = request.args.get("strategy_id")
    print(strategy_id)
    quant_service.stop_back_test(strategy_id)
    return 'stopped'


import warnings
import numpy
if __name__ == '__main__':

    warnings.filterwarnings("ignore")
    numpy.seterr(invalid='ignore')
    run_env = None
    if len(sys.argv) > 1:
        run_env = sys.argv[1]
    setup_run_env(run_env)

    # 开启数据抽取定时任务
    print("starting quant web...")

    def ingest_data():
        print("ingesting data...")
        register_calendar("China", ChinaCalendar(), force=True)
        db = get_mongodb()
        symbols = db['Z3_STK_MKT_DAY'].distinct("innerCode")
        # print symbols
        # symbols = ['000033.SZ', '000511.SZ', '000707.SZ', '002756.SZ', '002749.SZ', '002800.SZ', '002830.SZ',  '002578.SZ', '002024.SZ',
        #            '600019.SH', '600031.SH', '600067.SH', '600083.SH', '600087.SH', '600550.SH']
        # symbols=['000511.SZ','000707.SZ','002830.SZ',  '002578.SZ','600031.SH']
        start_session_str = '2005-01-04'
        end_session_str = datetime.date.today()
        # print end_session_str
        register(
            'genius_bundle',
            genius_equities(symbols),
            "China",
            pd.Timestamp(start_session_str, tz='utc'),
            pd.Timestamp(end_session_str, tz='utc'),
            # 中国股市每日交易时间为4个小时 美国是6个半小时
            minutes_per_day=240
        )
        # ingest('genius_bundle')
        #
        # load_extensions(
        #     default=True,
        #     extensions=[],
        #     strict=True,
        #     environ=os.environ,
        # )
        print("ingest data complete.")

    ingest_data()
    # scheduler = BackgroundScheduler()
    # scheduler.add_job(ingest_data, 'cron', hour=22, minute=30)
    # scheduler.add_job(ingest_data, 'interval', minutes=2)
    # scheduler.start()

    print("quant web started.")

    app.run(host="0.0.0.0")
