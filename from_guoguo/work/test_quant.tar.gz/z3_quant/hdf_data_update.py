# -*- coding:utf-8 -*-
# h
# 2017-07-12 15:52
from quant_dao import *
from pymongo import ASCENDING
import pandas as pd
from datetime import *
from numpy import (
    float64
)

indexs = {'000300.SH', '000001.SH', '399001.SZ', '399006.SZ', '399005.SZ', '000016.SH', '399905.SZ',
          '000906.SH', '000852.SH', '000013.SH'}


# symbols = ['000033.SZ', '000511.SZ']\
# , '000707.SZ', '002756.SZ', '002749.SZ', '002800.SZ', '002830.SZ', '002578.SZ',
#   '002024.SZ','600019.SH', '600031.SH', '600067.SH', '600083.SH', '600087.SH', '600550.SH']


def n8_to_date(n8):
    day = n8 % 100
    value = int(n8 / 100)
    month = int(value % 100)
    year = int(value / 100)
    return datetime(year, month, day)


def date_to_n8(date):
    if date is None:
        return 0
    return date.year * 10000 + date.month * 100 + date.day


STOCK_COLUMNS = (
    'open', 'high', 'low', 'close', 'volume', 'day', 'id'
    , 'trade_status', 'trade_next_status', 'limit_up_non_open', 'limit_down_non_open',
    'ex_open', 'ex_high', 'ex_low', 'ex_close', 'mtkcap_a', 'avg'
)

load_length = 30

def load_data(symbol, store, db):
    name = symbol[7:9] + symbol[0:6]
    df_old = None
    # if name != "SZ300372":
    #     continue
    last_day = 20050103
    try:

        df_old = store.select(name)
        if len(df_old)>load_length:
            last_day = date_to_n8(df_old.index[-load_length].to_pydatetime())
            store.remove(key=name, where=[pd.Term('index', '>=', df_old.index[-load_length])])
            df_old.drop(df_old.index[-load_length:],axis=0,inplace=True)
        else:
            last_day = date_to_n8(df_old.index[-1].to_pydatetime())
            store.remove(key=name, where=[pd.Term('index', '>=', df_old.index[-1])])
            df_old.drop([df_old.index[-1]],axis=0,inplace=True)

    except Exception, e:
        print e
    cursor = db['Z3_STK_MKT_DAY'].find(
        {
            'innerCode': symbol,
            'trade_date': {
                '$gte': last_day
                # , "$lt": 20170713
            }
        },
        projection={
            '_id': 0,
            'trade_date': 1,
            'open_px': 1,
            'high_px': 1,
            'low_px': 1,
            'close_px': 1,
            'volume': 1,
            'trade_status': 1,
            'trade_next_status': 1,
            'limit_up_non_open': 1,
            'limit_down_non_open': 1,
            'ex_open_px': 1,
            'ex_low_px': 1,
            'ex_high_px': 1,
            'ex_close_px': 1,
            'mtkcap_a': 1,
            'price_avg': 1
        }).sort([('trade_date', ASCENDING)])
    if cursor is None:
        return None
    cursor_list = list(cursor)
    if cursor_list is None or len(cursor_list) == 0:
        return None

    last_obj = cursor_list[-1]
    if last_obj.has_key('trade_next_status'):
        last_obj['trade_next_status'] = 1
    if last_obj.has_key('price_avg'):
        if last_obj['price_avg'] is None:
            last_obj['price_avg'] = 0.0

    dtype = [
        ("open_px", "f8"),
        ("high_px", "f8"),
        ("low_px", "f8"),
        ("close_px", "f8"),
        ("volume", "f8"),
        ("trade_date", "i8"),

        ("avg", "f8"),
        ("ex_open_px", "f8"),
        ("ex_high_px", "f8"),
        ("ex_low_px", "f8"),
        ("ex_close_px", "f8"),
        ("mtkcap_a", "i8"),
        ("trade_status", "i8"),
        ("trade_next_status", "i4")
        # ("limit_up_non_open","i4"),
        # ("limit_down_non_open","i4")

    ]
    columns = ["open_px", "high_px", "low_px", "close_px", "volume", "avg",
               "ex_open_px", "ex_high_px", "ex_low_px", "ex_close_px", "mtkcap_a",
               'trade_status', 'trade_next_status',
               'limit_up_non_open', 'limit_down_non_open']

    offset = len(columns)

    if symbol in indexs:
        offset = 6
    df = pd.DataFrame(cursor_list)
    trade_date_list = df["trade_date"].map(n8_to_date).values
    datetime_index = pd.DatetimeIndex(data=trade_date_list, tz='utc')
    df.set_index(datetime_index, inplace=True)

    df = pd.DataFrame(df, dtype=float64)

    del df["trade_date"]
    # df = pd.DataFrame(df,index=datetime_index)
    df.rename(
        columns={
            'open_px': 'open',
            'high_px': 'high',
            'low_px': 'low',
            'close_px': 'close',
            'ex_low_px': 'ex_low',
            'ex_open_px': 'ex_open',
            'ex_high_px': 'ex_high',
            'ex_close_px': 'ex_close',
            'price_avg': 'avg',
        },
        inplace=True
    )
    # hfile.create_group(symbol)
    # hgroup = hfile[symbol]
    # for colum in STOCK_COLUMNS:
    #     hgroup.create_dataset(colum, (4000), dtype="f8")
    if symbol not in indexs:
        df["limit_down_non_open"] = df["limit_down_non_open"].map(lambda x: 1 if x else 0)
        df["limit_up_non_open"] = df["limit_up_non_open"].map(lambda x: 1 if x else 0)

    # else:
    #     df.columns = ["open", "high", "low", "close", "volume"]
    # print df.dtypes
    # if df_old is not None:
    #     print df_old.dtypes
    # print df.dtypes
    #
    # print name, index, length, len(df)

    store.append(name, df, append=True)
    if df_old is not None:
        return df_old.append(df)
    else:
        return df
    # if update_callback is not None:
    #     update_callback(name, df)
    # index += 1
    # return df_new


def get_data(update_callback=None):
    db = get_mongodb()
    # symbols = db['Z3_STK_MKT_DAY'].distinct("innerCode")
    index = 1
    with pd.HDFStore("stocks.h5") as store:
        keys = store.keys()
        length = len(keys)
        for name in keys:
            # name = symbol[7:9] + symbol[0:6]
            # print name
            try:
                df = store.select(name)
                print index,length,name,len(df)
                if update_callback is not None:
                    update_callback(name, df)
                index += 1
            except Exception,e:
                print e

def update_data():
    # hfile = h5.File("stocks.h5", 'w')
    db = get_mongodb()
    symbols = db['Z3_STK_MKT_DAY'].distinct("innerCode")
    index = 0

    with pd.HDFStore("stocks.h5") as store:
        length = len(symbols)
        for symbol in symbols:
            name = symbol[7:9] + symbol[0:6]
            df = load_data(symbol, store, db)
            print symbol, index, length, len(df)
            index += 1
            # df.to_hdf("stocks.h5", name, append=True)
            # idt=date_to_n8(datetime.now())
            # pn.to_hdf(""+str(idt)+".h5","pa")
            # store.close()


if __name__ == "__main__":
    db = get_mongodb()
    with pd.HDFStore("stocks.h5") as store:
        df = load_data("002146.SZ",store,db)

        print df.iloc[-50:]