# -*- coding:utf-8 -*-
# h
# 2017-07-18 9:43

import logbook
import pandas as pd
from pandas.tslib import normalize_date
from six import string_types
from sqlalchemy import create_engine

from zipline.assets import AssetDBWriter, AssetFinder
from zipline.data.loader import load_market_data
from zipline.utils.calendars import get_calendar
from zipline.utils.memoize import remember_last
from zipline.finance.trading import TradingEnvironment


class Z3TradingEnvironment(TradingEnvironment):
    PERSISTENT_TOKEN = "<TradingEnvironment>"
    def __init__(
            self,
            load=None,
            bm_symbol='^GSPC',
            exchange_tz="US/Eastern",
            trading_calendar=None,
            asset_db_path=':memory:'
    ):
        self.bm_symbol = bm_symbol
        if not load:
            load = load_market_data

        if not trading_calendar:
            trading_calendar = get_calendar("NYSE")

        self.benchmark_returns, self.treasury_curves = load(
            trading_calendar.day,
            trading_calendar.schedule.index,
            self.bm_symbol,
        )

        self.exchange_tz = exchange_tz

        if isinstance(asset_db_path, string_types):
            asset_db_path = 'sqlite:///' + asset_db_path
            self.engine = engine = create_engine(asset_db_path, connect_args={'check_same_thread': False})
        else:
            self.engine = engine = asset_db_path

        if engine is not None:
            AssetDBWriter(engine).init_db()
            self.asset_finder = AssetFinder(engine)
        else:
            self.asset_finder = None


    def write_data(self, **kwargs):
        """Write data into the asset_db.

        Parameters
        ----------
        **kwargs
            Forwarded to AssetDBWriter.write
        """
        AssetDBWriter(self.engine).write(**kwargs)