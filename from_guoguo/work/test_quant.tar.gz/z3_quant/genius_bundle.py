# -*- coding:utf-8 -*-
# __author__=qiang.fu

import numpy as np
import pandas as pd
import pymongo
import datetime
from quant_dao import get_mongodb
today = datetime.datetime.today()
today_date = datetime.datetime(today.year, today.month, today.day, 0, 0, 0)
index_inner_code = {'000300.SH', '000001.SH', '399001.SZ', '399006.SZ', '399005.SZ', '000016.SH', '399905.SZ',
                    '000906.SH', '000852.SH'}

def genius_equities(symbols, start=None, end=None):
    def ingest(environ,
               asset_db_writer,
               minute_bar_writer,  # unused
               daily_bar_writer,
               adjustment_writer,
               calendar,
               start_session,
               end_session,
               cache,
               show_progress,
               output_dir,
               # pass these as defaults to make them 'nonlocal' in py2
               start=start,
               end=end):
        if start is None:
            start = start_session
        if end is None:
            end = None

        db = get_mongodb()
        cursor = db['Z3_EQUITY_PROFILE'].find(
            {},
            projection={"list_date":1,
                        "delist_date":1,
                        })
        sid = 0
        meta_list = []
        symbol_set = set()
        for profile in cursor:
            end_date = profile.get("delist_date")
            start_date = profile.get("list_date")
            symbol = profile.get("_id")
            if symbol not in symbols:
                # print "not exist ",symbol
                continue
            symbols.remove(symbol)
            if start_date is None:
                now = datetime.datetime.now()
                start_date = datetime.datetime(now.year,now.month,now.day)
            if end_date is None:
                end_date = datetime.datetime(2099,1,1)
            meta_list.append((start_date,end_date,end_date,symbol))
            symbol_set.add(symbol)
            sid+=1
            # print sid,start_date,end_date,end_date,symbol

        metadata = pd.DataFrame(np.empty(sid, dtype=[
            ('start_date', 'datetime64[ns]'),
            ('end_date', 'datetime64[ns]'),
            ('auto_close_date', 'datetime64[ns]'),
            ('symbol', 'object'),
        ]))
        index = 0
        for (start_date,end_date,end_date,symbol) in meta_list:
            # print start_date,end_date,end_date,symbol
            metadata.iloc[index]=start_date,end_date,end_date,symbol
            index+=1
        def _pricing_iter():
            sid = 0
            db = get_mongodb()
            for symbol_item in symbols:
                # 只返回projection中指定字段以及排除_id字段
                cursor = db['Z3_STK_MKT_DAY'].find(
                    {'innerCode': symbol_item
                        # , 'trade_date': {'$gte': today_date}
                     },
                    projection={
                        '_id': 0,
                        'trade_date': 1,
                        'open_px': 1,
                        'high_px': 1,
                        'low_px': 1,
                        'close_px': 1,
                        'volume': 1,
                        'trade_status': 1,
                        'trade_next_status': 1,
                        'limit_up_non_open': 1,
                        'limit_down_non_open': 1,
                        'ex_low_px': 1,
                        'ex_open_px': 1,
                        'ex_high_px': 1,
                        'ex_close_px': 1,
                        'mtkcap_a': 1,
                        'price_avg': 1
                    }).sort([('trade_date', pymongo.ASCENDING)])
                # 转化结果
                print 'sid:%d and code:%s' % (sid, symbol_item)
                df = pd.DataFrame(list(cursor))
                new_date = []
                for x in df['trade_date']:
                    s = str(x)
                    d = datetime.datetime(int(s[:4]), int(s[4:6]), int(s[6:]))
                    new_date.append(d)
                df['trade_date'] = new_date

                # 对trade_date字段设置索引
                df.set_index('trade_date', inplace=True)
                # 从索引的第一位和最后一位取到起始日期和结束日期
                start_date = df.index[0]
                end_date = df.index[-1]
                # The auto_close date is the day after the last trade
                # 修改自动关闭日 -1 要改
                # 如果 end date< 今天
                # 提前一天 自动闭
                ac_date = end_date + pd.Timedelta(days=10)
                # if end_date+ pd.Timedelta(days=1)< pd.Timestamp.today():
                #     ac_date = ac_date = end_date - pd.Timedelta(days=1)
                #     pass
                metadata.iloc[sid] = start_date, end_date, ac_date, symbol_item

                # 指数人工添加status字段
                if symbol_item in index_inner_code:
                    df['trade_status'] = 99
                    df['trade_next_status'] = 99
                    df['limit_up_non_open'] = 99
                    df['limit_down_non_open'] = 99
                    df['ex_low_px'] = 99
                    df['ex_open_px'] = 99
                    df['ex_high_px'] = 99
                    df['ex_close_px'] = 99
                    df['mtkcap_a'] = 0
                    df['price_avg'] = 0



                # 将日期从整形转换为DateTime型


                # 对列名进行重新命名以符合zipline的格式
                df.rename(
                    columns={
                        'open_px': 'open',
                        'high_px': 'high',
                        'low_px': 'low',
                        'close_px': 'close',
                        'ex_low_px': 'ex_low',
                        'ex_open_px': 'ex_open',
                        'ex_high_px': 'ex_high',
                        'ex_close_px': 'ex_close',
                        'price_avg': 'avg',
                    },
                    inplace=True
                )
                df.fillna(99, inplace=True)
                # print df
                yield sid, df
                sid += 1
        # 生成OHLCV的列式数据结构
        begin_time = datetime.datetime.now()
        # daily_bar_writer.write(_pricing_iter(), show_progress=show_progress)
        symbol_map = pd.Series(metadata.symbol.index, metadata.symbol)
        # print symbol_map
        end_time = datetime.datetime.now()
        # print end_time-begin_time
        metadata['exchange'] = "China"
        # 生成sqlite数据库assets-5.sqlite
        asset_db_writer.write(equities=metadata)

        # db = get_mongodb()
        cursor = db['Z3_STK_DIV_PS'].find({}, projection={
            '_id': 0, 'innerCode':1,'end_date': 1, 'cash': 1, 'div_total': 1})

        div_dict={}
        for div in cursor:
            id = div.get("innerCode")
            if div_dict.has_key(id):
                div_dict[id].append(div)
            else:
                div_dict[id] =[div]
        # print div_dict
        for symbol,value in div_dict.items():
            if symbol not in symbol_set:
                continue
            df = pd.DataFrame(value)
            # symbol = div.get("innerCode")
            print "adjustment",symbol_map[symbol],symbol
            df['sid'] = symbol_map[symbol]
            # 判断无数据时跳过
            if df.empty:
                continue
            dividends = df[['cash', 'end_date', 'sid']]
            dividends = dividends.rename(columns={'cash': 'amount', 'end_date': 'ex_date'})
            dividends['amount'] = dividends['amount'].values.astype(float)*0.9
            dividends['record_date'] = pd.NaT
            dividends['declared_date'] = pd.NaT
            dividends['pay_date'] = pd.NaT
            # print dividends

            stock_dividends = df[['div_total', 'end_date', 'sid']]
            stock_dividends = stock_dividends.rename(columns={'div_total': 'ratio', 'end_date': 'ex_date'})
            stock_dividends['ratio'] = stock_dividends['ratio'].values.astype(float)
            stock_dividends['record_date'] = pd.NaT
            stock_dividends['declared_date'] = pd.NaT
            stock_dividends['pay_date'] = pd.NaT
            stock_dividends['payment_sid'] = stock_dividends['sid']
            # print stock_dividends

            # 生成sqlite数据库adjustments.sqlite
            adjustment_writer.write(dividends=dividends, stock_dividends=stock_dividends)

    return ingest
