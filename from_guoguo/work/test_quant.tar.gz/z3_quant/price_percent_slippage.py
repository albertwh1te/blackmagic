# -*- coding:utf-8 -*-
# __author__=qiang.fu

from zipline.finance.slippage import SlippageModel

class PricePercentSlippage(SlippageModel):
    def __init__(self, slippage, buy_price_type, sell_price_type):
        self.slippage = slippage
        self.buy_price_type = buy_price_type
        self.sell_price_type = sell_price_type
        self.price = None

    def process_order(self, data, my_order):
        if my_order.direction > 0:
            self.price = str(self.buy_price_type)
        else:
            self.price = str(self.sell_price_type)
        price = data.current(my_order.sid, self.price)
        new_price = price * (1 + my_order.direction * self.slippage)
        # print "price",price
        return (new_price, my_order.amount)

    def adjustment_price(self,sid,data,data_daily,direction):
        if direction > 0:
            self.price = str(self.buy_price_type)
        else:
            self.price = str(self.sell_price_type)
        # price = data[sid.symbol][self.price]
        price = data.current(sid,self.price)
        new_price = price * (1 + direction * self.slippage)
        return new_price
