# -*- coding:utf-8 -*-

from datetime import timedelta
from multiprocessing.managers import DictProxy

import numpy as np
import pandas as pd

from Z3DailyHistoryLoader import *
# from z3_quant.cache.ex_data_cache import *
from zipline.data.data_portal import *
from datetime import *
from zipline.utils.memoize import weak_lru_cache

ex_columns = ('open','high','low','close','volume',
              'ex_open', 'ex_high', 'ex_low', 'ex_close','avg','mtkcap_a',
              'trade_next_status','trade_status',
              'limit_down_non_open','limit_up_non_open')

class Z3DataPortal(DataPortal):
    def __init__(self,
                 asset_finder,
                 trading_calendar,
                 first_trading_day,
                 equity_daily_reader=None,
                 equity_minute_reader=None,
                 future_daily_reader=None,
                 future_minute_reader=None,
                 adjustment_reader=None,
                 memory_bars=None
                 ):

        super(Z3DataPortal, self).__init__(asset_finder,
                                           trading_calendar,
                                           first_trading_day,
                                           equity_daily_reader,
                                           equity_minute_reader,
                                           future_daily_reader,
                                           future_minute_reader,
                                           adjustment_reader)

        self._history_loader = Z3DailyHistoryLoader(
            self.trading_calendar,
            self._history_loader._reader,
            None
        )
        self.memory_bars = memory_bars
        self.daily_data ={}
        #
        # self.get_daily_df(pd.Timestamp(datetime(2017,1,4)))
        # print memory_bars
        # self.pd_data = pd.Panel(memory_bars.dict())
        # print self.pd_data.major_xs("000001.SZ")
        # DictProxy

    def symbols(self, symbols):
        syms = [self.symbol(identifier) for identifier in symbols]
        return syms

    # def symbol_today(self, symbol_str,today):
    #     now = datetime.now() - timedelta(days=1)
    #     end_dt = pd.Timestamp(now)
    #     tds = self.trading_calendar.all_sessions
    #     end_session = self.trading_calendar.minute_to_session_label(end_dt, direction='previous')
    #     sym = self.asset_finder.lookup_symbol(
    #         symbol_str,
    #         as_of_date=end_session,
    #     )
    #     return sym


    def get_all_data_by_date(self,dt_session):
        pass

    @weak_lru_cache(None)
    def symbol(self, symbol_str):
        now = datetime.now() - timedelta(days=1)
        end_dt = pd.Timestamp(now)
        tds = self.trading_calendar.all_sessions
        end_session = self.trading_calendar.minute_to_session_label(end_dt, direction='previous')
        sym = self.asset_finder.lookup_symbol(
            symbol_str,
            as_of_date=end_session,
        )
        return sym

    # def get_histor_data_today(self,symbol,today):
    #     if self.memory_bars is not  None:
    #         return self.memory_bars.get(symbol)


    @weak_lru_cache(None)
    def get_history_data(self, symbol):
        if self.memory_bars is not  None:
            now = datetime.now()
            return self.memory_bars.get(symbol)

        now = datetime.now() - timedelta(days=1)
        end_dt = pd.Timestamp(now)  # z3_benchmark_returns.index[-1]

        tds = self.trading_calendar.all_sessions
        # 最后一个交易日
        end_session = self.trading_calendar.minute_to_session_label(end_dt, direction='previous')
        end_loc = tds.get_loc(end_session)
        count = end_loc + 1  # 所有数据
        sym = self.asset_finder.lookup_symbol(symbol, as_of_date=end_session)
        df_dict = {
            field: self.get_history_window([sym], end_session, count, "1d", field)[sym] for field in
            ex_columns
        }
        df = pd.DataFrame(df_dict)
        return df

    # 取历史数据
    def get_all_history_window(self, symbols, end_session):
        ret_dict = {
            #.loc[:end_session]
            symbol: self.get_history_data(symbol) for symbol in symbols
        }
        return ret_dict

    def get_history_window(self, assets, end_dt, bar_count, frequency, field,
                           ffill=True):
        """
        Public API method that returns a dataframe containing the requested
        history window.  Data is fully adjusted.

        Parameters
        ----------
        assets : list of zipline.data.Asset objects
            The assets whose data is desired.

        bar_count: int
            The number of bars desired.

        frequency: string
            "1d" or "1m"

        field: string
            The desired field of the asset.

        ffill: boolean
            Forward-fill missing values. Only has effect if field
            is 'price'.

        Returns
        -------
        A dataframe containing the requested data.
        """
        # if field not in OHLCVP_FIELDS:
        #     raise ValueError("Invalid field: {0}".format(field))

        if frequency == "1d":
            if field == "price":
                df = self._get_history_daily_window(assets, end_dt, bar_count,
                                                    "close")
            else:
                df = self._get_history_daily_window(assets, end_dt, bar_count,
                                                    field)
        elif frequency == "1m":
            if field == "price":
                df = self._get_history_minute_window(assets, end_dt, bar_count,
                                                     "close")
            else:
                df = self._get_history_minute_window(assets, end_dt, bar_count,
                                                     field)
        else:
            raise ValueError("Invalid frequency: {0}".format(frequency))

        # forward-fill price
        if field == "price":
            if frequency == "1m":
                data_frequency = 'minute'
            elif frequency == "1d":
                data_frequency = 'daily'
            else:
                raise Exception(
                    "Only 1d and 1m are supported for forward-filling.")

            dt_to_fill = df.index[0]

            perspective_dt = df.index[-1]
            assets_with_leading_nan = np.where(pd.isnull(df.iloc[0]))[0]
            for missing_loc in assets_with_leading_nan:
                asset = assets[missing_loc]
                previous_dt = self.get_last_traded_dt(
                    asset, dt_to_fill, data_frequency)
                if pd.isnull(previous_dt):
                    continue
                previous_value = self.get_adjusted_value(
                    asset,
                    field,
                    previous_dt,
                    perspective_dt,
                    data_frequency,
                )
                df.iloc[0, missing_loc] = previous_value

            df.fillna(method='ffill', inplace=True)

            for asset in df.columns:
                if df.index[-1] >= asset.end_date:
                    # if the window extends past the asset's end date, set
                    # all post-end-date values to NaN in that asset's series
                    series = df[asset]
                    series[series.index.normalize() > asset.end_date] = np.NaN

        return df

    def get_daily_df(self,session_label):

        if self.daily_data.has_key(session_label):
            return self.daily_data[session_label]
        else:
            df_dict ={}
            for key in self.memory_bars.keys():
                h_df = self.get_history_data(key)
                if session_label in h_df.index:
                    df_dict[key] = h_df.loc[session_label]
                # df = self.get_history_data(key).loc[session_label]
                # print df
            df = pd.DataFrame(df_dict)
            self.daily_data[session_label]=df
            return df


    def get_spot_value(self, asset, field, dt, data_frequency):




        #return



        """
        Public API method that returns a scalar value representing the value
        of the desired asset's field at either the given dt.

        Parameters
        ----------
        asset : Asset
            The asset whose data is desired.
        field : {'open', 'high', 'low', 'close', 'volume',
                 'price', 'last_traded'}
            The desired field of the asset.
        dt : pd.Timestamp
            The timestamp for the desired value.
        data_frequency : str
            The frequency of the data to query; i.e. whether the data is
            'daily' or 'minute' bars

        Returns
        -------
        value : float, int, or pd.Timestamp
            The spot value of ``field`` for ``asset`` The return type is based
            on the ``field`` requested. If the field is one of 'open', 'high',
            'low', 'close', or 'price', the value will be a float. If the
            ``field`` is 'volume' the value will be a int. If the ``field`` is
            'last_traded' the value will be a Timestamp.
        """
        # if self._is_extra_source(asset, field, self._augmented_sources_map):
        #     return self._get_fetcher_value(asset, field, dt)
        #
        # if field not in BASE_FIELDS:
        #     raise KeyError("Invalid column: " + str(field))

        if type(field)==str:
            if field == 'price':
                field = 'close'
        elif type(field) == list:
            if 'price' in field:
                field.remove('price')
                field.append('close')


        session_label = self.trading_calendar.minute_to_session_label(dt)
        if dt < asset.start_date or \
                (data_frequency == "daily" and
                         session_label > asset.end_date) or \
                (data_frequency == "minute" and
                         session_label > asset.end_date):
            if field == "volume":
                return 0
            elif field != "last_traded":
                return np.NaN


        try:
            df =  self.get_history_data(asset.symbol).loc[session_label][field]
            return df
        except Exception,e:
            print 'Z3DataPortal get_spot_value:',asset.symbol,session_label,e
            return np.NaN

        if data_frequency == "daily":
            return self._get_daily_data(asset, field, session_label)
        else:
            if field == "last_traded":
                return self.get_last_traded_dt(asset, dt, 'minute')
            elif field == "price":
                return self._get_minute_spot_value(asset, "close", dt,
                                                   ffill=True)
            else:
                return self._get_minute_spot_value(asset, field, dt)

    def _get_daily_data(self, asset, column, dt):
        reader = self._get_pricing_reader('daily')
        if column == "last_traded":
            last_traded_dt = reader.get_last_traded_dt(asset, dt)

            if pd.isnull(last_traded_dt):
                return pd.NaT
            else:
                return last_traded_dt
        elif column in OHLCV_FIELDS or column == 'avg':
            # don't forward fill
            try:
                val = reader.get_value(asset, dt, column)
                if val == -1:
                    if column == "volume":
                        return 0
                    else:
                        return np.nan
                else:
                    return val
            except NoDataOnDate:
                return np.nan
        elif column == "price":
            found_dt = dt
            while True:
                try:
                    value = reader.get_value(
                        asset, found_dt, "close"
                    )
                    if value != -1:
                        if dt == found_dt:
                            return value
                        else:
                            # adjust if needed
                            return self.get_adjusted_value(
                                asset, column, found_dt, dt, "minute",
                                spot_value=value
                            )
                    else:
                        found_dt -= self.trading_calendar.day
                except NoDataOnDate:
                    return np.nan
        elif column in ['trade_status', 'trade_next_status', 'limit_up_non_open', 'limit_down_non_open', 'mtkcap_a']:
            try:
                val = reader.get_value(asset, dt, column)
                return val
            except NoDataOnDate:
                return np.nan
