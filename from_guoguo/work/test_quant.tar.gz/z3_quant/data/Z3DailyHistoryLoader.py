from zipline.data.history_loader import DailyHistoryLoader
from zipline.utils.cache import ExpiringCache
from cachetools import LRUCache

class Z3DailyHistoryLoader(DailyHistoryLoader):
    def __init__(self,
                 trading_calendar,
                 reader,
                 adjustment_reader,
                 sid_cache_size=1):
        super(Z3DailyHistoryLoader,self).__init__(trading_calendar,
                                                  reader,
                                                  adjustment_reader,
                                                  sid_cache_size )

        self._window_blocks["ex_open"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["ex_high"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["ex_low"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["ex_close"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["mtkcap_a"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["avg"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["trade_next_status"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["trade_status"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["limit_down_non_open"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
        self._window_blocks["limit_up_non_open"] = ExpiringCache(LRUCache(maxsize=sid_cache_size))
