
from multiprocessing import *


class Mp(Process):
    def __init__(self):
        pass

if __name__=="__main__":
    pass
    manager=Manager()
    mdict = manager.dict()

