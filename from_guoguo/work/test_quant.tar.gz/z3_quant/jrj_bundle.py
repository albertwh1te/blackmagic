import numpy as np
import pandas as pd
from zipline.data.bundles import register
def jrj_equities(symbols, start=None, end=None):
    symbols = tuple(symbols)
    print symbols
    def ingest(environ,
               asset_db_writer,
               minute_bar_writer,  # unused
               daily_bar_writer,
               adjustment_writer,
               calendar,
               start_session,
               end_session,
               cache,
               show_progress,
               output_dir):
        import numpy as np
        import pandas as pd
        metadata = pd.DataFrame(np.empty(1, dtype=[
            ('start_date', 'datetime64[ns]'),
            ('end_date', 'datetime64[ns]'),
            ('auto_close_date', 'datetime64[ns]'),
            ('symbol', 'object'),
        ]))
        # data we will collect in `gen_symbol_data`
        splits = []
        dividends = []

        def fetch_single_equity():
            obj = pd.read_csv(
                '/data/stock.csv',
                index_col=0,
                na_values=['NA'],
                parse_dates=[0]
            )
            return obj

        df = fetch_single_equity()
        start_date = df.index[0]
        end_date = df.index[-1]
        ac_date = end_date
        metadata.set_value(0, 'start_date', start_date)
        metadata.set_value(0, 'end_date', end_date)
        metadata.set_value(0, 'auto_close_date', ac_date)
        metadata.set_value(0, 'symbol', '600000')

        def _pricing_iter():
            yield 0,df

        metadata['exchange'] = "SH"
        asset_db_writer.write(equities=metadata)
        daily_bar_writer.write(
            _pricing_iter(),
            show_progress=show_progress,
        )
        splits = pd.DataFrame(np.empty(1, dtype=[
            ('effective_date', 'datetime64[ns]'),
            ('ratio', 'float64'),
            ('sid', 'int64'),
        ]))
        splits.set_value(0, 'effective_date', "2014-03-27")
        splits.set_value(0, 'ratio', 0.500000)
        splits.set_value(0, 'sid', 0)

        dividends = pd.DataFrame(np.empty(1, dtype=[0
            ('ex_date', 'datetime64[ns]'),
            ('amount', 'float64'),
            ('sid', 'int64'),
            ('record_date', 'datetime64[ns]'),
            ('declared_date', 'datetime64[ns]'),
            ('pay_date', 'datetime64[ns]'),
        ]))
        dividends.set_value(0, 'ex_date', "2014-03-27")
        dividends.set_value(0, 'amount', 0.00393)
        dividends.set_value(0, 'sid', 0)
        dividends.set_value(0, 'record_date', "2014-03-27")
        dividends.set_value(0, 'declared_date', "2014-03-27")
        dividends.set_value(0, 'pay_date', "2014-03-27")

        adjustment_writer.write(
            splits=splits,
            dividends=dividends
        )
        print df
        print metadata
    return ingest

equities = {
    '600000'
}
register(
    'jrj_bundle',  # name this whatever you like
    jrj_equities(equities),
)


