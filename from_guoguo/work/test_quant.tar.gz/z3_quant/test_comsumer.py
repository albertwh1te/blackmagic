# -*- coding: utf-8 -*-
import struct
from pykafka import KafkaClient
import multiprocessing, Queue
from multiprocessing import Process

from time import sleep
import json

#
# mongodb = connect('z3dbus', host='117.121.98.91', port=27017, username='z3dbusadmin', password='z3dbusadmin')
# list = Z3StkMktDayInner.objects(equity__innerCode="300050.SZ").only("end_date", 'open_px','high_px','low_px','close_px','volume').order_by("-end_date").limit(31).all()
#pipi
# pass
import random
import uuid
from kafka import KafkaProducer, KafkaConsumer



def consume_data(consumer):
    try:
        for message in consumer:
            yield message
    except KeyboardInterrupt, e:
        print e
if __name__=="__main__":

    # try:
    #     print "run"
    #     # client = KafkaClient(hosts="10.77.2.7:9092,10.77.2.8:9092,10.77.2.9:9092")
    #     # client = KafkaClient(hosts="10.77.4.27:9092,10.77.4.28:9092,10.77.4.29:9092")
    #     client = KafkaClient(hosts="10.88.3.160:9092,10.88.3.161:9092,10.88.3.162:9092")
    #     topic_list = client.topics
    #     # for topic in topic_list:
    #     #     print topic
    #     topic = client.topics['gen_strategy']
    #     # topic = client.topics['quant_backtest']
    #
    #
    #     id = random.randint(0, 9999)
    #     consumer = topic.get_simple_consumer(consumer_group='quant_group',
    #                                          consumer_id=str(uuid.uuid1()),
    #                                          auto_commit_enable=True,
    #                                          auto_commit_interval_ms=1,
    #                                          # auto_offset_reset=-1,
    #                                          # auto_offset_reset=-2,#EARLIEST
    #                                          reset_offset_on_start=False
    #                                          # auto_offset_reset=
    #                                          )
    #
    #     # consumer = topic.get_simple_consumer(consumer_group='g5',
    #     #                                      auto_commit_enable=True,
    #     #                                      auto_commit_interval_ms=1,
    #     #                                      auto_offset_reset=-1,
    #     #                                      reset_offset_on_start=False
    #     #                                      #auto_offset_reset=
    #     #                                      )
    #
    #     for message in consumer:
    #         if message is not None:
    #             try:
    #                 # datas=json.loads(message.value)
    #                 print message.value
    #                # print message.partition_key,message.value
    #             except Exception, e:
    #                 print "解析错误"
    # except Exception, e:
    #     sleep(5)
    #     print e
    # consumer = KafkaConsumer("gen_strategy", bootstrap_servers='10.88.3.160:9092,10.88.3.161:9092,10.88.3.162:9092',group_id="quant_group")
    consumer = KafkaConsumer("quant_backtest", bootstrap_servers='10.77.4.57:9092,10.77.4.58:9092,10.77.4.59:9092')
    for message in consume_data(consumer):
        try:
            print message.value
        except Exception, e:
            print e
