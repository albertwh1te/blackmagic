# -*- coding:utf-8 -*-
# h
# 2017-08-24 8:36
import sys

sys.path.insert(0, "..")

from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
from Cython.Distutils import build_ext

ext_modules = [
    Extension("functions.indicator", ["functions/indicator.pyx"]),
    # Extension("functions.z3_indicator", ["functions/z3_indicator.pyx"]),

]

setup(
    cmdclass={'build_ext': build_ext},
    ext_modules=ext_modules,
)
