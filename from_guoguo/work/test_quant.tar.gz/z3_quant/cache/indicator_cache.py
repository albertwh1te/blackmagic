# -*- coding:utf-8 -*-
# h
# 2017-07-14 8:07


class IndicatorCache(object):
    # 保存指标
    def __init__(self, symbol, df):
        '''
            key ["000001.SZ"]
            value DataFrame
        '''
        # 股票
        self.symbol = symbol
        # 时间为索引
        # 用法 df[dt]
        # [日期->指标:参数]
        # [MA_0:{N=1,N2=2},MA_1:{N=1,N2=2}]
        self.df = df
        pass

    def __getitem__(self, dt):
        return self.df[dt]

    def get(self,dt):
        try:
            return self.df[dt]
        except:
            return None
#
# class IndicatorCacheDict(dict):
#     def __missing__(self, symbol):
#         self[symbol] = cache = IndicatorCache(symbol)
#         return cache
