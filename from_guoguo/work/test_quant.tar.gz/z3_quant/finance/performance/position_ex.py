# -*- coding: utf-8 -*-
from datetime import datetime
import time


class PositionEx(object):
    def __init__(self, sid):
        self.sid = sid

        self.hold_trade_days = 0

        # 开始日期int
        self.start_date = None
        # 持仓量
        self.amount = 0

        # 持仓成本
        self.hold_cost = 0.0

        # 持仓市值
        self.values = 0.0

        # 最大收益
        self.max_returns = 0

        # 收益回撤
        self.draw_down = 0

        # 收益
        self.profit = 0

        # 个股收益
        self.returns = 0.0

        self.hold_days = 0

        pass

    def clear(self):
        self.hold_trade_days = 0

        # 开始日期int
        self.start_date = None
        # 持仓量
        self.amount = 0

        # 持仓成本
        self.hold_cost = 0.0

        # 持仓市值
        self.values = 0.0

        # 最大收益
        self.max_returns = 0

        # 收益回撤
        self.draw_down = 0

        # 收益
        self.profit = 0

        # 个股收益
        self.returns = 0.0

        # 持有交易日
        self.hold_days = 0

    # # 拆股时 改变amount 成本变少 可以不做
    # def split(self, rate):
    #     self.amount *= 1 + rate

    # 现金分红 从成本中减掉
    def dividend(self, dividend_per_share):
        self.hold_cost -= self.amount * dividend_per_share

    def dividend_stock(self, new_amount):
        self.amount = new_amount

    @property
    def reference_cost(self):
        if self.amount == 0:
            return 0
        return self.hold_cost / self.amount

    # 实际持仓天数
    # def hold_days(self, date):
    #     if self.start_date is None:
    #         return 0
    #     return (date - self.start_date).days + 1

    def update(self, txs, position, date, buy_price_type, sell_price_type):
        '''
            Input:
                position:当天仓位
                txs:该股票当天所有交易
                date:当天日期int
        '''
        # 买卖处理优先级
        today_amount = 0
        start_amount = self.amount
        order_txs = []
        # 处理先买后卖
        order_buys = filter(lambda x: x['amount'] > 0, txs)
        order_sells = filter(lambda x: x['amount'] < 0, txs)

        # 除非确定卖在前  否则先买后卖
        if (sell_price_type == 'open' and buy_price_type != 'open') or (
                        buy_price_type == 'close' and sell_price_type != 'close'):
            order_txs.extend(order_sells)
            order_txs.extend(order_buys)
        else:
            order_txs.extend(order_buys)
            order_txs.extend(order_sells)

        # 更新交易 并合并
        for tx in order_txs:
            tx_amount = tx['amount']
            tx_price = tx['price']
            commission = tx['commission']
            if self.amount + tx_amount<0:
                pass

            total_shares = self.amount + tx_amount
            today_amount += tx_amount
            if total_shares == 0:
                self.clear()
                continue
            if tx_amount > 0:
                self.max_returns = 0
                # 买入
                txn_cost = tx_amount * tx_price
                self.hold_cost += txn_cost + commission
            else:
                # 卖出
                reference_cost = self.hold_cost / self.amount
                txn_cost = tx_amount * reference_cost
                self.hold_cost += txn_cost
            self.amount = total_shares

        self.hold_trade_days += 1

        # 计算持仓日期
        # if today_amount > 0:
        #     if self.start_date:
        #         start_i = date_to_ts(self.start_date)
        #         end_i = date_to_ts(date)
        #         mid_i = (start_i * start_amount + end_i * today_amount) / (self.amount)
        #         self.start_date = ts_to_date(mid_i)
        #     else:
        #         self.start_date = date

        if self.amount == 0:
            return

        if position:
            # 更新持仓
            #     if position.amount != self.amount:
            #         print "position.amount != self.amount", date, "posamount", position.amount, "examount", self.amount
            #         # 如果对持仓做过调整 则改成本
            #
            #         self.amount = position.amount
            self.hold_days += 1
            if self.amount == 0:
                self.clear()
                return
            self.values = self.amount * position.last_sale_price
            # 收益率-

            if self.hold_cost != 0:
                self.returns = (self.values - self.hold_cost) / self.hold_cost
            else:
                self.returns = 0
            self.max_returns = max(self.max_returns, self.returns, 0)
            if self.max_returns:
                self.draw_down = 1 - (self.returns / self.max_returns)
            else:
                self.draw_down = 0
            self.profit = self.values - self.hold_cost


def date_to_ts(dt):
    return time.mktime(dt.timetuple())


def ts_to_date(ts):
    dt = datetime.fromtimestamp(ts)
    return datetime(dt.year, dt.month, dt.day)


class PositionExs(dict):
    def __missing__(self, key):
        self[key] = pos = PositionEx(key)
        return pos

    def update(self, transactions, positions, date, buy_price_type, sell_price_type):
        ''' 交易分类
        '''
        # 分类
        txs_dict = {}
        keys = set()
        for tx in transactions:
            tx_sid = tx['sid']
            keys.add(tx_sid)
            if txs_dict.has_key(tx_sid):
                txs_dict[tx_sid].append(tx)
            else:
                txs_dict[tx_sid] = [tx]
        # 更新
        for key in positions.keys():
            keys.add(key)

        for sid in keys:
            if txs_dict.has_key(sid):
                txs = txs_dict[sid]
            else:
                txs = []
            position_ex = self[sid]
            v = None
            if positions.has_key(sid):
                v = positions[sid]
            position_ex.update(txs, v, date, buy_price_type, sell_price_type)

        keys = self.keys()
        for key in keys:
            if self[key].amount == 0:
                del self[key]
        pass
