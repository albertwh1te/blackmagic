# -*- coding:utf-8 -*-
# __author__=qiang.fu

from __future__ import division
import os
import re
import threading
from datetime import timedelta
import pandas as pd
from utils.utils import *
from zipline.api import (
    symbol,
    symbols,
    sid,
    set_slippage,
    set_commission
)
# from zipline.data.bundles.core import load
from quant_core import load
import sys
from zipline.finance.trading import TradingEnvironment
from genius_trading_algorithm import GeniusTradingAlgorithm
from zipline.utils.calendars import get_calendar
from zipline.utils.factory import create_simulation_parameters
from benchmark_loader import load_benchmark_data
from quant_dao import *
from collections import OrderedDict
from functions.z3_indicator import *
from functions.barDS import *
import json
from stock_commission import *
from empyrical import (
    beta_aligned,
    information_ratio,
    sharpe_ratio,
    annual_volatility,
    annual_return,
    max_drawdown,
)
import copy
from empyrical.stats import cum_returns
import pytz
import pymongo
from price_percent_slippage import PricePercentSlippage
from data.Z3DataPortal import Z3DataPortal
from finance.performance.position_ex import *
import urllib2
import math
from zipline.errors import NoFurtherDataError
import numpy as np
import bottleneck as bn
nanstd = bn.nanstd


class BacktestTask(object):
    def __init__(self, strategy_id, remove_thread):

        self.strategy_id = strategy_id

        # 卖出胜数
        self.sell_winning_count = 0

        # 卖出数
        self.sell_count = 0
        # 总买入金额
        self.total_buy_account = 0
        # 总卖出金额
        self.total_sell_account = 0
        # 每日资产
        self.daily_portfolio = dict()
        self.week_data = None
        self.month_data = None
        # print self.stock_name

        # 当前日期
        self.current_dt = None

        # 上一个交易日
        self.last_trade_date = None

        # 当日买入金额
        self.buy_value = 0
        # 当日卖出金额
        self.sell_value = 0
        # 当日盈亏
        self.profit = None
        # 当日资产
        self.portfolio = None
        self.algo_obj = None
        # 持仓扩展属性
        self.position_ex = PositionExs()

        # 更新次数
        self.update_count = 0
        self.returns = []
        # kafka
        self.producer = None
        self.mogodb_db = None

        self.last_dividens=None

        self.symbols={}
        db = self.mongodb
        cursor = db['Z3_EQUITY'].find({}, projection={
            '_id': 1,
            'name': 1,
        })
        df = pd.DataFrame(list(cursor))
        self.stock_name = pd.Series(df['name'].values, index=df['_id'])

        self.month_end_value=OrderedDict()
        self.month_idx_portfolio={}
        self.sell_profit = []

        self.last_port_portfolio = 0

        self.progress = 0

        self.sell_profit_40_cache=[]
        # 交易明细 push
        self.backtest_trade_detail_cache=[]
        # 月收益 set
        self.month_profit_cache=None
        # 每日持仓 push
        self.backtest_daily_position_detail_cache=[]
        # 每日表现 push
        self.backtest_result_overview_detail_cache=[]
        # 状态
        self.backtest_status_cache=0

        self.stop = False

        self.remove_thread = remove_thread

    def start(self):
        print('线程开始...')
        self.clock_time = time.clock()

        strategy_obj = self.get_strategy(self.strategy_id)
        # 获取选股策略或股票池
        self.stock_strategy_id = strategy_obj.get("stock_strategy_id")
        stock_pool_id = strategy_obj.get("stock_pool_id")
        if stock_pool_id is not None:
            self.pool_stocks = self.get_stocks_by_pool_id(stock_pool_id)

        # 获取买卖指标和条件表达式
        self.buy_strategy_index = strategy_obj.get("buy_strategy_index")


        self.buy_con_exp = strategy_obj.get("buy_con_exp")
        self.sell_strategy_index = strategy_obj.get("sell_strategy_index")
        self.sell_con_exp = strategy_obj.get("sell_con_exp")

        # 获取仓位控制模型
        self.position_model_id = strategy_obj.get("position_model_id")

        # 获取交易设置
        init_fund = strategy_obj.get("init_fund")
        self.fund_allocate = strategy_obj.get("fund_allocate")
        self.buy_price_type = strategy_obj.get("buy_price_type")
        self.sell_price_type = strategy_obj.get("sell_price_type")
        self.max_holding = strategy_obj.get("max_holding")
        self.stock_max_holding = strategy_obj.get("stock_max_holding")
        self.con_priority = strategy_obj.get("con_priority")
        self.commission_rate = strategy_obj.get("commission")
        self.commission = StockCommission(self.commission_rate)

        self.slippage_rate = strategy_obj.get("slippage")
        self.slippage = PricePercentSlippage(self.slippage_rate, self.buy_price_type, self.sell_price_type)

        benchmark = strategy_obj.get("benchmark")
        self.risk_free_ratio = strategy_obj.get("risk_free_ratio")
        backtest_start_date = strategy_obj.get("backtest_start_date")
        backtest_end_date = strategy_obj.get("backtest_end_date")
        self.trade_cycle_type = strategy_obj.get("trade_cycle_type")

        self.next_day_trade = False

        self.trade_cycle_value = strategy_obj.get("trade_cycle_value")
        self.trade_month_days =[]
        # 计算日期
        if self.trade_cycle_type == 'user_defined':
            days = self.trade_cycle_value.split(",")
            for day in days:
                target_month_day = day.replace('-','')
                self.trade_month_days.append(target_month_day)


        bundle = 'genius_bundle'
        bundle_data = load(
            bundle,
            os.environ,
            None,
        )

        prefix, connstr = re.split(
            r'sqlite:///',
            str(bundle_data.asset_finder.engine.url),
            maxsplit=1,
        )
        env = TradingEnvironment(
            load=load_benchmark_data,
            bm_symbol=benchmark,
            trading_calendar=get_calendar("China"),
            asset_db_path=connstr
        )
        first_trading_day = \
            bundle_data.equity_minute_bar_reader.first_trading_day
        data = Z3DataPortal(
            env.asset_finder,
            get_calendar("China"),
            first_trading_day=first_trading_day,
            equity_minute_reader=bundle_data.equity_minute_bar_reader,
            equity_daily_reader=bundle_data.equity_daily_bar_reader,
            adjustment_reader=bundle_data.adjustment_reader,
        )
        start_date = pd.to_datetime(str(backtest_start_date) + " 17:30:00").tz_localize("Asia/Shanghai").astimezone(
            tz=pytz.UTC)
        sim_params = create_simulation_parameters(
            start=start_date,
            end=pd.to_datetime(str(backtest_end_date) + " 23:00:00").tz_localize("Asia/Shanghai").astimezone(
                tz=pytz.UTC),
            capital_base=init_fund,
            data_frequency="daily",
            emission_rate="daily",
            trading_calendar=get_calendar("China")
        )
        self.algo_obj = GeniusTradingAlgorithm(
            initialize=self.initialize,
            handle_data=self.handle_data,
            sim_params=sim_params,
            env=env,
            trading_calendar=get_calendar("China"),
            before_trading_start=self.before_trading_start
        )
        # algo_obj.set_commission(StockCommission(self.commission))
        # 不允许做空
        self.algo_obj.set_long_only()
        self.algo_obj.data_portal = data
        self.write_strategy_info(self.strategy_id, init_fund, backtest_start_date, backtest_end_date)
        self.last_trade_date=start_date
        try:
            last_month = int(backtest_start_date/100)
            self.month_end_value[0]=init_fund

            # 初始化
            # 获取日级表现指标

            for perf in self.algo_obj.get_generator():
                if self.stop:
                    self.back_test_failed("用户取消")
                    break
                # 如果不是一个月 计算上个月
                # 当前市值
                my_perf = dict()
                my_perf['strategy_id'] = self.strategy_id
                self.update_count += 1
                # 计算顺序不能变
                # cumulative_risk_metrics = perf.get("cumulative_risk_metrics")

                if self.calc_daily(perf,my_perf):
                    # print perf
                    # print self.current_dt
                    # print algorithm_returns
                    # print benchmark_returns
                    # 计算风险
                    self.calc_risk_ex(perf,my_perf)
                    # 计算四十
                    self.calc_profit_merge()
                    progress = perf.get("progress")
                    self.progress=my_perf['progress'] = progress
                    if progress < 1.0:
                        my_perf['status'] = 1
                    elif progress == 1.0:
                        my_perf['status'] = 2

                    # tracker = self.algo_obj.perf_tracker
                    # algorithm_returns = tracker.cumulative_risk_metrics.algorithm_returns
                    # benchmark_returns = tracker.cumulative_risk_metrics.benchmark_returns
                    #
                    # algorithm_returns_series = pd.Series(algorithm_returns)
                    # benchmark_returns_series = pd.Series(benchmark_returns)
                    # benchmark_returns[0]=0
                    # my_perf['running_time'] = self.get_running_time()
                    # my_perf['backtest_date'] = self.datetime_to_int(self.current_dt)
                    #
                    # my_perf['algorithm_period_return'] = self.check_for_null(cumulative_risk_metrics.get("algorithm_period_return"))
                    # my_perf['benchmark_period_return'] = self.check_for_null(cumulative_risk_metrics.get("benchmark_period_return"))
                    #
                    # my_perf['annual_return'] = self.check_for_null(annual_return(algorithm_returns, annualization=250))
                    # my_perf['excess_return'] = self.check_for_null(cumulative_risk_metrics.get("excess_return"))
                    # my_perf['algo_volatility'] = self.check_for_null(cumulative_risk_metrics.get("algo_volatility"))
                    # my_perf['sharpe'] = self.check_for_null(cumulative_risk_metrics.get("sharpe"))
                    # my_perf['max_drawdown'] = self.check_for_null(cumulative_risk_metrics.get("max_drawdown"))
                    #
                    # alpha,beta = alpha_beta(algorithm_returns_series, benchmark_returns_series, risk_free=self.risk_free_ratio, annualization=250)
                    # my_perf['beta'] = self.check_for_null(beta)
                    # my_perf['alpha'] = self.check_for_null(alpha)
                    # my_perf['win_ratio'] = self.check_for_null(self.get_win_ratio())
                    # my_perf['turnover'] = self.check_for_null(self.get_turnover())

                    #写入月数据
                    # self.calc_and_write_month_data(date_to_n6(self.current_dt),my_perf['portfolio'],)
                    #print my_perf
                    # 记录每日持仓
                    self.write_daily_position_detail(self.algo_obj, self.algo_obj.trading_client.current_data,my_perf)
                    # 写每交易
                    self.write_trade_detail(perf.get("daily_perf").get("transactions"))
                    # 写每日表现
                    self.save_and_notify(my_perf)
                    # 3.现金分红检查
                    self.calc_dividend_posision()
                    self.last_trade_date=self.current_dt
                    # self.write_to_db()


            # self.calc_and_write_month_data(currend_month,self.get_today_position_value(),True)
        except Exception, e:
            print sys._getframe().f_lineno,e
            self.back_test_failed(e.message)

        self.write_to_db()
        self.algo_obj.data_portal = None
        self.remove_thread(self.strategy_id)
        print("线程结束")

    def set_stop(self):
        self.stop = True

    def back_test_failed(self,msg=None):
        my_perf = dict()
        my_perf['strategy_id'] = self.strategy_id
        my_perf['status'] = 3
        my_perf['progress']=self.progress
        if msg is not None:
            my_perf["failed_reason"] = msg
        self.save_and_notify(my_perf)


    def calc_volatility_sharp(self,returns,annual_return,annualization=250):
        n = len(returns)
        if n < 2:
            return 0,0

        volatility = nanstd(returns, ddof=0) * ((annualization*1.0) ** (1.0 / 2.0))
        if volatility == 0:
            return 0,0
        sharp = (annual_return-self.risk_free_ratio)/volatility
        return volatility, sharp
        pass
    def calc_information(self,algorithm_returns,benchmark_returns,annual_algorithm_return,annual_benchmark_return,annualization=250):
        pass
        n = len(algorithm_returns)
        if n < 2:
            return 0
        values = algorithm_returns-benchmark_returns
        std_value = nanstd(values, ddof=0) * ((annualization*1.0) ** (1.0 / 2.0))
        cha = (annual_algorithm_return-annual_benchmark_return)
        return cha/std_value

    # 重新计算指标
    def calc_risk_ex(self,perf,my_perf):
        cumulative_risk_metrics = perf.get("cumulative_risk_metrics")
        tracker = self.algo_obj.perf_tracker
        algorithm_returns = tracker.cumulative_risk_metrics.algorithm_returns
        benchmark_returns = tracker.cumulative_risk_metrics.benchmark_returns
        benchmark_returns[0] = 0
        # 累计收益率
        algorithm_period_return = cum_returns(algorithm_returns)[-1]
        benchmark_period_return = cum_returns(benchmark_returns)[-1]
        # 年化收益率
        annual_algorithm_return = annual_return(algorithm_returns, annualization=250)
        annual_benchmark_return = annual_return(benchmark_returns, annualization=250)

        my_perf['buy_value'] = self.buy_value
        my_perf['sell_value'] = self.sell_value
        my_perf['running_time'] = self.get_running_time()
        my_perf['backtest_date'] = self.datetime_to_int(self.current_dt)
        my_perf['algorithm_period_return'] = algorithm_period_return
        my_perf['benchmark_period_return'] = benchmark_period_return
        my_perf['annual_return'] = annual_algorithm_return
        my_perf['excess_return'] = algorithm_period_return - benchmark_period_return
        volatility,sharp = self.calc_volatility_sharp(algorithm_returns,annual_algorithm_return)
        my_perf['algo_volatility'] = volatility
        my_perf['sharpe'] = sharp
        my_perf['max_drawdown'] = self.check_for_null(cumulative_risk_metrics.get("max_drawdown"))
        beta = beta_aligned(algorithm_returns, benchmark_returns)
        alpha = self.get_alpha(annual_algorithm_return, annual_benchmark_return, risk_free=self.risk_free_ratio, beta=beta)
        my_perf['beta'] = beta
        my_perf['alpha'] = alpha

        my_perf['win_ratio'] = self.check_for_null(self.get_win_ratio())
        my_perf['turnover'] = self.check_for_null(self.get_turnover())
        my_perf['information']=self.calc_information(algorithm_returns,benchmark_returns,annual_algorithm_return,annual_benchmark_return)

        #写入月数据
        self.calc_and_write_month_data(date_to_n6(self.current_dt),my_perf['portfolio'],benchmark_returns[-1])

        # print "backtest_date",my_perf['backtest_date']
        # print "daily_returns",algorithm_returns[-1]
        # print "benchmark_returns",benchmark_returns[-1]
        # print "annual_return",my_perf['annual_return']
        # print "excess_return",my_perf['excess_return']
        # print "algo_volatility",my_perf['algo_volatility']
        # print "sharpe",my_perf['sharpe']
        # print "max_drawdown",my_perf['max_drawdown']
        # print "beta",my_perf['beta']
        # print "alpha",my_perf['alpha']
        # print "win_ratio",my_perf['win_ratio']
        # print "turnover",my_perf['turnover']
        # print "volatility,information",volatility,my_perf['information']
        # print "algorithm_period_return",my_perf['algorithm_period_return']
        # print 'portfolio',my_perf['portfolio']
        # print 'profit',my_perf['profit']
        # print "self.buy_value",self.buy_value
        # print "self.sell_value",self.sell_value
        # my_perf['beta'] = self.check_for_null(cumulative_risk_metrics.get("beta"))
        # my_perf['alpha'] = self.check_for_null(cumulative_risk_metrics.get("alpha"))
        if len(algorithm_returns) >= 20:
            self.compute_recent_performance(algorithm_returns, benchmark_returns, 20, my_perf)
        if len(algorithm_returns) >= 60:
            self.compute_recent_performance(algorithm_returns, benchmark_returns, 60, my_perf)
        if len(algorithm_returns) >= 120:
            self.compute_recent_performance(algorithm_returns, benchmark_returns, 120, my_perf)
        if len(algorithm_returns) >= 250:
            self.compute_recent_performance(algorithm_returns, benchmark_returns, 250, my_perf)

        pass
    # 回测初始化
    def initialize(self, context):

        set_slippage(self.slippage)
        set_commission(self.commission)

        # 买入备选池
        context.buy_candidate_pool = []
        # 卖出备选池
        context.sell_candidate_pool = []
        # 拟购买池
        context.pre_buy_pool = dict()
        # 拟卖出池
        context.pre_sell_pool = dict()
        # 拟卖出池附池
        context.pre_sell_attach_pool = []
        # 最近交易日
        context.recent_trading_days = []

    # 回测迭代
    def handle_data(self, context, data):
        try:
            # sym = symbol("002024.SZ")
            # columes = ['open', 'high', 'low', 'close', 'volume', 'day', 'id', 'trade_status', 'trade_next_status',
                       # 'limit_up_non_open', 'limit_down_non_open']
            # open, high, low, close, volume, day, id, trade_status, trade_next_status, limit_up_non_open, limit_down_non_open = data.current(
                # sym, columes)
            # print('open:' + str(open) + ',high:' + str(high) + ',low:' + str(low) + ',close:' + str(close)
            #       + ',volume:' + str(volume) + ',trade_status:' + str(trade_status) + ', trade_next_status:' + str(
            #     trade_next_status) + ', limit_up_non_open:' + str(limit_up_non_open) + ', limit_down_non_open:' + str(
            #     limit_down_non_open))
            self.current_dt = data.current_dt

            # # 卖出退市股票
            # self.sell_delist_stocks(context, data)
            #
            # # 买入拟购买池股票
            # context.pre_buy_pool = self.remove_paused_stocks(data.current_dt, data, context.pre_buy_pool)
            # context.pre_buy_pool = self.remove_less_than_one_hand_stocks(data.current_dt, data, context.pre_buy_pool)
            # self.buy_stocks(data, context.pre_buy_pool)
            #
            # # 卖出拟卖出池股票
            # context.pre_sell_pool = self.move_paused_stocks_to_attache_pool(data.current_dt, data, context.pre_sell_pool, context.pre_sell_attach_pool)
            # self.sell_stocks(data.current_dt, data, context.pre_sell_pool)

            self.portfolio = context.portfolio.portfolio_value
            context.buy_candidate_pool=[]
            context.sell_candidate_pool=[]

            # 设置下一个交易日的买入卖出股票池
            # 择时优先
            model_position = self.get_model_position(self.position_model_id, data.current_dt)
            if self.con_priority == 'time_first':
                # 设置拟买入股票池
                if self.is_adjustment_day(context, data):
                    if context.portfolio.portfolio_value!=0:
                        pos_persent = context.portfolio.positions_value / context.portfolio.portfolio_value * 100
                    else:
                        pos_persent = 0
                    if self.get_model_position(self.position_model_id,
                                               data.current_dt) > pos_persent:
                        if len(context.portfolio.positions) < self.max_holding:
                            # 选股策略不为空时，查询当前日期的股票列表
                            if self.stock_strategy_id is not None:
                                self.pool_stocks = self.get_stocks_by_strategy_id(self.stock_strategy_id, data.current_dt)
                            if self.buy_con_exp is not None:
                                context.buy_candidate_pool = self.get_candidate_pool_by_condition(self.buy_con_exp,
                                                                                                  self.buy_strategy_index,
                                                                                                  data,
                                                                                                  context.buy_candidate_pool,
                                                                                                  self.pool_stocks)
                            else:
                                context.buy_candidate_pool = self.pool_stocks
                                # print context.buy_candidate_pool
                            context.buy_candidate_pool = self.remove_next_day_paused_stocks_from_list(data,
                                                                                                      context.buy_candidate_pool)
                            context.buy_candidate_pool = self.remove_max_holding_stocks_from_list(context,
                                                                                                  context.buy_candidate_pool)
                            if len(context.buy_candidate_pool) > self.max_holding - len(context.portfolio.positions):
                                context.buy_candidate_pool = self.slice_candidate_pool(context, context.buy_candidate_pool)
                            context.pre_buy_pool = dict.fromkeys(context.buy_candidate_pool)
                            self.allocate_buy_fund(context, data, context.pre_buy_pool,model_position)

                # 设置拟卖出股票池
                holding_stocks = self.get_holding_stocks(context)
                if self.sell_con_exp is not None:
                    context.sell_candidate_pool = self.get_candidate_pool_by_condition(self.sell_con_exp,
                                                                                       self.sell_strategy_index, data,
                                                                                       context.sell_candidate_pool,
                                                                                       holding_stocks)
                context.sell_candidate_pool.extend(context.pre_sell_attach_pool)
                context.pre_sell_attach_pool=[]
                context.pre_sell_pool = dict.fromkeys(context.sell_candidate_pool)
                self.allocate_sell_share(context, data, context.pre_sell_pool, True,model_position)

            # 仓位优先
            elif self.con_priority == 'model_first':
                if self.is_adjustment_day(context, data):
                        context.pre_sell_attach_pool=[]
                position_value = self.get_today_position_value(context,data)
                portfolio_value = self.get_portfolio_value(context,data)
                total_position = position_value / portfolio_value
                if model_position > total_position:
                    # 有加仓空间
                    holding_stocks = self.get_holding_stocks(context)
                    context.pre_buy_pool = dict.fromkeys(holding_stocks)
                    if len(context.pre_buy_pool) < self.max_holding:
                        if self.stock_strategy_id is not None:
                            self.pool_stocks = self.get_stocks_by_strategy_id(self.stock_strategy_id, data.current_dt)
                        context.buy_candidate_pool.extend(self.pool_stocks)
                        context.buy_candidate_pool = self.remove_next_day_paused_stocks_from_list(data,
                                                                                                  context.buy_candidate_pool)
                        context.buy_candidate_pool = self.slice_candidate_pool(context, context.buy_candidate_pool)
                        context.pre_buy_pool = dict.fromkeys(context.buy_candidate_pool)
                    context.pre_buy_pool = self.remove_next_day_paused_stocks_from_dict(data, context.pre_buy_pool)
                    context.pre_buy_pool = self.remove_max_holding_stocks_from_dict(context, context.pre_buy_pool)
                    self.allocate_buy_fund(context, data, context.pre_buy_pool,model_position)
                elif model_position < total_position:
                    # 有减仓空间
                    holding_stocks = self.get_holding_stocks(context)
                    context.pre_sell_pool = dict.fromkeys(holding_stocks)
                    context.pre_sell_pool = self.remove_next_day_paused_stocks_from_dict(data, context.pre_sell_pool)
                    self.allocate_sell_share(context, data, context.pre_sell_pool,False,model_position=model_position)
                    pass

                pass
        except Exception,e:
            # 失败写入
            print sys._getframe().f_lineno,e
            raise e
            # self.back_test_failed(e.message)
            pass

    def get_portfolio_value(self,context,data):
        return context.portfolio.cash +  self.get_today_position_value(context,data)

    def get_today_position_value(self,context, data):
        value = 0.0
        positions = context.portfolio.positions
        for key,pos in positions.items():
            close = data.current(key,'close')
            value += pos.amount*close
        return value


    def before_trading_start(self, context, data):
        try:
            # 当日买入金额
            self.buy_value = 0
            # 当日卖出金额
            self.sell_value = 0

            print data.current_dt.date(),"开始"
            # 卖出退市股票
            self.sell_delist_stocks(context, data)

            # 买入拟购买池股票
            context.pre_buy_pool = self.remove_suspend_and_limit_up_non_open_stocks(data.current_dt, data,
                                                                                    context.pre_buy_pool)
            context.pre_buy_pool = self.remove_less_than_one_hand_stocks(data.current_dt, data, context.pre_buy_pool)
            self.buy_stocks(data, context.pre_buy_pool)

            # 卖出拟卖出池股票
            context.pre_sell_pool = self.move_suspend_and_limit_down_non_open_stocks_to_attache_pool(data.current_dt, data,
                                                                                                     context.pre_sell_pool,
                                                                                                     context.pre_sell_attach_pool)
            self.sell_stocks(data.current_dt, data, context.pre_sell_pool)
        except Exception,e:
            print sys._getframe().f_lineno,e
            # self.back_test_failed(e.message)
            raise e
    # 获取策略参数
    def get_strategy(self, strategy_id):
        db = self.mongodb
        return db['Z3_BACKTEST_STRATEGY'].find_one({'_id': strategy_id})

    # 删除停牌、开盘涨停且全天未开板股票
    def remove_suspend_and_limit_up_non_open_stocks(self, date, data, stock_pool):
        for stock in stock_pool.keys():
            name = self.stock_name[stock]
            trade_status, limit_up_non_open = data.current(symbol(stock), ['trade_status', 'limit_up_non_open'])
            # print trade_status, limit_up_non_open
            if trade_status == 2.0 or limit_up_non_open == 1.0:
                self.write_trade_error(date, stock, name, "买入", "下单失败", "停牌或开盘即涨停且全天未开板")
                del stock_pool[stock]
        return stock_pool

    # 删除买入量小于1手的股票
    def remove_less_than_one_hand_stocks(self, current_dt, data, stock_pool):
        for stock in stock_pool.keys():
            value = stock_pool.get(stock, 0)
            if value < 100:
                name = self.stock_name[stock]
                self.write_trade_error(current_dt, stock, name, "买入", "下单失败", "数量不足一手")
                del stock_pool[stock]
        return stock_pool

    # add by h
    def calc_buy_hand(self, sym, data, value):
        buy_price = data.current(sym, str(self.buy_price_type))
        new_price = self.slippage.adjustment_price(sym, data, 1)
        hand = math.floor(0.01 * value / new_price)
        commission = self.commission.calculate_by_amount_price(hand * 100, new_price)
        amount = (hand * new_price * 100) + commission
        while amount > value:
            hand -= 1
            commission = self.commission.calculate_by_amount_price(hand * 100, new_price)
            amount = (hand * new_price * 100) + commission

        return hand

    # 买入股票
    def buy_stocks(self, data, pre_buy_pool):
        for stock in pre_buy_pool.keys():
            sym = symbol(stock)
            value = pre_buy_pool[stock]
            hand = self.calc_buy_hand( sym, data, value)
            # modify by h
            if hand > 0 :
                self.algo_obj.order(sym, hand * 100)
                # print "buy",stock,hand
            else:
                self.write_trade_error(data.current_dt, stock, sym.asset_name, "买入", "下单失败", "数量不足一手")
            del pre_buy_pool[stock]
            # buy_price = data.current(sym, str(self.buy_price_type))
            # hand = math.floor(0.01 * value / buy_price)
            # self.algo_obj.order(sym, hand * 100)
            # self.buy_value = buy_price * 100 * hand
            # self.total_buy_account += buy_price * hand * 100
            # 1.计算 成交价格（滑点）
            # 2.

    # 将停牌、开盘涨停且全天未开板股票移动到拟卖出池附池
    def move_suspend_and_limit_down_non_open_stocks_to_attache_pool(self, date, data, pre_sell_pool,
                                                                    pre_sell_attach_pool):
        for stock in pre_sell_pool.keys():
            value = pre_sell_pool[stock]
            name = self.stock_name[stock]
            trade_status, limit_down_non_open = data.current(symbol(stock), ['trade_status', 'limit_down_non_open'])
            # print trade_status, limit_down_non_open
            if trade_status == 2.0 or limit_down_non_open == 1.0:
                # pre_sell_attach_pool[stock] = value
                pre_sell_attach_pool.append(stock)
                self.write_trade_error(date, stock, name, "卖出", "下单失败", "停牌")
                del pre_sell_pool[stock]
        return pre_sell_pool

    # 卖出股票
    def sell_stocks(self, date, data, pre_sell_pool):
        for stock in pre_sell_pool.keys():
            self.algo_obj.order(symbol(stock), -pre_sell_pool[stock])
            # print "sell",stock,pre_sell_pool[stock]
            del pre_sell_pool[stock]
            #columes = [self.buy_price_type, self.sell_price_type]
            #buy_price, sell_price = data.current(symbol(stock), columes)
            # self.sell_value = sell_price * pre_sell_pool[stock]
            # if sell_price > buy_price:
            #     self.sell_winning_count += 1
            # self.sell_count += 1
            # self.total_sell_account += buy_price * pre_sell_pool[stock]

    # 是否是调仓交易日
    def is_adjustment_day(self, context, data):
        if self.trade_cycle_type == 'day':
            trade_cycle_value_i = int(self.trade_cycle_value)
            size = len(context.recent_trading_days)
            if size == 0:
                context.recent_trading_days.append(data.current_dt)
                return True
            elif size > 0 and size < trade_cycle_value_i:
                context.recent_trading_days.append(data.current_dt)
                return False
            elif size == trade_cycle_value_i:
                context.recent_trading_days = []
                context.recent_trading_days.append(data.current_dt)
                return True
        elif self.trade_cycle_type == 'week':
            trade_cycle_value_i = int(self.trade_cycle_value)
            weekday = data.current_dt.weekday()+1
            if weekday == trade_cycle_value_i:
                return True
            else:
                return False
        elif self.trade_cycle_type == 'month':
            trade_cycle_value_i = int(self.trade_cycle_value)
            year = data.current_dt.year
            month = data.current_dt.month
            firstDay, lastDay = self.get_month_start_and_end(year, month)
            if trade_cycle_value_i == 1:
                if self.datetime_to_int(data.current_dt) == firstDay:
                    return True
                else:
                    return False
            if trade_cycle_value_i == -1:
                if self.datetime_to_int(data.current_dt) == lastDay:
                    return True
                else:
                    return False
        elif self.trade_cycle_type == 'user_defined':
            current_month = data.current_dt.month
            current_day = data.current_dt.day
            days = self.trade_cycle_value.split(",")
            # 这里得改
            while self.last_trade_date< data.current_dt:
                index_date = self.last_trade_date+timedelta(days=1)
                month_day_s = date_to_month_day_str(index_date)
                if month_day_s in self.trade_month_days:
                    return True


            return False

    # 根据选股策略获取股票列表
    def get_stocks_by_strategy_id(self, stock_strategy_id, current_dt):
        stocks = list()
        domain = get_dbus()
        url = "http://" + domain + "/dbus/filter/strategy.shtml?stock_strategy_id=" \
              + stock_strategy_id + "&date=" + current_dt.strftime("%Y-%m-%d")
        req = urllib2.Request(url)
        res_data = urllib2.urlopen(req)
        res = res_data.read()
        # print "filter",res
        json_array = json.loads(res).get("data")
        print "pool length",len(json_array)
        for code in json_array:
            stocks.append(code.get("innerCode"))
        return stocks
        # return ['002024.SZ']

    # 根据股票池id获取股票列表
    def get_stocks_by_pool_id(self, stock_pool_id):
        # debug
        # return ['002024.SZ']

        stocks = list()
        domain = get_dbus()
        url = "http://" + domain + "/dbus/filter/stockpool.shtml?stock_pool_id=" + stock_pool_id
        req = urllib2.Request(url)
        res_data = urllib2.urlopen(req)
        res = res_data.read()
        json_array = json.loads(res).get("data")
        for code in json_array:
            stocks.append(code.get("innerCode"))
        return stocks

    def get_symbols(self,*stocks):
        lefts = []
        ret_syms=[]
        for stk in stocks:
            if self.symbols.has_key(stk):
                ret_syms.append(self.symbols[stk])
            else:
                lefts.append(stk)
        left_list = symbols(*lefts)
        ret_syms.extend(left_list)
        for left in left_list:
            self.symbols[left.symbol]=left
        return ret_syms

    # 根据择时条件获取候选股票池
    def get_candidate_pool_by_condition(self, expression, indexs, data, candidate_pool, stocks):
        syms = self.get_symbols(*stocks)
        sell_indexs = ['GDZY_0', 'GDZS_0', 'GDTS_0', 'DRAWDOWN_0']
        columes = ['ex_open', 'ex_high', 'ex_low', 'ex_close', 'volume']
        max_counts= defaultdict(lambda :0)
        for index in indexs:
            index_func = index['index_func']
            if index_func not in sell_indexs:
                index_params = json.loads(index['index_params'])
                period = index_params['period']
                params_dict = {k: str_to_if(v) for k, v in index_params.items()}
                count = Z3_func_count(index_func, params_dict)
                max_counts[period] = max(max_counts[period],count)
        data_dict = {}
        for key,value in max_counts.items():
            data_dict[key] = self.data_history(syms, columes, value, key, data)

        for stock in stocks:
            sym = symbol(stock)
            # columes = ['open', 'high', 'low', 'close', 'volume']
            # open, high, low, close, volume = data.current(sym, columes)
            # print('open:' + str(open) + ',high:' + str(high) + ',low:' + str(low) + ',close:' + str(close)
            #       + ',volume:' + str(volume))

            if self.eval_con_exp(expression, indexs, sym, data_dict) is True:
                candidate_pool.append(stock)
        return candidate_pool

    # 删除下一个交易日停牌的股票
    def remove_next_day_paused_stocks_from_list(self, data, stocks):
        for stock in stocks:
            sym = symbol(stock)
            columes = ['open', 'close', 'trade_next_status']
            open, close, trade_next_status = data.current(sym, columes)
            # print open, close, trade_next_status
            if trade_next_status == 2.0:
                stocks.remove(stock)
        return stocks

    # 删除下一个交易日停牌的股票
    def remove_next_day_paused_stocks_from_dict(self, data, stock_pool):
        for stock in stock_pool.keys():
            sym = symbol(stock)
            trade_next_status = data.current(sym, 'trade_next_status')
            if trade_next_status == 2.0:
                del stock_pool[stock]
        return stock_pool

    # 删除达到个股持仓上限的股票
    def remove_max_holding_stocks_from_list(self, context, stocks):
        for stock in stocks:
            position = context.portfolio.positions[symbol(stock).sid]
            if position.amount * position.last_sale_price / context.portfolio.portfolio_value < self.stock_max_holding / 100:
                if symbol in stocks:
                    stocks.remove(position.symbol)
        return stocks

    # 删除达到个股持仓上限的股票
    def remove_max_holding_stocks_from_dict(self, context, stock_pool):
        for key, position in context.portfolio.positions.items():
            if position.amount * position.last_sale_price / context.portfolio.portfolio_value < self.stock_max_holding / 100:
                if symbol in stock_pool.keys():
                    del stock_pool[position.symbol]
        return stock_pool

    # 裁剪候选池池到合适大小
    def slice_candidate_pool(self, context, candidate_pool):
        for position in context.portfolio.positions:
            if symbol in candidate_pool:
                candidate_pool.remove(position.symbol)
        add_num = self.max_holding - len(context.portfolio.positions)
        return candidate_pool[0:add_num]

    # 分配买入资金
    def allocate_buy_fund(self, context, data, pre_buy_pool,model_position):
        market_value = self.get_market_value(data,pre_buy_pool, data.current_dt)
        sum_market_value = sum(market_value.values())
        # model_position = self.get_model_position(self.position_model_id, data.current_dt)
        #可分配
        positions_value = self.get_today_position_value(context,data)
        portfolio_value = self.get_portfolio_value(context,data)

        allocate_cash = (portfolio_value*model_position)-positions_value
        for stock in pre_buy_pool:
            current_position = context.portfolio.positions[symbol(stock).sid].amount * context.portfolio.positions[
                symbol(stock).sid].last_sale_price
            if self.fund_allocate == 'fund_value':
                add_position = 1 / len(pre_buy_pool) * allocate_cash
            elif self.fund_allocate == 'market_value':
                add_position = market_value[stock] / sum_market_value * allocate_cash

            if (current_position + add_position)/portfolio_value > self.stock_max_holding/100:
                add_position = self.stock_max_holding * portfolio_value / 100 - current_position

            pre_buy_pool[stock] = add_position
            print "send buy",stock,add_position

    # 分配卖出份额
    def allocate_sell_share(self, context, data, pre_sell_pool, sell_out,model_position):
        if pre_sell_pool is None:
            return
        market_value = self.get_market_value(data,pre_sell_pool, data.current_dt)
        sum_market_value = sum(market_value.values())
        position_value = self.get_today_position_value(context,data)
        portfolio_value = self.get_portfolio_value(context,data)
        if not sell_out:
            to_sell_cash = position_value - portfolio_value * model_position
            if to_sell_cash < 0:
                return
        length = len(pre_sell_pool)
        for stock in pre_sell_pool.keys():
            pos = context.portfolio.positions[symbol(stock).sid]
            if pos is None:
                return
            left_amount = pos.amount

            if sell_out or model_position ==0:
                pre_sell_pool[stock] = left_amount
            else:
                if self.fund_allocate == 'fund_value':
                    short_position = 1 / length * to_sell_cash
                elif self.fund_allocate == 'market_value':
                    short_position = market_value[stock] / sum_market_value * to_sell_cash

                # short_position = to_sell_cash * market_value[stock] / sum_market_value
                # 卖出价格
                new_price = self.slippage.adjustment_price(symbol(stock), data, -1)
                hand = math.floor(0.01 * short_position / new_price)
                hand100 = hand*100
                if hand < 1:
                    # self.write_trade_error(data.current_dt, stock, self.stock_name[stock], "卖出", "下单失败", "数量不足一手")
                    del pre_sell_pool[stock]
                else:
                    if left_amount <= hand100:
                        pre_sell_pool[stock] = left_amount
                    else:
                        if left_amount - hand100 <100:
                            pre_sell_pool[stock] = left_amount
                        else:
                            commission = self.commission.calculate_by_amount_price(-hand100, new_price)
                            amount = (hand100 * new_price) + commission
                            # 循环 直到求出交易手数
                            # 华喜说OK
                            while amount > short_position:
                                hand -= 1
                                if hand==0:
                                    del pre_sell_pool[stock]
                                    continue
                                commission = self.commission.calculate_by_amount_price(-hand*100, new_price)
                                amount = (hand*100 * new_price) + commission
                            pre_sell_pool[stock] = hand*100
            if pre_sell_pool.has_key(stock):
                print "send sell",stock,pre_sell_pool[stock]

    # 获取当前持仓股票代码
    def get_holding_stocks(self, context):
        holding_stocks = []
        for key,position in context.portfolio.positions.items():
            symbol = sid(position.sid).symbol
            if position.amount>0:
                holding_stocks.append(symbol)
        return holding_stocks

    # 发送回测进度消息
    def notify_progress(self, perf):
        perf_json = json.dumps(perf)
        if self.producer is None:
            self.producer = get_kafka_producer()
        self.producer.send("quant_backtest", perf_json)
        self.producer.flush()

    # 保存状态数据并发送通知
    def save_and_notify(self, perf,send = False):
        self.write_result_overview(perf)
        if perf.has_key("progress"):
            self.notify_progress(perf)

    # 计算回测运行时间
    def get_running_time(self):
        return time.clock() - self.clock_time

    # 调用函数计算指标值
    def compute(self, data_series, count, index_name, index_params, operator, comparison_value):
        # ds = barDS(data_frame)
        value = Z3_func_call(index_name, data_series, count, index_params)
        if comparison_value is None or operator is None:
            return value[-1]
        else:
            exp_str = "{0} {1} {2}".format(value[-1], operator, comparison_value)
            return eval(exp_str)

    def data_history(self, syms, columes, count, period, data):
        try:
            data_frames = None
            if period == 'day':
                # if data.current_dt < sym.start_date:
                #     return None
                data_frames={}
                history_bar = data.history(syms, columes, count, '1d')
                for sym in syms:
                    df=history_bar.minor_xs(syms[0])
                    data_frames[sym] = barDS(df)
                pass
            elif period == 'week':
                data_frames = self.get_week_data(syms, columes, count, self.current_dt,data)
            elif period == 'month':
                data_frames = self.get_month_data(syms, columes, count, self.current_dt,data)
            return  data_frames
        except Exception,e:
            return None

    @property
    def mongodb(self):
        if self.mogodb_db:
            return self.mogodb_db
        self.mogodb_db =get_mongodb()
        return self.mogodb_db

    def get_week_data(self, syms, columes, count, date,data):
        db = self.mongodb
        colume_maps = {"ex_open": "ex_open_px",
                       "ex_high": "ex_high_px",
                       "ex_low": "ex_low_px",
                       "ex_close": "ex_close_px"}
        projection = {}
        for k in columes:
            if k in colume_maps.keys():
                projection[colume_maps[k]] = 1
        projection["last_trade_date"] = 1
        from pymongo import DESCENDING
        idate = date_to_n8(date)
        date = datetime(date.year,date.month,date.day)


        data_frames={}

        for sym in syms:
            cursor = db['Z3_STK_MKT_WEEK'].find({"innerCode": sym.symbol, "end_date": {"$lte": idate}},
                                                projection).sort("end_date", DESCENDING).limit(count)
            datas = list(cursor)
            if len(datas) <count-1:
                return None

            last_date = datas[0]["last_trade_date"]

            datas = datas[::-1]

            # 如果今天不是周五 就
            history_bar = data.history(sym, columes, 5, '1d')
            if history_bar is None :
                return None
            length = len(history_bar)
            open = None
            high = None
            low = None
            close = history_bar["ex_close"][-1]
            all_stop = True

            for i in range(len(history_bar))[::-1]:
                volume = history_bar['volume'][i]
                if volume == 0:
                    continue
                trade_date = history_bar.index[i]
                if not is_same_week(trade_date,date):
                    break
                low = history_bar['ex_low'][i] if low is None else min(low,history_bar['ex_low'][i])
                high = history_bar['ex_high'][i] if high is None else max(high,history_bar['ex_high'][i])
                open = history_bar['ex_open'][i]
                all_stop = False

            if last_date==idate or all_stop:
                return pd.DataFrame(datas)


            data_dict = {'ex_open':open,
                         'ex_high':high,
                         'ex_low':low,
                         'ex_close':close}
            datas.append(data_dict)

            data_frames[sym]= barDS(pd.DataFrame(datas))

        return data_frames


        # 取count个
        # 如个数小于 count-1
        #  如果最后一个交易日等于今天
        #  返回
        # 否则
        # 取本周交易日计算ohlc
        # 去头 加本周  返回
        # df = pd.DataFrame()

    def get_month_data(self, syms, columes, count, date,data):
        db = self.mongodb
        colume_maps = {"ex_open": "ex_open_px",
                       "ex_high": "ex_high_px",
                       "ex_low": "ex_low_px",
                       "ex_close": "ex_close_px"}
        projection = {}
        for k in columes:
            if k in colume_maps.keys():
                projection[colume_maps[k]] = 1
        projection["last_trade_date"] = 1
        from pymongo import DESCENDING
        idate = date_to_n8(date)
        date = datetime(date.year,date.month,date.day)
        dataframes={}
        for sym in syms:
            cursor = db['Z3_STK_MKT_MONTH'].find({"innerCode": sym.symbol, "end_date": {"$lte": idate}},
                                                projection).sort("end_date", DESCENDING).limit(count)
            datas = list(cursor)
            if len(datas) <count-1:
                return None

            last_date = datas[0]["last_trade_date"]

            datas = datas[::-1]

            # 如果今天不是周五 就
            history_bar = data.history(sym, columes, 25, '1d')
            if history_bar is None :
                return None
            length = len(history_bar)
            open = None
            high = None
            low = None
            close = history_bar["ex_close"][-1]
            all_stop = True

            for i in range(len(history_bar))[::-1]:
                volume = history_bar['volume'][i]
                if volume == 0:
                    continue
                trade_date = history_bar.index[i]
                if not is_same_month(trade_date,date):
                    break
                low = history_bar['ex_low'][i] if low is None else min(low,history_bar['ex_low'][i])
                high = history_bar['ex_high'][i] if high is None else max(high,history_bar['ex_high'][i])
                open = history_bar['ex_open'][i]
                all_stop = False

            if last_date==idate or all_stop:
                return pd.DataFrame(datas)


            data_dict = {'ex_open':open,
                         'ex_high':high,
                         'ex_low':low,
                         'ex_close':close}
            datas.append(data_dict)
            dataframes[sym]=barDS(pd.DataFrame(datas))
        return dataframes
    def Z3_DRAWDOWN(self):
        pass

    # 备份 计算条件表达式
    # def eval_con_exp(self, con_exp, strategy_index,sym, data):
    #     columes = ['open', 'high', 'low', 'close', 'volume']
    #     order_dict = dict()
    #     value_dict = dict()
    #     for index in strategy_index:
    #         index_name = index['index_name']
    #         page_order = index['page_order']
    #         order_dict[page_order]=index_name
    #         index_params = index['index_params']
    #         period = json.loads(index_params)['period']
    #
    #         sell_index = False
    #
    #         # history_bar = data.history(sym,columes,count,)
    #         # if period == 'day':
    #         #     data_frame = pd.DataFrame(history_bar)
    #         # elif period == 'week':
    #         #     data_frame = self.week_data
    #         # elif period == 'month':
    #         #     data_frame = self.month_data
    #         data_frame = None
    #         operator = index['operator']
    #         comparison_value = index['comparison_value']
    #         value = self.compute(data_frame, index_name, index_params, operator, comparison_value)
    #         value_dict[index_name] = value
    #
    #     tokens = (
    #         'NUMBER',
    #         'AND',
    #         'OR',
    #         'LPAREN',
    #         'RPAREN',
    #     )
    #
    #     def t_NUMBER(t):
    #         r'\d+'
    #         t.value = int(t.value)
    #         return t
    #     t_AND = r'AND'
    #     t_OR = r'OR'
    #     t_LPAREN = r'\('
    #     t_RPAREN = r'\)'
    #     t_ignore = r' \t'
    #     def t_error(t):
    #         print "Illegal character '%s'" % t.value[0]
    #         t.lexer.skip(1)
    #
    #     lexer = lex.lex()
    #     # con_exp = con_exp.replace('#', '')
    #     lexer.input(con_exp)
    #
    #     token_list = []
    #     for token in lexer:
    #         if token.type == 'NUMBER':
    #             # 根据page_order获取indexName
    #             token_list.append(value_dict(order_dict(token.value)))
    #         else:
    #             token_list.append(token.value)
    #     value_str = ' '.join(  )
    #     return eval(value_str)

    # 计算条件表达式


    class symbol_data(object):
        def __init__(self,sym,ds):
            self.sym


    # 1.取大长度
    # 2.取历史长度
    # 3.补齐历史
    # 4.合并当天与历史
    def get_max_count(self, con_exp, strategy_index, sym, data):

        count = 0
        #ds 缓存


    def eval_con_exp(self, con_exp, strategy_index, sym, data_dict):
        #先算出最大取数据量
        # 所有指标用一个DS
        columes = ['ex_open', 'ex_high', 'ex_low', 'ex_close', 'volume']
        sell_indexs = ['GDZY_0', 'GDZS_0', 'GDTS_0', 'DRAWDOWN_0']

        # order_dict = dict()
        value_dict = dict()
        for index in strategy_index:
            index_func = index['index_func']
            page_order = int(index['page_order'])
            # order_dict[page_order]=index_name
            index_params = json.loads(index['index_params'])
            period = index_params['period']
            del index_params['period']
            params_dict = {k: str_to_if(v) for k, v in index_params.items()}
            operator = None
            if index.has_key('operator'):
                operator = index['operator']
            comparison_value = None
            if index.has_key('comparison_value'):
                comparison_value = index['comparison_value']
            if index_func in sell_indexs:
                value_dict[page_order] = False
                if not self.position_ex.has_key(sym.sid):
                    continue
                comparison_value_f = float(comparison_value)
                try:
                    pos_ex = self.position_ex[sym.sid]
                    if index_func == "GDZY_0":
                        returns = pos_ex.returns
                        if returns >= comparison_value_f:
                            value_dict[page_order] = True
                    elif index_func == "GDZS_0":
                        returns = pos_ex.returns
                        if returns <= comparison_value_f:
                            value_dict[page_order] = True
                    elif index_func == "GDTS_0":
                        # 交易日 还是自然日  还是平均的
                        # 北京时间2017 06 28 18:48华喜在吃晚饭时说 用交易日 并且以后再也不改了
                        hold_days = pos_ex.hold_days
                        if hold_days >= comparison_value_f:
                            value_dict[page_order] = True

                    elif index_func == "DRAWDOWN_0":
                        draw_down = pos_ex.draw_down
                        if draw_down >= comparison_value_f:
                            value_dict[page_order] = True
                except Exception, e:
                    print sys._getframe().f_lineno,sym.asset_name,e
                    value_dict[page_order] = False

            else:
                try:
                    count = Z3_func_count(index_func, params_dict)
                    data_series = data_dict[period][sym]
                    if data_series is None or len(data_series) < count:
                        value_dict[page_order] = False
                    else:
                        value = self.compute(data_series, count, index_func, params_dict, operator, comparison_value)
                        value_dict[page_order] = value
                except Exception, e:
                    print sys._getframe().f_lineno,index_func,e
                    value_dict[page_order] = False
        # 倒序
        con_exp = con_exp.lower()
        import collections
        d_value_dict = collections.OrderedDict(sorted(value_dict.items(), reverse=True))
        for k, v in d_value_dict.items():
            con_exp = con_exp.replace(str(k), str(v))
        for i in range(10):
            str_i = str(i)
            assert str_i not in con_exp

        ret = eval(con_exp)
        return ret

    # 获取仓位模型
    def get_model_position(self, model_id, current_dt):
        if model_id == '1001':
            return 1
        else:
            db = self.mongodb
            record = db['Z3_POSITION'].find_one({'pm_id': int(model_id), 'trade_date': self.datetime_to_int(current_dt)})
            return record.get("pm_position")/100

    # 获取已达个股最大仓位的股票
    def get_max_holding_stocks(self, context, stocks):
        max_holding_stocks = []
        for stock in stocks:
            sym = symbol(stock)
            if context.portfolio.positions[sym.sid].amount * context.portfolio.positions[
                sym.sid].last_sale_price / context.portfolio.portfolio_value >= self.max_holding:
                max_holding_stocks.append(stock)
        return max_holding_stocks

    # 获取股票市值
    def get_market_value(self,data, stocks, date):
        market_value_dict = dict()
        db = self.mongodb
        for stock in stocks:
            sym = symbol(stock)
            market_value_dict[stock] = data.current(sym,'mtkcap_a')
            # record = db['Z3_EQUITY_HISTORY'].find_one({'innerCode': stock, 'trade_date': datetime(date.year, date.month, date.day)})
            # market_value_dict[stock] = record.get("mkt_idx").get("mktcap_a")
        return market_value_dict

    # 卖出退市股票
    def sell_delist_stocks(self, context, data):
        for position in context.portfolio.positions:
            columes = [str(self.sell_price_type), 'trade_status']
            sell_price, trade_status = data.current(position, columes)
            if trade_status == 0.0:
                self.algo_obj.order_target(position, 0)

    # 计算年化收益
    def get_annual_return(self, total_return, n):
        return (math.pow(1 + total_return, 250 / n) - 1)

    # 计算胜率
    def get_win_ratio(self):
        if self.sell_count == 0:
            return 0
        else:
            return self.sell_winning_count*1.0 / self.sell_count

    # 计算换手率
    def get_turnover(self):
        portfolio_list = self.daily_portfolio.values()
        if len(portfolio_list) == 0:
            return 0
        if sum(portfolio_list)== 0:
            return 0
        avg_portfolio = (sum(portfolio_list) / len(portfolio_list))

        return min(self.total_buy_account, self.total_sell_account) / avg_portfolio

    # 记录策略参数
    def write_strategy_info(self, strategy_id, init_fund, backtest_start_date, backtest_end_date):
        db = self.mongodb
        db['Z3_BACKTEST'].delete_one({'strategy_id': strategy_id})
        db['Z3_BACKTEST'].insert({'strategy_id': strategy_id,
                                  'init_fund': init_fund,
                                  'backtest_start_date': backtest_start_date,
                                  'backtest_end_date': backtest_end_date,
                                  'backtest_result_overview_detail': [],
                                  'backtest_trade_detail': [],
                                  'backtest_daily_position_detail': []})








    # 格式化日期，时间戳转换为整形
    def datetime_to_int(self, datetime):
        return int(datetime.strftime("%Y%m%d"))

    # 获取指定月份的月初和月末
    def get_month_start_and_end(self, year, month):
        if month != 1:
            if month <= 10:
                pre_month_end = int(str(year) + "0" + str(month - 1) + "31")
            else:
                pre_month_end = int(str(year) + str(month - 1) + "31")
        else:
            pre_month_end = int(str(year - 1) + "1231")
        if month != 12:
            if month < 9:
                next_month_start = int(str(year) + "0" + str(month + 1) + "01")
            else:
                next_month_start = int(str(year) + str(month + 1) + "01")
        else:
            next_month_start = int(str(year + 1) + "0101")

        db = self.mongodb
        cursor = db['Z3_EXCHANGE_CALENDAR'].find(
            {'trade_date': {'$gt': pre_month_end, '$lt': next_month_start},
             'exchange': 'SZ'},projection={
                'trade_date': 1,
                '_id': 0
            }).sort([('trade_date', pymongo.ASCENDING)])
        df = pd.DataFrame(list(cursor))
        df = df['trade_date']
        values = df.values
        return min(values), max(values)


        # 计算近期指标表现

    def compute_recent_performance(self, algorithm_returns, benchmark_returns, recent_days, perf):
        algorithm_returns = algorithm_returns[-recent_days:]
        benchmark_returns = benchmark_returns[-recent_days:]
        # 年化收益率
        annual_algorithm_return = annual_return(algorithm_returns, annualization=250)
        annual_benchmark_return = annual_return(benchmark_returns, annualization=250)
        beta = beta_aligned(algorithm_returns, benchmark_returns)
        alpha = self.get_alpha(annual_algorithm_return, annual_benchmark_return, risk_free=self.risk_free_ratio, beta=beta)
        perf['alpha_' + str(recent_days)] = self.check_for_null(alpha)
        perf['beta_' + str(recent_days)] = self.check_for_null(beta)

        volatility,sharp = self.calc_volatility_sharp(algorithm_returns,annual_algorithm_return)
        perf['information_' + str(recent_days)] = self.check_for_null(self.calc_information(algorithm_returns,benchmark_returns,annual_algorithm_return,annual_benchmark_return))
        perf['sharpe_' + str(recent_days)] = self.check_for_null(sharp)
        perf['algo_volatility_' + str(recent_days)] = self.check_for_null(volatility)
        perf['max_drawdown_' + str(recent_days)] = self.check_for_null(max_drawdown(algorithm_returns))

    # 非空校验
    def check_for_null(self, value):
        if value == None:
            return 0
        else:
            return float(value)

    def calc_daily(self,perf,my_perf):
        if perf is None or not perf.has_key("daily_perf"):
            return False
        daily_perf = perf["daily_perf"]
        transactions = daily_perf["transactions"]
        my_perf['profit'] = daily_perf['pnl']
        my_perf['portfolio'] = daily_perf['portfolio_value']
        my_perf['cash'] = daily_perf['ending_cash']

        # print "my_perf['portfolio']",my_perf['portfolio']
        # print "my_perf['cash']",my_perf['cash']
        self.daily_portfolio[self.current_dt] = daily_perf['portfolio_value']
        #以下顺序不可变
        # 1.计算买卖
        self.calc_daily_buy_sell(transactions)
        # 2.更新扩展持仓
        self.calc_daily_position(transactions)

        return True

    def calc_dividend_posision(self):
        # 计算现金分红后 持仓成本
        tracker = self.algo_obj.perf_tracker
        next_session = tracker._current_session
        if (next_session is None) or (next_session >= tracker.last_close) or self.last_dividens == next_session:
            return
        self.last_dividens = next_session
        adjustment_reader=self.algo_obj.data_portal._adjustment_reader
        if adjustment_reader is None:
            return
        # position_tracker = self.algo_obj.position_tracker
        held_sids = set(tracker.position_tracker.positions)
        if len(held_sids)>0:
            cash_dividends = adjustment_reader.get_dividends_with_ex_date(
                held_sids,
                next_session,
                self.algo_obj.asset_finder
            )
            for dividend in cash_dividends:
                if self.position_ex.has_key(dividend.asset.sid):
                    pos_ex = self.position_ex[dividend.asset.sid]
                    pos_ex.dividend(dividend.amount)

            stock_dividends = adjustment_reader. \
                get_stock_dividends_with_ex_date(
                held_sids,
                next_session,
                self.algo_obj.asset_finder
            )
            for stock_dividend in stock_dividends:
                sym = stock_dividend.asset
                if self.position_ex.has_key(dividend.asset.sid):
                    pos_ex = self.position_ex[dividend.asset.sid]
                    pos = tracker.position_tracker.positions[dividend.asset.sid]
                    pos_ex.dividend_stock(pos.amount)
                if self.algo_obj.pre_sell_pool and sym.symbol in self.algo_obj.pre_sell_pool:
                    self.algo_obj.pre_sell_pool[sym.symbol] *= (1+stock_dividend.ratio)




    def calc_daily_buy_sell(self,transactions):
        self.sell_value = 0
        self.buy_value = 0
        for tx in transactions:
            amount = tx['amount']
            price = tx['price']
            asset= tx["sid"]
            #计算手续费
            tx['commission'] = self.commission.calculate_by_amount_price(amount,price)
            value = abs(amount*price)
            if amount >0:
                #买
                print "buy",asset.symbol,amount,price
                self.buy_value += value
                self.total_buy_account += value

            elif amount<0:
                # 卖出处理
                print "sell",asset.symbol,amount,price
                self.sell_value += value
                self.total_sell_account += value
                sid = asset.sid
                if self.position_ex.has_key(sid):
                    pos_ex = self.position_ex[sid]
                    reference_cost = pos_ex.reference_cost
                    if price > reference_cost:
                        self.sell_winning_count += 1
                    self.sell_count += 1
                    # 不考虑持仓成本为负 因为太大没法算
                    if reference_cost>0:
                        profit = (price-reference_cost)/reference_cost
                        self.sell_profit.append(profit)
                pass
        pass



    def calc_daily_position(self, transactions):
        # 计算持仓成本
        # 当日交易
        portfolio = self.algo_obj.portfolio
        positions = portfolio.positions
        values = {}
        # 更新持仓
        self.position_ex.update(transactions, positions, self.current_dt,self.buy_price_type,self.sell_price_type)
        pass

    def get_alpha(self, annual_returns, annual_benchmark_returns, risk_free=0.0, beta=None):
        return annual_returns - (risk_free + beta * (annual_benchmark_returns - risk_free))

        # 记录每日持仓
    def write_daily_position_detail(self, context, data,my_perf):
        wirte_list = []
        holding_stocks = self.get_holding_stocks(context)
        for stock in holding_stocks:
            position_dict = dict()
            pos_ex = self.position_ex[symbol(stock).sid]
            pos = context.portfolio.positions[symbol(stock).sid]
            position_dict['backtest_date'] = self.datetime_to_int(data.current_dt)
            position_dict['portfolio_value'] = my_perf['portfolio']
            position_dict['cash'] = my_perf['cash']


            position_dict['inner_code'] = stock
            name = self.stock_name[stock]
            #close = data.current(symbol(stock), 'close')
            position_dict['name'] = name
            position_dict['market_price'] = pos.last_sale_price
            position_dict['hold_volume'] = pos_ex.amount
            position_dict['market_value'] = pos.last_sale_price * pos_ex.amount

            # position_dict['cost_price'] = context.portfolio.positions[symbol(stock)].cost_basis
            # position_dict['profit_loss_amount'] = (close - context.portfolio.positions[symbol(stock)].cost_basis) * \
            #                                       context.portfolio.positions[symbol(stock)].amount
            # cost_basis = context.portfolio.positions[symbol(stock)].cost_basis
            # if cost_basis == 0:
            #     position_dict['profit_loss_ratio'] = 0
            # else:
            #     position_dict['profit_loss_ratio'] = (close - context.portfolio.positions[symbol(stock)].cost_basis) / \
            #                                          context.portfolio.positions[symbol(stock)].cost_basis

            # modify by h
            # 参考成本
            position_dict['cost_price'] = pos_ex.reference_cost
            # 参考盈亏
            position_dict['profit_loss_amount'] = pos_ex.profit
            # 盈亏比例
            position_dict['profit_loss_ratio'] = pos_ex.returns
            # print stock,pos_ex.reference_cost,pos_ex.profit,pos_ex.returns
            # print "position_dict",position_dict,pos_ex.reference_cost
            wirte_list.append(position_dict)

        if wirte_list:
            self.backtest_daily_position_detail_cache.extend(wirte_list)




    # 记录统计概况
    def write_result_overview(self, perf):
        # db = self.mongodb
        # result_overview_detail = db['Z3_BACKTEST'].find_one({'strategy_id': self.strategy_id}).get(
        #     'backtest_result_overview_detail')
        # if len(result_overview_detail) == 0:
        # modify by h
        # result_overview_detail = list()
        # result_overview_detail.append(perf)
        self.backtest_status_cache = perf.get("status")
        self.backtest_result_overview_detail_cache.append(perf)


    # 记录交易详情
    def write_trade_detail(self, transactions):
        backtest_trade_detail = []
        for transaction in transactions:
            trade_dict = dict()
            trade_dict['backtest_date'] = self.datetime_to_int(transaction.get("dt"))
            innerCode = transaction.get("sid").symbol
            trade_dict['inner_code'] = innerCode
            trade_dict['name'] = self.stock_name[innerCode]
            amount = transaction.get("amount")
            if amount < 0:
                trade_dict['buy_sell_type'] = "卖出"
            else:
                trade_dict['buy_sell_type'] = "买入"
            price = transaction.get("price")
            trade_dict['price'] = price
            trade_dict['amount'] = abs(amount)
            trade_dict['quantity'] = abs(price * amount)

            trade_dict['commission'] = self.commission.calculate_by_amount_price_no_tax(amount, price)

            trade_dict['status'] = "交易成功"

            backtest_trade_detail.append(trade_dict)

        db = self.mongodb
        # backtest_trade_detail = db['Z3_BACKTEST'].find_one({'strategy_id': self.strategy_id}).get(
        #     "backtest_trade_detail")
        # if backtest_trade_detail is None:
        if backtest_trade_detail:
            self.backtest_trade_detail_cache.extend(backtest_trade_detail)

    # 记录交易异常
    def write_trade_error(self, current_dt, code, name, buy_sell_type, status, log=None):
        trade_dict = dict()
        trade_dict['backtest_date'] = self.datetime_to_int(current_dt)
        trade_dict['inner_code'] = code
        trade_dict['name'] = name
        trade_dict['buy_sell_type'] = buy_sell_type
        trade_dict['status'] = status
        trade_dict['log'] = log


        self.backtest_trade_detail_cache.append(trade_dict)




    #一个月最后一天 或 回测结束 添加
    def calc_and_write_month_data(self,currend_month,my_perf_portfolio,idx_return,force = False):
        # 如果
        last_month = self.month_end_value.values()[-1]
        self.month_end_value[currend_month]=my_perf_portfolio

        if self.month_idx_portfolio.has_key(currend_month):
            ratio = self.month_idx_portfolio[currend_month]
            self.month_idx_portfolio[currend_month] = ratio*(1+idx_return)
        else:
            self.month_idx_portfolio[currend_month] = 1+idx_return

        month_list = []

        if last_month!=currend_month or force:
            self.month_profit_cache=[]
            month=[]
            month_profit=[]
            month_idx_profit=[]
            last_value=0
            for key,value in self.month_end_value.items():
                if key==0:
                    pass
                else:
                    pnl = value-last_value
                    if last_value:
                        month_profit.append(pnl/last_value)
                    else:
                        month_profit.append(0)
                    str_month = str(key)
                    month.append(str_month[:4]+'.'+str_month[4:])
                    month_idx_profit.append(self.month_idx_portfolio[key])
                    pass
                last_value = value

            self.month_profit_cache.append(month)
            self.month_profit_cache.append(month_profit)
            self.month_profit_cache.append(month_idx_profit)



    def calc_profit_merge(self):
        self.sell_profit_40_cache=[]
        index_group = [0 for _ in range(40)]
        profit_group = [0 for _ in range(40)]
        if self.sell_profit:
            length = len(self.sell_profit)
            max_profit = max(self.sell_profit)
            min_profit = min(self.sell_profit)
            x = max_profit - min_profit
            for i in range(40):
                if x >=0.004:
                    value =min_profit+(i/39)*(x)
                else:
                    value = min_profit+ i*0.0001
                profit_group[i]=value

            #确定索引
            for profit in self.sell_profit:
                xs = map(lambda x:abs(x-profit),profit_group)
                index = xs.index(min(xs))
                index_group[index]+=1

        self.sell_profit_40_cache.append(profit_group)
        self.sell_profit_40_cache.append(index_group)





        pass


    def write_to_db(self):




        db = self.mongodb

        # 每日必写

        db['Z3_BACKTEST'].update({'strategy_id': self.strategy_id},
                                 {"$push": {'backtest_result_overview_detail': {"$each":self.backtest_result_overview_detail_cache }},
                                  "$set":{'backtest_status': self.backtest_status_cache,
                                          'month_profit':self.month_profit_cache,
                                          'sell_profit_40': self.sell_profit_40_cache},
                                  })
        self.backtest_result_overview_detail_cache=[]
        # db['Z3_BACKTEST'].update_one({'strategy_id': self.strategy_id},{'$set':{'month_profit':self.month_profit_cache}})
        #
        #
        # db['Z3_BACKTEST'].update_one({'strategy_id': self.strategy_id},
        #                              {"$set": {'sell_profit_40': self.sell_profit_40_cache}})



        if self.backtest_trade_detail_cache:
            db['Z3_BACKTEST'].update({'strategy_id': self.strategy_id},
                                     {"$push": {'backtest_trade_detail': {"$each":self.backtest_trade_detail_cache}}})
            self.backtest_trade_detail_cache=[]

        if self.backtest_daily_position_detail_cache:
            db['Z3_BACKTEST'].update({'strategy_id': self.strategy_id},
                                 {"$push": {'backtest_daily_position_detail':{"$each":self.backtest_daily_position_detail_cache} }})
            self.backtest_daily_position_detail_cache=[]


        pass