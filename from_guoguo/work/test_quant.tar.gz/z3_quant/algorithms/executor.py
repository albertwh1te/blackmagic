
import multiprocessing
import os
from multiprocessing import Process
import threading
import time

from multiprocessing.pool import ThreadPool


class StatObject(object):
    def __init__(self):
        self.stopped = False

    def stop(self):
        self.stopped = True

    def work(self):
        while True:
            if self.stopped:
                print("haha stop")
                break

            print(id(self))
            print("i am working")
            time.sleep(3)


class SimpleThread(threading.Thread):
    def run(self):
        while True:
            print("thread name {}".format(self.name))
            time.sleep(10)


def task(stat):
    print(id(stat))
    stat.work()


def hello(x):
    s = SimpleThread()
    s.name = x
    s.start()


def stop(stat):
    print(id(stat))
    stat.stop()


if __name__ == "__main__":
    pool = ThreadPool(3)
    stat = StatObject()
    pool.apply_async(task, args=(stat, ))
    time.sleep(10)
    print(stat.stopped)
    pool.apply_async(stop, args=(stat,))
    print(stat.stopped)
    pool.close()
    pool.join()

