# -*- coding:utf-8 -*-
# __author__=qiang.fu
from __future__ import division


import logbook
import pandas as pd
import pymongo
from zipline.utils.calendars import get_calendar, register_calendar
from china_calendar import ChinaCalendar
import datetime
logger = logbook.Logger('Loader')

def load_benchmark_data(trading_day=None, trading_days=None, bm_symbol='000001'):
    """
    Load benchmark returns and treasury yield curves for the given calendar and
    benchmark symbol.

    Benchmarks are downloaded as a Series from Yahoo Finance.  Treasury curves
    are US Treasury Bond rates and are downloaded from 'www.federalreserve.gov'
    by default.  For Canadian exchanges, a loader for Canadian bonds from the
    Bank of Canada is also available.

    Results downloaded from the internet are cached in
    ~/.zipline/data. Subsequent loads will attempt to read from the cached
    files before falling back to redownload.

    Parameters
    ----------
    trading_day : pandas.CustomBusinessDay, optional
        A trading_day used to determine the latest day for which we
        expect to have data.  Defaults to an NYSE trading day.
    trading_days : pd.DatetimeIndex, optional
        A calendar of trading days.  Also used for determining what cached
        dates we should expect to have cached. Defaults to the NYSE calendar.
    bm_symbol : str, optional
        Symbol for the benchmark index to load.  Defaults to '^GSPC', the Yahoo
        ticker for the S&P 500.

    Returns
    -------
    (benchmark_returns, treasury_curves) : (pd.Series, pd.DataFrame)

    Notes
    -----

    Both return values are DatetimeIndexed with values dated to midnight in UTC
    of each stored date.  The columns of `treasury_curves` are:

    '1month', '3month', '6month',
    '1year','2year','3year','5year','7year','10year','20year','30year'
    """
    if trading_day is None:
        trading_day = get_calendar('China').trading_day
    # print 'trading_day', trading_day
    if trading_days is None:
        trading_days = get_calendar('China').all_sessions

    first_date = trading_days[0]
    # print 'first_date', first_date
    last_date = trading_days[-1]
    # print 'last_date', last_date
    now = pd.Timestamp.utcnow()
    # print 'now', now
    br = ensure_benchmark_data(
        bm_symbol,
        first_date,
        last_date,
        now,
        # We need the trading_day to figure out the close prior to the first
        # date so that we can compute returns for the first date.
        trading_day,
    )

    # tc = ensure_treasury_data(
    #     bm_symbol,
    #     first_date,
    #     last_date,
    #     now,
    # )
    benchmark_returns = br[br.index.slice_indexer(first_date, last_date)]

    # print "benchmark_returns",benchmark_returns
    # print "benchmark_prices",benchmark_returns['indx_price']
    # treasury_curves = tc[tc.index.slice_indexer(first_date, last_date)]
    treasury_curves = pd.DataFrame(
        index=trading_days,
        columns=['Time Period','1month','3month', '6month','1year','2year', '3year', '5year', '7year', '10year', '20year', '30year',]
    )
    # print benchmark_returns
    # print treasury_curves
    return benchmark_returns['indx_chng'], treasury_curves

def ensure_benchmark_data(symbol, first_date, last_date, now, trading_day):
    """
    Ensure we have benchmark data for `symbol` from `first_date` to `last_date`

    """
    first_date_int = int(first_date.strftime('%Y%m%d'))
    last_date_int = int(last_date.strftime('%Y%m%d'))
    from quant_dao import get_mongodb
    db = get_mongodb()
    cursor = db['Z3_INDEX_HIS_QUOTE'].find(
        {'symbol': symbol,
         'trade_date': {'$gte': first_date_int, '$lte': last_date_int}},
        projection={
            'trade_date': 1,
            'indx_price':1,
            '_id': 0
         }).sort([('trade_date', pymongo.ASCENDING)])
    df = pd.DataFrame(list(cursor))
    list_date = []
    # 数据源字段为int32类型，转为datetime类型
    for i in df['trade_date']:
        list_date.append(datetime.datetime.strptime(str(i), '%Y%m%d'))
    list_chng = []
    pre_data = df['indx_price'][0]
    for price in df['indx_price']:
        if pre_data:
            list_chng.append((price-pre_data)/pre_data)
        else:
            list_chng.append(0)
        pre_data = price

    df['indx_chng'] = pd.Series(list_chng)#df['indx_chng']/100
    df['trade_date'] = pd.Series(list_date)
    df.drop('indx_price',axis=1, inplace=True)
    df.set_index('trade_date', inplace=True)
    # print "基准数据："
    # print df
    return df

if __name__ == '__main__':
    print 'start main function...'
    # list_int = [20050104, 20050105]
    # print datetime.datetime.strptime('20050104', '%Y%m%d')
    register_calendar("China", ChinaCalendar(), force=True)
    load_benchmark_data()
# def ensure_treasury_data(bm_symbol, first_date, last_date, now):
#     """
#     Ensure we have treasury data from treasury module associated with
#     `bm_symbol`.
#
#     """
#     from datetime import datetime
#     dates = [datetime(2016,1,1), datetime(2016,1,2), datetime(2016,1,3), datetime(2016,1,4), datetime(2016,1,5),]
#     return pd.Series([int('2.00%'), int('2.25%'), int('2.50%'), int('2.75%'), int('3.00%')], index=dates)