# -*- coding:utf-8 -*-
# __author__=yuliang.liu
'''
交易模拟请求
'''
from pymongo import MongoClient, ReadPreference
import urllib2
import time
from datetime import datetime
import sys
from bson.objectid import ObjectId

db_name = 'z3dbus'
username = 'z3dbusadmin'
password = 'z3dbusadmin'
run_env = None

# 设置开发环境
def setup_run_env(env):
    global run_env
    run_env = env

global_db = None

def clear_mongodb():
    global global_db
    if global_db is not None:
        global_db.logout()
        global_db = None
# 获取mongodb地址
def get_mongodb():
    # print "get_mongodb",run_env
    global global_db

    if global_db is None:
        if run_env is None or run_env == 'dev':
            client = MongoClient([u'10.77.4.37:27017',u'10.77.4.38:27017',u'10.77.4.39:27017'])
        elif run_env == 'test':
            client = MongoClient([u'10.77.4.37:27017',u'10.77.4.38:27017',u'10.77.4.39:27017'])
        elif run_env == 'pro':
            client = MongoClient([u'10.77.4.45:27017', u'10.77.4.46:27017',u'10.77.4.47:27017'])
        global_db = client[db_name]
        global_db.authenticate(username, password)
    return global_db

# 获取过滤器地址
def get_dbus():
    # print "get_dbus",run_env
    if run_env is None or run_env == 'dev':
        return '127.0.0.1:5000'
    elif run_env == 'test':
        return '10.77.4.23'
        #return '10.77.4.77'
    elif run_env == 'pro':
        #return 'www.z3quant.com'
        #return '10.77.4.42:5001'
        return '10.77.99.5'

# 根据策略id和策略类型拼模拟交易请求
def trade_simulate_request(strategy_id, strategy_type, current_dt):
    domain = get_dbus()
    try:
        url = "http://" + domain + "/start_back_test?backtest_id=" \
              + str(strategy_id) + "&strategy_id="+str(strategy_id) + "&type="+str(strategy_type)
        print 'trade_simulate_request url:',url,'current_dt:',current_dt
        req = urllib2.Request(url)
        res_data = urllib2.urlopen(req)
        res = res_data.read()
    except Exception,e:
        print(e)

# 根据策略类型获取策略id发起模拟交易请求
def trade_simulate(strategy_type=2,sleep_times=30):
    #print 'strategy_type:',strategy_type
    db = get_mongodb()
    BACKTEST_STRATEGY_TBNAME = 'Z3_BACKTEST_STRATEGY_SIMULATE'
    if strategy_type == 1:
        BACKTEST_STRATEGY_TBNAME = 'Z3_BACKTEST_STRATEGY'
    elif strategy_type == 2:
        BACKTEST_STRATEGY_TBNAME = 'Z3_BACKTEST_STRATEGY_SIMULATE'
    elif strategy_type == 3:
        BACKTEST_STRATEGY_TBNAME = 'Z3_BACKTEST_STRATEGY_GOLD'
    cursor = db[BACKTEST_STRATEGY_TBNAME].find( {},projection = {
        '_id': 1,
        'name': 1,
    })
    if cursor.count()>0:
        for item in list(cursor):
            strategy_id =item['_id']
            current_dt = datetime.strftime(datetime.now(), '%Y-%m-%d %H:%M:%S')
            print current_dt, strategy_id
            trade_simulate_request(strategy_id, strategy_type, current_dt)
            time.sleep(sleep_times) #secondss

# 当日失败重试一次，失败状态的策略id重新发起模拟交易请求
def trade_simulate_again(strategy_type=2,sleep_times=30):
    #print 'strategy_type:',strategy_type
    db = get_mongodb()
    BACKTEST_TBNAME = 'Z3_BACKTEST_SIMULATE'
    if strategy_type == 1:
        BACKTEST_TBNAME = 'Z3_BACKTEST'
    elif strategy_type == 2:
        BACKTEST_TBNAME = 'Z3_BACKTEST_SIMULATE'
    elif strategy_type == 3:
        BACKTEST_TBNAME = 'Z3_BACKTEST_GOLD'
    cursor = db[BACKTEST_TBNAME].find( {'backtest_status':3},projection = {
        'strategy_id': 1
    })
    if cursor.count()>0:
        for item in list(cursor):
            strategy_id =item['strategy_id']
            current_dt = datetime.strftime(datetime.now(), '%Y-%m-%d %H:%M:%S')
            print current_dt, strategy_id
            trade_simulate_request(strategy_id, strategy_type, current_dt)
            time.sleep(sleep_times) #secondss

# 同步金牌策略数据
def sync_gold_strategy_data():
    #print 'strategy_type:',strategy_type
    '''同步金牌策略数据，原始金牌策略表Z3_BACKTEST_STRATEGY_GOLD数据删除，
    金牌模拟交易结果表同步Z3_BACKTEST_STRATEGY_GOLD_RESULT、Z3_BACKTEST_GOLD删除更新'''
    db = get_mongodb()
    src_stragetyids = []
    BACKTEST_STRATEGY_TBNAME = 'Z3_BACKTEST_STRATEGY_GOLD'
    cursor = db[BACKTEST_STRATEGY_TBNAME].find({}, projection={
        '_id': 1,
    })
    if cursor.count() > 0:
        for item in list(cursor):
            src_stragetyids.append(item['_id'])
    #print src_stragetyids
    cursor.close()

    sync_stragetyids = []
    BACKTEST_TBNAME = 'Z3_BACKTEST_GOLD'
    cursor = db[BACKTEST_TBNAME].find( {},projection = {
        '_id': 1
    })
    if cursor.count()>0:
        for item in list(cursor):
            #print 'itme:',item
            strategy_id =item['_id']
            if strategy_id not in src_stragetyids:
                #print 'not in id:',strategy_id
                sync_stragetyids.append(strategy_id)
    cursor.close()

    #print sync_stragetyids
    for item in sync_stragetyids:
        strategy_id =item
        #print '{_id,',strategy_id,'}'
        db['Z3_BACKTEST_STRATEGY_GOLD_RESULT'].remove({'_id':ObjectId(strategy_id)})
        db['Z3_BACKTEST_GOLD'].remove({'_id': ObjectId(strategy_id)})
        db['Z3_BACKTEST_DAILY_SIGNAL_DETAIL'].remove({'_id': ObjectId(strategy_id)})

if __name__ == '__main__':
    run_env = None
    if len(sys.argv) > 1:
        run_env = sys.argv[1]
    setup_run_env(run_env)
    trade_simulate(2,10)
    # 先同步金牌策略数据后再模拟请求
    sync_gold_strategy_data()
    trade_simulate(3,30)
    #当日重试
    trade_simulate_again(2,10)
    trade_simulate_again(3,30)
