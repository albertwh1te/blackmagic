# -*- coding:utf-8 -*-
# h
# 2017-07-25 13:40

import os
# os.open("kill -9 $(ps -aux | grep quant_web.py | awk '{print $2}')")

import psutil
pids = psutil.pids()
kill_pids = []
for pid in pids:
    try:
        p = psutil.Process(pid)
        print p.cmdline()
        if "/data/App/z3quant.jrj.local/quant_web.py" in p.cmdline():
            kill_pids.append(p.pid)
    except :
        pass

for kill_id in kill_pids:
    print "kill", p.pid
    os.kill(kill_id,9)