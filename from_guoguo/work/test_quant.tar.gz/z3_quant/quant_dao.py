# -*- coding:utf-8 -*-
# __author__=qiang.fu

from pymongo import MongoClient, ReadPreference
from kafka import KafkaProducer, KafkaConsumer

db_name = 'z3dbus'
username = 'z3dbusadmin'
password = 'z3dbusadmin'
run_env = None

# 设置开发环境
def setup_run_env(env):
    global run_env
    run_env = env

global_db = None

def clear_mongodb():
    global global_db
    if global_db is not None:
        global_db.logout()
        global_db = None
# 获取mongodb地址
def get_mongodb():
    # print "get_mongodb",run_env
    global global_db

    if global_db is None:
        if run_env is None or run_env == 'dev':
            client = MongoClient([u'10.77.4.37:27017',u'10.77.4.38:27017',u'10.77.4.39:27017'])
        elif run_env == 'test':
            client = MongoClient([u'10.77.4.37:27017',u'10.77.4.38:27017',u'10.77.4.39:27017'])
        elif run_env == 'pro':
            client = MongoClient([u'10.77.4.45:27017', u'10.77.4.46:27017',u'10.77.4.47:27017'])
        global_db = client[db_name]
        global_db.authenticate(username, password)
    return global_db

global_kafka = None

# 获取kafka地址
def get_kafka_producer():
    global global_kafka
    print "get_kafka_producer",run_env
    if global_kafka is None:
        if run_env is None or run_env == 'dev':
            global_kafka =  KafkaProducer(bootstrap_servers='10.77.4.27:9092,10.77.4.28:9092,10.77.4.29:9092')
        elif run_env == 'test':
            global_kafka =  KafkaProducer(bootstrap_servers='10.77.4.27:9092,10.77.4.28:9092,10.77.4.29:9092')
        elif run_env == 'pro':
            global_kafka =  KafkaProducer(bootstrap_servers='10.77.4.57:9092,10.77.4.58:9092,10.77.4.59:9092')
    return global_kafka

# 获取过滤器地址
def get_dbus():
    # print "get_dbus",run_env
    if run_env is None or run_env == 'dev':
        return '139.219.194.107'
    elif run_env == 'test':
        return '10.77.4.23'
    elif run_env == 'pro':
        return 'www.z3quant.com'


global_kafka_consumer = None
# kafka consumer
def get_kafka_consumer(topic):
    global global_kafka_consumer
    topics = (topic)
    if global_kafka_consumer is None:
        if run_env is None or run_env == 'dev':
            global_kafka_consumer = KafkaConsumer(topics, bootstrap_servers='10.77.4.27:9092,10.77.4.28:9092,10.77.4.29:9092')
        elif run_env == 'test':
            global_kafka_consumer = KafkaConsumer(topics, bootstrap_servers='10.77.4.27:9092,10.77.4.28:9092,10.77.4.29:9092')
        elif run_env == 'pro':
            global_kafka_consumer = KafkaConsumer(topics, bootstrap_servers='10.77.4.57:9092,10.77.4.58:9092,10.77.4.59:9092')
    return global_kafka_consumer


if __name__=="__main__":
    db = get_mongodb()
