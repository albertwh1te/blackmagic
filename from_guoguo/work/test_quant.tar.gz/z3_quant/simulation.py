# -*- coding:utf-8 -*-
# __author__=qiang.fu
import urllib2
from quant_dao import *

if __name__ == "__main__":
    db = get_mongodb()
    cursor = db['Z3_BACKTEST_STRATEGY_SIMULATE'].find({}, projection={
        '_id': 1,
        'name': 1,
    })

def simulate_by_url():
    url = ""
    req = urllib2.Request(url)
    urllib2.urlopen(req)

def simulate_by_message():
    producer = get_kafka_producer()
    pass