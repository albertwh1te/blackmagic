#/usr/local/bin

nohup python /data/App/z3quant.jrj.local/quant_web_multiprocess.py > /data/App/logs/stdout.log 2>&1 &
printf "started"

