# -*- coding:utf-8 -*-
# h
# 2017-09-04 16:33
import json
from utils.utils import *
from functions.z3_indeicator_call import *
import pandas as pd

uncalc_indexs = ['GDZY_0', 'GDZS_0', 'GDTS_0', 'DRAWDOWN_0', 'TCRQ_0']


def update_strategy_index(indexs,need_columns,indicator_dict,max_counts, sb):
    to_list_date = False
    for index in indexs:
        index_func = index['index_func']
        page_order = int(index['page_order'])
        # self.page_order_dict[page_order] = index
        if index_func not in uncalc_indexs:
            index['index_params'] = index['index_params'].replace("'","\"")
            index_params = json.loads(index['index_params'])
            period = index_params['period']
            del index_params['period']
            params_dict = {k: str_to_if(v) for k, v in index_params.items()}
            try:
                # 得函数窗口
                count = Z3_func_count(index_func, params_dict)
                # 更新最小需求行
                max_counts[period] = max(max_counts[period], count)
                # 加入函数列表
                key = sb + str(page_order)
                indicator_dict[key] = (index_func, params_dict)
                # 更新需要列
                need_columns.update(Z3_func_columns(index_func))

                if Z3_func_to_list_date(index_func):
                    to_list_date = True
            except Exception, e:
                print e
    return to_list_date

from collections import defaultdict
def init_indicator(buy_indexes, sell_indexes):
    # 计算最小数据需求
    need_columns = {'volume'}
    indicator_dict = {}
    max_counts= defaultdict(lambda: 0)
    to_list_date = False
    if buy_indexes is not None:
        told = update_strategy_index(buy_indexes,need_columns,indicator_dict,max_counts, "b")
        if told:
            to_list_date = told
    if sell_indexes is not None:
        told = update_strategy_index(sell_indexes,need_columns,indicator_dict,max_counts, "s")
        if told:
            to_list_date = told

    return need_columns, indicator_dict,max_counts, to_list_date

from datetime import timedelta


def get_start_session(calendar, dt):
    tds = calendar.all_sessions
    for i in range(10):
        try:
            idx = tds.get_loc(dt)
            return tds[idx]
        except:
            dt = dt + timedelta(days=i)
            pass


def get_end_session(calendar, dt):
    tds = calendar.all_sessions
    for i in range(10):
        try:
            idx = tds.get_loc(dt)
            return tds[idx]
        except:
            dt = dt - timedelta(days=i)
            pass


def get_calendar_session(calendar,dt):
    return calendar.minute_to_session_label(dt)


def get_date_loc(calendar,dt):
    tds = calendar.all_sessions
    dt_session = get_calendar_session(calendar,dt)
    return tds.get_loc(dt_session)

from functions.barDS import barDS


def get_day_indicator( stock,dt, sb, page_order,calc_results,trading_calendar):
    key = sb + str(page_order)
    session = trading_calendar.minute_to_session_label(dt)
    if calc_results.has_key(stock):
        # 得缓存
        colum = calc_results[stock].get(key)
        if colum is None:
            return None
        ret = colum.get(session)
        return ret

def load_day_indicator(data,calendar,stocks,start_session,end_session,need_columns, indicator_dict):
    calc_results ={}

    # syms = data.symbol(stocks)

    history_bar = data.get_all_history_window(stocks,end_session)
    for inner_code in stocks:
        # 不写注释  自动加密 -_-!!!
        data_df = history_bar[inner_code]
        newdf = data_df if data_df is None else data_df[data_df['volume'] > 0]
        df_dict={}
        data_series = barDS(newdf)
        for item_key,value in indicator_dict.items():
            try:
                index_name,params_dict=value
                values = Z3_func_call(index_name,data_series, len(data_series), params_dict)
                df_dict[item_key] = values
            except Exception,e:
                pass
            pass
        indicator_df = pd.DataFrame(data=df_dict,index=newdf.index)
        calc_results[inner_code]=indicator_df.loc[indicator_df.index>=start_session ]
    return calc_results


def compute(value, operator, comparison_value):
    if value is None:
        return False

    if comparison_value is None or operator is None:
        return value
    else:
        exp_str = "{0} {1} {2}".format(value, operator, comparison_value)
        return eval(exp_str)


def get_calc_ret(dt,con_exp, strategy_index, inner_code,sb,calc_results,trading_calendar):
    #先算出最大取数据量
    # 所有指标用一个DS

    # order_dict = dict()
    value_dict = dict()
    for index in strategy_index:
        index_func = index['index_func']
        page_order = int(index['page_order'])
        # order_dict[page_order]=index_name
        if index.has_key('index_params') and index['index_params']!="undefined":
            index_params = json.loads(index['index_params'])
            period = index_params['period']
            del index_params['period']
            params_dict = {k: str_to_if(v) for k, v in index_params.items()}
        operator = None
        if index.has_key('operator'):
            operator = index['operator']
        comparison_value = None
        if index.has_key('comparison_value'):
            comparison_value = index['comparison_value']
        if index_func in uncalc_indexs:
            value_dict[page_order] = False
            continue
        else:
            value_dict[page_order] = False
            try:
                values= None
                if period=="day":
                    value = get_day_indicator(inner_code,dt,sb,page_order,calc_results,trading_calendar)
                    value = compute(value, operator, comparison_value)
                    value = value if value != 0 else False
                    value_dict[page_order] = value
                else:
                    pass
                    # count = Z3_func_count(index_func, params_dict)
                    # if data_dict.has_key(period) and  data_dict[period] is not None and data_dict[period].has_key(sym):
                    #     data_series = data_dict[period][sym]
                    #     if data_series is not None and len(data_series) >= count:
                    #         values = Z3_func_call(index_func, data_series, count, index_params)
                    #         value = compute(values[-1], operator, comparison_value)
                    #         value_dict[page_order] = value

            except Exception, e:
                import sys
                print sys._getframe().f_lineno,index_func,e
    # 倒序
    con_exp = con_exp.lower()
    import collections
    d_value_dict = collections.OrderedDict(sorted(value_dict.items(), reverse=True))
    for k, v in d_value_dict.items():
        con_exp = con_exp.replace(str(k), str(v))
    for i in range(10):
        str_i = str(i)
        assert str_i not in con_exp

    ret = eval(con_exp)
    return ret



def get_true_days(inner_code,buy_indexes,buy_exp,sell_indexes,sell_exp,start_date,end_date,data,z3_asset_finder,calendar):

    end_date = get_end_session(calendar,end_date)
    start_date = get_start_session(calendar,start_date)
    end_session = get_calendar_session(calendar,end_date)
    start_session = get_calendar_session(calendar,start_date)
    end_loc = get_date_loc(calendar,end_date)+1
    start_loc = get_date_loc(calendar,start_date)
    need_columns, indicator_dict, max_counts, to_list_date = init_indicator(buy_indexes,sell_indexes)
    calc_results = load_day_indicator(data,calendar,[inner_code],start_session,end_session,need_columns, indicator_dict)

    buy_days = []
    sell_days = []
    tds = calendar.all_sessions
    calc_buy = True
    for date_index in range(start_loc,end_loc):
        dt = tds[date_index]
        if dt >end_session:
            break

        #计算是否可买
        if calc_buy and get_calc_ret(dt,buy_exp, buy_indexes, inner_code,"b",calc_results,calendar) :
            buy_day = date_to_n8(dt)
            buy_days.append(buy_day)
            calc_buy = not calc_buy
            continue
        if not calc_buy and  get_calc_ret(dt,sell_exp, sell_indexes, inner_code,"s",calc_results,calendar)  :
            sell_day = date_to_n8(dt)
            sell_days.append(sell_day)
            calc_buy = not calc_buy
        #是否可卖

    return {"buy_days":buy_days,"sell_days":sell_days}

if __name__=="__main__":
    pass
