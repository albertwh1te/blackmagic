# coding:utf-8
# Created by qinlin.liu at 2017/3/14
from common import get_args, elogger, slogger, curr_time, checkMain
from config import config
from model.baseinfo import BaseInfo


def main(config):
    args = get_args()
    args["controller"] = args["table_name"].lower()
    args["update_status"] = int(args["update_status"])
    args["curr_time"] = curr_time()
    config = config.get(args["branch"], 'product')
    baseinfo = BaseInfo(args, config, elogger, slogger)
    controller = "controller.{}".format(args["controller"])
    try:
        controller = __import__(controller, globals(), locals(), ['main'])
        print controller
        controller.main(args, config, baseinfo)
    except ImportError, e:
        checkMain(args, config, baseinfo)


if __name__ == "__main__":
    main(config)
    # import urllib, json
    #
    # url = "http://10.88.3.90/tp/zsfnd/getfndval?type=3"
    # response = urllib.urlopen(url)
    # cache_datas = response.read()
    # # print cache_datas
    # print json.loads(cache_datas)
