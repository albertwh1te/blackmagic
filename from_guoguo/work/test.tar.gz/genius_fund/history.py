# coding: utf-8
"""
# @Time    : 2017/8/29 23:23
# @Author  : Kylin
# @File    : history.py
# @Software: PyCharm
# @Descript: 运行历史数据，如果是insert 方式，需要先drop源表 python history.py 目的表名
"""

import datetime
import os
import sys

model_dict = {
    # -- kylin
    "Z3_FUND_DIV": {
        "bash": "python /data/App/genius_fund/main.py -t Z3_FUND_DIV -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product",
        "start": 1993,
        "name": "基金分红表",
    },
    "Z3_FUND_SPLIT_TRANSL": {
        "bash": "python /data/App/genius_fund/main.py -t Z3_FUND_SPLIT_TRANSL -s {}0101 -e {}0101 -tf declaredate -us 0 -d 0 -m insert -b product",
        "start": 2005,
        "name": "",
    },
    "Z3_FUND_NET_VAL": {
        "bash": "python /data/App/genius_fund/main.py -t Z3_FUND_NET_VAL -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product",
        "start": 1996,
        "name": "",
    },
    "Z3_FUND_MNY_INCM": {
        "bash": "python /data/App/genius_fund/main.py -t Z3_FUND_MNY_INCM -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product",
        "start": 2004,
        "name": "",
    },
    "Z3_FUND_ASSET_EXCHR_HLD": {
        "bash": "python /data/App/genius_fund/main.py -t Z3_FUND_ASSET_EXCHR_HLD -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product",
        "start": 1994,
        "name": "",
    },
    "Z3_FUND_ASSET_CONF_DTL": {
        "bash": "python /data/App/genius_fund/main.py -t Z3_FUND_ASSET_CONF_DTL -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product",
        "start": 1998,
        "name": "",
    },
    # -- others
}
tb = sys.argv[1]
print tb
max_year = datetime.datetime.now().year + 1
model = model_dict[tb]["bash"]
start = model_dict[tb].get("start", max_year - 1)
for i in range(max_year - start):
    end = max_year - i
    start = max_year - i - 1
    print "开始{},{}", start, end
    command = model.format(start, end)
    print command
    os.system(command)
    print "完成{},{}", start, end
