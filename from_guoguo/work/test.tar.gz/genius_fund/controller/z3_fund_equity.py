# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo
from common import int_date, pre_date
import copy
import pymongo
import datetime

from common import make_threads, create_model, checkMain
import copy


def main(args, config, baseinfo):
    Model = create_model(args, config)
    if not baseinfo.indexes:
        checkMain(args, config, baseinfo)
        Model.get_years_fndval()
        Model.get_months_fndval()
    print baseinfo.indexes
    if "base" in baseinfo.indexes:
        print "base"
        baseinfo.indexes = baseinfo.indexes[1:]
        checkMain(args, config, baseinfo)
    if "year" in baseinfo.indexes:
        print "year"
        Model.get_years_fndval()
    if "month" in baseinfo.indexes:
        print "month"
        Model.get_months_fndval()
