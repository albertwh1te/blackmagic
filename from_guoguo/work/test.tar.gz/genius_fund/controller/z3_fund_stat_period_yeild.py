# coding: utf-8
"""
# @Time    : 2017/9/6 14:14
# @Author  : liutao
# @File    : z3_fund_stat_period_yeild.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo
from common import int_date, pre_date
import copy
import pymongo
import datetime

from common import make_threads, create_model,checkMain
import copy


def main(args, config, baseinfo):
    print "thread start", datetime.datetime.now()
    checkMain(args, config, baseinfo)
    print "thread end", datetime.datetime.now()

    Model = create_model(args, config)
    Model.main_no_thread()
