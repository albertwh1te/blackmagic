# coding:utf-8

from common import pre_date, get_mysql


def handle_Z3_NEWS_update_error(e, filter, tmp, db, table_name):
    # pass
    emsg = e.message
    conn = get_mysql()
    if emsg.find("title_md5_1") or emsg.find("content_md5_1"):
        # 删除mysql搜索表
        sql = """
            delete from pgznty.z3_news_info_search where guid = '%s'
        """ % tmp["_id"]
        conn.execute(sql)

        # 删除mongo的新闻主表,个股新闻关系表，主题新闻关系表中的新闻
        db["Z3_TOPIC_XREF_NEWS"].remove({"guid": tmp["_id"]})
        db["Z3_EQUITY_XREF_NEWS"].remove({"guid": tmp["_id"]})
        db["Z3_NEWS"].remove({"_id": tmp["_id"]})

    return
