# coding:utf-8
import os

task_order = {
    "base_task": ["Z3_FUND_DIV", "Z3_FUND_SPLIT_TRANSL", "Z3_FUND_NET_VAL", "Z3_FUND_MNY_INCM",
                  "Z3_FUND_ASSET_EXCHR_HLD", "Z3_FUND_ASSET_CONF_DTL"],

}
task_config = {
    "tao_task": {
        # 基金公告表
        "Z3_FUND_DISC": "python /data/App/genius_fund/main.py -t Z3_FUND_DISC -mh 1 -b test",
        # 基金重大事件表
        "Z3_FUND_IMPORT_EVENT": "python /data/App/genius_fund/main.py -t Z3_FUND_IMPORT_EVENT -mh 1 -us 0 -b test ",
        # 基金阶段涨幅表
        "Z3_FUND_STAT_PERIOD_YEILD": "python /data/App/genius_fund/main.py -t Z3_FUND_STAT_PERIOD_YEILD -mh 1 -us 0 -b test",
        # 基金累计收益率表
        "Z3_FUND_ACCUM_YEILD": "python /data/App/genius_fund/main.py -t Z3_FUND_ACCUM_YEILD -mh 0 -us 0 -b test",
    },
    "base_task": {
        # 基金分红表
        "Z3_FUND_DIV": "python /data/App/genius_fund/main.py -t Z3_FUND_DIV -b product",
        # 基金拆分折算表
        "Z3_FUND_SPLIT_TRANSL": "python /data/App/genius_fund/main.py -t Z3_FUND_SPLIT_TRANSL -b product",
        # 基金净值表
        "Z3_FUND_NET_VAL": "python /data/App/genius_fund/main.py -t Z3_FUND_NET_VAL -b product",
        # 货基收益表
        "Z3_FUND_MNY_INCM": "python /data/App/genius_fund/main.py -t Z3_FUND_MNY_INCM -b product",
        # 资产配置/换手率/规模变动/持有人比例表
        "Z3_FUND_ASSET_EXCHR_HLD": "python /data/App/genius_fund/main.py -t Z3_FUND_ASSET_EXCHR_HLD -b product",
        # 资产配置/换手率/规模变动/基金投资组合资产配置明细表
        "Z3_FUND_ASSET_CONF_DTL": "python /data/App/genius_fund/main.py -t Z3_FUND_ASSET_CONF_DTL -b product",
        # 基金购买信息_按机构分
        "Z3_FUND_BUY_INFO_ORG": "python /data/App/genius_fund/main.py -t Z3_FUND_BUY_INFO_ORG -tf declaredate",
        # 基金份额变动表
        "Z3_FUND_UNIT_CHNG": "python /data/App/genius_fund/main.py -t Z3_FUND_UNIT_CHNG -tf declaredate",
        # 基金购买信息_费率相关
        "Z3_FUND_BUY_INFO_FEE_RATE": "python /data/App/genius_fund/main.py -t Z3_FUND_BUY_INFO_FEE_RATE -tf declaredate",
        # 基金经理_变动
        "Z3_FUND_MGR_CHANGE": "python /data/App/genius_fund/main.py -t Z3_FUND_MGR_CHANGE -tf declaredate",
        # 基金经理_现任
        "Z3_FUND_MGR_CURRENT": "python /data/App/genius_fund/main.py -t Z3_FUND_MGR_CURRENT -tf declaredate",

    },
    "equity_task": {
        "Z3_FUND_EQUITY":"python /data/App/genius_fund/main.py -t Z3_FUND_EQUITY -i base -mh 1",
    },

    "factor_task_after": {
    },
    "week_month_task": {
    },

    "factor_task_7pre": {
    },

    "factor_task_pre": {
    },
    "factor_task": {
    },
    "topic_task": {

    },
    "once_a_day": {
    },

}


def main(task_key, single_task=''):
    task_list = task_config.get(task_key, {})
    task_subs = task_order.get(task_key, [])
    single_task = task_list.get(single_task, None)
    if single_task:
        print "single"
        print os.system(single_task)
        return
    for i in task_subs:
        print os.system(task_list[i])


# 运行任务组
# python task.py news_task

# 运行单个任务
# * * * * * python /tmp/task.py topic_task aaa
if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        task_key = sys.argv[1]
        single_task = sys.argv[2] if len(sys.argv) == 3 else ""
        main(task_key, single_task)
