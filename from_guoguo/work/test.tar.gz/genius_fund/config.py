# coding:utf-8
# Created by qinlin.liu at 2017/3/14
import pymysql

config = {
    "product": {
        "mysql": {
            "host": "10.77.4.8",
            "port": 3306,
            "user": "kylinpython",
            "password": "x2D9uoQpei9y",
            "db": "pgenius",
            "charset": 'utf8mb4',
            "cursorclass": pymysql.cursors.DictCursor
        },
        "mongodb": {
            "db": "z3dbus",
            "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.37,10.77.4.38,10.77.4.39:27017/z3dbus?authMechanism=SCRAM-SHA-1",
        },
        "email": {
            "mailhost": ('smtp.exmail.qq.com', 465),
            "fromaddr": 'qinlin.liu@genius.com.cn',
            "toaddrs": ['qinlin.liu@genius.com.cn'],
            "subject": 'Z3_TRANSFER Logged Event',
            "credentials": ('qinlin.liu@genius.com.cn', '123.comA')
        },
        "redis": {
            "host": 'redis-formal.redis.cache.chinacloudapi.cn',
            "port": 6380,
            "password": '+95CPBw7Y8wtkNGSNsD52/wk+/nbcNyu5n2AxvmCsx0=',
            "ssl": True,
            "db": 3
        },
        "redis_key": "cache_test:",
        "log_path": r"/data/Logs/z3dbus/z3_transfer/shenzhen/",
        "http_api": "10.88.3.90",
    },
    "test": {
        "mysql": {
            "host": "10.77.4.65",
            "port": 6031,
            "user": "klpython",
            "password": "0OIaZ86gr54i",
            "db": "pgenius",
            
            "charset": 'utf8mb4',
            "cursorclass": pymysql.cursors.DictCursor
        },
        "mongodb": {
            "db": "z3dbus",
            "uri": "mongodb://z3dbusadmin:z3dbusadmin@10.77.4.37,10.77.4.38,10.77.4.39:27017/z3dbus?authMechanism=SCRAM-SHA-1",
        },
        "redis": {
            "host": 'test-redis-jrj.redis.cache.chinacloudapi.cn',
            "port": 6380,
            "password": 's2HajV5WcqG9U9T385CH3gsSNSO2gDnLiEf6aGdnBYE=',
            "ssl": True,
            "db": 0
        },
        "redis_key": "cache_test:",
        "email": {
            "mailhost": ('smtp.exmail.qq.com', 465),
            "fromaddr": 'qinlin.liu@genius.com.cn',
            "toaddrs": ['qinlin.liu@genius.com.cn'],
            "subject": 'Z3_TRANSFER Logged Event',
            "credentials": ('qinlin.liu@genius.com.cn', '123.comA')
        },
        "log_path": r"/data/Logs/z3dbus/z3_transfer/shenzhen/",
        "http_api": "10.88.3.90",
    },
}
