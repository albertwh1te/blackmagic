# -*- coding: utf-8 -*-
from model.baseinfo import BaseInfo
import random
import pymongo
from dateutil import relativedelta
#from datetime import datetime
import datetime
import numpy as np
import re


datetimetoint = lambda x:10000*x.year + 100*x.month + x.day
datetimetostr = lambda x:x.strftime("%Y-%m-%d")
inttodatetime = lambda x:datetime.datetime.strptime(str(x), '%Y%m%d')

def cal_days_between(startdate,enddate):
    return (enddate-startdate).days

def cal_post_day(info):
    during_str = info['post_day']
    int_list =  re.findall(r'\d+',during_str)
    [years,days] = int_list
    return int(years)*365+int(days)

def daytostr(during_days):
    during_str = "{years}年{days}天".format(
            years=during_days/365,
            days=during_days%365
            )
    return during_str

class Main(BaseInfo):
    info = {
        "pri_key": ["_id"]
    }


#    def get_sharp_data(self,code):
#        url = "http://%ip%/tp/zsfnd/getfndval"
#        args = {
#                "code":code
#                }
#        raw = self.http.get(url,args=args)
#        self.sharpdata = raw
#        print(self.sharpdata)


    #def cal_profit_year_avg(slef,funds):
#    url = "http://%ip%/tp/zsfnd/getstyle"
    #    args = {
    #        "code": self.cur_code["symbol"],
    #        "date": self.now.strftime("%Y-%m-%d")
    #    }

    #    raw = self.http.get(url,args=args)


    def cal_post_fund_scale_type(self,funds):
        sentence_dict = {
                "symbol":
                {
                    "$in":funds
                    }
                }
        raw = list(self.mongo.Z3_FUND_EQUITY.find(sentence_dict))
        scale = sum(filter(lambda x:x!=None,map(lambda x:x.get('fund_scale',None),raw)))

        type_list = map(lambda x:x['fund_type'],list(raw))
        good_type = max(set(type_list), key=type_list.count)
        return scale,good_type

    def cal_post_day_total(self,info):
        manager_code = info['manager_code']
        raw_list = self.mongo.Z3_FUND_MGR_CHANGE.find({
                "manager_code":manager_code}
                )
        start_date = 99991022
        end_date = 10001020
        for raw in raw_list:
            if start_date > raw['post_begin_date']:
                start_date = raw['post_begin_date']
            if end_date < raw['post_end_date']:
                end_date = raw['post_end_date']
        end_date = datetime.datetime.now() if end_date == u'\u81f3\u4eca' else inttodatetime(end_date)
        totally_days = cal_days_between(
               inttodatetime(start_date),
               end_date
                )
        totally_str = daytostr(totally_days)
        info.update({
            "post_day_total":totally_str
            })
        return info


    def cal_post_fund_about(self,info):
        sql = """
        select distinct indi_id ,indi_name,FUND_CODE
        from FND_MANAGER a inner join
        FND_GEN_INFO b
        on a.fund_id = b.fund_id where a.isvalid=1 and
        b.isvalid=1 and post=1
        and a.indi_id = {manager_code}
        order by indi_id;
        """.format(
                manager_code=info['manager_code']
                )

        raw = self.mysql.fetchall(sql)
        fund_num = len(raw)
        scale,good_type = self.cal_post_fund_scale_type(map(lambda x:str(x['FUND_CODE']),raw))
        info.update({
            "post_fund_num":fund_num,
            "post_fund_scale":round(scale,2),
            "good_fund_type":good_type,
            "profit_year_avg":1,
            "max_profit":1,
            "max_drawdown":1,
            "post_profit_type_avg":1,
            "post_profit":info.pop("post_return")
        })

        #del info['manager_id']
        print(info['symbol'])
        print(info['post_fund_scale'])
        return info

    def cal_post_chg_pct_hs300(self,info):
        end_date = info['post_end_date']
        end_date = datetime.datetime.now() if end_date == u'\u81f3\u4eca' else inttodatetime(end_date)
        sql = """
        select  a.INNER_CODE,INDX_CODE,b.TRADEDATE,b.lclose,b.TCLOSE,tradedate
        from INDX_GEN_INFO a
        inner join  INDX_MKT b on a.INNER_CODE =b .INNER_CODE
        where a.ISVALID=1 and b.isvalid=1
        and tradedate between '{startdate}'
        and '{enddate}'
        and INDX_CODE  = '000300'
        and b.lclose is not null
        and b.TCLOSE is not null
        order by tradedate desc
        """.format(
                startdate=datetimetostr(inttodatetime(info['post_begin_date'])),
                enddate=datetimetostr(end_date)
                )
        results = self.mysql.fetchall(sql)
        chng_pct = 0
        if results:
            start_value = float(results[0].get('TCLOSE'))
            end_value = float(results[-1].get('lclose'))
            chng_pct = round(
                    (np.true_divide(
                        start_value,end_value
                        )-1)*100,2
                    )
        info.update(
                {
                    "post_chg_pct_hs300":chng_pct
                    }
                )
        print("post_chg_pct_hs300",chng_pct)
        info['_id'] = str(info['innerCode'])+"-"+str(info["manager_code"])
        del info["innercode"]
        return info




#    def cal_post_day_total(self,info):
#        manager_code = info['manager_code']
#        raw_list = self.mongo.Z3_FUND_MGR_CHANGE.find(
#                {"manager_code":manager_code}
#                )
#        totally_days = 0
#        for raw in raw_list:
#            post_day = cal_post_day(raw)
#            totally_days += post_day
#            print(totally_days)
#        totally_str = daytostr(totally_days)
#        info.update({
#            "post_day_total":totally_str
#            })

#        return info
    def main(self, tradedate=None):

       # self.get_sharp_data()
        raw = list(
                self.mongo.Z3_FUND_MGR_CHANGE.find(
                    {
                        "post_end_date":"至今"
                        }
                    )
                )

        raw = map(self.cal_post_fund_about,raw)
        raw = map(self.cal_post_day_total,raw)
        raw = map(self.cal_post_chg_pct_hs300,raw)
        print(raw[0]['post_day_total'],raw[0]['post_day'])
        print(raw[20:21])
        results = raw
        self.upsert_mongo_data(results)
        self.update_task()
        print("done")



