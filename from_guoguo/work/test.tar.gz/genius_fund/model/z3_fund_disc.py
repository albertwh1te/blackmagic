# coding: utf-8
"""
# @Time    : 2017/8/22 
# @Author  : liutao
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript: Z3_FUND_DISC
"""
from model.baseinfo import BaseInfo
import random

import pymongo


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"]
    }

    def delete_x(self, tradedate=None):
        # where_str = self._make_where_time(['a','b','c','d','e','f'])
        where_codes = self._make_where_codes()
        sql = """
       SELECT concat(b.disc_id,'-',CONCAT(a.fund_code,'.',case a.TRADE_MKT when 1 then 'SZ' 
                                      when 2 then 'SH' else 'CW' end)) as _id 
          from pgenius.FND_GEN_INFO a
          join pgenius.DISC_FND b
            on a.INNER_CODE = b.inner_code 
          join pgenius.DISC_MAIN_FND c
            on b.disc_id = c.disc_id 
          left join pgenius.DISC_CONTENT_FND e
            on b.disc_id = e.disc_id 
          left join pgenius.DISC_ACCE_FND f
            on b.disc_id = f.disc_id 
         where (a.isvalid = 0 or b.isvalid = 0 or c.isvalid = 0 or e.isvalid = 0 or f.isvalid = 0)
          {base_where}
        """
        sql = self.format(
            sql,
            # innerCode=self.make_innerCode_concat(),
            base_where=self._make_base_where(
                {"time": {"alias_list": ['a', 'b', 'c', 'e', 'f']}, "codes": {"alias": "a"}}),
            # where_codes=where_codes,
            symbol=self.args["cur_code"]["symbol"]
        )
        # print sql
        result = self.mysql.fetchall(sql)
        self.delete_mongo_data(result)

    def main(self):
        sql = """
        SELECT concat(b.disc_id,'-',CONCAT(a.fund_code,'.',case a.TRADE_MKT when 1 then 'SZ' 
                                      when 2 then 'SH' else 'CW' end)) as _id,
              {fund_base},
              {d2i[b.declaredate]} declare_date
              ,(select case when CLS_CODE in ('003001003001','003001003002','003001003003',
                          '003001003004','003001001','003001002','003001003') then 1
                    when CLS_CODE in ('003002001') then 2
                    else null  end
                from pgenius.DISC_CLS_FND where disc_id = b.disc_id and isvalid = 1
                order by 1 desc,CLS_CODE limit 1) as cls_code
              ,c.title
              ,e.TXT_CONTENT as content
              ,f.ACCE_ROUTE as acce_route
              ,f.ACCE_TYPE as acce_type   
          from pgenius.FND_GEN_INFO a
          join pgenius.DISC_FND b
            on a.INNER_CODE = b.inner_code and b.isvalid = 1
          join pgenius.DISC_MAIN_FND c
            on b.disc_id = c.disc_id and c.isvalid = 1
          left join pgenius.DISC_CONTENT_FND e
            on b.disc_id = e.disc_id and e.isvalid = 1
          left join pgenius.DISC_ACCE_FND f
            on b.disc_id = f.disc_id and f.isvalid = 1
         where a.isvalid = 1 
          {base_where}
        """
        sql = self.format(
            sql,
            fund_base=self.make_fund_base_where(alias='a'),
            base_where=self._make_base_where({"time":{"alias_list":['a','b','c','e','f']},"codes":{"alias":"a"}})
        )
        # print sql
        result = self.mysql.fetchall(sql)
        self.upsert_mongo_data(result)
