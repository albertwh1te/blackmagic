# coding: utf-8
"""
# @Time    : 2017/8/22 
# @Author  : liutao
# @File    : z3_fund_entry_param.py
# @Software: PyCharm
# @Descript:Z3_FUND_ENTRY_PARAM
"""
from model.baseinfo import BaseInfo
import random

import pymongo


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"]
    }

    def delete(self):
        pass

    def main(self):
        sql = """
            select * from pgznty.Z3_FUND_ENTRY_PARAM
        """

        data = self.mysql.fetchall(sql)
        self.upsert_mongo_data(data)