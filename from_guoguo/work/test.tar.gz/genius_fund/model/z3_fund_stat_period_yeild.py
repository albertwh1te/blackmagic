# coding: utf-8
"""
# @Time    : 2017/8/22 
# @Author  : liutao
# @File    : z3_fund_stat_period_yeild.py
# @Software: PyCharm
# @Descript:Z3_FUND_STAT_PERIOD_YEILD
"""
from model.baseinfo import BaseInfo
import random
import pymongo
from datetime import datetime


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"]
    }

    def get_period_field(self, period):
        dic = {
            1: "UNIT_NET_CHNG_PCT_1_MON",  # 1-近1月
            2: "UNIT_NET_CHNG_PCT_3_MON",  # 2-近3月
            3: "UNIT_NET_CHNG_PCT_6_MON",  # 3-近6月
            4: "UNIT_NET_CHNG_PCT_1_YEAR",  # 4-近1年
            5: "UNIT_NET_CHNG_PCT_2_YEAR",  # 5-近2年
            6: "UNIT_NET_CHNG_PCT_3_YEAR",  # 6-近3年
            8: "UNIT_NET_CHNG_PCT_5_YEAR",  # 8-近5年
            9: "UNIT_NET_CHNG_PCT_TYEAR",  # 9-今年来
            0: "UNIT_NET_CHNG_PCT_BASE",  # 0-成立以来
            10: "UNIT_NET_CHNG_PCT_1_WEEK",  # 10-近1周
        }
        return dic.get(period, None)

    def get_fund_type(self, fund_code, end_date):
        """
        获取基金类型
        :return: 
        """
        sql = """
        select a.FND_TYPE as fund_type
          from pgenius.ANA_FND_GR_CALC_SPEC a
         where fund_code = '{fund_code}'
           and a.isvalid = 1
           and a.enddate <= date('{enddate}')
           and FND_TYPE is not null
         order by a.ENDDATE desc 
         limit 1 
        """

        sql = self.format(
            sql,
            fund_code=fund_code,
            enddate=end_date
        )

        result = self.mysql.fetchone(sql)
        # print "aaaaaa", result, result["FND_TYPE"]
        return result.get("fund_type", None)

    def get_max_tradedate(self):
        sql = """
            select max(ENDDATE) as end_date
              from pgenius.ANA_FND_GR_CALC_SPEC a 
             where a.isvalid = 1
               and a.fund_code = '{fund_code}'
        """
        sql = self.format(
            sql,
            fund_code=self.args["cur_code"]["symbol"],
            # base_where=self._make_base_where({"onecode": {"alias": "a"}})
        )
        # print sql
        result = self.mysql.fetchone(sql)
        return result

    def get_complex_data_type(self):
        """
        获取mongodb中所有区间类型和基金类别
        :return: 
        """
        ptype = list(self.mongo[self.ttable].distinct(
            "stat_period",
            # {"stat_period":{"$in":[0,1,2,3,4,5,6,7,8,9,10 ]}}
        ))
        # ptype = [5, ]
        for p in ptype:
            ftype = list(self.mongo[self.ttable].distinct(
                "fund_type",
                {"stat_period": p}))
            # ftype = [3, 6]
            for t in ftype:
                print "period",p,"fund_type",t,"start", datetime.now()
                results = self.get_rank_base_data(p, t)
                # print "period",p,"fund_type",t ,len(results) , "query end", datetime.now()
                self.upsert_mongo_data(results) if results else None
                # print "period", p, "fund_type", t, "update end", datetime.now()

    def get_quarter_base_data(self):
        """
        获取季度数据
        :return: 
        """
        # print "aaaaaaaaa"
        sql = """
        select concat({innerCode},'-',stat_period) as _id,
               {fund_base},
              {d2i[a.end_date]} as end_date
             ,{d2i[a.start_date]} as start_date
             ,stat_period 
             ,if(ISNULL(d.FAC_UNIT_NET),null,round((c.FAC_UNIT_NET - d.FAC_UNIT_NET)/d.FAC_UNIT_NET * 100,2) ) as stat_accum_yeild 
        from (
             SELECT b.inner_code,b.end_year,b.end_quarter,b.end_date
                    ,stat_period
                    ,max(a.tradedate) as date_start_date
                    ,b.start_date
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_NAV_CALC a 
               join (
                    select a.inner_code,year(a.tradedate) as end_year,QUARTER(a.tradedate) as end_quarter 
                          ,cast(concat(substr(a.TRADEDATE,3,2),QUARTER(a.TRADEDATE)) as SIGNED) as stat_period
                          ,max(a.tradedate) as end_date 
                          ,date(concat(year(a.tradedate),
                                   (case QUARTER(a.tradedate) when 1 then '-01-01' 
                                    when 2 then '-04-01' 
                                    when 3 then '-07-01' 
                                    when 4 then '-10-01' end))) as start_date
                          ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
                      from pgenius.ANA_FND_NAV_CALC a
                      join pgenius.FND_GEN_INFO b
                        on a.INNER_CODE = b.INNER_CODE and b.ISVALID = 1
                       and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE() 
                       and b.ESTAB_DATE <= date(concat(year(a.tradedate),
                                   (case QUARTER(a.tradedate) when 1 then '-01-01'
                                    when 2 then '-04-01'
                                    when 3 then '-07-01'
                                    when 4 then '-10-01' end)))
                     where a.isvalid = 1
                       and a.tradedate >= '2015-01-01'
                       {base_where}
                     group by 1,2,3
                    ) b
                 on a.inner_code = b.inner_code 
                and a.tradedate < b.start_date
                 and b.stat_period <> cast(concat(substr(CURDATE(),3,2),QUARTER(CURDATE())) as SIGNED)
              where a.isvalid = 1
              group by 1,2,3,4) a
      join (select * from pgenius.ANA_FND_NAV_CALC a
              where isvalid = 1 and a.inner_code = {INNER_CODE}
            ) c on a.inner_code = c.inner_code and c.isvalid = 1
       and c.tradedate = a.end_date
      join (select * from pgenius.ANA_FND_NAV_CALC a
              where isvalid = 1 and a.inner_code = {INNER_CODE}
            ) d on a.inner_code = d.inner_code and d.isvalid = 1
       and d.tradedate = a.date_start_date
        """

        sql = self.format(
            sql,
            fund_base=self.make_fund_base_where(alias="a"),
            base_where=self._make_base_where(
                {
                    "time": {"alias_list": ["a"]},
                    "onecode": {"alias": "b"}
                }),
            innerCode=self.make_innerCode_concat(alias="a"),
            INNER_CODE=self.cur_code["INNER_CODE"]
            # fund_type=
        )
        # print sql
        data = self.mysql.fetchall(sql)


        # 获取基金类型(如果是货币型基金，则删除数据)
        result = []
        for row in data:
            fund_type = self.get_fund_type(row["symbol"], row["end_date"])
            row["fund_type"] = fund_type

            if row["fund_type"] in (3, 6):
                data.remove(row)
            result.append(row)

        self.upsert_mongo_data(result)

    def get_curr_quar_year_data(self):
        """
        获取货币式基金季度和年度数据
        :return: 
        """
        # print "aaaaaaaaa"
        sql_quar = """
             SELECT concat({innerCode},'-',stat_period) as _id,
                    {fund_base}, 
                    {d2i[date(concat(year(a.enddate),
                         (case QUARTER(a.enddate) when 1 then '-03-31' 
                            when 2 then '-06-30' 
                            when 3 then '-09-30' 
                            when 4 then '-12-31' end)))]} as end_date
                    ,{d2i[c.start_date]} as start_date
                   ,stat_period 
                   ,round(QUA_GR,2) as stat_accum_yeild
                   ,a.FND_TYPE as fund_type
               from pgenius.ANA_FND_GR_CALC_SPEC a
               join (select FUND_CODE,cast(concat(substr(a.enddate,3,2),QUARTER(a.enddate)) as SIGNED) as stat_period
                           ,max(a.ENDDATE) as ENDDATE 
                           ,date(concat(year(a.enddate),
                         (case QUARTER(a.enddate) when 1 then '-01-01' 
                            when 2 then '-04-01' 
                            when 3 then '-07-01' 
                            when 4 then '-10-01' end))) as start_date
                       from pgenius.ANA_FND_GR_CALC_SPEC a
                      where isvalid = 1 
                        and a.ENDDATE >= '2015-01-01'
--                         and a.ENDDATE < date(concat(year(CURDATE()),'-01-01'))
                        and a.fnd_type in (3,6)
                      group by 1,2) c
                 on a.FUND_CODE  = c.FUND_CODE and a.ENDDATE = c.ENDDATE
                and c.stat_period <> cast(concat(substr(CURDATE(),3,2),QUARTER(CURDATE())) as SIGNED) 
               join pgenius.FND_GEN_INFO b
                 on b.FUND_CODE = c.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE() 
                and b.ESTAB_DATE <= c.start_date
              where a.isvalid = 1 
                and a.fnd_type in (3,6)
             /*   and a.fund_code in 
                (000009,000010,000013,000198,000203,000204,000210,000211,000300,000301,
                 000324,000325,000330,000331,000332,000343,000359,000366,000371,000379,
                 000037,000038,000089,000090,000134,000135,000322,000323,000485,000486,
                000715,000791,000792,000798,000808,000809,000833,000951,000952,001041)*/
        """

        sql_quar = self.format(
            sql_quar,
            fund_base=self.make_fund_base_where(alias="b"),
            # base_where=self._make_base_where(
            #     {
            #         "time": {"alias_list": ["a"]},
            #         "onecode": {"alias": "b"}
            #     }),
            innerCode=self.make_innerCode_concat(alias="b"),
            # INNER_CODE=self.cur_code["INNER_CODE"]
        )
        # print sql_quar
        data_q = self.mysql.fetchall(sql_quar)
        self.upsert_mongo_data(data_q)

        # 获取货币式基金年度数据
        sql_year = """
             SELECT concat({innerCode},'-',stat_period) as _id,
                    {fund_base}, 
                    {d2i[date(concat(YEAR(a.ENDDATE),'-12-31'))]} as end_date
                    ,{d2i[c.start_date]} as start_date
                   ,stat_period 
                   ,round(OYR_GR,2) as stat_accum_yeild
                   ,a.FND_TYPE as fund_type
               from pgenius.ANA_FND_GR_CALC_SPEC a
               join (select FUND_CODE,cast(YEAR(ENDDATE) as SIGNED) as stat_period
                           ,max(a.ENDDATE) as ENDDATE 
                           ,date(concat(YEAR(ENDDATE),'-01-01')) as start_date
                       from pgenius.ANA_FND_GR_CALC_SPEC a
                      where isvalid = 1 
                        and a.ENDDATE >= '2009-01-01'
                        and a.ENDDATE < date(concat(year(CURDATE()),'-01-01'))
                        and a.fnd_type in (3,6)
                      group by 1,2) c
                 on a.FUND_CODE  = c.FUND_CODE and a.ENDDATE = c.ENDDATE
               join pgenius.FND_GEN_INFO b
                 on b.FUND_CODE = c.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE() 
                and b.ESTAB_DATE <= c.start_date
              where a.isvalid = 1 
                and a.fnd_type in (3,6)
              /*  and a.fund_code in 
                (000009,000010,000013,000198,000203,000204,000210,000211,000300,000301,
                 000324,000325,000330,000331,000332,000343,000359,000366,000371,000379,
                 000037,000038,000089,000090,000134,000135,000322,000323,000485,000486,
                000715,000791,000792,000798,000808,000809,000833,000951,000952,001041)*/
        """
        sql_year = self.format(
            sql_year,
            fund_base=self.make_fund_base_where(alias="b"),
            # base_where=self._make_base_where(
            #     {
            #         "time": {"alias_list": ["a"]},
            #         "onecode": {"alias": "b"}
            #     }),
            innerCode=self.make_innerCode_concat(alias="b"),
            # INNER_CODE=self.cur_code["INNER_CODE"]
        )
        # print sql_year
        data_y = self.mysql.fetchall(sql_year)
        self.upsert_mongo_data(data_y)

    def get_year_base_data(self):
        """
        获取年度涨跌幅,最好是不单个基金跑
        :return: 
        """
        sql = """
            SELECT concat({innerCode},'-',stat_period) as _id,
                   {fund_base}, 
                   {d2i[a.TRADEDATE]} as end_date
                   ,{d2i[c.start_date]} as start_date
                   ,stat_period 
                   ,round(UNIT_NET_CHNG_PCT_TYEAR,2) as stat_accum_yeild
               from pgenius.ANA_FND_NAV_CALC a
               join (select inner_code,cast(YEAR(TRADEDATE) as SIGNED) as stat_period
                           ,max(a.TRADEDATE) as TRADEDATE 
                           ,date(concat(YEAR(TRADEDATE),'-01-01')) as start_date
                       from pgenius.ANA_FND_NAV_CALC a
                      where isvalid = 1 
                        and a.TRADEDATE >= '2009-01-01'
                        and a.TRADEDATE < date(concat(year(CURDATE()),'-01-01'))
                      group by 1,2) c
                 on a.INNER_CODE  = c.INNER_CODE and a.TRADEDATE = c.TRADEDATE
               join pgenius.FND_GEN_INFO b
                 on b.INNER_CODE = c.INNER_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE() 
                and b.ESTAB_DATE <= c.start_date
              where a.isvalid = 1 
          /*      and b.fund_code in 
                (000009,000010,000013,000198,000203,000204,000210,000211,000300,000301,
         000324,000325,000330,000331,000332,000343,000359,000366,000371,000379,
         000082,000309,000409,000411,000418,000457,000471,000513,000524,000549,
        000577,000586,000592,000594,000628,000688,000696,000697,000711,000729,
        000001,000011,000017,000020,000021,000029,000031,000039,000056,000057,
        960028,960026,960024,960023,960021,960020,960018,960016,960012,960011,
        000037,000038,000089,000090,000134,000135,000322,000323,000485,000486,
        000715,000791,000792,000798,000808,000809,000833,000951,000952,001041,
        000003,000004,000005,000007,000014,000015,000016,000024,000025,000026,
        960029,960027,750003,750002,720003,720002,710302,710301,700006,700005,
        000071,000075,000076,000948,110031,110032,110033,159920,160138,160139,
        513660,513600,510900,501021,164705,161831,161124,160924,160922,160717,
        000008,000022,000023,000042,000051,000059,000087,000088,000172,000176,
        960022,740101,700002,690008,660011,660008,590007,585001,540012,530018)
         */
        """

        sql = self.format(
            sql,
            fund_base=self.make_fund_base_where(alias="b"),
            # base_where=self._make_base_where(),
            innerCode=self.make_innerCode_concat(alias="b")
            # pct_field=self.get_period_field(period),
            # period=period
        )
        # print sql
        data = self.mysql.fetchall(sql)

        # 获取基金类型
        result = []
        for row in data:
            row["fund_type"] = self.get_fund_type(row["symbol"], row["end_date"])
            if row["fund_type"] in (3, 6):
                data.remove(row)
            result.append(row)

        self.upsert_mongo_data(result)

    def get_period_base_data(self):
        """
        按基金逐个查询
        :return: 
        """
        end_date = self.get_max_tradedate()
        if end_date:
            sql = """
            SELECT concat({innerCode},'-',stat_period) as _id,
                   {fund_base},
                   {d2i[end_date]} as end_date,
                   {d2i[start_date]} as start_date,
                   stat_period,
                   fund_type,
                   round(stat_accum_yeild,2) as stat_accum_yeild
             from(	SELECT  a.ENDDATE as end_date
                    ,DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -1 month),INTERVAL 1 day) as start_date
                    ,1 as stat_period  -- 1-近1月 
                    ,OMTH_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -1 month),INTERVAL 1 day)
              where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
              union all
              SELECT a.ENDDATE as end_date
                    ,DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -3 month),INTERVAL 1 day) as start_date
                    ,2 as stat_period  -- 2-近3月 
                    ,QUA_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -3 month),INTERVAL 1 day)
             where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
              union all
              SELECT a.ENDDATE as end_date
                    ,DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -6 month),INTERVAL 1 day) as start_date
                    ,3 as stat_period  -- 3-近6月 
                    ,HLFYR_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -6 month),INTERVAL 1 day)
              where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
              union all
              SELECT a.ENDDATE as end_date
                    ,DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -1 year),INTERVAL 1 day) as start_date
                    ,4 as stat_period  -- 4-近1年 
                    ,OYR_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL  -1 year),INTERVAL 1 day)
              where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
               union all
              SELECT a.ENDDATE as end_date
                    ,DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -2 year),INTERVAL 1 day) as start_date
                    ,5 as stat_period  -- 5-近2年 
                    ,TYR_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL  -2 year),INTERVAL 1 day)
              where a.isvalid = 1
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}	
               union all
              SELECT a.ENDDATE as end_date
                    ,DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -3 year),INTERVAL 1 day) as start_date
                    ,6 as stat_period  -- 6-近3年 
                    ,THYR_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL  -3 year),INTERVAL 1 day)
              where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
             union all
              SELECT a.ENDDATE as end_date
                    ,DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL -5 year),INTERVAL 1 day) as start_date
                    ,8 as stat_period  -- 8-近5年 
                    ,FIVYR_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL  -5 year),INTERVAL 1 day)
              where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}	
               union all
              SELECT a.ENDDATE as end_date
                    ,date(concat(year(a.ENDDATE),'-01-01')) as start_date
                    ,9 as stat_period  -- 9-今年来 
                    ,YTD_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= date(concat(year(a.ENDDATE),'-01-01'))
              where a.isvalid = 1
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
               union all
              SELECT a.ENDDATE as end_date
                    ,b.ESTAB_DATE as start_date
                    ,0 as stat_period  -- 0-成立以来 
                    ,ESTA_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
             where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
              union all
              SELECT a.ENDDATE as end_date
                    ,date_add(a.ENDDATE,INTERVAL -6 day) as start_date
                    ,10 as stat_period  -- 10-近1周 
                    ,OWK_GR as stat_accum_yeild
                    ,a.FND_TYPE as fund_type
                    ,b.FUND_CODE,b.TRADE_MKT,b.FUNDSNAME
               from pgenius.ANA_FND_GR_CALC_SPEC a 
               join pgenius.FND_GEN_INFO b
                 on a.FUND_CODE = b.FUND_CODE and b.ISVALID = 1
                and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
                and b.ESTAB_DATE is not null 
                and b.ESTAB_DATE <= DATE_ADD(DATE_ADD(a.ENDDATE,INTERVAL  -1 week),INTERVAL 1 day)
              where a.isvalid = 1 
                and a.FND_TYPE in (3,4,5,6,7,11,12)
                and a.ENDDATE = '{end_date}'
                {base_where}
             ) aa	
            """
            sql = self.format(
                sql,
                fund_base=self.make_fund_base_where(alias="aa"),
                base_where=self._make_base_where(
                    {
                        "time": {"alias_list": ["a"]},
                        "onecode": {"alias": "b"}
                    }),
                end_date=end_date["end_date"],
                innerCode=self.make_innerCode_concat(alias="aa")
            )
            # print sql
            data = self.mysql.fetchall(sql)
            # 获取基金类型
            # result = []
            # for row in data:
            #     row["fund_type"] = self.get_fund_type(row["symbol"], row["end_date"])
            #     result.append(row)

            self.upsert_mongo_data(data)

    def get_rank_base_data(self, period, fund_type):

        data1 = list(self.mongo[self.ttable].find({
            "stat_period": period,
            "fund_type": fund_type,
            # "stat_accum_yeild": {"$ne": None},
            # "stat_accum_yeild_rank":{"$exists":False}
        },
            {"_id": 1, "fund_type": 1, "stat_accum_yeild": 1,
             "start_date": 1, "end_date": 1}))
        if not data1: return

        datas = []
        result = []
        for row1 in data1:
            # 计算统计区间沪深300累计涨幅 和 统计区间标普500累计涨幅
            row1.update(self.get_hs300_sp500_pct(row1["start_date"], row1["end_date"]))
            # 计算 统计区间比较基准累计涨幅
            print "sssss", row1["_id"]
            if row1["fund_type"] in [4, 12]:
                row1["stat_chg_pct_perform_bench"] = row1["stat_accum_chg_pct_hs300"]
            elif row1["fund_type"] in [11]:
                row1["stat_chg_pct_perform_bench"] = row1["stat_accum_chg_pct_sp500"]
            elif row1["fund_type"] in [5]:
                row1["stat_chg_pct_perform_bench"] = \
                    round((row1["stat_accum_chg_pct_hs300"] * 0.7 + row1["stat_accum_chg_pct_h11001"] * 0.3), 2)
            elif row1["fund_type"] in [7]:
                row1["stat_chg_pct_perform_bench"] = \
                    round((row1["stat_accum_chg_pct_hs300"] * 0.3 + row1["stat_accum_chg_pct_h11001"] * 0.7), 2)
            elif row1["fund_type"] in [3, 6]:
                row1["stat_chg_pct_perform_bench"] = \
                    self.get_stat_chg_pct_perform_bench(row1["start_date"], row1["end_date"])
            else:
                row1["stat_chg_pct_perform_bench"] = None

            # 获取累计收益率不为空的单独处理
            if row1["stat_accum_yeild"] is not None:
                datas.append(row1)
            else:
                result.append(row1)

        sort_data = sorted(datas, key=lambda x: x["stat_accum_yeild"], reverse=True)

        if sort_data:
            # 计算统计区间同类平均累计收益率
            pcts = [i["stat_accum_yeild"] for i in sort_data]

            stat_accum_yeild_avg = round(sum(pcts) / len(pcts), 2) if len(pcts) <> 0 else None
            stat_fund_num = len(pcts)

            for index, row in enumerate(sort_data):
                # print "row", row["_id"]
                # 计算统计区间同类平均累计收益率
                row["stat_accum_yeild_avg"] = stat_accum_yeild_avg
                # 计算统计区间同类基金总数
                row["stat_fund_num"] = stat_fund_num

                # 计算统计区间累计收益率同类排名
                if index <> 0 and sort_data[index]["stat_accum_yeild"] == sort_data[index - 1]["stat_accum_yeild"]:
                    row["stat_accum_yeild_rank"] = sort_data[index - 1]["stat_accum_yeild_rank"]
                else:
                    row["stat_accum_yeild_rank"] = index + 1

                # 计算统计区间四分位同类排名
                rank4 = float(row["stat_accum_yeild_rank"]) / float(row["stat_fund_num"]) \
                    if row["stat_fund_num"] <> 0 else None
                if row["stat_fund_num"] <> 0 and 0 < rank4 <= 0.25:
                    row["stat_4_rank"] = u'优秀'
                elif row["stat_fund_num"] <> 0 and 0.25 < rank4 <= 0.50:
                    row["stat_4_rank"] = u'良好'
                elif row["stat_fund_num"] <> 0 and 0.50 < rank4 <= 0.75:
                    row["stat_4_rank"] = u'中等'
                elif row["stat_fund_num"] <> 0 and rank4 > 0.75:
                    row["stat_4_rank"] = u'一般'
                # print row
                result.append(row)

        return result

    def get_stat_chg_pct_perform_bench(self, start_date, end_date):
        """
        计算统计区间比较基准累计涨幅fund_type in (3,6)
        :return: 
        """
        sql = """
          select EXECUTEDATE,FIX_DEP_1Y
            from pgenius.BND_RMB_INTR
           where isvalid = 1 
             and EXECUTEDATE > date('{start_date}') 
             and EXECUTEDATE < date('{end_date}')
          union all
           select date('{start_date}') as EXECUTEDATE,FIX_DEP_1Y
           from
          (select EXECUTEDATE,FIX_DEP_1Y
            from pgenius.BND_RMB_INTR
           where isvalid = 1 
             and EXECUTEDATE <= date('{start_date}') 
           order by EXECUTEDATE desc 
            limit 1) a
          union ALL
          select date('{end_date}') as EXECUTEDATE, FIX_DEP_1Y 
          from 
          (select EXECUTEDATE,FIX_DEP_1Y
            from pgenius.BND_RMB_INTR
           where isvalid = 1  
             and EXECUTEDATE <= date('{end_date}')
           order by EXECUTEDATE desc
          limit 1) b
           order by EXECUTEDATE
        """.format(start_date=start_date,
                   end_date=end_date)
        # print sql
        data = self.mysql.fetchall(sql)

        dlen = len(data)
        dds = (data[dlen - 1]["EXECUTEDATE"] - data[0]["EXECUTEDATE"]).days+1
        # print "days",dds
        rate = 0.00
        for index, row in enumerate(data):
            if index <> dlen - 1:
                d1 = data[index]["EXECUTEDATE"]
                d2 = data[index + 1]["EXECUTEDATE"]
                day_betw = (d2 - d1).days if (index <> dlen-2) else (d2 - d1).days+1

                rate += float(day_betw) / float(dds) * data[index]["FIX_DEP_1Y"]
                print "day_betw", day_betw, "dds", dds,"rr", data[index]["FIX_DEP_1Y"],rate
        # print "rrrrrr",rate
        return round(rate, 2)

    def get_hs300_sp500_pct(self, start_date, end_date):
        """
        获取沪深300和标普500区间累计收益率
        :return: 
        """
        sql = """
          select stat_accum_chg_pct_hs300
                 ,stat_accum_chg_pct_sp500
                 ,stat_accum_chg_pct_h11001
           from (
             SELECT a.SECCODE,a.INDX_SNAME
                    ,if(ifnull(b.TCLOSE,0)=0,0.00,round((a.TCLOSE - b.TCLOSE) / b.TCLOSE*100,2)) as stat_accum_chg_pct_hs300
               FROM (SELECT *
                       FROM pgenius.INDX_MKT
                      where ISVALID = 1 
                        and SECCODE = '399300'
                        and TRADEDATE <= date({end_date})
                      order by TRADEDATE desc
                      limit 1) a
                join
                    (SELECT *
                       FROM pgenius.INDX_MKT
                      where ISVALID = 1 
                        and SECCODE = '399300'
                        and TRADEDATE < date({hs_start_date})
                      order by TRADEDATE desc
                      limit 1) b
                  on a.INNER_CODE = b.inner_code
                  ) aa
         join
            (
             select a.inner_code ,a.indx_name
                   ,if(ifnull(b.TCLOSE,0)=0,0.00,round((a.TCLOSE-b.TCLOSE)/b.TCLOSE*100,2)) as stat_accum_chg_pct_sp500
              from (select * 
                      from pgenius.MAC_WORLD_INDX_PRC 
                     where isvalid = 1 
                       and inner_code=106001932
                       and TRADEDATE <= date({end_date})
                     order by TRADEDATE desc
                     limit 1 
                   ) a
              join (select * 
                      from pgenius.MAC_WORLD_INDX_PRC 
                     where isvalid = 1 
                       and inner_code=106001932
                       and TRADEDATE < date({start_date})
                     order by TRADEDATE desc
                     limit 1 
                   ) b
               on a.inner_code = b.inner_code
            ) bb
         on 1=1
         JOIN
           (SELECT a.SECCODE,a.INDX_SNAME
                    ,if(ifnull(b.TCLOSE,0)=0,0.00,round((a.TCLOSE - b.TCLOSE) / b.TCLOSE*100,2)) as stat_accum_chg_pct_h11001
               FROM (SELECT *
                       FROM pgenius.INDX_MKT
                      where ISVALID = 1 
                        and SECCODE = 'h11001'
                        and TRADEDATE <= date({end_date})
                      order by TRADEDATE desc
                      limit 1) a
                join
                    (SELECT *
                       FROM pgenius.INDX_MKT
                      where ISVALID = 1 
                        and SECCODE = 'h11001'
                        and TRADEDATE < date({h11_start_date})
                      order by TRADEDATE desc
                      limit 1) b
                  on a.INNER_CODE = b.inner_code
                  ) cc
            on 1=1
        """
        sql = self.format(
            sql,
            end_date=end_date,
            start_date=start_date,
            hs_start_date=max(start_date, 20050105),
            h11_start_date=max(start_date, 20071215)
        )

        # print sql
        return self.mysql.fetchone(sql)

    def delete_x(self, tradedate=None):
        pass

        sql = """
            select fund_code 
        """

        self.mongo[self.ttable].remove({})

    def main(self):
        # print "start", datetime.now()
        # 多线程跑数
        self.get_period_base_data()
        self.get_quarter_base_data()

        # pass
    def main_no_thread(self):
        # 非线程跑数
        # pass
        self.get_year_base_data()
        print "year end", datetime.now()
        self.get_curr_quar_year_data()
        print "curr end", datetime.now()
        self.get_complex_data_type()
        print "all", datetime.now()

        # self.get_stat_chg_pct_perform_bench(20150101, 20151231)



