# coding: utf-8
from model.baseinfo import BaseInfo
import random
import pymongo
from dateutil import relativedelta
from datetime import datetime
import numpy as np

class Main(BaseInfo):
    info = {
        "pri_key": ["_id"]
    }
    def main(self, tradedate=None):

        where_str = self._make_where_time(['a'])
        sql = """
        SELECT
        concat({innerCode},'-',DATE_FORMAT(a.end_date, '%Y%m%d')) _id,
        {innerCode} innerCode,
        b.FUND_CODE symbol,
        b.FUNDNAME name,
        a.end_date end_date,
        a.START_SHARE start_shares,
        a.APPL_SHARES purch_shares,
        a.REDEEM_SHARES redeem_shares,
        ifnull(a.END_SHARES,a.END_SHARES_MERGE) end_shares
        from FND_UNIT_CHNG a
        left join fnd_gen_info b
        on a.INNER_CODE  = b.INNER_CODE
        WHERE a.ISVALID = 1 AND b.ISVALID = 1
        {where_str}
        """
        sql = self.format(
                sql,
                innerCode=self.make_innerCode_concat(),
                where_str=where_str
                )

        results = self.mysql.fetchall(sql)
        self.upsert_mongo_data(results)
        self.update_task()

