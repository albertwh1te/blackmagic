# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"],
        "name": u"货基收益表",
    }

    def delete(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.enddate]},'-',a.vol_grd) _id
        FROM FND_MNY_INCM a
        
          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        WHERE a.ISVALID = 0
        AND b.fund_status = 1
        AND a.ENDDATE IS NOT NULL 
        AND a.vol_grd IS NOT NULL 
        {base_where}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            base_where=self._make_base_where(),
        )
        result = self.mysql.fetchall(sql)
        self.delete_mongo_data(result)

    def main(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.enddate]},'-',a.vol_grd) _id,
          {fund_base},
          {d2i[a.enddate]} end_date,
          {d2i[a.declaredate]} declare_date,
          a.tenthou_unit_incm,
          a.year_yld,
          a.nav,
          (SELECT fix_dep_1y
           FROM BND_RMB_INTR 
           WHERE EXECUTEDATE<=a.ENDDATE ORDER BY EXECUTEDATE DESC LIMIT 1) fix_dep_year
        FROM FND_MNY_INCM a
          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        WHERE a.ISVALID = 1 AND b.ISVALID = 1
        AND b.fund_status = 1
        {base_where}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            fund_base=self.make_fund_base_where(),
            base_where=self._make_base_where(),
        )
        print sql
        result = self.mysql.fetchall(sql)
        self.upsert_mongo_data(result)
