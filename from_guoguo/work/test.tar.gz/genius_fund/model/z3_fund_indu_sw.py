# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo
import datetime


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"],
        "name": u"基金所属行业表_申万标准",
    }

    def main(self):
        # tmp = {
        #     "sw_indu_name_1": None,
        #     "sw_indu_code_1": None,
        #     "innerCode": self.cur_code["innerCode"],
        #     "symbol": self.cur_code["symbol"],
        #     "name": self.cur_code["name"],
        #     "_id": self.cur_code["innerCode"],
        # }
        url = "http://%ip%/tp/zsfnd/gettag"
        args = {
            "code": self.cur_code["symbol"]
        }

        start = datetime.datetime.now()
        print "开始时间", start
        result = self.http.get(url=url, args=args)

        end = datetime.datetime.now()
        print "结束时间", end
        print "耗时", (end - start).microseconds
        if result["code"]:
            return

        industry_name = result["data"].get("industry_name", "")
        industry = result["data"].get("industry", "")
        if not industry_name or not industry:
            return
        indu_list = industry.split(",")
        indu_name_list = industry_name.split(",")
        data_list = []
        for k, v in enumerate(indu_list):
            data_list.append({
                "sw_indu_name_1": indu_name_list[k],
                "sw_indu_code_1": v,
                "innerCode": self.cur_code["innerCode"],
                "symbol": self.cur_code["symbol"],
                "name": self.cur_code["name"],
                "_id": "{}-{}".format(self.cur_code["innerCode"], v),
            })
        self.upsert_mongo_data(data_list)
