# coding: utf-8
"""
# @Time    : 2017/9/4 
# @Author  : liutao
# @File    : z3_fund_accum_yeild.py
# @Software: PyCharm
# @Descript: Z3_FUND_ACCUM_YEILD  , FUND_PERIOD_ACCUM_CALAVG 
"""
from model.baseinfo import BaseInfo
import random
import pymongo
import datetime
from dateutil.relativedelta import relativedelta


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"]
    }

    def int2date(self,date):
        """
        八位整数转换成日期
        :param date: 
        :return: 
        """
        tmp = datetime.datetime.strptime(str(date),"%Y%m%d")

        return datetime.datetime.strftime(tmp,"%Y-%m-%d")

    def get_date_month_diff(self,start_date,end_date):
        """
        获取两个日期之间相差的月份
        :return: 
        """
        sdate = datetime.datetime.strptime(str(start_date), '%Y%m%d')
        edate = datetime.datetime.strptime(str(end_date), '%Y%m%d')

        mthdiff = abs(edate.year - sdate.year) * 12 + (edate.month - sdate.month)*1

        # 开始日期未满一个月的不算一个月
        mthdiff = (mthdiff-1) if edate - relativedelta(months=mthdiff) < sdate else mthdiff

        return mthdiff

    def get_base_data(self):
        """
        从mongo Z3_FUND_STAT_PERIOD_YEILD 获取基础数据
        :return: 
        """
        # table = self.ttable
        periods = [1,2,3,4,6,8,9,0]
        # periods = [2, 3, 4]
        # periods = [1,6,8,9,0]
        # periods = [0]
        for p in periods:
            ftype = list(self.mongo.Z3_FUND_STAT_PERIOD_YEILD.distinct(
                "fund_type",
                {"stat_period":p,
                 # "fund_type":{"$not":{"$in":[3, 6]}}
                 }))
            for t in ftype:
            # for t in [5]:
                print "period", p, "type", t, "start"
                data = list(self.mongo.Z3_FUND_STAT_PERIOD_YEILD.find({
                    "stat_period": p,
                    "fund_type": t
                }))
                results = []
                for row in data:
                    # results = []
                    tmp = {}
                    tmp["_id"] = row.get("_id")
                    tmp["innerCode"] = row.get("innerCode")
                    tmp["symbol"] = row.get("symbol")
                    tmp["name"] = row.get("name")
                    tmp["fund_type"] = row.get("fund_type")
                    tmp["end_date"] = row.get("end_date")
                    tmp["start_date"] = row.get("start_date")
                    tmp["stat_period"] = row.get("stat_period")
                    tmp["stat_accum_yeild"] = row.get("stat_accum_yeild")
                    tmp["stat_accum_yeild_avg"] = row.get("stat_accum_yeild_avg")
                    tmp["stat_accum_yeild_rank"] = row.get("stat_accum_yeild_rank")
                    tmp["stat_fund_num"] = row.get("stat_fund_num")
                    # 货币型基金单独处理
                    if tmp.get("fund_type") in [3, 6]:
                        results.append(tmp)
                    else:
                        tmp["stat_accum_chg_pct_hs300"] = row.get("stat_accum_chg_pct_hs300")
                        tmp["stat_accum_chg_pct_sp500"] = row.get("stat_accum_chg_pct_sp500")
                        # 获取嵌套
                        tmp_data = self.get_nests_data(
                            row.get("symbol"),
                            row.get("start_date"),
                            row.get("end_date"),
                            row.get("stat_period"),
                            row.get("_id"),
                            row.get("fund_type")
                        )
                        tmp.update(tmp_data)
                        # 获取定投收益字段
                        invest = self.get_stat_auto_invest_yeild(
                            row["symbol"],
                            row.get("start_date"),
                            row.get("end_date"),
                            row.get("stat_period")
                        )
                        tmp.update(invest)
                        results.append(tmp)

                # print "period",p,"fund_type",t,len(results)
                self.upsert_mongo_data(results)

    def get_nests_data(self,symbol,start_date, end_date,stat_period,_id,fund_type):
        """
        计算嵌套字段
        :param start_date: 
        :param end_date: 
        :return: 
        """
        # print "symbol",symbol, datetime.datetime.now()
        if stat_period == 0:
            sql = """
            select {d2i[aa.TRADEDATE]} as trade_date
                   ,aa.accum_chg_pct_hs300
                   ,bb.accum_chg_pct_sp500
                   ,cc.accum_yeild
              from (
                  select a.TRADEDATE,a.SECCODE,a.INDX_SNAME
                        ,if(ifnull(b.TCLOSE,0) = 0,null,round((a.TCLOSE - b.TCLOSE)/b.TCLOSE * 100,2)) as accum_chg_pct_hs300
                     from pgenius.INDX_MKT a
                     join (select INNER_CODE,TCLOSE,TRADEDATE
                             from pgenius.INDX_MKT 
                            where ISVALID = 1 and SECCODE = '399300' and TRADEDATE < date({start_date})
                            order by TRADEDATE desc 
                            limit 1) b
                  on a.INNER_CODE = b.INNER_CODE 
                    where a.ISVALID = 1 
                      and a.SECCODE = '399300'
                      and a.TRADEDATE >= date({start_date}) and a.TRADEDATE <= date({end_date})
                  ) aa
             left JOIN
                  (select a.TRADEDATE 
                         ,if(ifnull(b.TCLOSE,0) = 0,0.0,round((a.TCLOSE - b.TCLOSE)/b.TCLOSE * 100,2)) as accum_chg_pct_sp500
                     from pgenius.MAC_WORLD_INDX_PRC a
                     join (select inner_code,TCLOSE,TRADEDATE
                             from pgenius.MAC_WORLD_INDX_PRC
                            where isvalid = 1 and inner_code=106001932
                              and TRADEDATE < date({start_date})
                                       order by TRADEDATE desc
                                       limit 1  
                          ) b
                     on a.inner_code = b.inner_code
                  where a.isvalid = 1 
                    and a.inner_code=106001932
                    and a.TRADEDATE >= date({start_date}) and a.TRADEDATE <= date({end_date})
                   ) bb
               on aa.TRADEDATE = bb.TRADEDATE
             left join
                  (select a.TRADEDATE
                         ,if(ifnull(b.BOOK_VAL,0) = 0,null,round((a.FAC_UNIT_NET - b.BOOK_VAL)/b.BOOK_VAL*100,2)) as accum_yeild 
                     from pgenius.ANA_FND_NAV_CALC a
                     join pgenius.FND_OEF_ISS b
                     on a.INNER_CODE = b.inner_code and b.isvalid = 1
                  where a.isvalid = 1 
                    and a.FUND_CODE='{symbol}'
                    and a.TRADEDATE >= date({start_date}) and a.TRADEDATE <= date({end_date})
                   group by a.TRADEDATE
                  ) cc
               on aa.TRADEDATE = cc.TRADEDATE
               order by aa.TRADEDATE
            """
        else:
            sql = """
              select {d2i[aa.TRADEDATE]} as trade_date
                     ,aa.accum_chg_pct_hs300
                     ,bb.accum_chg_pct_sp500
                     ,cc.accum_yeild
                from (
                    select a.TRADEDATE,a.SECCODE,a.INDX_SNAME
                          ,if(ifnull(b.TCLOSE,0) = 0,null,round((a.TCLOSE - b.TCLOSE)/b.TCLOSE * 100,2)) as accum_chg_pct_hs300
                       from pgenius.INDX_MKT a
                       join (select INNER_CODE,TCLOSE,TRADEDATE
                               from pgenius.INDX_MKT 
                              where ISVALID = 1 and SECCODE = '399300' and TRADEDATE < date({start_date})
                              order by TRADEDATE desc 
                              limit 1) b
                    on a.INNER_CODE = b.INNER_CODE 
                      where a.ISVALID = 1 
                        and a.SECCODE = '399300'
                        and a.TRADEDATE >= date({start_date}) and a.TRADEDATE <= date({end_date})
                    ) aa
               left JOIN
                    (select a.TRADEDATE 
                           ,if(ifnull(b.TCLOSE,0) = 0,0.0,round((a.TCLOSE - b.TCLOSE)/b.TCLOSE * 100,2)) as accum_chg_pct_sp500
                       from pgenius.MAC_WORLD_INDX_PRC a
                       join (select inner_code,TCLOSE,TRADEDATE
                               from pgenius.MAC_WORLD_INDX_PRC
                              where isvalid = 1 and inner_code=106001932
                                and TRADEDATE < date({start_date})
                                         order by TRADEDATE desc
                                         limit 1  
                            ) b
                       on a.inner_code = b.inner_code
                    where a.isvalid = 1 
                      and a.inner_code=106001932
                      and a.TRADEDATE >= date({start_date}) and a.TRADEDATE <= date({end_date})
                     ) bb
                 on aa.TRADEDATE = bb.TRADEDATE
               left join
                    (select a.TRADEDATE
                           ,if(b.FAC_UNIT_NET = 0,0.00,round((a.FAC_UNIT_NET - b.FAC_UNIT_NET)/b.FAC_UNIT_NET*100,2)) as accum_yeild 
                       from pgenius.ANA_FND_NAV_CALC a
                       join (select INNER_code ,FAC_UNIT_NET,TRADEDATE
                               from pgenius.ANA_FND_NAV_CALC 
                              where isvalid = 1 and FUND_CODE='{symbol}'
                                and TRADEDATE < date({start_date})
                              order by TRADEDATE desc
                              limit 1  ) b
                       on a.INNER_CODE = b.inner_code
                    where a.isvalid = 1 
                      and a.FUND_CODE='{symbol}'
                      and a.TRADEDATE >= date({start_date}) and a.TRADEDATE <= date({end_date})
                    ) cc
                 on aa.TRADEDATE = cc.TRADEDATE
                 order by aa.TRADEDATE
                """

        sql = self.format(
            sql,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date
        )
        datas = self.mysql.fetchall(sql)
        # print sql
        # print "symbol",symbol,datetime.datetime.now()

        # 如果基金当日无累计收益率 处理成前一日的收益率
        dds = []
        dcal = []
        trade_date_num = len(datas)
        for index,row in enumerate(datas):
            tmp = {}
            datas[0]["accum_yeild"] = 0.00 if not datas[0]["accum_yeild"] else datas[0]["accum_yeild"]
            if row.get("accum_yeild",0) == 0:
                row["accum_yeild"] = datas[index-1]["accum_yeild"] if index<>0 else 0.00
            dds.append(row)

            tmp.update(row)
            # tmp = row.deepcopy()
            tmp["symbol"] = symbol
            tmp["_id"] = _id+'-'+str(row["trade_date"])
            tmp["fund_type"] = fund_type
            tmp["stat_period"] = stat_period
            dcal.append(tmp)

        # 处理成嵌套
        result = {
            "trade_date_num": trade_date_num,
            "data":[]
        }
        result["data"].extend(dds)

        # 嵌套的数据放入临时表中，方便计算平均值
        self.mongo["FUND_PERIOD_ACCUM_CALAVG"].remove({"symbol": symbol, "stat_period": stat_period})
        if dcal:
            self.mongo["FUND_PERIOD_ACCUM_CALAVG"].insert_many(dcal)
        # for rr in dcal:
        #     tt = rr
        #     tt["mtime"] = datetime.datetime.now()
        #     filter = {"_id": rr["_id"]}
            # self.mongo["FUND_PERIOD_ACCUM_CALAVG"].update(filter,{"$set": tt}, upsert=True, multi=True)

        return result

    def get_nests_avg(self,stat_period,fund_type):
        """
        计算嵌套字段的平均值accum_yeild_avg
        :return: 
        """
        # 获取区间类所有交易日期
        tds = list(self.mongo["FUND_PERIOD_ACCUM_CALAVG"].distinct(
               "trade_date",
            {"stat_period": stat_period,
            "fund_type": fund_type}
        ))
        results = {}
        for d in tds:
            results.setdefault(d, {})
            tmp = {}
            base = list(self.mongo["FUND_PERIOD_ACCUM_CALAVG"].find({
                "stat_period": stat_period,
                "fund_type": fund_type,
                "trade_date": d,
                # "accum_yeild":{"$exists": True}
            }
            ))
            all = 0.0
            for i in base:
                all = all + i.get("accum_yeild", 0.0) if i.get("accum_yeild", 0.0) else all + 0

            avg = all/len(base) if base else None
            tmp = {"accum_yeild_avg":round(avg,2)}
            results[d].update(tmp)

        # print results
        return results

    def get_nests_avg02(self,stat_period,fund_type,trade_date):
        """
        计算嵌套字段的平均值accum_yeild_avg
        :return: 
        """
        base = list(self.mongo["FUND_PERIOD_ACCUM_CALAVG"].find({
            "stat_period": stat_period,
            "fund_type": fund_type,
            "trade_date": trade_date,
            # "accum_yeild":{"$exists": True}
        }
        ))

        print "trade_date",trade_date
        all = 0.0

        for i in base:
            if trade_date == 20170823:
                print "sososo", i.get("accum_yeild", 0.0),i
            all = all + i.get("accum_yeild", 0.0) if i.get("accum_yeild", 0.0) else all + 0
        avg = all/len(base) if base else None

        return round(avg,2)

    def cal_accum_yeild_avg(self,period,fund_type,end_date):
        """
        计算同类平均累计收益率accum_yeild_avg
        :param period: 
        :param fund_type: 
        :param end_date: 
        :return: 
        """
        bs_data = list(self.mongo[self.ttable].find({
            "stat_period":period,"fund_type":fund_type,
            "data.trade_date":end_date
            },
            {"_id": 1, "data": 1}))
        pcts = []
        avg_data = {}
        avg_data.setdefault("")
        for row in bs_data:
            for row2 in row["data"]:
                pcts.append(row2.get("accum_yeild", 0.0)) if row2["trade_date"] == end_date else None

        tmp = {"accum_yeild_avg": round(sum(pcts)/len(pcts), 2)}

    def get_stat_auto_invest_yeild(self,fund_code,start_date,end_date,period):
        """
        计算统计区间定投收益
        :param fund_code: 
        :param start_date: 
        :param end_date: 
        :return: 
        """
        rate = 0.00
        if period in [1, 3, 5]:
            ms = period*12
            for i in range(ms):
                sql = """
                select aa.TRADEDATE,ifnull((aa.FAC_UNIT_NET-bb.FAC_UNIT_NET)/bb.FAC_UNIT_NET*100,0.00) as invest_yeild
                      from (select a.INNER_CODE,a.TRADEDATE,a.FAC_UNIT_NET
                        from pgenius.ANA_FND_NAV_CALC a
                       where a.ISVALID = 1
                         and a.TRADEDATE <= date('{end_date}')
                         and a.FUND_CODE = '{fund_code}'
                        order by a.TRADEDATE desc
                       limit 1) aa
                      join (
                        select a.INNER_CODE,a.TRADEDATE,a.FAC_UNIT_NET
                        from pgenius.ANA_FND_NAV_CALC a
                       where a.ISVALID = 1
                         and a.TRADEDATE <= DATE_SUB(date('{end_date}'),INTERVAL  {m} month)
                         and a.FUND_CODE = '{fund_code}'
                        order by a.TRADEDATE desc
                       limit 1
                    ) bb
                       on aa.inner_code = bb.inner_code
                     join pgenius.fnd_gen_info c
                       on aa.inner_code = c.inner_code 
                    where c.ISVALID = 1
                      and c.FUND_CODE = '{fund_code}'
                      and c.FUND_STATUS = 1
                      and c.ESTAB_DATE <= DATE_SUB(date('{end_date}'),INTERVAL {m}+1 month)
                    """.format(
                    fund_code=fund_code,
                    end_date=end_date,
                    m=i+1
                )
                # print sql
                data = self.mysql.fetchone(sql)
                if data:
                    rate += data.get("invest_yeild",0.00)

            tmp = {"stat_auto_invest_yeild": round(rate/ms, 2)}

        elif period == 0:
            ms = self.get_date_month_diff(start_date, end_date)
            if ms <12:
                tmp =  {"stat_auto_invest_yeild": None}
            else:
                for i in range(ms):
                    sql01 = """
                        select aa.TRADEDATE
                              ,ifnull((aa.FAC_UNIT_NET-bb.FAC_UNIT_NET)/bb.FAC_UNIT_NET*100,0.0) as invest_yeild
                          from (select a.INNER_CODE,a.TRADEDATE,a.FAC_UNIT_NET
                            from pgenius.ANA_FND_NAV_CALC a
                           where a.ISVALID = 1
                             and a.TRADEDATE <= date('{end_date}')
                             and a.FUND_CODE = '{fund_code}'
                            order by a.TRADEDATE desc
                           limit 1) aa
                          join (
                            select a.INNER_CODE,a.TRADEDATE,a.FAC_UNIT_NET
                            from pgenius.ANA_FND_NAV_CALC a
                           where a.ISVALID = 1
                             and a.TRADEDATE <= DATE_SUB(date('{end_date}'),INTERVAL  {m} month)
                             and a.FUND_CODE = '{fund_code}'
                            order by a.TRADEDATE desc
                           limit 1
                        ) bb
                           on aa.inner_code = bb.inner_code
                         join pgenius.fnd_gen_info c
                           on aa.inner_code = c.inner_code 
                        where c.ISVALID = 1
                          and c.FUND_CODE = '{fund_code}'
                          and c.FUND_STATUS = 1
                          and c.ESTAB_DATE <= DATE_SUB(date('{end_date}'),INTERVAL {m}+1 month)
                        """.format(
                        fund_code=fund_code,
                        end_date=end_date,
                        m=i+1
                    )

                    sql02 = """
                      select a.INNER_CODE,a.TRADEDATE,a.FAC_UNIT_NET,b.BOOK_VAL
                            ,if(IFNULL(b.BOOK_VAL,0)=0,0.00,(a.FAC_UNIT_NET - b.BOOK_VAL) / b.BOOK_VAL*100)
                        from pgenius.ANA_FND_NAV_CALC a
                        join pgenius.FND_OEF_ISS b
                          on a.INNER_CODE = b.INNER_CODE and b.ISVALID = 1
                       where a.ISVALID = 1
                         and a.TRADEDATE <= date('{end_date}')
                         and a.FUND_CODE = '{fund_code}'
                        order by a.TRADEDATE desc
                       limit 1
                    """.format(
                        fund_code=fund_code,
                        end_date=end_date,
                        m=i+1
                    )
                    if i < ms - 1:
                        data = self.mysql.fetchone(sql01)
                    else:
                        data = self.mysql.fetchone(sql02)

                    if data: rate += data.get("invest_yeild",0.00)
                tmp = {"stat_auto_invest_yeild": round(rate / ms, 2)}

        else:
            tmp = {"stat_auto_invest_yeild": None}

        # print "result",tmp
        return tmp

    def get_http_getfndval_data(self,fund_code,stat_period):
        """
        从接口获取 1,3,5年度的数据    
        :return: 
        """
        period_trans = {
            "4": 1,
            "6": 3,
            "8": 5
        }
        pkey = "{stat_period}".format(stat_period=stat_period)
        prd = period_trans.get(pkey,None)

        # print "tttttttttttt",prd
        url= "http://%ip%/tp/zsfnd/getfndval"
        # print "vvvvvvvvv", code
        args = {
            "code": fund_code
        }

        bs_data = self.http.get(url=url, args=args)
        tmp = {}

        if bs_data["code"] <> 0:
            print "error"
            return tmp

        if bs_data["data"]:
            for row in bs_data["data"]:
                if row["cycle"] == prd:
                    tmp = {
                        "stat_sharpe_ratio":row.get("sharpe", None),
                        "stat_max_drawdown": row.get("drawdown", None),
                        "stat_ex_yield":row.get("excess", None)
                    }

        return tmp

    def get_http_gettrend_data(self,fund_code,start_date,end_date):
        """
        计算统计区间超额收益，统计区间JRJ基金评价
        http://%ip%/tp/zsfnd/gettrend 
        :param symbol: 
        :param start_date: 
        :param end_date: 
        :return: 
        """
        args={
            "code":fund_code,
            "start":self.int2date(start_date),
            "end_date":self.int2date(end_date)

        }
        url="http://%ip%/tp/zsfnd/gettrend"
        # print "jrj_rank", row["symbol"], "start", datetime.datetime.now()
        tmp = {}
        try:

            hdata = self.http.get(url=url, args=args)
            # print "jrj_rank", row["symbol"], "end", datetime.datetime.now()
            # print hdata
            if hdata["code"] == 0:
                tmp["stat_ex_yield"] = hdata["data"].get("excess", None)
                tmp["stat_jrj_fund_rank"] = hdata["data"].get("score", None)
            # print tmp
            return tmp
        except Exception as e:
            # hdata = e
            print "get_http_gettrend_data error"
            return tmp
        # print hdata


        # self.upsert_mongo_data(result)

    def get_http_getstats_data(self,fund_code,start_date,end_date):
        """
        计算 统计区间夏普比率，统计区间波动率，统计区间最大回撤
        http://%ip%/tp/zhds/getstats
        :param stat_period: 
        :return: 
        """
        d1 = datetime.datetime.strptime(str(start_date), '%Y%m%d')
        delta = datetime.timedelta(days=1)
        d2 = d1 - delta
        start_date = datetime.datetime.strftime(d2, '%Y-%m-%d')
        # print start_date
        tmp = {}
        try:
            hdata = self.get_api_getstats(
                sdate=start_date,
                edate=self.int2date(end_date),
                FUND_CODE=fund_code
            )
            # print row["symbol"], "end", datetime.datetime.now()
            if hdata["code"] == 0:
                tmp["stat_sharpe_ratio"] = float(hdata["data"].get("sharpe_ratio")) \
                    if hdata["data"].get("sharpe_ratio") and hdata["data"].get("sharpe_ratio") <> 'NaN' else None
                tmp["stat_volat"] = float(hdata["data"].get("sd1", None)) \
                    if hdata["data"].get("sd1") and hdata["data"].get("sd1") <> "NaN" else None
                tmp["stat_max_drawdown"] = float(hdata["data"].get("max_dd", None)) \
                    if hdata["data"].get("max_dd") and hdata["data"].get("max_dd") <> "NaN" else None

            return tmp
        except Exception as e:
            print "get_api_getstats error",e

            return tmp

    def get_currency_stat_volat(self,fund_code,start_date,end_date):
        """
        计算货币式基金的区间波动率
        :return: 
        """
        sql="""
        select 	TENTHOU_UNIT_INCM as pct
            from pgenius.FND_MNY_INCM a
            join pgenius.fnd_gen_info b 
              on a.inner_code = b.inner_code and b.isvalid = 1
         where a.isvalid = 1
             and a.TENTHOU_UNIT_INCM is not null
             and a.enddate >= '{start_date}'
             and a.enddate <= '{end_date}'
             and b.fund_code = '{fund_code}'
        order by enddate
        """.format(
            fund_code=fund_code,
            start_date=self.int2date(start_date),
            end_date=self.int2date(end_date)
        )
        results = self.mysql.fetchall(sql)
        pct_list = "|".join(map(lambda i: str(i["pct"]), results))
        datas = self.http.post(
            url="http://%ip%/tp/zhds/getstats",
            args={
                "rets": pct_list,
                "start": self.int2date(start_date),
                "end": self.int2date(end_date),
            }
        )
        return datas

    def get_http_data(self):
        """
        调用其他自定义函数生成稍复杂数据
        :return: 
        """
        ptype = list(self.mongo[self.ttable].distinct("stat_period"
                                                      # {"stat_period":{"$in":[]}}
                                                      ))

        # ptype = [2]
        for p in ptype:
            ftype = list(self.mongo[self.ttable].distinct("fund_type",{"stat_period":p}))
            # ftype = [11]
            for f in ftype:
                bs_data = list(self.mongo[self.ttable].find({
                    "stat_period":p,
                    "fund_type":f
                },
                {"_id":1, "symbol":1, "start_date":1, "end_date": 1,
                 "fund_type":1,"stat_period":1,"data":1}))
                print "ppp", p, "fff", f,datetime.datetime.now()
                # 计算该类型该区间的accum_yeild_avg
                nest_avgs = self.get_nests_avg(p, f) if p <> 0 else None
                results = []
                for row in bs_data:
                    tmp = {}
                    # data1 = self.get_http_getfndval_data(row["symbol"], p)
                    data2 = self.get_http_gettrend_data(row["symbol"], row["start_date"], row["end_date"])
                    data3 = self.get_http_getstats_data(row["symbol"], row["start_date"], row["end_date"])
                    data_curr = self.get_currency_stat_volat(row["symbol"], row["start_date"], row["end_date"])

                    # 货币型基金单独处理
                    if row["fund_type"] in [3, 6]:
                        row["stat_volat"] = data_curr.get("stat_volat", None)
                        row["stat_jrj_fund_rank"] = data2.get("stat_jrj_fund_rank", None)
                    else:
                        row["stat_sharpe_ratio"] = data3.get("stat_sharpe_ratio", None)
                        row["stat_max_drawdown"] = data3.get("stat_max_drawdown", None)
                        row["stat_volat"] = data3.get("stat_volat", None)
                        row["stat_ex_yield"] = data2.get("stat_ex_yield", None)
                        row["stat_jrj_fund_rank"] = data2.get("stat_jrj_fund_rank", None)

                        # 计算 accum_yeild_avg
                        # print "ID",row["_id"]
                        if row["stat_period"] <> 0:
                            for i in row["data"]:
                                i.update(nest_avgs.get(i["trade_date"], {"accum_yeild_avg":None}))
                    results.append(row)
                self.upsert_mongo_data(results)

    def delete(self):
        pass
        print "delete table ",self.ttable
        # self.mongo[self.ttable].remove({})

    def main(self):
        """
        不能多线程跑数
        :return: 
        """

        print "base start" ,datetime.datetime.now()
        self.get_base_data()
        print "http start",datetime.datetime.now()
        self.get_http_data()
        print "all end", datetime.datetime.now()

        # self.get_stat_auto_invest_yeild("000001",20140909,20170908,3)

        # print self.get_nests_avg02(1,11)


