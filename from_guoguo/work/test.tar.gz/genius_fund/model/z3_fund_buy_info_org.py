# coding: utf-8
from model.baseinfo import BaseInfo
import random
import pymongo
from dateutil import relativedelta
from datetime import datetime
import numpy as np

datetimetoint = lambda x:10000*x.year + 100*x.month + x.day
datetimetostr = lambda x:x.strftime("%Y-%m-%d")

def cal_innercode(info):
    symbol = str(info['_id'])
    if symbol.startswith("1"):
        innercode = symbol + ".SZ"
    elif symbol.startswith("5"):
        innercode = symbol + ".SH"
    else:
        innercode = symbol + ".CW"
    return innercode

def cal_main_key(info):
    innercode = cal_innercode(info)
    info.update({
        "_id":innercode+"-"+"200180365",
        "innerCode":innercode,
        })
    return info

def add_org_about(info):
    info.update({
        "org_code":200180365,
        "org_name":"中国金融在线有限公司"
        })
    return info

def format_data(info):
    info.update({
        "symbol":info.get("_id"),
        "name":info.pop("fundname"),
        "first_buy_min":info.pop("firstbuymin"),
        "first_buy_max":info.pop("firstbuymax"),
        "buy_max":info.pop("buymax"),
        "buy_min":info.pop("buymin"),
        "hold_min":info.pop("holdmin"),
        "sell_min":info.pop("sellmin"),
        "sell_max":info.pop("sellmax"),
        "change_min":info.pop("changemin"),
        "change_max":info.pop("changemax"),
        "plain_min":info.pop("planmin"),
        "plain_max":info.pop("planmax"),
        "day_buy_max":info.pop("daybuymax"),
        "risk_level":info.pop("risklevel"),
        "charge_rate":info.pop("chargerate"),
        "buy_day":info.pop("buyday"),
        "sell_day":info.pop("sellday"),
        "pay_day":info.pop("payday"),
        })
    return info

#class Z3_FUND_BUY_INFO_ORG(BaseInfo):
class Main(BaseInfo):
    info = {
        "pri_key": ["_id"]
    }
    def main(self):
        raw = list(self.mongo.Z3_YLB_FUND_INFO.find({}))

        raw = map(format_data,raw)
        raw = map(cal_main_key,raw)
        raw = map(add_org_about,raw)

#        import ipdb; ipdb.set_trace()
        print(raw[20:21])
        results = raw

        self.upsert_mongo_data(results)
        self.update_task()



