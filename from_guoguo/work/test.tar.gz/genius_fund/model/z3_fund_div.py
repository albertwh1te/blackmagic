# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"],
        "name": u"基金分红表",
    }

    def delete(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.enddate]},'-',a.decl_cls,'-',a.rank) _id
        FROM fnd_div a

          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        WHERE a.ISVALID = 0
        AND b.fund_status = 1
        AND a.ENDDATE IS NOT NULL 
        AND a.decl_cls IS NOT NULL 
        AND a.rank IS NOT NULL 
        {base_where}

        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            base_where=self._make_base_where(),
        )
        result = self.mysql.fetchall(sql)
        self.delete_mongo_data(result)

    def main(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.enddate]},'-',a.decl_cls,'-',a.rank) _id,
          {fund_base},
          {d2i[a.record_date]} record_date,
          {d2i[a.ex_div_date]} ex_div_date,
          {d2i[a.declaredate]} declare_date,
          {d2i[a.enddate]} end_date,
          a.decl_cls,
          a.div,
          a.rank
        FROM fnd_div a

          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        WHERE a.ISVALID = 1 AND b.ISVALID = 1 AND a.DECL_CLS=2
        AND b.fund_status = 1
        {base_where}

        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            fund_base=self.make_fund_base_where(),
            base_where=self._make_base_where(),
        )
        result = self.mysql.fetchall(sql)
        self.upsert_mongo_data(result)
