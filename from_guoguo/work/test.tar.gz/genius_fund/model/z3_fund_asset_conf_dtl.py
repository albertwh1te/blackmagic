# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_equity.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo
from common import digit


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"],
        "name": u"基金投资组合资产配置明细表",
    }
    where_config = {
        "onecode": {
            "tb_filed": "FUND_ID",
            "dict_filed": "FUND_ID",
        }
    }
    thread_list = 'get_fundid_list'

    def main(self):
        sql = """
          SELECT
              concat({innerCode},'-',{d2i[a.enddate]}) _id,
              {fund_base},
              b.fund_id,
              {d2i[a.enddate]} end_date,
              a.STK_VAL stk_val_total,
              a.HLD_FND_VAL fnd_val_total,
              a.BND_VAL bnd_val_total,
              a.STK_VAL_NA_PROP stk_val_na_pct,
              a.HLD_FND_VAL_NA_PROP fnd_val_na_pct,
              a.BND_VAL_NA_PROP bnd_val_na_pct,
              a.DEP_VAL_NA_PROP dep_val_na_pct,
              100-ifnull(a.STK_VAL_NA_PROP,0)
              -ifnull(a.HLD_FND_VAL_NA_PROP,0)
              -ifnull(a.BND_VAL_NA_PROP,0)
              -ifnull(a.DEP_VAL_NA_PROP,0) oth_val_na_pct,
              a.source
          FROM FND_ASSET_CONF a
          LEFT JOIN fnd_gen_info b
            ON a.FUND_ID = b.FUND_ID
        
          WHERE a.isvalid = 1 AND a.SOURCE = (
            SELECT max(SOURCE)
            FROM FND_ASSET_CONF c
            WHERE c.FUND_ID = a.FUND_ID AND c.ENDDATE = a.ENDDATE
            AND c.ISVALID = 1
            AND b.FUND_STATUS = 1
          )
        {base_where}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            fund_base=self.make_fund_base_where(),
            base_where=self._make_base_where(self.where_config),
        )
        print sql
        result = self.mysql.fetchall(sql)

        indu_sql = """
            SELECT 
                indu_code,
                indu_sname,
                SECT_VAL indu_val,
                SECT_VAL_PROP indu_val_pct
            FROM FND_INDU_SUM_CONF a 
            WHERE a.ISVALID=1
            AND a.FUND_ID={fund_id}
            AND a.ENDDATE='{end_date}'
            AND a.SOURCE={source}
            ORDER BY indu_val DESC
        """
        stk_sql = """
          SELECT
          stockcode,
          stocksname,
          HLD_STK_VAL                  stk_val,
          TOT_VAL_PROP                 stk_val_pct,
          a.HLD_STK_SUM - ifnull((SELECT HLD_STK_SUM
                                  FROM FND_STK_SUM_CONF b
                                  WHERE b.ISVALID = 1
                                        AND b.FUND_ID = {fund_id}
                                        AND b.STOCKCODE = a.STOCKCODE
                                        AND b.ENDDATE < '{end_date}'
                                  ORDER BY b.ENDDATE DESC, b.SOURCE DESC
                                  LIMIT 1
                                 ), 0) chg_vol
            FROM FND_STK_SUM_CONF a
            WHERE a.ISVALID = 1
                  AND a.FUND_ID = {fund_id}
                  AND a.ENDDATE = '{end_date}'
                  AND a.SOURCE = {source}
            ORDER BY stk_val DESC
        """
        bnd_sql = """
            SELECT 
                bondcode,
                bondsname,
                TOT_VAL bnd_val,
                TOT_VAL_PROP bnd_val_pct
            FROM FND_BND_CONF a 
            WHERE a.ISVALID=1
            AND a.FUND_ID={fund_id}
            AND a.ENDDATE='{end_date}'
            AND a.SOURCE={source}
            ORDER BY bnd_val DESC
        """
        bnd_type_sql = """
            SELECT 
                bnd_type,
                BND_TYPE_MARK bnd_type_name,
                TOT_VAL bnd_val,
                TOT_VAL_PROP bnd_val_pct_bt
            FROM FND_BND_TYPE_CONF a 
            WHERE a.ISVALID=1
            AND a.FUND_ID={fund_id}
            AND a.ENDDATE='{end_date}'
            AND a.SOURCE={source}
            ORDER BY bnd_val DESC
        """
        # print len(result)
        z = 0
        for row in result:
            z += 1
            # print z
            # print indu_sql.format(**row)
            indu = self.mysql.fetchall(indu_sql.format(**row))
            # print indu
            # print stk_sql.format(**row)
            stk = self.mysql.fetchall(stk_sql.format(**row))
            # print stk
            # print bnd_sql.format(**row)
            bnd = self.mysql.fetchall(bnd_sql.format(**row))
            # print bnd
            # print bnd_type_sql.format(**row)
            bnd_type = self.mysql.fetchall(bnd_type_sql.format(**row))
            # print bnd_type
            row["stk_num"] = len(stk)
            row["indu_num"] = len(indu)
            row["bnd_num"] = len(bnd)
            row["bnd_type_num"] = len(bnd_type)
            row["stk_conf"] = stk
            row["indu_conf"] = indu
            row["bnd_conf"] = bnd
            row["bnd_type_conf"] = bnd_type
            sum_stk = round(sum([digit(i["stk_val"]) for i in stk[:10]]), 2)
            sum_bnd = round(sum([digit(i["bnd_val"]) for i in bnd[:10]]), 2)
            sum_bnd_type = round(sum([digit(i["bnd_val"]) for i in bnd_type[:5]]), 2)
            sum_indu = round(sum([digit(i["indu_val"]) for i in indu[:5]]), 2)
            # print 'a', (sum_stk)
            # print 'b', (row["stk_val_total"])
            row["stk_conc_ratio"] = round(float(sum_stk) / float(row["stk_val_total"]), 2) if row[
                "stk_val_total"] else None
            # print row["stk_conc_ratio"]
            row["bnd_conc_ratio"] = round(float(sum_bnd) / float(row["bnd_val_total"]), 2) if row[
                "bnd_val_total"] else None
            row["bnd_type_conc_ratio"] = round(float(sum_bnd_type) / float(row["bnd_val_total"]), 2) if row[
                "bnd_val_total"] else None
            row["indu_conc_ratio"] = round(float(sum_indu) / float(row["stk_val_total"]), 2) if row[
                "stk_val_total"] else None
            # del row['source']
        self.upsert_mongo_data(result)
