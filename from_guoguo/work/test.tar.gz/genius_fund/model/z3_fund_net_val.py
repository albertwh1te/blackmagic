# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"],
        "name": u"基金净值表",
    }

    def delete(self):
        sql = """
                SELECT
                  concat({innerCode},'-',{d2i[a.enddate]}) _id
                FROM FND_NET_VAL a

                  LEFT JOIN fnd_gen_info b
                    ON a.INNER_CODE = b.INNER_CODE
                WHERE a.ISVALID = 0
                AND b.fund_status = 1 AND a.enddate IS NOT NULL
                {base_where}
                """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            base_where=self._make_base_where(),
        )
        result = self.mysql.fetchall(sql)
        self.delete_mongo_data(result)

    def main(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.enddate]}) _id,
          {fund_base},
          {d2i[a.declaredate]} declare_date,
          {d2i[a.enddate]} end_date,
          round(a.unit_net,4) unit_net,
          round(a.accum_net,4) accum_net,
          round(a.nav,2) nav,
          round(c.UNIT_NET_CHNG_PCT,2) chg_pct
        FROM FND_NET_VAL a
          
          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
          LEFT JOIN ANA_FND_NAV_CALC c
            ON a.INNER_CODE = c.INNER_CODE
            AND a.ENDDATE = c.TRADEDATE
        WHERE a.ISVALID = 1 AND b.ISVALID = 1 AND c.ISVALID = 1
        AND b.fund_status = 1
        {base_where}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            fund_base=self.make_fund_base_where(),
            base_where=self._make_base_where(),
        )
        print sql
        result = self.mysql.fetchall(sql)
        self.upsert_mongo_data(result)
