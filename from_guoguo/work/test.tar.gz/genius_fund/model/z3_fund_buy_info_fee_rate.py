# coding: utf-8
from model.baseinfo import BaseInfo
import random
import pymongo
from dateutil import relativedelta
from datetime import datetime
import numpy as np
import re


datetimetoint = lambda x:10000*x.year + 100*x.month + x.day
datetimetostr = lambda x:x.strftime("%Y-%m-%d")
inttodatetime = lambda x:datetime.datetime.strptime(str(x), '%Y%m%d')

def add_unit(num,unit):
    if num and unit:
        return str(num)+unit
    return None


class Main(BaseInfo):
    info = {
        "pri_key": ["_id"]
    }

    def get_field_data(self,field,max_term,info):
        """
        get field data from table fnd_chag_rate
        """
        data = None
        sql = """
        select {field}
        from FND_CHAG_RATE a
        where CHNG_MAX_TERM={max_term}
        and a.DECLAREDATE = "{declaredate}"
        and a.INNER_CODE  = "{innercode}"
        """.format(
                field=field,
                max_term= max_term,
                innercode = info['true_innercode'],
                declaredate= datetimetostr(info.get("declare_date")),
                )
        raw = self.mysql.fetchone(sql)
        if raw:
            data = raw[field]
        return data


    def cal_ref_name1(self,info,join_field,cls_code):
        sql = """
        select b.cls_code,b.ref_name
        from fnd_chag_rate a
        left join GEN_REF b
        on a.{join_field}=b.REF_CODE
        where b.cls_code= {cls_code}
        and a.DECLAREDATE = "{declaredate}"
        and a.INNER_CODE  = "{innercode}"
        """.format(
                innercode = info['true_innercode'],
                declaredate= datetimetostr(info.get("declare_date")),
                join_field =join_field,
                cls_code = cls_code,
                )

        #we only need one unit
        raw = self.mysql.fetchone(sql)
        if raw:
            return raw.get("ref_name",None)
        return None


    def cal_run_fee(self,info):
        manage_fee = trustee_fee = sales_service_charge = None
        ref_name1 = self.cal_ref_name1(info,"CHAG_RATE_RELA","3028")
        if ref_name1:
            manage_fee = add_unit(self.get_field_data("CHAG_RATE_UP_LIM",1,info),ref_name1)
            trustee_fee = add_unit(self.get_field_data("CHAG_RATE_UP_LIM",2,info),ref_name1)
            sales_service_charge = add_unit(self.get_field_data("CHAG_RATE_UP_LIM",3,info),ref_name1)
        info.update({
            "ref_name1":ref_name1,
            "manage_fee":manage_fee,
            "trustee_fee":trustee_fee,
            "sales_service_charge":sales_service_charge
            })
        print(ref_name1,manage_fee)
        return info


    def cal_range_str_value(self,info,term_name,term_value,flag_name,show_name,value_name,ref_name3,ref_name2,ref_name1):

        results_list = []
        sql = """
        select a.{value_name},a.{flag_name},a.{show_name}
        from FND_CHAG_RATE a
        left join GEN_REF b
        on a.CHAG_RATE_RELA=b.REF_CODE
        where a.{term_name} = {term_value}
        and a.{value_name} is not null
        and a.{flag_name} is not null
        and a.{show_name} is not null
        and a.DECLAREDATE = "{declaredate}"
        and a.INNER_CODE  = "{innercode}"
        """.format(
                show_name= show_name,
                value_name =value_name,
                flag_name =flag_name,
                term_name =term_name,
                term_value =term_value,
            innercode = info['true_innercode'],
            declaredate= datetimetostr(info.get("declare_date")),
        )
        raws = self.mysql.fetchall(sql)
        if raws:
            for raw in raws:
                range_value = fee_rate = None
                if raw[flag_name] == 6:
                    range_value = str(raw[show_name]) + str(raw[flag_name]) + str(ref_name3.encode('utf-8')) + str(raw[flag_name])+str(ref_name2.encode('utf-8'))
                else:
                    range_value = str(raw[show_name]) + str(raw[flag_name]) + str(ref_name3.encode('utf-8'))
                fee_rate = str(raw[value_name]) + str(ref_name1.encode('utf-8'))
                results_list.append({
                    "range":range_value,
                    "fee_rate":fee_rate
                    })
        return results_list



    def cal_back_end_purch_fee(self,info):
        back_end_purch_fee_list = []
        ref_name1 = info.get("ref_name1",None)
        ref_name4 = self.cal_ref_name1(info,"HLD_TERM_UNIT","1064")
        ref_name5 = self.cal_ref_name1(info,"TERM_COND_RELA","3029")
        if ref_name4 and ref_name5:
            back_end_purch_fee_list = self.cal_range_str_value(
                    info=info,
                    term_name="CHNG_MIN_TERM",
                    term_value="501",
                    flag_name="CHAG_RATE_RELA",
                    show_name="PERT_VAL_LOW_LIM",
                    value_name="HLD_TERM_UP_LIM",
                    ref_name1=ref_name1,
                    ref_name2=ref_name4,
                    ref_name3=ref_name5)
        info.update(
                {
                    "back_end_purch_fee":back_end_purch_fee_list,
                    }
                )
        return info


    def cal_purchase_fee(self,info):

        purchase_list=redeem_list = subscrip_fee_list = []
        ref_name1 = info.get("ref_name1",None)
        ref_name2 = self.cal_ref_name1(info,"PERT_VAL_UNIT","3030")
        ref_name3 = self.cal_ref_name1(info,"CHAG_RATE_RELA","3029")


        if ref_name2 and ref_name3:
            purchase_list = self.cal_range_str_value(
                    info=info,
                    term_name="CHNG_MIN_TERM",
                    term_value="501",
                    flag_name="CHAG_RATE_RELA",
                    show_name="PERT_VAL_LOW_LIM",
                    value_name="HLD_TERM_UP_LIM",
                    ref_name1=ref_name1,
                    ref_name2=ref_name2,
                    ref_name3=ref_name3)
            redeem_list = self.cal_range_str_value(
                    info=info,
                    term_name="CHNG_MAX_TERM",
                    term_value="6",
                    flag_name="CHAG_RATE_RELA",
                    show_name="PERT_VAL_LOW_LIM",
                    value_name="HLD_TERM_UP_LIM",
                    ref_name1=ref_name1,
                    ref_name2=ref_name2,
                    ref_name3=ref_name3)
            subscrip_fee_list = self.cal_range_str_value(
                    info=info,
                    term_name="CHNG_MAX_TERM",
                    term_value="4",
                    show_name="PERT_VAL_LOW_LIM",
                    flag_name="CHAG_RATE_RELA",
                    value_name="PERT_VAL_UP_LIM",
                    ref_name1=ref_name1,
                    ref_name2=ref_name2,
                    ref_name3=ref_name3)

        info.update(
                {
                    "front_end_purch_fee":purchase_list,
                    "subscrip_fee":subscrip_fee_list,
                    "redeem_fee":redeem_list
                    })
        #print(purchase_list,redeem_list,subscrip_fee_list)
        print(len(purchase_list))
        return info



    def main(self, tradedate=None):

        where_str = self._make_where_time(['a'])
        sql = """
        SELECT
          concat({innerCode},'-',DATE_FORMAT(a.declaredate, '%Y%m%d')) _id,
          {innerCode} innercode,
           a.declaredate declare_date,
           b.FUND_CODE symbol,
           b.FUNDNAME name,
           b.INNER_CODE true_innercode
        from FND_CHAG_RATE a
        left join fnd_gen_info b
        on b.INNER_CODE = a.INNER_CODE
        where a.CHNG_MAX_TERM = 1
        {where_str}
        order by declaredate DESC
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            where_str=where_str
        )

        results = self.mysql.fetchall(sql)

        #import ipdb; ipdb.set_trace()
        results = map(self.cal_run_fee,results)
        results = map(self.cal_purchase_fee,results)
        results = map(self.cal_back_end_purch_fee,results)
        print(results[20:21])
        self.upsert_mongo_data(results)
        self.update_task()


