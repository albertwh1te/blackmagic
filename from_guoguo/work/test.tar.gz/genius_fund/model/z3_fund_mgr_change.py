# coding: utf-8
from model.baseinfo import BaseInfo
import random
import pymongo
from dateutil import relativedelta
from datetime import datetime
import numpy as np

datetimetoint = lambda x:10000*x.year + 100*x.month + x.day
datetimetostr = lambda x:x.strftime("%Y-%m-%d")

#class Z3_FUND_MGR_CHANGE(BaseInfo):

class Main(BaseInfo):
    info = {
        "pri_key": ["_id"]
    }
    def main(self, tradedate=None):

        where_str = self._make_where_time(['a'])
        sql = """
        SELECT
          concat({innerCode},'-',DATE_FORMAT(a.declaredate, '%Y%m%d')) _id,
           a.declaredate declare_date,
          {innerCode} innerCode,
           b.FUND_CODE symbol,
           b.FUNDNAME name,
           a.INDI_NAME manager_name,
           a.POST_DATE post_begin_date,
           a.INDI_ID manager_code,
           b.FUND_ID fund_id,
           b.INNER_CODE search_code
        from FND_MANAGER a
        left join fnd_gen_info b
        on a.FUND_ID = b.FUND_ID
        WHERE a.ISVALID = 1 AND b.ISVALID = 1
        and a.post = 1
        and a.post_status = 1
        and a.post_date is not NUll
        and a.resi_date is not NUll
        {where_str}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            where_str=where_str
        )


        results = self.mysql.fetchall(sql)
        results = map(self.cal_post_end_date,results)
        results = map(self.cal_post_day,results)
        results = map(self.cal_post_return,results)
        results = map(self.final_format,results)

        #import ipdb; ipdb.set_trace()
        # result is a list of dict
        self.upsert_mongo_data(results)
        self.update_task()

    def cal_post_end_date(self,info):
        post_end_date = None
        sql = """
        select resi_date
        from FND_MANAGER
        where RESI_DATE > '{declaredate}'
        and FUND_ID = {fund_id}
        and INDI_ID = {manager_id}
        and POST_STATUS = 2
        and ISVALID = 1
        order by declaredate
        """.format(
                declaredate=datetimetostr(info['declare_date']),
                fund_id = info['fund_id'],
                manager_id = info['manager_code']
                )
        raw = self.mysql.fetchone(sql)
        if raw:
            post_end_date = raw.get('resi_date')
        info.update({'post_end_date':post_end_date})
        return info

    def cal_post_day(self,info):
        start_date = info['post_begin_date'].date()
        end_date = info['post_end_date'].date() if info['post_end_date'] else datetime.now().date()
        during_days = (end_date - start_date).days
        during_str = "{years}年{days}天".format(
                years=during_days/365,
                days=during_days%365
                )
        info.update({'post_day':during_str})
        return info

    def cal_post_return(self,info):
        post_return = 0
        start_date = info['post_begin_date']
        end_date = info['post_end_date'] if info['post_end_date'] else datetime.now()
        sql = """
        select FAC_UNIT_NET
        from ANA_FND_NAV_CALC a
        where a.INNER_CODE = {inner_code}
        and a.ISVALID = 1
        and a.FAC_UNIT_NET is not NULL
        and a.tradedate between '{start_date}'
        and'{end_date}'
        order by a.tradedate desc;
        """.format(
                inner_code = info['search_code'],
                start_date=start_date,
                end_date=end_date
                )
        raw = self.mysql.fetchall(sql)
        if raw:
            end_value = float(raw[0]['FAC_UNIT_NET'])
            start_value = float(raw[-1]['FAC_UNIT_NET'])
            post_return = round(np.true_divide(
                    (end_value-start_value),
                    start_value
                    )*100,2)
        info.update({'post_return':post_return})
        print(info)
        return info

    def final_format(self,info):
        post_end_date = datetimetoint(info['post_end_date']) if info['post_end_date'] else "至今"
        info.update(
                {
                    'post_begin_date':datetimetoint(info['post_begin_date']),
                    'declare_date':datetimetoint(info['declare_date']),
                    'post_end_date':post_end_date
                }
                )
        del info['search_code']
        # i should delete it if it needed
        del info['manager_code']
        del info['fund_id']
        #del info['inner_code']
        #del info['manager_id']
        return info
