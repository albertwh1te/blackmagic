# coding: utf-8
"""
# @Time    : 2017/8/22 
# @Author  : liutao
# @File    : z3_fund_import_event.py
# @Software: PyCharm
# @Descript:Z3_FUND_IMPORT_EVENT
"""
from model.baseinfo import BaseInfo
import random
from datetime import datetime,timedelta
import pymongo
import math


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"]
    }

    def get_nest_data(self, code):
        """
        获取能直接从数据库读取的数据
        :return: 
        """
        sql = """
        select 1 as imp_event   -- 基金经理变更
               ,{d2i[RESI_DATE]} as date
               ,1 as imp_level
           from pgenius.FND_MANAGER a
           join pgenius.FND_GEN_INFO b
            on a.FUND_ID = b.fund_id and b.isvalid = 1
         where a.ISVALID = 1
           and b.fund_code = '{code}'
         union all
         select 3 as imp_event -- 基金转型
               ,{d2i[ESTAB_DATE]} as date
               ,1 as imp_level 
           from pgenius.FND_GEN_INFO b
          where isvalid = 1
            and b.IF_TRAN_FUND=1
            and b.fund_code = '{code}'
         union ALL
         select 5 as imp_event  -- 基金分红
               ,{d2i[ifnull(a.EX_DIV_DATE,a.TRANS_DATE)]} as date
               ,3 as imp_level
           from pgenius.FND_DIV a
           join pgenius.FND_GEN_INFO b
             on a.INNER_CODE = b.INNER_CODE and b.isvalid = 1
           where a.ISVALID = 1 
            and a.DECL_CLS=2
             and b.fund_code = '{code}'
         UNION ALL
         select 6 as imp_event  -- 基金拆分
               ,{d2i[a.SP_DATE]} as date
               ,3 as imp_level
           from pgenius.FND_SPLIT_TRANSL a
           join pgenius.FND_GEN_INFO b
             on a.INNER_CODE = b.INNER_CODE and b.isvalid = 1
         where a.ISVALID = 1
           and a.DECL_CLS=2
           and b.fund_code = '{code}'
        """
        sql = self.format(
            sql,
            code=code
        )
        # print sql
        result = self.mysql.fetchall(sql)
        return result

    def get_track_error_change(self,fund_code):
        """
        4-跟踪误差变动（指数基金）
        :param fund_code: 
        :return: 
        """
        now = datetime.now()
        detra = timedelta(days=1)
        ystday = now - detra

        tmonth = int(datetime.strftime(ystday,"%m"))
        tyear = datetime.strftime(ystday,"%Y")

        if tmonth < 7:
            date = str(tyear)+"-01-01"
            last_date = str(int(tyear)-1) + "07-01"
        else:
            date = str(tyear) + "-07-01"
            last_date = str(tyear) + "01-01"

            te_now = self.get_track_error(
                FUND_CODE=fund_code,
                trade_date= date
            )
            te_last = self.get_track_error(
                FUND_CODE=fund_code,
                trade_date= last_date
            )
            tmp = {}
            if te_now and te_last and te_last <> 0.00:
                tedif  = (te_now.get("track_error") - te_last.get("track_error")) / te_last.get("track_error")-1
                if abs(tedif) >= 0.20:
                    tmp = {
                        "date": int(datetime.strftime(date,"%Y%m%d")),
                        "imp_event":4,
                        "imp_level":2
                    }
            return tmp

    def get_hld_data(self,code):
        """
        从Z3_FUND_ASSET_EXCHR_HLD 获取 7-持仓比例发生大的变动
        :return: 
        """
        data = list(self.mongo.Z3_FUND_ASSET_EXCHR_HLD.find({
            "symbol":code,
            "exchr": {"$gt": 50.0}
            },
            {"end_date":1}
            ))
        # print "ddddddddddddd", data
        result = []
        if not data:
            return

        for row in data:
            tmp = {}
            tmp["imp_event"] = 7
            tmp["imp_level"] = 3
            tmp["date"] = row.get("end_date", None)
            result.append(tmp)
        return result

    def delete(self):

        self.mongo[self.ttable].remove({
            "symbol": self.args["cur_code"]["symbol"]})

    def main(self):
        # print "aaaaaaaaaaaaaaaa"
        sql = """
            select {innerCode} as _id
                   ,FUND_CODE as symbol
                   ,fundsname as name
              from pgenius.FND_GEN_INFO b
             where isvalid = 1
               and ifnull(b.FUND_MATU,'2099-12-31') >= CURDATE()
               and b.ESTAB_DATE is not null
              {base_where}
        """
        sql = self.format(
            sql,
            base_where=self._make_base_where(
                {
                    "time":{"alias_list":["b"]},
                    "onecode":{"alias":"b"}
                 }),
            innerCode=self.make_innerCode_concat()
        )
        # print sql
        data = self.mysql.fetchone(sql)
        # print data
        result = []
        if data:
            data["imp_event_data"] = []
            base_data = self.get_nest_data(data["symbol"])
            if base_data:
                data["imp_event_data"].extend(base_data)

            hld_data = self.get_hld_data(data["symbol"])
            if hld_data:
                data["imp_event_data"].extend(hld_data)

            result.append(data)

        self.upsert_mongo_data(result)