# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_equity.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo
import random

import pymongo


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"],
        "name": u"基金拆分折算表",
    }

    def delete(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.declaredate]},'-',a.sp_type) _id
       
        FROM FND_SPLIT_TRANSL a

          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        WHERE a.ISVALID = 0
        AND b.FUND_STATUS = 1 
        AND a.declaredate IS NOT NULL 
        AND a.sp_type IS NOT NULL 
        {base_where}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            base_where=self._make_base_where(),
        )
        result = self.mysql.fetchall(sql)
        self.delete_mongo_data(result)

    def main(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.declaredate]},'-',a.sp_type) _id,
          {fund_base},
          {d2i[a.sp_date]} sp_date,
          {d2i[a.declaredate]} declare_date,
          a.sp_porp,
          a.sp_type
        FROM FND_SPLIT_TRANSL a

          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        WHERE a.ISVALID = 1 AND b.ISVALID = 1 AND a.DECL_CLS=2
        AND b.fund_status = 1
        {base_where}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            fund_base=self.make_fund_base_where(),
            base_where=self._make_base_where(),
        )
        result = self.mysql.fetchall(sql)
        self.upsert_mongo_data(result)
