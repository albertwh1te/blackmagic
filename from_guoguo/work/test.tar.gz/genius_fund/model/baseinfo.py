# coding: utf-8
"""
# @Time    : 2017/8/16 16:50
# @Author  : Kylin
# @File    : baseinfo.py
# @Software: PyCharm
# @Descript:
"""
from common import get_mysql, curr_time, get_last_update_time, get_mongo, Http

import error_handler
import copy
from utils import tools
import datetime
import re
import traceback
import math


class BaseInfo():
    thread_list = 'get_fund_list'

    def make_innerCode_concat(self, alias='b'):
        return """
        concat({alias}.FUND_CODE, '.', CASE {alias}.TRADE_MKT
           WHEN 1
             THEN 'SZ'
           WHEN 2
             THEN 'SH'
           ELSE 'CW' END)""".format(alias=alias)

    def make_innerCode_where(self, alias='b'):
        return """
            {innerCode} innerCode""".format(innerCode=self.make_innerCode_concat(alias))

    def make_symbol_where(self, alias='b'):
        return """
          {alias}.FUND_CODE symbol""".format(alias=alias)

    def make_fname_where(self, alias='b'):
        return """
          {alias}.FUNDSNAME name""".format(alias=alias)

    def make_fund_base_where(self, alias='b'):
        return """
          {innerCode},{symbol},{fname}""".format(
            innerCode=self.make_innerCode_where(alias),
            symbol=self.make_symbol_where(alias),
            fname=self.make_fname_where(alias),
        )

    def __init__(self, args, config, elogger, slogger):
        self.http = Http(config["http_api"], config=config)
        self.config = config
        self.args = args
        self.mysql = get_mysql(config)
        self.tdatabase = config["mongodb"]["db"]
        self.ttable = args["table_name"]
        self.starttime = args["start_date"]
        self.endtime = args["end_date"]
        self.cur_code = args.get("cur_code", {})
        self.curr_time = args["end_date"] if args["end_date"] else args["curr_time"]
        self.slogger = slogger
        self.elogger = elogger
        self.task_info = self._get_task_info()
        self.limit_codes = args["codes"].split(',') if args["codes"] else []
        self.mongo = get_mongo(config)
        self.time_field = args.get("time_field", "CTIME")
        self.indexes = args.get("indexes").split(",") if args.get("indexes") else []
        self.now = datetime.datetime.now()
        if self.args["delete"]:
            self.delete()

    def main(self):
        pass

    def delete(self):
        pass

    def get_api_getstats(self, sdate, edate, INNER_CODE="", FUND_CODE=""):
        if isinstance(sdate, datetime.datetime):
            sdate = sdate.strftime("%Y-%m-%d")
        if isinstance(edate, datetime.datetime):
            edate = edate.strftime("%Y-%m-%d")

        args = {
            "sdate": sdate,
            "edate": edate
        }
        if INNER_CODE:
            args.update(
                {"code": "INNER_CODE={}".format(INNER_CODE)}
            )
        if FUND_CODE:
            args.update(
                {"code": "FUND_CODE='{}'".format(FUND_CODE)}
            )
        sql = """
          SELECT UNIT_NET_CHNG_PCT/100 pct

          FROM ANA_FND_NAV_CALC
          WHERE ISVALID = 1
                AND {code}
                AND TRADEDATE <= '{edate}'
                AND tradedate > '{sdate}'
                AND UNIT_NET_CHNG_PCT IS NOT NULL
          ORDER BY TRADEDATE
        """.format(**args)
        # print sql
        results = self.mysql.fetchall(sql)
        if len(results) < 2:
            return {"code": 1, "data": {}, "msg": "无数据"}
        pct_list = "|".join(map(lambda i: str(i["pct"]), results))
        # api = "http://%ip%/tp/zhds/getstats?rets={pct_list}&start={sdate}&end={edate}"
        datas = self.http.post(
            url="http://%ip%/tp/zhds/getstats",
            args={
                "rets": pct_list,
                "start": sdate,
                "end": edate,

            }
        )
        return datas

    def get_fund_list(self):
        where_codes = self._make_where_codes()
        sql = """
        SELECT DISTINCT
            concat(b.FUND_CODE, '.', CASE b.TRADE_MKT
                                               WHEN 1
                                                 THEN 'SZ'
                                               WHEN 2
                                                 THEN 'SH'
                                               ELSE 'CW' END) innerCode,    
          b.FUND_CODE  symbol,
          b.FUNDSNAME   name,
          b.fundname,
          b.chi_abbr,
          b.FUND_ID,
          b.INNER_CODE
        FROM fnd_gen_info b
        WHERE b.ISVALID = 1
        AND b.fund_status = 1
        {where_codes}
        ORDER BY FUND_CODE
        """.format(where_codes=where_codes)
        fund_list = self.mysql.fetchall(sql)
        return fund_list

    def get_fundid_list(self):
        where_codes = self._make_where_codes()
        sql = """
        SELECT DISTINCT
          b.FUND_ID,
          b.FUND_CODE,
          b.ESTAB_DATE
        FROM fnd_gen_info b
        WHERE b.ISVALID = 1
        AND b.fund_status = 1
        {where_codes}
        ORDER BY FUND_CODE
        """.format(where_codes=where_codes)
        fund_list = self.mysql.fetchall(sql)
        return fund_list

    def _get_task_info(self):
        """
        获取 任务 信息
        :return:
        """

        if not self.args["update_status"]:
            return {}
        sql = """
            SELECT * FROM pgznty.z3_update_task a WHERE a.TDATABASE=%(tdatabase)s
            AND a.TTABLE = %(ttable)s
        """

        result = self.mysql.fetchone(sql, {"tdatabase": self.tdatabase, 'ttable': self.ttable})
        return result if result else {}

    def _make_where_codes(self, key='fund_code', alias='b'):

        if self.cur_code: return ''
        where_codes = []
        fetch_limit_code = lambda c: where_codes.append("%s.%s='%s'" % (alias, key, c))
        if self.limit_codes:
            map(fetch_limit_code, self.limit_codes)
        where_codes = '' if not where_codes else " AND ({}) ".format(" OR ".join(where_codes))
        return where_codes

    def _make_where_onecode(self, tb_filed='INNER_CODE', dict_filed='INNER_CODE', alias='a'):
        if not self.cur_code:
            return ''
        return """
            AND {alias}.{tb_filed}={dict_filed}
        """.format(
            alias=alias,
            tb_filed=tb_filed,
            dict_filed=("{}" if dict_filed in (['INNER_CODE', 'FUND_ID']) else "'{}'").format(
                self.cur_code[dict_filed]),
        )

    def _make_base_where(self, config={}):
        time_config = config.get("time", {})
        onecode_config = config.get("onecode", {})
        codes_config = config.get("codes", {})
        where_str = self._make_where_time(**time_config)
        where_onecode = self._make_where_onecode(**onecode_config)
        where_codes = self._make_where_codes(**codes_config)
        return """
        
        {where_onecode}
        {where_str}
        {where_codes}
        
        """.format(
            where_str=where_str,
            where_onecode=where_onecode,
            where_codes=where_codes,
        )

    def _make_where_time(self, alias_list=['a']):
        """
        生成sql where条件
        :param alias_list:      list    过滤时间段表别名列表
        :return:
        """
        time_field = self.time_field
        where_str = ""
        less_curr = " %%(alias)s.%s<'%s'" % (time_field, self.curr_time)

        where_last_model = (
            "( %%(alias)s.%s>='%s' AND  %s )" % (time_field, self.task_info[
                "LASTRUNTIME"], less_curr)) if self.task_info.get(
            "LASTRUNTIME",

            None) else less_curr
        where_last_model = (
            "( %%(alias)s.%s>='%s' AND  %s )" % (
                time_field, self.starttime, less_curr)) if self.starttime else where_last_model

        where_list = []

        where_list.append(" AND (%s)" % " OR ".join([where_last_model % {"alias": alias} for alias in alias_list]))

        if where_list:
            where_str = "".join(where_list)
        # print self.task_info,"stock_info"
        return where_str

    def update_task(self):
        # 更新任务信息
        # return
        if not self.args["update_status"]:
            return
        curr_time = self.curr_time
        database = self.tdatabase
        table_name = self.ttable
        update_dict = {

            "LASTRUNTIME": curr_time,
            "NEXTRUNTIME": curr_time,
            "UPDATETIME": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "SDATABASE": '',
            "STABLE": '',
            "TDATABASE": database,
            "TTABLE": table_name,
            "FREQUENCY": 'D',
            "SPACE": 1,
        }
        self.slogger.info(update_dict.values())
        sql = """
            INSERT INTO pgznty.z3_update_task(%(keys)s) VALUES (%(values)s)
            ON DUPLICATE KEY UPDATE %(kwargs)s;
        """ % ({
            "keys": ",".join(update_dict.keys()),
            "values": ",".join([("'%s'" % v) for k, v in update_dict.items()]),
            "kwargs": " , ".join(
                [("%s='%s'" % (k, v)) for k, v in update_dict.items()])
        })
        self.slogger.info(sql)
        self.mysql.execute(sql)

    def format(self, sql, **kwargs):
        arr = re.findall('d2i\[(.*?)\]', sql)
        d2i = {i: "CONVERT(date_format({i}, '%Y%m%d'),SIGNED)".format(i=i) for i in arr}
        return sql.format(d2i=d2i, **kwargs)

    def get_api_gettrend(self, sdate, edate, INNER_CODE="", FUND_CODE=""):
        if isinstance(sdate, datetime.datetime):
            sdate = sdate.strftime("%Y-%m-%d")
        if isinstance(edate, datetime.datetime):
            edate = edate.strftime("%Y-%m-%d")

        if INNER_CODE:
            sql = """
                     SELECT fund_code

                     FROM fnd_gen_info
                     WHERE ISVALID = 1
                          AND fund_status = 1
                           AND INNER_CODE=''
                   """.format(INNER_CODE=INNER_CODE)
            # print sql
            results = self.mysql.fetchone(sql)
            FUND_CODE = results["fund_code"]

        datas = self.http.get(
            url="http://%ip%/tp/zsfnd/gettrend",
            args={
                "code": FUND_CODE,
                "start": sdate,
                "end": edate,

            }
        )
        return datas

    def get_track_error(self, args):
        '''
        跟踪误差
        :param args:
        :return:
        '''
        print args
        sql = """
            SELECT
              CHNG_PCT                   Xi,
              ifnull(b.UNIT_NET_CHNG, 0) Yi
            FROM INDX_MKT a
              LEFT JOIN ANA_FND_NAV_CALC b
                ON a.TRADEDATE = b.TRADEDATE
                   AND b.ISVALID = 1
            WHERE a.INNER_CODE = 106000233
                  AND a.ISVALID = 1
                  AND b.FUND_CODE = '{FUND_CODE}'
                  AND a.TRADEDATE <= '{trade_date}'
                  AND a.TRADEDATE >= date_sub('{trade_date}', INTERVAL 1 YEAR)
        """.format(**args)
        print sql
        print "gggg"
        results = self.mysql.fetchall(sql)
        if not results:
            return {"track_error": None}
        diffs = [i["Xi"] - i["Yi"] for i in results]
        avg = float(sum(diffs)) / float(len(diffs))

        track_error = (math.sqrt(sum(map(lambda i: (i - avg) ** 2, diffs)))) * 100

        return {"track_error": round(track_error, 2)}

    def delete_mongo_data(self, data):
        table_name = self.ttable
        data = copy.deepcopy(data)
        for key, row in enumerate(data):
            result = self.mongo[table_name].remove(row)
            if result["n"]:
                self.slogger.info("delete:{n},filter:{filter}".format(
                    n=result["n"],
                    filter=row
                ))

    def upsert_mongo_data(self, data, filter={}):
        """
        更新数据到mongo
        :param args:        list 来自sys.argv
        :param database:    str 目的表库名
        :param table_name:  str 目的表表名
        :param data:        list 需要更新同步的数据
        :param table_info:  dict 目的表配置信息，来自oonvert_config文件
        :return:
        """
        database = self.tdatabase
        table_name = self.ttable
        table_info = self.info
        args = self.args
        data = copy.deepcopy(data)
        if filter:
            for row in data:
                rs = self.mongo[table_name].update(
                    filter, {"$set": row}, upsert=True, multi=True
                )
            return
        for key, row in enumerate(data):
            tmp = row
            tmp["mtime"] = datetime.datetime.now()
            filter = {i: row[i] for i in table_info["pri_key"]}
            if args["method"] != "insert":

                for i in table_info.get("nesteds", []):
                    filtero = copy.deepcopy(filter)
                    filtero.update({i: None})
                    if self.mongo[table_name].find_one(filtero):
                        self.mongo[table_name].update(filter, {"$set": {i: {}}}, upsert=True)
                try:
                    result = self.mongo[table_name].update(filter, {"$set": tmp}, upsert=True, multi=True)
                    if not result["ok"]: raise Exception("update mongo Error!")

                except Exception, e:
                    self.elogger.error(e.message)
                    traceback.print_exc()
                    # error_func = "handle_{}_update_error".format("Z3_NEWS")
                    # if hasattr(error_handler, error_func):
                    #     error_method = getattr(error_handler, error_func)
                    #     error_method(e, filter, tmp, self.mongo, table_name)
            else:
                data[key] = tmp
        if args["method"] == "insert" and data:
            conn = tools.mongo_cursor(self.config)
            db = conn[database]
            self.mongo[table_name].insert_many(data)
