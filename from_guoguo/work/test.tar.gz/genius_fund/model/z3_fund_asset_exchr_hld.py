# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo


class Main(BaseInfo):
    info = {

        "pri_key": ["_id"],
        "name": u"资产配置/换手率/规模变动/持有人比例表",
    }

    def delete(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.enddate]}) _id
          FROM FND_FIN_IDX a
          LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        WHERE a.ISVALID = 0
        AND b.FUND_STATUS = 1
        AND a.ENDDATE IS NOT NULL 
        {base_where}

        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            base_where=self._make_base_where(),
        )
        result = self.mysql.fetchall(sql)
        self.delete_mongo_data(result)

    def main(self):
        sql = """
        SELECT
          concat({innerCode},'-',{d2i[a.enddate]}) _id,
          {fund_base},
          {d2i[a.enddate]} end_date,
          a.EQUITY  net_value,
          d.org_hld_pct,
          d.indi_hld_pct,
          d.STAFF_HLD_PCT+d.MANA_HLD_PCT inner_hld_pct,
          (CASE WHEN e.BUY_COST > e.SALE_INCM
              THEN e.SALE_INCM
                    ELSE e.BUY_COST END) volume,
          a.INNER_CODE
        FROM FND_FIN_IDX a
        LEFT JOIN fnd_gen_info b
            ON a.INNER_CODE = b.INNER_CODE
        LEFT JOIN FND_INDI_ORG_HOLD d
            ON d.INNER_CODE = a.INNER_CODE
            AND d.ENDDATE = a.ENDDATE
            AND d.SOURCE = a.RPT_SRC  
        LEFT JOIN FND_STK_COST e
            ON a.ENDDATE = e.ENDDATE
               AND b.FUND_ID = e.FUND_ID
               AND e.RPT_SRC = (
            SELECT max(RPT_SRC)
            FROM FND_STK_COST f
            WHERE e.FUND_ID = f.FUND_ID AND e.ENDDATE = f.ENDDATE
                  AND f.ISVALID = 1
          )
        WHERE
          a.ISVALID = 1 AND b.ISVALID = 1 AND b.FUND_STATUS = 1 AND d.ISVALID = 1
        AND b.fund_status = 1
          AND a.RPT_SRC = (
        
            SELECT max(RPT_SRC)
            FROM FND_FIN_IDX c
            WHERE c.INNER_CODE = a.INNER_CODE AND c.ENDDATE = a.ENDDATE
                  AND c.ISVALID = 1
          )
          {base_where}
        """
        sql = self.format(
            sql,
            innerCode=self.make_innerCode_concat(),
            fund_base=self.make_fund_base_where(),
            base_where=self._make_base_where(),
        )
        print sql
        result = self.mysql.fetchall(sql)
        sql_model = """
          SELECT avg(EQUITY) equity
            FROM FND_FIN_IDX g
            WHERE g.ISVALID = 1
                  AND g.INNER_CODE={INNER_CODE}
                  AND g.ENDDATE <= '{end_date}'
                  AND g.RPT_SRC = (
              SELECT max(RPT_SRC)
              FROM FND_FIN_IDX h
              WHERE g.INNER_CODE = h.INNER_CODE AND g.ENDDATE = h.ENDDATE
            )
            ORDER BY enddate DESC
            LIMIT 2

        """
        for item in result:
            r = self.mysql.fetchone(sql_model.format(**item))
            item["exchr"] = round(item["volume"] / r["equity"], 2) if r and item["volume"] else None
            del item["INNER_CODE"]
            del item["volume"]

        self.upsert_mongo_data(result)
