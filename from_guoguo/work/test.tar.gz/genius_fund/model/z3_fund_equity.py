# coding: utf-8
"""
# @Time    : 2017/8/16 16:46
# @Author  : Kylin
# @File    : z3_fnd_split_transl.py
# @Software: PyCharm
# @Descript:
"""
from model.baseinfo import BaseInfo
from common import int_date, pre_date, pre_date_month, pre_date_year, float_round
import copy
import pymongo
import datetime
import time


class Main(BaseInfo):
    index_config = {
        "fund_type": ["get_fund_type", ],  # 基金类型
        "trade_cost": ["get_iss_enddate", "get_trade_cost", ],  # 交易成本
        "trade_status": ["get_trade_status", ],  # 交易状态
        "fund_scale": ["get_fund_scale", ],  # 基金规模
        "large_purch_limit": ["get_large_purch_limit", ],  # 大额申购限制
        "fund_fav": ["get_fund_fav", ],  # 投资风格
        "buying_point": ["get_point", ],  # 机会期
        "selling_point": ["get_point", ],  # 风险期
        "manager_duration_max": ["get_manager_duration_max", ],  # 最长任职时间
        "track_error": ["get_track_error", ],  # 跟踪误差
        "static_yield": ["get_static_yield", ],  # 静态收益
        "closed_period": ["get_closed_period", ],  # 封闭期
        "tenthou_unit_incm": ["get_tenthou_unit_incm", ],  # 万份收益
        "year_yld": ["get_tenthou_unit_incm", ],  # 七日年化收益率
        "chg_pct": ["get_chg_pct", ],  # 涨跌幅
        "unit_net": ["get_unit_net", ],  # 单位净值
        "accum_net": ["get_unit_net", ],  # 累计净值
        "iss_startdate": ["get_iss_startdate", ],  # 认购开始日
        "iss_enddate": ["get_iss_enddate", ],  # 认购截止日
        "fund_manager": ["get_fund_manager", ],  # 基金经理
        "fund_org_manage": ["get_fund_org_manage", ],  # 管理人
        "fund_org_trustee": ["get_fund_org_trustee", ],  # 托管人
        "purch_status": ["get_purch_status", ],  # 申购状态
        "redeem_status": ["get_redeem_status", ],  # 赎回状态
        "jrj_fund_rank": ["get_jrj_fund_rank", ],  # JRJ基金评价
        "volat_estab": ["get_volat_estab", ],  # 成立以来波动率

    }
    info = {

        "pri_key": ["_id"],
        "name": u"基金大宽表",
    }

    def get_fund_scale(self, args):
        if type(args.get("fund_type", None)) == type(None):
            return {"fund_scale": None}
        sql = """
        SELECT ROUND(CASE
               WHEN {fund_type} IN (3, 6)
                 THEN (CASE WHEN b.ENDDATE > a.ENDDATE
                   THEN b.NAV
                       ELSE a.MERGE_EQUITY END)
               ELSE (CASE WHEN c.ENDDATE > a.ENDDATE
                 THEN c.NAV
                     ELSE a.MERGE_EQUITY END)
               END,2) fund_scale
        FROM FND_FIN_IDX a
          LEFT JOIN FND_MNY_INCM b ON a.INNER_CODE = b.INNER_CODE
                                      AND b.ISVALID = 1
                                      AND b.NAV IS NOT NULL
                                      AND b.ENDDATE <= curdate()
          LEFT JOIN FND_NET_VAL c ON a.INNER_CODE = c.INNER_CODE
                                     AND c.ISVALID = 1
                                     AND c.NAV IS NOT NULL
                                     AND c.ENDDATE <= curdate()
        
        WHERE
          MERGE_EQUITY IS NOT NULL AND
          a.ENDDATE >= DATE_SUB('{trade_date}', INTERVAL 200 DAY) AND
          a.ENDDATE <= '{trade_date}' AND
          a.ISVALID = 1 AND
          a.INNER_CODE = {INNER_CODE}
        
        ORDER BY a.ENDDATE DESC , b.ENDDATE DESC , c.ENDDATE DESC
        LIMIT 1

        """.format(**args)
        print sql
        result = self.mysql.fetchone(sql)

        return result if result else {"fund_scale": None}

    def get_fund_org_trustee(self, args):
        sql = """
            SELECT ORG_NAME fund_org_trustee FROM
              FND_RELA_ORG
            WHERE INNER_CODE={INNER_CODE}
            AND ORG_TYPE = 3 AND ISVALID=1
        """.format(**self.cur_code)
        result = self.mysql.fetchone(sql)

        return result if result else {"fund_org_trustee": None}

    def get_fund_org_manage(self, args):
        sql = """
            SELECT ORG_NAME fund_org_manage FROM
              FND_RELA_ORG
            WHERE INNER_CODE={INNER_CODE}
            AND ORG_TYPE = 2 AND ISVALID=1
        """.format(**self.cur_code)
        result = self.mysql.fetchone(sql)

        return result if result else {"get_fund_org_manage": None}

    def get_fund_base(self, cur_code={}):
        cur_code = cur_code if cur_code else self.cur_code
        # print self.cur_code
        sql = """
        SELECT DISTINCT
            concat(b.FUND_CODE, '.', CASE b.TRADE_MKT
                                               WHEN 1
                                                 THEN 'SZ'
                                               WHEN 2
                                                 THEN 'SH'
                                               ELSE 'CW' END) _id,    
          b.FUND_CODE  symbol,
          b.FUNDSNAME   name,
          b.fundname,
          b.chi_abbr,
          b.INNER_CODE,
          {d2i[b.estab_date]} estab_date,
          {d2i[b.fund_matu]} fund_matu,
          CASE b.TRADE_MKT WHEN 1 THEN 'SZ' WHEN
          2 THEN 'SH' ELSE 'CW' END exchange
        FROM fnd_gen_info b
        WHERE b.ISVALID = 1
        AND FUND_CODE='{symbol}'
        AND b.FUND_STATUS=1
        AND INNER_CODE={INNER_CODE}
        ORDER BY FUND_CODE

        """
        # print self.cur_code
        sql = self.format(sql, **cur_code)

        result = self.mysql.fetchone(sql)

        return result

    def get_fund_base_simple(self, cur_code={}):
        cur_code = cur_code if cur_code else self.cur_code
        # print self.cur_code
        sql = """
        SELECT DISTINCT
            concat(b.FUND_CODE, '.', CASE b.TRADE_MKT
                                               WHEN 1
                                                 THEN 'SZ'
                                               WHEN 2
                                                 THEN 'SH'
                                               ELSE 'CW' END) _id,    
          b.FUND_CODE  symbol,
          b.FUNDSNAME   name
        FROM fnd_gen_info b
        WHERE b.ISVALID = 1
        AND b.FUND_STATUS=1
        AND FUND_CODE='{symbol}'
        ORDER BY FUND_CODE LIMIT 1

        """
        sql = self.format(sql, **cur_code)

        result = self.mysql.fetchone(sql)

        return result

    def get_max_tradedate(self, basedate=pre_date()):
        sql = """
            SELECT ENDDATE
            FROM PUB_EXCHANGE_CALENDAR a
            WHERE MKT_TYPE = 1 AND ENDDATE <= '{}' AND OPEN_CLOSE = 1
            ORDER BY ENDDATE DESC
            LIMIT 1;
        """.format(basedate)
        result = self.mysql.fetchone(sql)

        return result

    def get_fund_manager(self, args):
        sql = """
        SELECT group_concat(DISTINCT INDI_NAME) fund_manager
        FROM FND_MANAGER a
          LEFT JOIN fnd_gen_info b ON a.FUND_ID = b.FUND_ID
        WHERE a.ISVALID = 1 AND b.ISVALID = 1
              AND post_status = 1 AND post = 1
              AND b.FUND_CODE = '{symbol}'
              AND b.FUND_STATUS=1
        ORDER BY RESI_DATE DESC 
        """

        result = self.mysql.fetchone(sql)

        return result if result else {"fund_manager": None}

    def get_unit_net(self, args):

        result = {}
        if args["fund_type"] not in [3, 6]:
            sql = """
                SELECT
                  {d2i[a.ENDDATE]} end_date,
                  unit_net,
                  accum_net
                FROM FND_NET_VAL a
                WHERE ISVALID = 1
                      AND INNER_CODE = {INNER_CODE}
                      AND ENDDATE <= '{trade_date}'
                ORDER BY ENDDATE DESC
                LIMIT 1
            """
            sql = self.format(
                sql,
                **args
            )

            result = self.mysql.fetchone(sql)

        return result if result else {
            "unit_net": None,
            "accum_net": None,
        }

    def get_static_yield(self, args):
        result = {}
        if args["fund_type"] in [3, 6]:
            sql = """
            SELECT
              ROUND(SUM(tenthou_unit_incm) / 2 * 365, 2) static_yield
            FROM (SELECT
                    tenthou_unit_incm,
                    enddate,
                    INNER_CODE,
                    weekofyear(ENDDATE)
                  FROM FND_MNY_INCM a
                  WHERE ISVALID = 1
                        AND INNER_CODE = {INNER_CODE}
                        AND ENDDATE <= '{trade_date}'
                        AND dayofweek(ENDDATE) IN (1, 7)
                  ORDER BY ENDDATE DESC
                  LIMIT 2) a
            GROUP BY weekofyear(ENDDATE)
            ORDER BY weekofyear(ENDDATE) DESC
            LIMIT 1
            """
            sql = self.format(
                sql,
                **args
            )

            result = self.mysql.fetchone(sql)

        return result if result else {"static_yield": None}

    def get_tenthou_unit_incm(self, args):
        sql = """
        SELECT
          {d2i[a.ENDDATE]} end_date,
          round(tenthou_unit_incm,4) tenthou_unit_incm,
          round(year_yld,4) year_yld
        FROM FND_MNY_INCM a
        WHERE ISVALID = 1
              AND INNER_CODE = {INNER_CODE}
              AND ENDDATE <= '{trade_date}'
        ORDER BY ENDDATE DESC, VOL_GRD
        LIMIT 1
        """
        sql = self.format(
            sql,
            **args
        )

        result = self.mysql.fetchone(sql)

        return result if result else {
            "tenthou_unit_incm": None,
            "year_yld": None
        }

    def get_manager_duration_max(self, args):
        res1 = list(self.mongo.Z3_FUND_MGR_CURRENT.find(
            {"symbol": self.cur_code["symbol"]},
            {"post_day": 1, "_id": 0}
        ).sort("post_day", pymongo.DESCENDING).limit(1))
        res2 = list(self.mongo.Z3_FUND_MGR_HISTORY.find(
            {"symbol": self.cur_code["symbol"]},
            {"post_day": 1, "_id": 0}
        ).sort("post_day", pymongo.DESCENDING).limit(1))
        if not res1 and not res2:
            return {"manager_duration_max": None}
        else:

            post_day1 = res1[0]["post_day"] if res1 else 0
            post_day2 = res2[0]["post_day"] if res2 else 0
            return {"manager_duration_max": max([post_day1, post_day2])}

    def get_closed_period(self, args):
        result = {}
        if args["fund_type"] == 6:
            sql = """
            
            select CLOSE_PERI closed_period from FND_FIN_CLOSE_PERI
            WHERE ISVALID=1 and INNER_CODE={INNER_CODE}
            """.format(**self.cur_code)
            result = self.mysql.fetchone(sql)

        return {"closed_period": result["closed_period"]} if result else {"closed_period": None}

    def get_purch_status(self, args):
        sql = """
        SELECT CHNG_TYPE purch_status
        FROM FND_STATUS_CHNG 
        WHERE ISVALID=1
        AND INNER_CODE={INNER_CODE}
        AND EVENT_TYPE=3
        AND ENDDATE<='{trade_date}'
        ORDER BY ENDDATE DESC LIMIT 1
        """
        sql = self.format(
            sql,
            **args
        )
        print sql
        result = self.mysql.fetchone(sql)

        return result if result else {"purch_status": None}

    def get_redeem_status(self, args):
        sql = """
        SELECT CHNG_TYPE redeem_status
        FROM FND_STATUS_CHNG 
        WHERE ISVALID=1
        AND INNER_CODE={INNER_CODE}
        AND EVENT_TYPE=4
        AND ENDDATE<='{trade_date}'
        ORDER BY ENDDATE DESC LIMIT 1
        """
        sql = self.format(
            sql,
            **args
        )

        result = self.mysql.fetchone(sql)

        return result if result else {"redeem_status": None}

    def get_trade_status(self, args):
        """
        交易状态
        :return:
        """
        print "xxxxxxxxxxx"
        res1 = self.mongo.Z3_FUND_BUY_INFO_ORG.find_one(
            {"innerCode": self.cur_code["innerCode"]},
            {"status": 1, "_id": 0}
        )
        return {"trade_status": int(res1["status"])} if res1 else {"trade_status": None}

    def get_trade_cost(self, args):
        """
        交易成本
        :return:
        """
        cost1 = 0
        cost2 = 0
        cost3 = 0
        cost4 = 0
        res1 = self.mongo.Z3_FUND_BUY_INFO_FEE_RATE.find_one(
            {"_id": self.cur_code["innerCode"]},
            {
                "_id": 0,
                "manage_fee": 1,
                "trustee_fee": 1,
                "sales_service_charge": 1,
                "redeem_fee": 1,
                "front_end_purch_fee": 1,
                "subscrip_fee": 1,
            }
        )
        if res1:
            if res1["manage_fee"]:

                manage_fee = float(res1["manage_fee"].replace("%", "")) if res1["manage_fee"].find('%') > 0 else 0
            else:
                manage_fee = 0
            if res1["trustee_fee"]:
                trustee_fee = float(res1["trustee_fee"].replace("%", "")) if res1["trustee_fee"].find('%') > 0 else 0

            else:
                trustee_fee = 0

            if res1["sales_service_charge"]:
                sales_service_charge = float(res1["sales_service_charge"].replace("%", "")) if res1[
                                                                                                   "sales_service_charge"].find(
                    '%') > 0 else 0

            else:
                sales_service_charge = 0
            cost1 = sum([manage_fee,
                         trustee_fee,
                         sales_service_charge])

            cost2 = sum([(0, float(i["fee_rate"].replace("%", "")))[i["fee_rate"].find("%") or None] for i in
                         res1["redeem_fee"]])

            cost3 = sum(
                [(0, float(i["fee_rate"].replace("%", "")))[i["fee_rate"].find("%") or None] for i in
                 res1["front_end_purch_fee"]])

            cost4 = sum([float(i["fee_rate"].replace("%", "")) if i["fee_rate"].find("%") > 0 else 0 for i in
                         res1["subscrip_fee"]])

        if args["iss_enddate"] > int_date(pre_date()):
            trade_cost = round(cost1 + cost2 + cost3, 2)
            return {"trade_cost": trade_cost}
        else:
            trade_cost = round(cost1 + cost2 + cost4, 2)
            return {"trade_cost": trade_cost}

        return {"trade_cost": None}

    def get_fund_type(self, args):
        """
        基金类型
        :param args:
        :return:
        """
        sql = """
        SELECT ifnull(FND_TYPE,-1) fund_type,
         CASE WHEN FND_TYPE IN (4,12) THEN 1
         WHEN FND_TYPE IN (11) THEN 2
         WHEN FND_TYPE IN (5) THEN 3
         WHEN FND_TYPE IN (7) THEN 4
         WHEN FND_TYPE IN (3,6) THEN 5 END perform_bench
         FROM ANA_FND_GR_CALC_SPEC
        WHERE ISVALID=1 AND FUND_CODE='{symbol}'
        AND ENDDATE<= '{trade_date}'
        ORDER BY ENDDATE DESC LIMIT 1
        """
        sql = self.format(
            sql,
            **args
        )
        print sql

        result = self.mysql.fetchone(sql)

        return result if result else {
            "fund_type": None,
            "perform_bench": None,
        }

    def get_chg_pct(self, args):
        result = {}
        if args["fund_type"] not in [3, 6]:
            sql = """
            SELECT 
              UNIT_NET_CHNG_PCT chg_pct 
            FROM ANA_FND_NAV_CALC
            WHERE ISVALID = 1
                  AND INNER_CODE = {INNER_CODE}
                  AND TRADEDATE <= '{trade_date}'
             ORDER BY TRADEDATE DESC LIMIT 1
            
            """
            sql = self.format(
                sql,
                **args
            )
            # print sql
            result = self.mysql.fetchone(sql)

        return result if result else {"chg_pct": None}

    def get_iss_startdate(self, args):
        sql = """
        SELECT
          {d2i[ISS_STARTDATE]} iss_startdate,
          1 tag
        FROM FND_OEF_ISS
        WHERE INNER_CODE = {INNER_CODE}
        UNION
        SELECT
          {d2i[ISS_STARTDATE]} iss_startdate,
          2 tag
        FROM FND_CEF_ISS
        WHERE INNER_CODE = {INNER_CODE}
        ORDER BY tag
        LIMIT 1

        """
        sql = self.format(
            sql,
            **self.cur_code
        )

        # print sql
        result = self.mysql.fetchone(sql)

        return {
            "iss_startdate": result["iss_startdate"]
        } if result else {
            "iss_startdate": None
        }

    def get_iss_enddate(self, args):
        sql = """
        SELECT
          {d2i[ISS_ENDDATE]} iss_enddate,
          1 tag
        FROM FND_OEF_ISS
        WHERE INNER_CODE = {INNER_CODE}
        UNION
        SELECT
          {d2i[ISS_ENDDATE]} iss_enddate,
          2 tag
        FROM FND_CEF_ISS
        WHERE INNER_CODE = {INNER_CODE}
        ORDER BY tag
        LIMIT 1

        """
        sql = self.format(
            sql,
            **self.cur_code
        )
        # print sql
        result = self.mysql.fetchone(sql)

        return {
            "iss_enddate": result["iss_enddate"]
        } if result else {
            "iss_enddate": None
        }

    def get_yield(self, args):

        sql = """
        SELECT
          OMTH_GR          fund_yield_month,
          QUA_GR           fund_yield_3month,
          hlfyr_GR         fund_yield_6month,
          YTD_GR           fund_yield_year_sofar,
          oyr_GR           fund_yield_year,
          OYR_GR_RANK      fund_yield_year_rank,
          OYR_GR_TT        fund_num,
          tyr_GR           fund_yield_2year,
          thyr_GR          fund_yield_3year,
          FIVYR_GR         fund_yield_5year,
          ESTA_GR          fund_yield_estab,
          OMTH_GR_avg      fund_yield_month_avg,
          QUA_GR_avg       fund_yield_3month_avg,
          hlfyr_GR_avg     fund_yield_6month_avg,
          YTD_GR_AVG       fund_yield_year_sofar_avg,
          oyr_GR_avg       fund_yield_year_avg,
          (CASE WHEN OMTH_GR_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_month_istop100,
          (CASE WHEN QUA_GR_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_3month_istop100,
          (CASE WHEN HLFYR_GR_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_6month_istop100,
          (CASE WHEN YTD_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_year_sofar_istop100,
          (CASE WHEN OYR_GR_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_year_istop100,
          (CASE WHEN TYR_GR_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_2year_istop100,
          (CASE WHEN THYR_GR_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_3year_istop100,
          (CASE WHEN FIVYR_GR_RANK <= 100
            THEN TRUE
           ELSE FALSE END) fund_yield_5year_istop100

        FROM ANA_FND_GR_CALC_SPEC
        WHERE ISVALID = 1
              AND FUND_CODE = '{symbol}'
              AND ENDDATE<='{trade_date}'
        ORDER BY ENDDATE DESC
        LIMIT 1
        """.format(**args)
        # print sql
        result = self.mysql.fetchone(sql, bool_fields=[

            "fund_yield_month_istop100",
            "fund_yield_3month_istop100",
            "fund_yield_6month_istop100",
            "fund_yield_year_sofar_istop100",
            "fund_yield_year_istop100",
            "fund_yield_2year_istop100",
            "fund_yield_3year_istop100",
            "fund_yield_5year_istop100",
        ])
        return result if result else{
            "fund_yield_month": None,
            "fund_yield_3month": None,
            "fund_yield_6month": None,
            "fund_yield_year_sofar": None,
            "fund_yield_year": None,
            "fund_yield_year_rank": None,
            "fund_num": None,
            "fund_yield_2year": None,
            "fund_yield_3year": None,
            "fund_yield_5year": None,
            "fund_yield_month_avg": None,
            "fund_yield_3month_avg": None,
            "fund_yield_6month_avg": None,
            "fund_yield_year_sofar_avg": None,
            "fund_yield_year_avg": None,
            "fund_yield_month_istop100": None,
            "fund_yield_3month_istop100": None,
            "fund_yield_6month_istop100": None,
            "fund_yield_year_sofar_istop100": None,
            "fund_yield_year_istop100": None,
            "fund_yield_2year_istop100": None,
            "fund_yield_3year_istop100": None,
            "fund_yield_5year_istop100": None,
        }

    def get_drawdown(self, args):

        sql = """
        SELECT
          DRAWDOWN_3_MON max_drawdown_3month,
          DRAWDOWN_6_MON max_drawdown_6month,
          DRAWDOWN_TYEAR max_drawdown_year_sofar,
          DRAWDOWN_1_YEAR max_drawdown_year,
          DRAWDOWN_2_YEAR max_drawdown_2year,
          DRAWDOWN_3_YEAR max_drawdown_3year

        FROM ANA_FND_NAV_CALC
        WHERE ISVALID = 1
              AND FUND_CODE = '{symbol}'
              AND TRADEDATE<='{trade_date}'
        ORDER BY TRADEDATE DESC
        LIMIT 1
        """.format(**args)
        print sql
        result = self.mysql.fetchone(sql)
        return result if result else{
            "max_drawdown_3month": None,
            "max_drawdown_6month": None,
            "max_drawdown_year_sofar": None,
            "max_drawdown_year": None,
            "max_drawdown_2year": None,
            "max_drawdown_3year": None,
        }

    def get_volat_estab(self, args):
        sql = """
        SELECT STD_BASE volat_estab
        FROM ANA_FND_NAV_CALC
        WHERE ISVALID = 1
              AND FUND_CODE = '{symbol}'
              AND TRADEDATE<='{trade_date}'
        ORDER BY TRADEDATE DESC LIMIT 1
        """.format(**args)
        result = self.mysql.fetchone(sql)

        return result if result else {"volat_estab": None}

    def get_large_purch_limit(self, args):

        sql = """
        SELECT VAL_LIMIT large_purch_limit
        FROM FND_STATUS_CHNG a
        WHERE
          ISVALID = 1 AND
          a.INNER_CODE = {INNER_CODE} AND
          a.ENDDATE <= '{trade_date}'  AND EVENT_TYPE=1
        ORDER BY CHANGE_DATE DESC 
        LIMIT 1
        """.format(**args)
        print sql
        result = self.mysql.fetchone(sql)

        return result if result else {"large_purch_limit": None}

    def get_jrj_fund_rank(self, args):
        url = "http://%ip%/tp/zsfnd/gettrend"
        args = {
            "code": self.cur_code["symbol"],
            "end": self.now.strftime("%Y-%m-%d"),
            "start": pre_date(365).strftime("%Y-%m-%d")
        }
        data = self.http.get(url, args=args)
        # print data
        if data["code"]:
            return {"score": None}
        data = data.get("data", {})
        return {"score": data.get("score", None)}

    def get_fund_fav(self, args):
        url = "http://%ip%/tp/zsfnd/getstyle"
        args = {
            "code": self.cur_code["symbol"],
            "date": self.now.strftime("%Y-%m-%d")
        }
        data = self.http.get(url, args=args)
        # print type(data), len(data)
        # print data.keys()
        if data["code"]:
            return {}
        data = data["data"][0] if len(data.get("data", [])) else {}
        for k, v in enumerate([
            "Beta0", "Beta1", "Beta2", "Beta3",
            "Beta4", "Beta5", "Beta6", "Beta7", "Beta8"]):
            if data.get(v, False):
                return {"fund_fav": k}
        return {"fund_fav": None}

    def handle_year_fndval(self, fund_type):
        edate = pre_date()
        first_day = time.strptime("%s-01-01" % edate.strftime("%Y"), "%Y-%m-%d")

        sdate_list = [
            pre_date_year(-1, edate),
            pre_date_year(-2, edate),
            pre_date_year(-3, edate),
            pre_date_year(-4, edate),
            pre_date_year(-5, edate),
            datetime.datetime(*first_day[0:6]),  # 今年以来
        ]
        fund_list = list(self.mongo["Z3_FUND_EQUITY"].find(
            {
                "fund_type": fund_type
            },
            {
                "_id": 1,
                "symbol": 1
            }
        ))
        tmp = {}
        year_dict = {0: "", 1: "1", 2: "2", 3: "3", 4: "4", 5: ""}
        year_after = {5: "_sofar"}
        for fund in fund_list:
            print fund
            for index, sdate in enumerate(sdate_list):
                str_year = year_dict[index]
                str_year_after = year_after.get(index, "")
                result = self.get_api_getstats(
                    FUND_CODE=fund["symbol"],
                    sdate=sdate,
                    edate=edate

                )

                if not result["code"]:
                    data = result["data"]

                    if index <= 2:
                        # 获取超额收益率
                        rsl2 = self.get_api_gettrend(
                            FUND_CODE=fund["symbol"],
                            sdate=sdate,
                            edate=edate

                        )
                        if rsl2["code"]:
                            data.update({"excess": None})
                        else:
                            data.update({"excess": rsl2["data"]["excess"]})
                else:
                    if index <= 2:
                        fund["year_yield_{}year".format(str_year)] = None
                        fund["ex_yield_{}year".format(str_year)] = None
                        fund["year_yield_{}year_avg".format(str_year)] = None
                        fund["ex_yield_{}year_avg".format(str_year)] = None
                        fund["year_yield_{}year_istop100".format(str_year)] = None
                        fund["ex_yield_{}year_istop100".format(str_year)] = None
                    fund["max_drawdown_{}year{}".format(str_year, str_year_after)] = None
                    fund["sharpe_ratio_{}year{}".format(str_year, str_year_after)] = None
                    fund["max_drawdown_{}year{}_avg".format(str_year, str_year_after)] = None
                    fund["sharpe_ratio_{}year{}_avg".format(str_year, str_year_after)] = None
                    fund["max_drawdown_{}year{}_istop100".format(str_year, str_year_after)] = None
                    fund["sharpe_ratio_{}year{}_istop100".format(str_year, str_year_after)] = None
                    continue
                if index <= 2:
                    fund["year_yield_{}year".format(str_year)] = data["annual_ret"]
                    fund["ex_yield{}year".format(str_year)] = data["excess"]

                    tmp.setdefault("year_yield_{}year".format(str_year), [])
                    tmp.setdefault("ex_yield{}year".format(str_year), [])
                    tmp["year_yield_{}year".format(str_year)].append(
                        {"v": float_round(data["annual_ret"], default=0.0), "c": fund["_id"]})
                    tmp["ex_yield{}year".format(str_year)].append(
                        {"v": float_round(data["excess"], default=0.0), "c": fund["_id"]})
                fund["max_drawdown_{}year{}".format(str_year, str_year_after)] = data["max_dd"]
                fund["sharpe_ratio_{}year{}".format(str_year, str_year_after)] = data["sharpe_ratio"]
                tmp.setdefault("max_drawdown_{}year{}".format(str_year, str_year_after), [])
                tmp["max_drawdown_{}year{}".format(str_year, str_year_after)].append(
                    {"v": float_round(data["max_dd"], default=0.0), "c": fund["_id"]})
                tmp.setdefault("sharpe_ratio_{}year{}".format(str_year, str_year_after), [])
                tmp["sharpe_ratio_{}year{}".format(str_year, str_year_after)].append(
                    {"v": float_round(data["sharpe_ratio"], default=0.0), "c": fund["_id"]})
        month_avg = {}
        month_100 = {}
        for key, value in tmp.items():
            # 求value的均值
            month_avg["{}_avg".format(key)] = round(sum([i["v"] for i in value]) / len(value), 2)
            # 对value做排序
            sorted_value = sorted(value, key=lambda i: i["v"], reverse=True)

            month_100["{}_istop100".format(key)] = [i["c"] for i in sorted_value[:100]]
        if tmp:
            # 更新均值
            filter_avg = {
                "fund_type": fund_type,
            }
            self.upsert_mongo_data([month_avg, ], filter_avg)
            # 更新top值
            for k, v in month_100.items():
                filter_100 = {
                    "_id": {
                        "$in": v
                    }
                }
                filter_not_100 = {
                    "_id": {
                        "$nin": v
                    }
                }
                self.upsert_mongo_data([{k: True}, ], filter_100)
                self.upsert_mongo_data([{k: False}, ], filter_not_100)

        # 更新其他值
        self.upsert_mongo_data(fund_list)

    def handle_month_fndval(self, fund_type):

        edate = pre_date()
        sdate_list = [
            pre_date_month(-1, edate),
            pre_date_month(-3, edate),
            pre_date_month(-6, edate),
        ]
        fund_list = list(self.mongo["Z3_FUND_EQUITY"].find(
            {
                "fund_type": fund_type
            },
            {
                "_id": 1,
                "symbol": 1
            }
        ))
        tmp = {}
        month_dict = {0: "", 1: "3", 2: "6"}
        for fund in fund_list:
            print fund
            for index, sdate in enumerate(sdate_list):
                str_month = month_dict[index]
                result = self.get_api_getstats(
                    FUND_CODE=fund["symbol"],
                    sdate=sdate,
                    edate=edate

                )
                # print result

                if not result["code"]:
                    data = result["data"]
                else:
                    fund["max_drawdown_{}month".format(str_month)] = None
                    fund["sharpe_ratio_{}month".format(str_month)] = None
                    fund["max_drawdown_{}month_avg".format(str_month)] = None
                    fund["sharpe_ratio_{}month_avg".format(str_month)] = None
                    fund["max_drawdown_{}month_istop100".format(str_month)] = None
                    fund["sharpe_ratio_{}month_istop100".format(str_month)] = None
                    continue
                fund["max_drawdown_{}month".format(str_month)] = data["max_dd"]
                fund["sharpe_ratio_{}month".format(str_month)] = data["sharpe_ratio"]
                tmp.setdefault("max_drawdown_{}month".format(str_month), [])
                tmp["max_drawdown_{}month".format(str_month)].append(
                    {"v": float_round(data["max_dd"], default=0.0), "c": fund["_id"]})
                tmp.setdefault("sharpe_ratio_{}month".format(str_month), [])
                tmp["sharpe_ratio_{}month".format(str_month)].append(
                    {"v": float_round(data["sharpe_ratio"], default=0.0), "c": fund["_id"]})
        month_avg = {}
        month_100 = {}
        for key, value in tmp.items():
            # 求value的均值
            month_avg["{}_avg".format(key)] = round(sum([i["v"] for i in value]) / len(value), 2)
            # 对value做排序
            sorted_value = sorted(value, key=lambda i: i["v"], reverse=True)

            month_100["{}_istop100".format(key)] = [i["c"] for i in sorted_value[:100]]
        if tmp:
            # 更新均值
            filter_avg = {
                "fund_type": fund_type,
            }
            self.upsert_mongo_data([month_avg, ], filter_avg)
            # 更新top值
            for k, v in month_100.items():
                filter_100 = {
                    "_id": {
                        "$in": v
                    }
                }
                filter_not_100 = {
                    "_id": {
                        "$nin": v
                    }
                }
                self.upsert_mongo_data([{k: True}, ], filter_100)
                self.upsert_mongo_data([{k: False}, ], filter_not_100)

        # 更新其他值
        self.upsert_mongo_data(fund_list)

    def handle_estab_fndval(self, fund_type, estab_date_info):

        edate = pre_date()
        sdate_list = [
            None,
        ]
        fund_list = list(self.mongo["Z3_FUND_EQUITY"].find(
            {
                "fund_type": fund_type
            },
            {
                "_id": 1,
                "symbol": 1
            }
        ))
        for fund in fund_list:
            print fund

            for index, sdate in enumerate(sdate_list):
                sdate = estab_date_info.get(fund["symbol"], None)
                if not sdate: continue
                result = self.get_api_getstats(
                    FUND_CODE=fund["symbol"],
                    sdate=sdate,
                    edate=edate

                )

                # 获取超额收益率
                result2 = self.get_api_gettrend(
                    FUND_CODE=fund["symbol"],
                    sdate=sdate,
                    edate=edate

                )

                data = result["data"] if not result["code"] else {}
                data.update(result2["data"] if not result2["code"] else {})
                fund["max_drawdown_estab"] = data.get("drawdown", None)
                fund["sharpe_ratio_estab"] = data.get("sharpe", None)
                fund["ex_yield_estab"] = data.get("excess", None)
                fund["year_yield_estab"] = data.get("return", None)
        # 更新其他值
        self.upsert_mongo_data(fund_list)

    def get_months_fndval(self):

        # 获取所有基金fund_code
        # 分1月，3月，6月获取年化收益率、夏普比率、最大回撤率
        # 根据fund_type进行分组，计算同类平均，istop100
        fund_type_list = self.mongo["Z3_FUND_EQUITY"].distinct("fund_type")
        print fund_type_list
        # for enddate in enddate_list:

        for fund_type in fund_type_list:
            if not fund_type: continue
            self.handle_month_fndval(fund_type)
            # break

    def get_years_fndval(self):

        # 获取所有基金fund_code
        # 分1月，3月，6月获取年化收益率、夏普比率、最大回撤率
        # 根据fund_type进行分组，计算同类平均，istop100
        fund_type_list = self.mongo["Z3_FUND_EQUITY"].distinct("fund_type")
        print fund_type_list
        # for enddate in enddate_list:
        fund_list = self.get_fundid_list()
        estab_date_info = {i["FUND_CODE"]: i["ESTAB_DATE"] for i in fund_list}

        for fund_type in fund_type_list:
            if not fund_type: continue
            self.handle_year_fndval(fund_type)
            self.handle_estab_fndval(fund_type, estab_date_info)

    def get_fndval(self):
        """
        yield,drawdown,ratio

        :return:
        """
        # 股票信息
        fund_info = {i["symbol"]: i for i in self.get_fund_list()}
        # 基金类型
        fund_types = [3, 4, 5, 6, 7, 11, 12]
        for f_type in fund_types:
            # 获取各基金类型的数据
            ss = datetime.datetime.now()
            datas = self.http.get(
                url="http://%ip%/tp/zsfnd/getfndval?type={type}".format(type=f_type))
            ee = datetime.datetime.now()
            # print datas

            if datas["code"]:
                continue
            datas = datas["data"]
            print "耗时", (ee - ss).seconds
            tmp_list = {}
            sum_return = {}
            sum_drawdown = {}
            sum_excess = {}
            sum_sharpe = {}
            for item in datas:
                code = item["fnd_code"]
                cycle = item["cycle"]
                tmp_list.setdefault(code, {})
                sum_return.setdefault(cycle, [])
                sum_drawdown.setdefault(cycle, [])
                sum_sharpe.setdefault(cycle, [])
                sum_excess.setdefault(cycle, [])
                tmp_list[code].update(
                    {"_id": self.get_fund_base_simple({"symbol": code})["_id"]}
                )

                if cycle in [1, 2, 3, 4, 5]:
                    str_cycle = "" if cycle == 1 else cycle
                    # 近1年
                    try:
                        tmp_list[code].update(
                            {
                                "year_yield_{}year".format(str_cycle): float_round(item["return"], 2),
                                "ex_yield_{}year".format(str_cycle): float_round(item["excess"], 2),
                                "max_drawdown_{}year".format(str_cycle): float_round(item["drawdown"], 2),
                                "sharpe_ratio_{}year".format(str_cycle): float_round(item["sharpe"], 2),
                                "year_yield_{}year_istop100".format(str_cycle): (
                                    False if float(item["return_rank"]) > 100 else True) if
                                item["return_rank"] else None,
                                "ex_yield_{}year_istop100".format(str_cycle): (
                                    False if float(item["excess_rank"]) > 100 else True) if
                                item[
                                    "excess_rank"] else None,
                                "max_drawdown_{}year_istop100".format(str_cycle): (
                                    False if float(item["drawdown_rank"]) > 100 else True) if item[
                                    "drawdown_rank"] else None,
                                "sharpe_ratio_{}year_istop100".format(str_cycle): (
                                    False if float(item["sharpe_rank"]) > 100 else True) if
                                item["sharpe_rank"] else None
                            }
                        )
                    except:
                        print "error", item

                sum_return[cycle].append(float_round(item["return"], default=0.0))
                sum_drawdown[cycle].append(float_round(item["drawdown"], default=0.0))
                sum_sharpe[cycle].append(float_round(item["sharpe"], default=0.0))
                sum_excess[cycle].append(float_round(item["excess"], default=0.0))

            avg_tmp_filter = {"fund_type": f_type}
            avg_tmp = {}
            for c in [1, 2, 3, 4, 5]:
                # year_yield_year_avg
                year_avg = round(sum(sum_return[c]) / float(len(sum_return[c])), 2)
                drawdown_avg = round(sum(sum_drawdown[c]) / float(len(sum_drawdown[c])), 2)
                sharpe_avg = round(sum(sum_sharpe[c]) / float(len(sum_sharpe[c])), 2)
                excess_avg = round(sum(sum_excess[c]) / float(len(sum_excess[c])), 2)
                if c == 1:
                    avg_tmp["year_yield_year_avg"] = year_avg
                    avg_tmp["max_drawdown_year_avg"] = drawdown_avg
                    avg_tmp["sharpe_ratio_year_avg"] = sharpe_avg
                    avg_tmp["ex_yield_year_avg"] = excess_avg
                elif c == 2:
                    avg_tmp["year_yield_2year_avg"] = year_avg
                    avg_tmp["max_drawdown_2year_avg"] = drawdown_avg
                    avg_tmp["sharpe_ratio_2year_avg"] = sharpe_avg
                    avg_tmp["ex_yield_2year_avg"] = excess_avg
                elif c == 3:
                    avg_tmp["year_yield_3year_avg"] = year_avg
                    avg_tmp["max_drawdown_3year_avg"] = drawdown_avg
                    avg_tmp["sharpe_ratio_3year_avg"] = sharpe_avg
                    avg_tmp["ex_yield_3year_avg"] = excess_avg
                elif c == 4:
                    avg_tmp["year_yield_4year_avg"] = year_avg
                    avg_tmp["max_drawdown_4year_avg"] = drawdown_avg
                    avg_tmp["sharpe_ratio_4year_avg"] = sharpe_avg
                    avg_tmp["ex_yield_4year_avg"] = excess_avg
                elif c == 5:
                    avg_tmp["year_yield_5year_avg"] = year_avg
                    avg_tmp["max_drawdown_5year_avg"] = drawdown_avg
                    avg_tmp["sharpe_ratio_5year_avg"] = sharpe_avg
                    avg_tmp["ex_yield_5year_avg"] = excess_avg
            self.upsert_mongo_data(tmp_list.values())
            self.upsert_mongo_data([avg_tmp, ], avg_tmp_filter)

    def test_aa(self):
        print self.cur_code
        print self.get_api_getstats(
            self.cur_code["INNER_CODE"],
            '2016-12-01',
            '2017-01-01'
        )

    def get_point(self, args):
        url = "http://%ip%/tp/zsfnd/getreason"
        args = {
            "code": self.cur_code["symbol"]
        }
        data = self.http.get(url, args=args)
        if data["code"]:
            return {
                "buying_point": None,
                "selling_point": None
            }
        data = data.get("data", {})
        return {
            "buying_point": 1 if data.get("flag", None) == 1 else 0,
            "selling_point": 1 if data.get("flag", None) == -1 else 0
        }

    def get_methods(self):
        methods = []
        for i in self.indexes:
            methods.extend(self.index_config.get(i, []))
        return list(set(methods))

    def main(self):
        # 最大交易日
        if 'base' in self.indexes:
            self.indexes = self.indexes[1:]

        basedate = int_date(pre_date())
        basedate = self.args["start_date"] if self.args["start_date"] else basedate

        max_tradedate = self.get_max_tradedate(basedate)
        tmp = self.get_fund_base()
        tmp["trade_date"] = int_date(max_tradedate["ENDDATE"])

        default_args = {
            "symbol": tmp["symbol"],
            "INNER_CODE": tmp["INNER_CODE"],
            "trade_date": tmp["trade_date"],
        }
        tmp.update(self.get_fund_type(default_args))

        type_args = {

            "fund_type": tmp["fund_type"],
        }
        type_args.update(default_args)
        r = self.mongo.Z3_FUND_EQUITY.find_one(
            {"_id": self.cur_code["innerCode"]},
            {"iss_enddate": 1, "_id": 0}
        )
        iss_enddate = r["iss_enddate"] if r else int_date(pre_date())
        cost_args = {
            "iss_enddate": iss_enddate
        }
        cost_args.update(default_args)
        other_args = {
            "get_fund_scale": {
                "INNER_CODE": tmp["INNER_CODE"],
                "fund_type": tmp["fund_type"],
                "trade_date": tmp["trade_date"],
            },
            "get_track_error": {

                "FUND_CODE": tmp["symbol"],
                "trade_date": tmp["trade_date"],
            },
            "get_closed_period": {
                "fund_type": tmp["fund_type"],
            },
            "get_static_yield": type_args,
            "get_tenthou_unit_incm": type_args,
            "get_chg_pct": type_args,
            "get_unit_net": type_args,
            "get_trade_cost": cost_args,

        }
        if not self.indexes:
            self.main_all(default_args, other_args, tmp)
            return
        methods = self.get_methods()
        # print methods
        print "ccc"
        for m in methods:
            # print tmp
            method = getattr(self, m)
            res = method(other_args.get(m, default_args))
            print res
            tmp.update(res)
        print "aaa"
        del tmp["INNER_CODE"]
        self.upsert_mongo_data([tmp, ])

        print "bbb"

    def main_all(self, args, other_args, tmp):
        tmp.update(self.get_trade_status(args))
        tmp.update(self.get_fund_scale(other_args.get("get_fund_scale")))
        tmp.update(self.get_fund_fav(args))
        tmp.update(self.get_manager_duration_max(args))
        tmp.update(self.get_closed_period(other_args.get("get_closed_period")))
        tmp.update(self.get_static_yield(other_args.get("get_static_yield")))
        tmp.update(self.get_tenthou_unit_incm(other_args.get("get_tenthou_unit_incm")))
        tmp.update(self.get_chg_pct(other_args.get("get_chg_pct")))
        tmp.update(self.get_unit_net(other_args.get("get_unit_net")))
        tmp.update(self.get_track_error(other_args.get("get_track_error")))
        tmp.update(self.get_point(args))
        tmp.update(self.get_large_purch_limit(args))
        tmp.update(self.get_iss_startdate(args))
        tmp.update(self.get_iss_enddate(args))
        tmp.update(self.get_fund_manager(args))
        tmp.update(self.get_fund_org_manage(args))
        tmp.update(self.get_fund_org_trustee(args))
        tmp.update(self.get_purch_status(args))
        tmp.update(self.get_redeem_status(args))
        tmp.update(self.get_jrj_fund_rank(args))
        tmp.update(self.get_volat_estab(args))
        tmp.update(self.get_yield(args))
        tmp.update(self.get_drawdown(args))
        tmp.update(self.get_trade_cost(other_args.get("get_trade_cost")))

        del tmp["INNER_CODE"]
        self.upsert_mongo_data([tmp, ])
