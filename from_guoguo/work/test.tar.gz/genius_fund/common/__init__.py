# coding:utf-8
# Created by qinlin.liu at 2017/3/14

import sys
import os
import decimal
import types
import time
import datetime
import logging
from config import config
from utils.mysqlutil import Mysql
from logging.handlers import TimedRotatingFileHandler
import uuid
import urllib, urllib2
import socket
import threadpool
import traceback
from utils.tools import mongo_cursor
import json
import redis
import hashlib
import copy
from dateutil.relativedelta import *


def get_mac_address():
    mac = uuid.UUID(int=uuid.getnode()).hex[-12:]
    return ":".join([mac[e:e + 2] for e in range(0, 11, 2)])


def get_base_info(keys=["pid", "addr"]):
    myname = socket.getfqdn(socket.gethostname())
    myaddr = socket.gethostbyname(myname)
    return {k: v for k, v in {
        "name": myname,
        "addr": myaddr,
        "mac": get_mac_address(),
        "pid": os.getpid()
    }.items() if k in keys}


def _change_data(v):
    if type(v) == decimal.Decimal:
        return float(v)
    elif type(v) == types.UnicodeType:
        return v
        # elif type(v) == datetime:
        #     return datetime.utcfromtimestamp(time.mktime(v.timetuple()))
        # return v.strftime('%Y-%m-%d %H:%M:%S')
        # return datetime.utcfromtimestamp(time.mktime(v))
        # da\tetime.utc
    return v


def format_data(data):
    for i, row in enumerate(data):
        for k in row:
            row[k] = _change_data(row[k])
        data[i] = row


def get_mongo(config):
    conn = mongo_cursor(config)
    db = conn[config["mongodb"]["db"]]
    return db


def get_mysql(config):
    while True:
        try:
            return Mysql(config["mysql"])
        except Exception, e:
            print e
            time.sleep(5)


def curr_time():
    return datetime.datetime.now()


def pre_date(days=0, base_day=None):
    if base_day:
        base_day = base_day.strftime('%Y-%m-%d')
    else:
        base_day = time.strftime('%Y-%m-%d', time.localtime(time.time()))
    return datetime.datetime.strptime(base_day,
                                      '%Y-%m-%d') - datetime.timedelta(days=days)


def pre_date_month(months=0, base_day=datetime.datetime.now()):
    return base_day + relativedelta(months=months)


def pre_date_year(years=0, base_day=datetime.datetime.now()):
    return base_day + relativedelta(years=years)


class SMTPSSLHandler(logging.handlers.SMTPHandler):
    def emit(self, record):
        """
              Emit a record.

              Format the record and send it to the specified addressees.
              """
        try:
            import smtplib
            from email.utils import formatdate
            port = self.mailport
            if not port:
                port = smtplib.SMTP_PORT
            smtp = smtplib.SMTP_SSL(self.mailhost, port, timeout=self._timeout)
            msg = self.format(record)
            if isinstance(msg, unicode):
                msg = msg.encode('gbk')

            msg = "From: %s\r\nTo: %s\r\nSubject: %s\r\nDate: %s\r\n\r\n%s" % (
                self.fromaddr,
                ",".join(self.toaddrs),
                self.getSubject(record),
                formatdate(), msg)
            if self.username:
                if self.secure is not None:
                    smtp.ehlo()
                    smtp.starttls(*self.secure)
                    smtp.ehlo()
                smtp.login(self.username, self.password)
            smtp.sendmail(self.fromaddr, self.toaddrs, msg)
            smtp.quit()
        except (KeyboardInterrupt, SystemExit):
            raise Exception("ERRRROR")
        except:
            self.handleError(record)


def get_args():
    import argparse

    parser = argparse.ArgumentParser(description='Short sample app')

    # 开始时间
    parser.add_argument('-s', dest='start_date', default=None,
                        help=u'开始时间')
    # 结束时间
    parser.add_argument('-e', dest='end_date', default=None,
                        help=u'结束时间')
    # 目的表名
    parser.add_argument('-t', dest='table_name', default='',
                        help=u'mongo目的表名')
    # 股票代码 逗号分隔
    parser.add_argument('-c', dest='codes', default='',
                        help=u'指定代码，多个用,分隔')
    # 分支develop,test,product
    parser.add_argument('-b', dest='branch', default='test',
                        help=u'分支，eg:test,develop,默认test')
    # mongo更新方式,update,insert
    parser.add_argument('-m', dest='method', default='update',
                        help=u'mongo更新方式,update,insert 默认update')
    # 时间字段名
    parser.add_argument('-tf', dest='time_field', default='CTIME',
                        help=u'-s,-e对应的mysql时间字段 默认CTIME')
    # 更新状态表
    parser.add_argument('-us', dest='update_status', default=1, type=int,
                        help=u'是否更新update_task记录 跑历史数据是要置为0，默认为1')
    # 删除isvalid=0的数据
    parser.add_argument('-d', dest='delete', default=1, type=int,
                        help=u'是否删除isvalid=0的数据 跑历史数据是要置为0，默认为1')
    # 是否多线程跑数据，每个线程会传递一个fund_id,默认为0
    parser.add_argument('-mh', dest='multithread', default=0, type=int,
                        help=u'是否多线程跑数据，每个线程会传递一个fund_id,默认为0')
    # 指标列表
    parser.add_argument('-i', dest='indexes', default='',
                        help=u'指标列表,多个用逗号分割，默认为""')

    results = parser.parse_args()

    keys = filter(lambda x: x.find("_") != 0, dir(results))

    result = dict(map(lambda x: (x, getattr(results, x)), keys))
    return dict(map(lambda x: (x, getattr(results, x)), keys))


def init_logger(log_path, logfile, email_config):
    """
    实例化日志处理类
    :return:
    """
    # 创建目录
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    success_handler = TimedRotatingFileHandler(
        filename='{}{}.log'.format(log_path, logfile),
        when='D',
        interval=1,
        backupCount=14)
    success_handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    success_handler.setFormatter(formatter)
    success_logger = logging.getLogger('success')
    success_logger.addHandler(success_handler)

    # error_handler = TimedRotatingFileHandler(
    #     filename='{}{}.error'.format(log_path, logfile),
    #     when='D',
    #     interval=1,
    #     backupCount=14)
    # error_handler.setLevel(logging.ERROR)
    # formatter = logging.Formatter('%(message)s')
    # error_handler.setFormatter(formatter)
    # error_logger = logging.getLogger('success')
    # error_logger.addHandler(success_handler)

    #
    error_handler = SMTPSSLHandler(**email_config)
    error_handler.setLevel(logging.ERROR)
    formatter = logging.Formatter("{},{}\n%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s\n%(message)s".format(
        str(get_base_info()), logfile))
    error_handler.setFormatter(formatter)
    error_logger = logging.getLogger('error')
    error_logger.addHandler(error_handler)

    return success_logger, error_logger


args = get_args()

logfile = args["table_name"]
slogger, elogger = init_logger(
    config[args["branch"]]["log_path"], logfile, config[args["branch"]]["email"])


# slogger, elogger = None, None
def find_model(args, baseinfo):
    method = args["controller"]
    model = "model.{}".format(method)
    # model = __import__(model, globals(), locals(), [method.upper()])
    model = __import__(model, globals(), locals(), 'Main')
    # Model = Model[model.upper()]
    # return getattr(model, method.upper())
    return getattr(model, 'Main')


def create_model(args, baseinfo):
    Model = find_model(args, baseinfo)
    return Model(args, baseinfo, elogger, slogger)


def int_date(some_date):
    return int(some_date.strftime("%Y%m%d"))


def handle_thread_error(request, exc_info):
    '''
    threadpool 异常回掉方法
    :param request:
    :param exc_info:
    :return:
    '''
    """Default exception handler callback function.

    This just prints the exception info via ``traceback.print_exception``.

    """
    # traceback.print_exc(*exc_info)
    # print str(request)
    # print traceback.format_exception(*exc_info)
    # return
    elogger.error('{}\n{}'.format(str(request), ''.join(traceback.format_exception(*exc_info))))


def make_threads(thread_nums, callable, args_list, ):
    pool = threadpool.ThreadPool(thread_nums)
    requests = threadpool.makeRequests(callable, args_list, exc_callback=handle_thread_error)
    [pool.putRequest(req) for req in requests]
    pool.wait()


def get_last_update_time(curr_time, info={}):
    """
    生成 预测任务执行时间
    :param curr_time:   datetimestr 当前时间
    :param info:        dict 定时信息
    :return:
    """
    prequency = info.get("FREQUENCY", "H")
    space = info.get("SPACE", 1)
    if prequency == "H":
        interval_time = "HOUR"
    elif prequency == "D":
        interval_time = "DAY"
    elif prequency == "W":
        interval_time = "WEEK"
    elif prequency == "M":
        interval_time = "MONTH"
    elif prequency == "Q":
        interval_time = "QUARTER"
    elif prequency == "Y":
        interval_time = "YEAR"
    else:
        interval_time = "HOUR"

    # return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return "DATE_ADD('%s', INTERVAL %s %s)" % (curr_time, space, interval_time)


def base_thread_method(c, args, config):
    args = copy.deepcopy(args)
    args["cur_code"] = c
    Model = create_model(args, config)
    Model.main()


def checkMain(args, config, baseinfo, thread_method=None):
    startss = datetime.datetime.now()
    print "start:", startss
    if args["multithread"]:
        thread_method = thread_method if thread_method else base_thread_method
        Class = find_model(args, config)
        thread_list = getattr(Class, 'thread_list')
        thread_list = getattr(baseinfo, thread_list)
        some_list = thread_list()  # get_stock_list 方法可以参数
        args_list = []
        for c in some_list:
            # for c in innercode_list:
            baseinfo.slogger.info(c)
            args_list.append((None, {
                'c': c,
                'args': args,
                'config': config
            }))

        make_threads(10, thread_method, args_list)
    else:

        Model = create_model(args, config)
        Model.main()

    baseinfo.update_task()
    end = datetime.datetime.now()
    print "end:", end
    print "耗时", (end - startss).microseconds

    # elogger.error("{}==耗时:{}".format(args["table_name"], (end - startss).microseconds))


def digit(string):
    try:
        return float(string)
    except:
        return 0.0


def get_redis(config):
    return redis.StrictRedis(**config["redis"])


def float_round(value, num=-1, default=None):
    try:
        if num < 0:
            return float(value) if value else default
        else:
            return round(float(value), num) if value else default
    except:
        return default


class Http():
    def __init__(self, ip="", j2d=True, config={}):
        self.ip = ip
        self.j2d = j2d
        self.redis = get_redis(config)
        self.redis_key = config["redis_key"]

    def get(self, url="", args={}, cache=True, ex=3600 * 24):
        return self._req(url, args, post=False)

    def post(self, url="", args={}, cache=True, ex=3600 * 24):
        return self._req(url, args, post=True)

    def md5_key(self, url):
        m = hashlib.md5()
        m.update(url)
        return m.hexdigest()

    def make_key(self, url="", args=""):
        url = url if not args else "{}?{}".format(url, args)
        if len(url) > 1024:
            url = self.md5_key(url)
        return "{}{}".format(self.redis_key, url)

    def _req(self, url="", args={}, post=False, ex=3600 * 24):

        url = url.replace("%ip%", self.ip)
        data = urllib.urlencode(args)
        key = self.make_key(url, data)
        cache_datas = self.redis.get(key)
        cache_datas = None

        if not cache_datas:
            if post:
                response = urllib.urlopen(url, data)
            else:
                url = ("%s?%s" % (url, data)) if data else url
                # print url
                response = urllib.urlopen(url)
            cache_datas = response.read()
            self.redis.set(key, cache_datas, ex=ex)
        if self.j2d:
            try:
                cache_datas = json.loads(cache_datas)
            except:
                elogger.error("{}返回数据异常解析异常\n{}".format(url, cache_datas))
                return {}
        return cache_datas
