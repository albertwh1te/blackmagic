# coding: utf-8
"""
# @Time    : 2017/8/29 23:23
# @Author  : Kylin
# @File    : s.py.py
# @Software: PyCharm
# @Descript:
"""

# coding:utf-8

import os
model = "python /data/App/genius_fund/main.py -t Z3_FUND_DIV -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product"
model = "python /data/App/genius_fund/main.py -t Z3_FUND_SPLIT_TRANSL -s {}0101 -e {}0101 -tf declaredate -us 0 -d 0 -m insert -b product"
model = "python /data/App/genius_fund/main.py -t Z3_FUND_MNY_INCM -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product"
model = "python /data/App/genius_fund/main.py -t Z3_FUND_ASSET_EXCHR_HLD -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product"
model = "python /data/App/genius_fund/main.py -t Z3_FUND_ASSET_CONF_DTL -s {}0101 -e {}0101 -tf enddate -us 0 -d 0 -m insert -b product"
# model = "python /data/App/genius_fund/main.py -t QP_MAC_PRODUCT_OUTPT -s {} -e {} -tf rpt_year -us 0 -m insert -b product"
for i in range(23):
        end = 2017-i
        start = 2017-i-1
        print "开始{},{}",start,end
        command = model.format(start,end)
        print command
        os.system(command)
        print "完成{},{}",start,end
